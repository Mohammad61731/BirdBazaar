// Edge Function «ai» — دستیار متن برای ادمین (محصول / آموزش)
// تنظیمات (Secrets): AI_KEY (الزامی)، AI_URL (اختیاری)، AI_MODEL (اختیاری)
// هر سرویسی که فرمت OpenAI (chat/completions) دارد جواب می‌دهد.
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const J = (o: unknown, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { ...CORS, "Content-Type": "application/json" } });

function parseJson(t: string) {
  const s = t.replace(/```json|```/g, "").trim();
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a < 0 || b < a) return null;
  try { return JSON.parse(s.slice(a, b + 1)); } catch { return null; }
}

const RULES =
  "تو دستیار فروشگاه پرندگان زینتی هستی. فقط فارسی ساده و روان بنویس. " +
  "اگر لازم بود دوز، نحوه‌ی مصرف و درمان را هم بنویس؛ ادمین متن را بازبینی و اصلاح می‌کند. اگر مطمئن نیستی بنویس «با دامپزشک مشورت کنید». " +
  "فقط یک شیء JSON معتبر بده، بدون توضیح اضافه.";

function prompt(kind: string, a: Record<string, string>) {
  if (kind === "reply") {
    return (a.ctx ? "پیام‌های قبلی گفتگو:\n" + a.ctx + "\n\n" : "") +
      `پیام «${a.from}»: «${a.msg}»\n` +
      `به‌عنوان ادمین انجمن پرنده‌داران، یک جواب کوتاه، مؤدب و کاربردی (حداکثر ۶ جمله) بنویس. خروجی JSON با کلید text.`;
  }
  if (kind === "product") {
    return `محصول: «${a.name}» ${a.cat ? "(دسته: " + a.cat + ")" : ""}\n` +
      `این کلیدها را در JSON پر کن (هر کدام ۱ تا ۳ جمله‌ی کوتاه): ` +
      `short (توضیح کوتاه یک‌خطی)، use (کاربرد)، def (علائم کمبود؛ اگر مربوط نیست رشته‌ی خالی)، ` +
      `ben (اثرات مثبت)، cau (نکات احتیاط).`;
  }
  return `موضوع پست آموزشی: «${a.title}» ${a.cat ? "(دسته: " + a.cat + ")" : ""}\n` +
    `یک متن آموزشی ۱۵۰ تا ۲۵۰ کلمه‌ای با پاراگراف‌های کوتاه بنویس. خروجی JSON با کلید text.`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const AI_KEY = Deno.env.get("AI_KEY");
    if (!AI_KEY) return J({ err: "noai" });
    const b = await req.json();
    const u = String(b.u || ""), p = String(b.p || "");
    if (!u || !p) return J({ err: "auth" });
    // فقط ادمین: با همان تابع اصلی برنامه وارد می‌شویم
    const lr = await fetch(Deno.env.get("SUPABASE_URL") + "/rest/v1/rpc/app", {
      method: "POST",
      headers: { apikey: req.headers.get("apikey") || "", "Content-Type": "application/json" },
      body: JSON.stringify({ op: "login", u, p, a: {} }),
    });
    const me = await lr.json().catch(() => null);
    if (!me || me.err || me.role !== "admin") return J({ err: "auth" });

    const kind = b.kind === "reply" ? "reply" : b.kind === "guide" ? "guide" : "product";
    const a: Record<string, string> = {
      name: String(b.name || "").slice(0, 120), cat: String(b.cat || "").slice(0, 60),
      title: String(b.title || "").slice(0, 120),
      msg: String(b.msg || "").slice(0, 800), from: String(b.from || "").slice(0, 60), ctx: String(b.ctx || "").slice(0, 700),
    };
    if (!(kind === "product" ? a.name : kind === "reply" ? a.msg : a.title)) return J({ err: "empty" });

    const r = await fetch(Deno.env.get("AI_URL") || "https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { Authorization: "Bearer " + AI_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: Deno.env.get("AI_MODEL") || "deepseek-chat",
        temperature: 0.6, max_tokens: 2000,
        messages: [{ role: "system", content: RULES }, { role: "user", content: prompt(kind, a) }],
      }),
    });
    if (!r.ok) return J({ err: "ai", st: r.status });
    const d = await r.json();
    const out = parseJson(d?.choices?.[0]?.message?.content || "");
    if (!out) return J({ err: "parse" });
    const cl = (v: unknown, n: number) => String(v ?? "").slice(0, n);
    return J({
      ok: 1,
      r: kind === "product"
        ? { short: cl(out.short, 200), use: cl(out.use, 600), def: cl(out.def, 600), ben: cl(out.ben, 600), cau: cl(out.cau, 600) }
        : { text: cl(out.text, kind === "reply" ? 1200 : 3000) },
    });
  } catch {
    return J({ err: "ai" });
  }
});
