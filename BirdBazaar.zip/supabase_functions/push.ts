// Edge Function «push» — فرستادن اعلان گوشی با Firebase (FCM HTTP v1)
// Secrets لازم: FCM_SA (کل فایل JSON کلید Service Account فایربیس)، PUSH_KEY (یک رشته‌ی دلخواه؛ همان که در SQL گذاشته‌ای)
// SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY را خود Supabase می‌دهد. «Verify JWT» این تابع باید خاموش باشد.
declare const Deno: any;
const J = (o: unknown, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

let tok = { v: "", exp: 0 };
const b64u = (b: ArrayBuffer | string) => {
  const u = typeof b === "string" ? new TextEncoder().encode(b) : new Uint8Array(b);
  let s = ""; u.forEach((c) => (s += String.fromCharCode(c)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};

async function accessToken(sa: any): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (tok.v && tok.exp - 60 > now) return tok.v;
  const head = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64u(JSON.stringify({
    iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600,
  }));
  const pem = String(sa.private_key).replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(head + "." + claim));
  const jwt = head + "." + claim + "." + b64u(sig);
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + jwt,
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("token");
  tok = { v: j.access_token, exp: now + (j.expires_in || 3000) };
  return tok.v;
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return J({ err: "method" }, 405);
  const pk = Deno.env.get("PUSH_KEY") || "";
  if (!pk || req.headers.get("x-push-key") !== pk) return J({ err: "denied" }, 401);
  let b: any; try { b = await req.json(); } catch { return J({ err: "json" }, 400); }
  const users: string[] = Array.isArray(b.users) ? b.users.map(String).slice(0, 500) : [];
  if (!users.length) return J({ ok: 1, n: 0 });
  let sa: any; try { sa = JSON.parse(Deno.env.get("FCM_SA") || ""); } catch { return J({ err: "no_sa" }, 500); }
  const base = Deno.env.get("SUPABASE_URL"), sk = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const H = { apikey: sk, Authorization: "Bearer " + sk };
  const q = users.map((u) => '"' + u.replace(/["\\]/g, "") + '"').join(",");
  const tr = await fetch(`${base}/rest/v1/f_push?select=token&uname=in.(${encodeURIComponent(q)})&limit=1000`, { headers: H });
  const toks: string[] = ((await tr.json()) || []).map((x: any) => x.token).filter(Boolean);
  if (!toks.length) return J({ ok: 1, n: 0 });
  const at = await accessToken(sa);
  let sent = 0;
  await Promise.all(toks.map(async (t) => {
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST", headers: { Authorization: "Bearer " + at, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token: t, notification: { title: String(b.title || "بازارچه پرندگان").slice(0, 80), body: String(b.body || "").slice(0, 160) }, android: { priority: "HIGH" } } }),
    });
    if (r.ok) { sent++; return; }
    if (r.status === 404 || r.status === 400) {
      await fetch(`${base}/rest/v1/f_push?token=eq.${encodeURIComponent(t)}`, { method: "DELETE", headers: H });
    }
  }));
  return J({ ok: 1, n: sent });
});
