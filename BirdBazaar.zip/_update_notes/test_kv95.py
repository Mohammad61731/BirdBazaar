# تست 1.9.95: عیب‌یابی کلیدهای سروری
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]
            st={'dl':1,'lt':1,'md':1,'qb':1,'sto':0}; cnt={'xget':0,'sget':0}; mode={'lie':0,'off':0}
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                d=json.loads(route.request.post_data or '{}'); op=d.get('op',''); body=BODY
                if op=='xset':
                    if not mode['lie']: st[d['a']['k']]=d['a']['v']
                    body={'ok':1,'f':dict(st,**{d['a']['k']:d['a']['v']})}
                if op=='xget': cnt['xget']+=1; body={'ok':1,'f':dict(st)}
                if op=='sget': cnt['sget']+=1; body={'ok':1,'off':mode['off'],'days':1,'rep':0,'dev':0,'tot':{},'hr':[],'sec':[],'ops':[],'bt':[],'byday':[],'ver':[]}
                if op=='sset': mode['off']=1 if d['a'].get('off')=='1' else 0; body={'ok':1,'off':mode['off']}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='sw';render()"); await pg.wait_for_timeout(300)
            chk(t+'APPV 1.9.x', await pg.evaluate("/^1\\.9\\.\\d+$/.test(APPV)"))
            chk(t+'5 xf diag buttons', await pg.evaluate("document.querySelectorAll('[data-a=kv_chk]').length")>=5)
            n=cnt['xget']; await pg.click('[data-a=kv_chk][data-v=dl]'); await pg.wait_for_timeout(500)
            chk(t+'one xget on tap', cnt['xget']-n==1)
            chk(t+'ok message', '✅ سرور هم اعمال کرد' in await pg.evaluate("document.body.innerText"))
            # toggle -> auto check
            n=cnt['xget']; await pg.click('[data-a=xf_tog][data-v=qb]'); await pg.wait_for_timeout(900)
            chk(t+'auto check after toggle (1 xget)', cnt['xget']-n>=1 and await pg.evaluate("/اعمال کرد/.test(KV.r.qb)"))
            # server did not persist -> mismatch
            mode['lie']=1; await pg.click('[data-a=xf_tog][data-v=md]'); await pg.wait_for_timeout(900)
            chk(t+'mismatch flagged', await pg.evaluate("/^❌/.test(KV.r.md)") and await pg.evaluate("xf('md')===true"))
            mode['lie']=0
            # stats
            await pg.click('[data-a=st_tog]') if await pg.query_selector('[data-a=st_tog]') else None
            await pg.wait_for_timeout(300)
            n=cnt['sget']; await pg.evaluate("kvAll()"); await pg.wait_for_timeout(900)
            chk(t+'kvAll uses 1 sget', cnt['sget']-n==1 and await pg.evaluate("/^✅/.test(KV.r.x)"))
            # non-admin: no buttons, no calls
            await pg.evaluate("S.role='user';S.pm=[];render()"); await pg.wait_for_timeout(200)
            n=cnt['xget']; await pg.evaluate("kvChk('dl')"); await pg.wait_for_timeout(300)
            chk(t+'non-admin: no request', cnt['xget']==n and await pg.evaluate("kvBtn('dl')===''"))
            await pg.evaluate("S.role='admin';S.pm=['all'];render()"); await pg.wait_for_timeout(200)
            chk(t+'no overflow', await pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            chk(t+'no js errors', not errs)
            if w==320 and sch=='dark': await pg.screenshot(path='%s/shots/kv95.png'%ROOT)
            await ctx.close()
        await b.close()
    print('ALL OK' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
asyncio.run(main())
