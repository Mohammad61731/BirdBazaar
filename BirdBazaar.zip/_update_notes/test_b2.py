# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.wz=1;S.role=null;D.cms.PL=[{t:'کد را بزن و جایزه بگیر',k:'تخفیف'},{t:'فقط متن'}];S.tab=0;S.v=null;render()");pg.wait_for_timeout(400)
        chk(t+'guest: 2 pills no edit',pg.evaluate("document.querySelectorAll('#scr .plr').length==2&&!document.querySelector('#scr .plx')"))
        chk(t+'link only with k',pg.evaluate("document.querySelectorAll('#scr .plt[data-a]').length==1"))
        chk(t+'off: none',pg.evaluate("(XF.wz=0,hnPl()==='')"))
        chk(t+'xss',pg.evaluate("(XF.wz=1,D.cms.PL=[{t:'<img src=x onerror=1>'}],!hnPl().includes('<img'))"))
        chk(t+'no overflow',pg.evaluate("(render(),document.documentElement.scrollWidth<=innerWidth)"))
        ctx.close()
print('ERRORS',errs)
