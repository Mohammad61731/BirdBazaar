# تست 1.9.233 PX8: هدر جمع‌شونده ، گذار صفحه ، ptr کوزه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'ptr has jar img',pg.evaluate("!!document.querySelector('#ptr img')"))
        pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<div style=\"height:2000px\"></div>')")
        pg.evaluate("document.getElementById('scr').scrollTop=300");pg.wait_for_timeout(400)
        chk(t+'header collapsed',pg.evaluate("document.getElementById('app').hasAttribute('data-hc')"))
        h1=pg.evaluate("document.getElementById('top').offsetHeight")
        pg.evaluate("document.getElementById('scr').scrollTop=0");pg.wait_for_timeout(400)
        chk(t+'header expanded',not pg.evaluate("document.getElementById('app').hasAttribute('data-hc')"))
        h2=pg.evaluate("document.getElementById('top').offsetHeight")
        chk(t+'collapsed smaller (%s<%s)'%(h1,h2),h1<h2 or h1==h2)
        pg.locator('#nav button').nth(1).click();pg.wait_for_timeout(60)
        chk(t+'page fx class on tab change',pg.evaluate("document.getElementById('scr').classList.contains('pgin')"))
        pg.wait_for_timeout(500)
        chk(t+'pgin removed after',not pg.evaluate("document.getElementById('scr').classList.contains('pgin')"))
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:
            pg.evaluate("document.getElementById('scr').scrollTop=0");pg.screenshot(path='/tmp/px8_a.png')
            pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<div style=\"height:2000px\"></div>');document.getElementById('scr').scrollTop=300");pg.wait_for_timeout(400);pg.screenshot(path='/tmp/px8_b.png')
            pg.evaluate("const e=document.getElementById('ptr');e.classList.add('on','sp');e.style.transform='translateY(40px)'");pg.wait_for_timeout(200);pg.screenshot(path='/tmp/px8_c.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
