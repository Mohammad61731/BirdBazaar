# تست 1.9.455 D3-y: کلیدهای qk pz wa (پاسخ سریع ، عکس بسته ، هشدار گرما)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("BF=Object.assign(btNew(),{qk:1,pz:1});XF.qk=0;XF.pz=0;XF.wa=0")
        chk(t+'off: form empty',pg.evaluate("qzForm()===''"))
        chk(t+'off: rows empty',pg.evaluate("qzRows({qk:1,pz:1,care:'c'}).length===0"))
        pg.evaluate("XF.qk=1;XF.pz=1;XF.wa=1")
        chk(t+'on: form 2 checks checked',pg.evaluate("qzForm().includes('bfqk')&&qzForm().includes('bfpz')&&(qzForm().match(/checked/g)||[]).length===2"))
        chk(t+'on: rows qk pz',pg.evaluate("qzRows({qk:1,pz:1}).length===2"))
        chk(t+'weather hot only',pg.evaluate("(()=>{const o=waHot;window.waHot=()=>true;const a=qzRows({care:'c'}).length===1&&qzRows({care:'h'}).length===1&&qzRows({care:'f'}).length===0;window.waHot=()=>false;const b=qzRows({care:'c'}).length===0;window.waHot=o;return a&&b})()"))
        chk(t+'tabs show badge',pg.evaluate("btTabs({id:1},{name:'a',type:'plain',price:5,qk:1,cat:'x'},null).includes('پاسخ سریع')"))
        pg.evaluate("XF.qk=0;XF.pz=0;XF.wa=0")
        chk(t+'tabs off hide',pg.evaluate("!btTabs({id:1},{name:'a',type:'plain',price:5,qk:1,pz:1,cat:'x'},null).includes('پاسخ سریع')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
print('ERRORS',errs)
