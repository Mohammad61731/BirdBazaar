# تست 1.9.385 D1/147: کلید cj ، انقضای سبد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.cj=0;D.cart=[{id:1,q:1,at:1}]");chk(t+'off: nothing removed',pg.evaluate("(cjSweep(),D.cart.length)")==1)
        pg.evaluate("XF.cj=1;D.cart=[{id:1,q:1,at:1},{id:2,q:1,at:Date.now()},{id:3,q:1,at:Date.now()-12*864e5},{id:4,q:1}]")
        h=pg.evaluate("cjSweep()");n=pg.evaluate("D.cart.length")
        chk(t+'old removed, 3 stay',n==3)
        chk(t+'warn shown','czx' in h and '۱' in h)
        chk(t+'new item stamped',pg.evaluate("!!D.cart.find(c=>c.id==4).at"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
