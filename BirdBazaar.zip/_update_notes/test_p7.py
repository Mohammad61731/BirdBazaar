import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='adm';go({tab:1,v:null,cat:''})");pg.wait_for_timeout(500)
    n=pg.evaluate("D.products.length");print('products',n)
    chk('دکمه‌ی سوییچ روی کارت‌ها',pg.locator('[data-a=pso]').count()>0)
    pid=pg.locator('[data-a=pso]').first.get_attribute('data-v');was=pg.evaluate("!!getP(%s).out"%pid)
    pg.locator('[data-a=pso]').first.click();pg.wait_for_timeout(400)
    chk('وضعیت برعکس شد',pg.evaluate("!!getP(%s).out"%pid)!=was)
    chk('ذخیره شد در حافظه',pg.evaluate("JSON.parse(localStorage.getItem(K)).products.find(x=>x.id==%s).out?1:0"%pid)==(0 if was else 1))
    pg.locator('[data-a=pso]').first.click();pg.wait_for_timeout(300)
    chk('برگشت',pg.evaluate("!!getP(%s).out"%pid)==was)
    pg.evaluate("S.role='user';S.pm=[];render()");pg.wait_for_timeout(300)
    chk('کاربر عادی سوییچ ندارد',pg.locator('[data-a=pso]').count()==0)
    pg.evaluate("S.role='admin';S.pm=['all'];render()")
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
