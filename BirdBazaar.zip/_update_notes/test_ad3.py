# تست 1.9.182: ثبت آگهی ۳ قدمی + پیش‌نویس خودکار
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1500)
        pg.evaluate("S.role='user';S.me='u1';S.pw='p';localStorage.removeItem('bp_addr_u1');ADSTEP=1;go({tab:2,v:null,sub:1})");pg.wait_for_timeout(400)
        vis=lambda i:pg.evaluate("(i)=>{const e=document.getElementById('ads'+i);return !!e&&e.style.display!=='none'}",i)
        chk(f'{w}: only step1 visible',vis(1) and not vis(2) and not vis(3))
        pg.evaluate("document.querySelector('[data-a=adst][data-v=\"2\"]').click()");pg.wait_for_timeout(200)
        chk(f'{w}: empty title blocks step2',vis(1) and not vis(2))
        pg.fill('#at','قناری');pg.evaluate("document.querySelector('[data-a=adst][data-v=\"2\"]').click()");pg.wait_for_timeout(200)
        chk(f'{w}: step2 visible',vis(2) and not vis(1))
        pg.fill('#ap','500000');pg.evaluate("document.querySelector('#ads2 [data-a=adst][data-v=\"3\"]').click()");pg.wait_for_timeout(200)
        chk(f'{w}: step3 visible with send button',vis(3) and pg.locator('#ads3 [data-a=subad]').count()==1)
        pg.fill('#ad','سالم و خوش‌صدا');pg.wait_for_timeout(900)
        dr=pg.evaluate("localStorage.getItem('bp_addr_u1')")
        chk(f'{w}: draft saved',bool(dr) and 'قناری' in dr and '500000' in dr)
        chk(f'{w}: no horizontal overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.evaluate("ADSTEP=1;render()");pg.wait_for_timeout(300)
        chk(f'{w}: draft restored after re-render',pg.input_value('#at')=='قناری' and pg.input_value('#ad')=='سالم و خوش‌صدا')
        chk(f'{w}: restore note shown',pg.locator('[data-a=addrx]').count()==1)
        pg.evaluate("document.querySelector('[data-a=addrx]').click()");pg.wait_for_timeout(300)
        chk(f'{w}: clear removes draft',pg.evaluate("localStorage.getItem('bp_addr_u1')")is None and pg.input_value('#at')=='')
        ctx.close()
    br.close()
print('ERRORS',errs)
