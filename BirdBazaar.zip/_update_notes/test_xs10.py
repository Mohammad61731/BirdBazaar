# تست 1.9.337: استودیو T2-e متن بنر/فونت/رنگ اصلی/رنگ‌های ذخیره‌شده/رنگ هماهنگ (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=0;XF.xs=1;render()");pg.wait_for_timeout(300)
        pg.evaluate("sgSheet()");pg.wait_for_timeout(250)
        chk(t+'controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-sgc="x.bj:2"]','#ov [data-sgc="x.bw:1"]','#ov [data-sgc="x.ft:2"]','#ov [data-sg="x.bc"]','#ov [data-sg="x.pf"]','#ov [data-sgp="save"]','#ov [data-sgp="clear"]')) and pg.locator('#ov [data-sgp^="#"]').count()>=10)
        clk(pg,'#ov [data-sgc="x.bj:2"]');clk(pg,'#ov [data-sgc="x.bw:1"]');clk(pg,'#ov [data-sgc="x.ft:2"]')
        pg.evaluate("sgSetV('x','bc','#ffcc00',1)");pg.wait_for_timeout(200)
        r=pg.evaluate("()=>{const h=document.querySelector('.hero'),t=h.querySelector('h2'),c=getComputedStyle(t);return [getComputedStyle(h).justifyContent,c.color,c.textShadow,c.fontFamily]}")
        chk(t+'banner text',r[0]=='center' and r[1]=='rgb(255, 204, 0)' and r[2]=='none' and 'Naskh' in r[3])
        # palette
        clk(pg,'#ov [data-sgp="#2FB585"]')
        f=pg.evaluate("()=>[getComputedStyle(document.getElementById('app')).getPropertyValue('--f').trim().toLowerCase(),getComputedStyle(document.getElementById('app')).getPropertyValue('--f2').trim().toLowerCase(),sgGet('x').pf]")
        chk(t+'main color',f[0]=='#2fb585' and f[1]!='#2fb585' and f[1].startswith('#') and f[2]=='#2FB585')
        har=pg.evaluate("stHar('#2FB585')")
        chk(t+'harmony 4',len(har)==4 and all(len(h)==7 for h in har) and har[0]!='#2FB585')
        clk(pg,'#ov [data-sgp="save"]')
        chk(t+'fav saved',pg.evaluate("sgFav().includes('#2FB585')"))
        clk(pg,'#ov [data-sgp="save"]')
        chk(t+'fav no dup',pg.evaluate("sgFav().length==1"))
        # reset keeps favorites
        pg.evaluate("document.querySelector('[data-sgc=\"reset:1\"]').click()");pg.wait_for_timeout(250)
        chk(t+'reset keeps fav & clears look',pg.evaluate("()=>sgFav().length==1&&!sgGet('x').pf&&getComputedStyle(document.getElementById('app')).getPropertyValue('--f').trim().toLowerCase()!='#2fb585'"))
        # apply fav then delete
        clk(pg,'#ov [data-sgp="#2FB585"]')
        clk(pg,'#ov [data-sgp="del:0"]')
        chk(t+'fav deleted',pg.evaluate("sgFav().length==0"))
        clk(pg,'#ov [data-sgp="clear"]')
        chk(t+'clear color',pg.evaluate("!sgGet('x').pf"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and not dark:
            pg.evaluate("cl();sgSetV('x','pf','#3B6FB6',0);sgSetV('x','bj',3,0);sgSetV('x','bw',3,0);sgSetV('x','ft',1,0)");pg.wait_for_timeout(300)
            pg.screenshot(path='/tmp/xs10_a.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
