import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("""S.role=null;S.pm=[];D.cfg.guestGuide=1;D.guides=[
{id:1,title:'جوجه‌کشی مرغ عشق',cat:'پرندگان زینتی',text:'دمای دستگاه ۳۷ درجه باشد',img:'',video:''},
{id:2,title:'تغذیه کاناری',cat:'پرندگان زینتی',text:'از مکمل کلسیم استفاده کنید',img:'',video:''},
{id:3,title:'نگهداری گربه',cat:'سگ و گربه',text:'واکسن سالانه',img:'',video:''}];
D.products=[{id:1,name:'کلسیم مایع',cat:'مکمل',price:1000,short:'',use:'',def:'',ben:'',cau:'',img:'',dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}},{id:2,name:'ویتامین',cat:'مکمل',price:2000,short:'',use:'',def:'',ben:'',cau:'',img:'',dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}}];go({v:'guides'})""");pg.wait_for_timeout(300)
    vis=lambda:pg.evaluate("[...document.querySelectorAll('#ggrid .pc')].filter(x=>x.style.display!='none').length")
    chk('1 سه آموزش',vis()==3)
    pg.fill('#gq','کلسیم');chk('2 جست‌وجو در متن',vis()==1)
    pg.fill('#gq','جوجه');chk('3 جست‌وجو در عنوان',vis()==1)
    pg.fill('#gq','سگ');chk('4 جست‌وجو در دسته',vis()==1)
    pg.fill('#gq','زzz');chk('5 پیام پیدا نشد',vis()==0 and pg.evaluate("$('#gnone').style.display!='none'"))
    pg.fill('#gq','');chk('6 پاک کردن',vis()==3 and pg.evaluate("$('#gnone').style.display=='none'"))
    pg.fill('#gq','ي');pg.fill('#gq','تغذيه');chk('7 ی/ي عربی',vis()==1)
    pg.fill('#gq','مرغ عشق');chk('8 چند کلمه',vis()==1)
    pg.fill('#gq','');pg.click('[data-a=gcat][data-v="سگ و گربه"]');pg.wait_for_timeout(200)
    chk('9 چیپ دسته',pg.locator('#ggrid .pc').count()==1)
    pg.fill('#gq','کلسیم');chk('10 دسته + جست‌وجو ترکیبی',vis()==0)
    pg.evaluate("go({tab:1,v:'prod',id:1})");pg.wait_for_timeout(300)
    chk('11 آموزش مرتبط زیر محصول',pg.locator('.grel .pc').count()>=1 and 'کاناری' in pg.inner_text('.hs.grel'))
    pg.evaluate("go({tab:1,v:'prod',id:2})");pg.wait_for_timeout(300)
    chk('12 محصول بی‌ربط: بدون بخش',pg.locator('.grel').count()==0)
    pg.evaluate("go({tab:1,v:'prod',id:1})");pg.wait_for_timeout(300)
    pg.click('.hs.grel .pc');pg.wait_for_timeout(300)
    chk('13 باز شدن آموزش',pg.evaluate("S.v=='guide'&&S.id==2"))
    for th in('light','dark'):
        for w in(320,360,412):
            pg.evaluate("document.documentElement.setAttribute('data-theme','%s');go({tab:1,v:'prod',id:1})"%th);pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    pg.screenshot(path=P+'/shots/q9.png')
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
