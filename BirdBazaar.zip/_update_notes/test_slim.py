# تست 1.9.70: fPoll با slim فقط پیام جدید می‌گیرد؛ اتاق‌ها/پین‌ها وقتی در پاسخ نیست پاک نمی‌شود؛ fRefresh تطبیقی
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        bodies=[]
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if u.startswith('http'):
                if 'fpull' in bd: bodies.append(bd)
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}))
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        # شبیه‌سازی پاسخ slim: بدون rooms/pins/reqn
        r=await pg.evaluate("""(async()=>{FM.rooms=[{id:1,name:'a'}];FM.pins=[{id:5}];FM.reqn=3;FM.room=1;
          const o=window.fetch;window.fetch=async()=>new Response(JSON.stringify({ok:1,mode:'on',slow:0,msgs:[]}),{status:200,headers:{'content-type':'application/json'}});
          await fpull(1,{after:0,n:60,slim:1});window.fetch=o;return [FM.rooms.length,FM.pins.length,FM.reqn]})()""")
        print('kept rooms/pins/reqn:',r); ok&=(r==[1,1,3])
        src=await pg.evaluate("document.documentElement.outerHTML")
        for k in ["noav:1,slim:1","n:40,noav:1,nomd:xf('md')?1:0","ia>60000"]:
            f=k in src; print(k,f); ok&=f
        print('errors',errs); ok&=not errs
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
