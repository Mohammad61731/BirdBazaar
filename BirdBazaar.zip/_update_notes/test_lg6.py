# تست 1.9.286: LG6 خانه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const q=document.querySelector('#scr .hqa .qa i'),qs=q?getComputedStyle(q):null,b=document.querySelector('#scr .bn,#scr .hero'),bs=b?getComputedStyle(b):null,s=document.querySelector('#scr .sec'),ss=s?getComputedStyle(s):null;const r=q?q.getBoundingClientRect():null;return {qw:r?r.width:-1,qr:qs?parseFloat(qs.borderTopLeftRadius):-1,br:bs?parseFloat(bs.borderTopLeftRadius):-1,sf:ss?parseFloat(ss.fontSize):-1,ov:document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(600)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'app-style icon squircle 56',abs(r['qw']-56)<1 and r['qr']==26)
                    chk(t+'banner radius 28',r['br']<0 or r['br']>=26)
                    chk(t+'section title 20',r['sf']<0 or r['sf']==20)
                    if w==360: pg.screenshot(path='/tmp/lg6_%s_%s.png'%(m,'d' if dark else 'l'))
                else:
                    chk(t+'minimal icon untouched',r['qr']==50)
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
