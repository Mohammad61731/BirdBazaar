# تست 1.9.515 114: آمار بازدید آگهی (کلید av)
# تست 1.9.460 A33: رسید فروش حضوری (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        F="__ops.filter(x=>x.includes('adv_hit')).length"
        pg.evaluate("window.__ops=[];localStorage.removeItem('bp_avq');S.me='u1';S.pw='x';window.fetch=async function(u,o){const b=String((o&&o.body)||'');window.__ops.push(b);let r={ok:1};if(b.includes('adv_get'))r={ok:1,t:30,l:[0,1,2,3,0,5,4]};return new Response(JSON.stringify(r),{headers:{'content-type':'application/json'}})}")
        pg.evaluate("XF.av=0")
        chk(t+'off: no button/no hit',pg.evaluate("avH({id:3,own:'u1'})==''&&(avSeen(3),1)")and pg.evaluate(F)==0)
        pg.evaluate("XF.av=1")
        chk(t+'owner gets stats button',pg.evaluate("avH({id:3,own:'u1'}).includes('data-a=\"avs\"')"))
        chk(t+'visitor: no button',pg.evaluate("avH({id:4,own:'zz'})===''"))
        pg.evaluate("avSeen(4)");pg.wait_for_timeout(300)
        chk(t+'first view flushes batch',pg.evaluate(F)==1 and pg.evaluate("__ops.some(x=>x.includes('adv_hit')&&x.includes('[4]'))"))
        pg.evaluate("avSeen(4);avSeen(4)");pg.wait_for_timeout(300)
        chk(t+'dedupe same day',pg.evaluate(F)==1)
        pg.evaluate("avSeen(5);avSeen(6)");pg.wait_for_timeout(300)
        chk(t+'next views wait (6h/5 ids)',pg.evaluate(F)==1 and pg.evaluate("avQ().ids.length")==2)
        pg.evaluate("avSeen(7);avSeen(8);avSeen(9)");pg.wait_for_timeout(300)
        chk(t+'5 pending flush together',pg.evaluate(F)==2 and pg.evaluate("avQ().ids.length")==0)
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=ta data-a=avs data-v=3></button>');document.getElementById('ta').click()");pg.wait_for_timeout(400)
        chk(t+'stats sheet',pg.evaluate("!!document.querySelector('.sheet .avs')&&document.querySelectorAll('.sheet .avs i').length==7"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        pg.screenshot(path='/tmp/av_%d.png'%w)
        pg.evaluate("avSheet({t:0,l:[]})")
        chk(t+'empty state',pg.evaluate("avSheet({t:0,l:[]}).includes('هنوز بازدیدی')"))
        ctx.close()
print('ERRORS',errs)
