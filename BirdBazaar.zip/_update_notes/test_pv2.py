# تست 1.9.264 P83: داشبورد فروشنده
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':760},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("""(()=>{const d=n=>new Date(Date.now()-n*864e5).toISOString().slice(0,10);
BT.u='x';BT.p='x';BM={ok:1,booth:{id:1,name:'غرفه آزمایشی با نام خیلی خیلی بلند',views:120,status:'active',logo:'',cover:'',bio:'',city:'',phone:''},prods:[{id:1,s:'on',d:{name:'الف',price:1}},{id:2,s:'off',d:{name:'ب',price:1}}],days:[{day:d(1),n:5},{day:d(0),n:9},{day:d(3),n:2}]};
BOR=[{s:'new',name:'a',phone:'1',t:Date.now(),lines:[]},{s:'done',name:'b',phone:'2',t:Date.now(),lines:[]}];
S.btt='d';S.tab=1;S.v='btm';render()})()""");pg.wait_for_timeout(500)
            chk(f'{w}/{dark}: hero+kpis',pg.locator('.sdh').count()==1 and pg.locator('.sdk .card').count()==4 and pg.locator('.sdc>div').count()==7)
            chk(f'{w}/{dark}: new orders=1',pg.locator('.sdk .card').nth(2).locator('b').inner_text().strip() in ('1','۱'))
            chk(f'{w}/{dark}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            pg.locator('.sdk .card').nth(3).click();pg.wait_for_timeout(300)
            chk(f'{w}/{dark}: products card opens tab',pg.evaluate("S.btt")=='p')
            if w==360:
                pg.evaluate("S.btt='d';render()");pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/sd_{w}_{dark}.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
