import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[];reqs=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
LIST={'ok':1,'l':[{'ad':11,'n':3,'why':['کلاهبرداری','تکراری'],'t':'2026-11-15T10:00:00Z'},{'ad':12,'n':1,'why':None,'t':'2026-11-15T09:00:00Z'},{'ad':99,'n':1,'why':[],'t':'2026-11-15T08:00:00Z'}]}
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:b=json.loads(q.post_data or '{}')
    except Exception:b={}
    reqs.append(b)
    body=LIST if b.get('op')=='arep_list' else {'ok':1}
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
SETUP="""S.role='admin';S.me='adm';S.pw='x';S.pm=['all'];
D.ads=[{id:11,title:'جفت مرغ عشق',sp:'x',price:900000,desc:'x',imgs:[],st:'ok',own:'sara'},{id:12,title:'قفس',sp:'x',price:300000,desc:'x',imgs:[],st:'pending',own:'sara'}]"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_page(viewport={'width':w,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700);pg.evaluate(SETUP)
        pg.evaluate("report(11)");chk('w%d برگه‌ی دلیل: ۵ دکمه'%w,pg.locator('[data-a=arps]').count()==5)
        reqs.clear();pg.locator('[data-a=arps]').first.click();pg.wait_for_timeout(400)
        chk('w%d ad_report و arep فرستاده شد'%w,any(r.get('op')=='ad_report' for r in reqs) and any(r.get('op')=='arep' and r['a'].get('ad')==11 and r['a'].get('why')=='کلاهبرداری' for r in reqs))
        pg.evaluate("arList()");pg.wait_for_timeout(500)
        t=pg.inner_text('#ovc')
        chk('w%d فهرست: ۳ کارت با ترتیب سرور'%w,pg.locator('#ovc .card').count()==3 and t.index('جفت مرغ عشق')<t.index('قفس'))
        chk('w%d دلیل‌ها و آگهی حذف‌شده'%w,'کلاهبرداری' in t and 'آگهی حذف‌شده' in t)
        chk('w%d پنهان فقط برای آگهی منتشرشده'%w,pg.locator('[data-a=arh]').count()==1)
        chk('w%d بدون سرریز'%w,pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.close()
    pg=br.new_page(viewport={'width':360,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700);pg.evaluate(SETUP)
    pg.evaluate("arList()");pg.wait_for_timeout(500)
    reqs.clear();pg.locator('[data-a=ard]').first.click();pg.wait_for_timeout(500)
    chk('بستن گزارش: arep_done برای 11 و فهرست دوباره بارگذاری',any(r.get('op')=='arep_done' and r['a'].get('ad')==11 for r in reqs) and any(r.get('op')=='arep_list' for r in reqs))
    reqs.clear();pg.locator('[data-a=arh]').first.click();pg.wait_for_timeout(500)
    chk('پنهان: ad_set با st=no',any(r.get('op')=='ad_set' for r in reqs) and pg.evaluate("D.ads[0].st")=='no')
    pg.evaluate("S.pm=[];S.role='user';reqs=0");reqs.clear();pg.evaluate("go({tab:4,v:null,pnl:1,at:'a'})")
    pg.evaluate("S.role='admin';S.pm=['all'];go({tab:4,v:null,pnl:1,at:'a'})");pg.wait_for_timeout(300)
    chk('دکمه‌ی «گزارش آگهی‌ها» در تب آگهی‌های پنل ادمین',pg.locator('[data-a=arl]').count()==1)
    pg.evaluate("S.role='user';S.pm=[]");reqs.clear();pg.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=tb data-a=arl></button>')");pg.click('#tb');pg.wait_for_timeout(300)
    chk('غیرادمین با arl درخواست نمی‌فرستد',not any(r.get('op')=='arep_list' for r in reqs))
    br.close()
chk('بدون خطای صفحه',not errs)
print('ALL PASS' if all(ok) else 'SOME FAIL',errs[:2])
