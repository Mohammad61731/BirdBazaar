# تست 1.9.294: LG14 پک آیفون
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    r=pg.evaluate("""async()=>{const P=ICPK['آیفون'],out=[];for(const [id] of ikS){const u=icPkSvg(P,id);const ok=await new Promise(res=>{const i=new Image();i.onload=()=>res(i.naturalWidth>0);i.onerror=()=>res(false);i.src=u});out.push([id,u.length,ok])}
      const mn=icPkSvg(ICPK['مینیمال'],'qa.ads');return {out,mn:atob(mn.split(',')[1]).includes('gradient'),n:Object.keys(P.ic).length,pk:typeof icPack}}""")
    chk('18 slots',len(r['out'])==18 and r['n']>=18)
    chk('all valid img',all(x[2] for x in r['out']))
    chk('size<8000',all(x[1]<8000 for x in r['out']))
    chk('minimal untouched',not r['mn'])
    pg.evaluate("S.role='admin';S.me='ادمین';S.pm=['all']")
    try:
        pg.evaluate("icSheet()");pg.wait_for_timeout(500)
        chk('button in sheet',pg.evaluate("[...document.querySelectorAll('#ovc [data-a=icmn]')].some(b=>b.dataset.v==='آیفون')"))
        pg.screenshot(path='/tmp/lg14_sheet.png')
    except Exception as e: chk('sheet open '+str(e)[:60],False)
    # preview strip
    pg.evaluate("""(()=>{const P=ICPK['آیفون'];const d=document.createElement('div');d.id='pvx';d.style.cssText='position:fixed;inset:auto 0 0 0;z-index:99;background:#fff;display:flex;flex-wrap:wrap;gap:8px;padding:10px';ikS.forEach(([id])=>{const i=new Image();i.src=icPkSvg(P,id);i.style.cssText='width:52px;height:52px';d.appendChild(i)});document.body.appendChild(d)})()""");pg.wait_for_timeout(400)
    pg.screenshot(path='/tmp/lg14_pack.png')
    br.close()
print('ERRORS',errs)
