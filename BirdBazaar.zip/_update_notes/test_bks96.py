# تست 1.9.96: بازگردانی پشتیبان ساده (پیش‌نمایش، حالت‌ها، ذخیره‌ی نسخه‌ی فعلی، ارسال به سرور، تأیید)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.route('**/*',lambda r: r.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}') if r.request.url.startswith('http') else r.continue_())
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        r=await pg.evaluate("""async()=>{
          S.me='a';S.pw='x';S.role='admin';S.pm=['all'];window.confirm=()=>true;
          const out={};const saved=[];window.Capacitor=window.Capacitor||{};
          Capacitor.Plugins={Filesystem:{writeFile:async o=>{saved.push(o.path);return {uri:'file:///c/'+o.path}}},Share:{share:async()=>{}}};
          const ops=[];window.fetch=async(u,o)=>{try{const b=JSON.parse(o.body);ops.push(b.op)}catch(e){}return {ok:true,status:200,json:async()=>({ok:1}),text:async()=>'{"ok":1}'}};
          D.products=[{id:1,name:'a'}];D.ads=[{id:5,title:'x'}];D.stories=[];D.guides=[{id:1}];
          const bk={app:'birdbazaar',ver:1,t:'2026-11-10T00:00:00Z',data:{products:[{id:1,name:'a'},{id:2,name:'b'},{id:3,name:'c',lite:1}],ads:[{id:5,title:'x'},{id:6,title:'y'}],stories:[{id:9,title:'s',img:'',imgs:[],t:'s'}],guides:[{id:1},{id:2}]}};
          const mk=()=>{const dt=new DataTransfer();dt.items.add(new File([JSON.stringify(bk)],'b.json',{type:'application/json'}));$('#bks_f').files=dt.files};
          bkRestore();out.open=!!$('#bks_f');mk();await bksRead();out.pv=$('#bks_pv').textContent;
          await bksGo('m');
          out.saved=saved;out.pc=D.products.length;out.ac=D.ads.length;out.sc=D.stories.length;out.gc=D.guides.length;out.ops=[...new Set(ops)];
          out.badfile=await (async()=>{const dt=new DataTransfer();dt.items.add(new File(['xx'],'c.json'));bkRestore();$('#bks_f').files=dt.files;await bksRead();return $('#bks_pv').textContent})();
          return out}""")
        print(json.dumps(r,ensure_ascii=False))
        ok = r['open'] and 'جاافتاده' in r['pv'] and r['saved'] and r['saved'][0].startswith('birdbazaar-before-restore-') \
          and r['pc']==2 and r['ac']==2 and r['sc']==1 and r['gc']==2 \
          and {'products_set','stories_set','guides_set','ad_set'} <= set(r['ops']) and not errs
        print('ERRS',errs); print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
