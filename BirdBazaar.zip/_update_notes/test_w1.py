from playwright.sync_api import sync_playwright
errs=[]
def bg(pg):return pg.evaluate("getComputedStyle(document.body).backgroundColor")
with sync_playwright() as p:
    br=p.chromium.launch()
    for scheme in ('light','dark'):
        ctx=br.new_context(viewport={'width':360,'height':780},color_scheme=scheme);pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(600)
        # old forced value must be ignored (migration)
        print(scheme,'auto ->',bg(pg),pg.evaluate("document.documentElement.getAttribute('data-theme')"))
        other='dark' if scheme=='light' else 'light'
        pg.emulate_media(color_scheme=other);pg.wait_for_timeout(300);print(' phone->',other,bg(pg))
        pg.evaluate("document.querySelector('[data-a=thm]').click()");pg.wait_for_timeout(200);print(' 1 click',pg.evaluate("localStorage.bp_th"),bg(pg))
        pg.evaluate("document.querySelector('[data-a=thm]').click()");pg.wait_for_timeout(200);print(' 2 clicks',pg.evaluate("localStorage.bp_th"),bg(pg))
        pg.evaluate("document.querySelector('[data-a=thm]').click()");pg.wait_for_timeout(200);print(' 3 clicks',pg.evaluate("localStorage.bp_th"),bg(pg),pg.evaluate("document.querySelector('[data-a=thm]').textContent"))
        ctx.close()
    # old stored dark migrated
    ctx=br.new_context(color_scheme='light');pg=ctx.new_page()
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{}'))
    pg.add_init_script("if(!localStorage.bp_thv2)localStorage.bp_th='dark'")
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(500);print('old dark pref, phone light ->',bg(pg))
    print('ERRORS',errs);br.close()
