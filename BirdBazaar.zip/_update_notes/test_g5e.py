# تست 1.9.414 G5-e: گزارش فروش و فاکتور (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnInv({id:1})===''&&pnStat()===''"))
        pg.evaluate("XF.pn=1;BOR=null")
        chk(t+'rep empty without BOR',pg.evaluate("pnRep()===''"))
        pg.evaluate("BOR=[{id:1,s:'new',t:Date.now(),total:100,name:'علی',phone:'09',addr:'ت',lines:[{n:'a',q:2,t:100,pr:1}]},{id:2,s:'cancel',t:Date.now(),total:500,lines:[]},{id:3,s:'done',t:Date.now()-864e5*30,total:900,lines:[]}]")
        chk(t+'rep counts only valid',pg.evaluate("(()=>{const h=pnRep();return h.includes('۱ سفارش')&&h.includes('۱۰۰')&&!h.includes('۵۰۰')&&!h.includes('۹۰۰')})()"))
        chk(t+'inv 2 chips',pg.evaluate("(pnInv({id:1}).match(/<button/g)||[]).length==2"))
        chk(t+'label has no price',pg.evaluate("(()=>{const x=pnInvTxt(BOR[0],'l');return x.includes('گیرنده: علی')&&!x.includes('جمع')})()"))
        chk(t+'invoice has total',pg.evaluate("pnInvTxt(BOR[0],'f').includes('جمع: ۱۰۰')"))
        pg.evaluate("window._c=null;Object.defineProperty(navigator,'share',{value:undefined,configurable:true});navigator.clipboard.writeText=x=>{window._c=x;return Promise.resolve()}")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pnfv';b.dataset.v='1:f';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(250)
        chk(t+'copy works',pg.evaluate("!!window._c&&window._c.includes('علی')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
