# تست 1.9.97: بازگردانی پشتیبان کامل داخل پنل (پیش‌نمایش، تکه‌تکه، قابل‌ادامه)
import asyncio, sys, json, os, tempfile
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            ctx=await b.new_context(viewport={'width':w,'height':700}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            st={'puts':[],'fail':6}
            async def h(route):
                u=route.request.url; bd=route.request.post_data or ''
                if not u.startswith('http'): return await route.continue_()
                hd={'access-control-allow-origin':'*'}
                if u.endswith('/rpc/bkpart'):
                    q=json.loads(bd); o=q['op']; a=q.get('a') or {}
                    if o=='bkput':
                        if a['t']=='ads' and st['fail']>0:
                            st['fail']-=1; return await route.fulfill(status=500,content_type='application/json',headers=hd,body='{"m":"boom"}')
                        if a['t']=='f_conf': return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'err':'table'}))
                        st['puts'].append((a['t'],len(a['rows']))); body={'ok':1,'ins':len(a['rows'])}
                    else: body={'err':'bad'}
                    return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{},'guides':[]}))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(3000)
            data={'users':[{'username':'u%d'%i,'pass':'x'} for i in range(5)],'ads':[{'id':i,'d':{'img':'a'*2000}} for i in range(400)],'f_conf':[{'k':'a','v':'b'}],'empty':[]}
            await pg.evaluate("S.role='admin';S.me='adm';S.pw='x';S.pm=['all'];S.pnl=1;S.at='x';render()"); await pg.wait_for_timeout(300)
            chk('%d card has restore button'%w,'bkb_open' in await pg.evaluate("bkfCard()"))
            path=os.path.join(tempfile.gettempdir(),'t97.bbk')
            enc=await pg.evaluate("async d=>bkEnc(JSON.stringify({ok:1,ddl:['x'],t:'2026-11-16',data:d}),'mypass1')",data)
            open(path,'w',encoding='utf-8').write(enc)
            await pg.evaluate("window.confirm=()=>true;bkbOpen()"); await pg.wait_for_timeout(300)
            chk('%d no overflow'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.set_input_files('#bkb_f',path); await pg.fill('#bkb_pw','WRONGPW'); await pg.evaluate("bkbRead()"); await pg.wait_for_timeout(1200)
            chk('%d wrong pw: no preview'%w, await pg.evaluate("!BKB"))
            await pg.fill('#bkb_pw','mypass1'); await pg.evaluate("bkbRead()"); await pg.wait_for_timeout(1200)
            pv=await pg.inner_text('#bkb_pv'); chk('%d preview counts'%w, 'users' in pv and 'ads' in pv)
            await pg.evaluate("bkbGo()"); await pg.wait_for_timeout(500)
            chk('%d stopped on failure, progress saved'%w, 'ads' not in [x[0] for x in st['puts']] and 'users' in await pg.evaluate("localStorage.getItem('bp_bkb')"))
            await pg.evaluate("bkbGo()"); await pg.wait_for_timeout(1500)
            ta=sum(n for t,n in st['puts'] if t=='ads'); tu=[x for x in st['puts'] if x[0]=='users']
            chk('%d all ads sent chunked'%w, ta==400 and len([x for x in st['puts'] if x[0]=='ads'])>=2)
            chk('%d users sent once (resume)'%w, len(tu)==1)
            chk('%d f_conf skipped, done msg'%w, 'انجام شد' in await pg.inner_text('#bkb_tx'))
            chk('%d no errors %s'%(w,errs), not errs)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
