# تست 1.9.433 D2-a: انتخاب تحویل (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.dt=0;cgG=()=>({lvl:1,hrs:{o:'00:00',c:'00:00'}});crFee=()=>[{n:'منطقه ۱',f:20000,m:30}];crTG=()=>({t:0})")
        chk(t+'off -> dtH empty',pg.evaluate("dtH(1)===''&&!dtOn()"))
        chk(t+'off -> small chips',pg.evaluate("!cpBx(1).includes('dtk')&&cpBx(1).includes('حضوری')"))
        pg.evaluate("XF.dt=1")
        chk(t+'on -> big switch',pg.evaluate("cpBx(1).includes('dtk')&&cpBx(1).includes('میام می‌برم')&&cpBx(1).includes('برام بفرست')"))
        chk(t+'closed warning',pg.evaluate("dtClosed(1)&&dtH(1).includes('الان بسته است')"))
        chk(t+'compare row',pg.evaluate("(()=>{const h=dtH(1);return h.includes('۰ تومان')&&h.includes('پیک')&&h.includes('منطقه')===false&&h.includes('دقیقه')})()"))
        pg.evaluate("cgG=()=>({lvl:1,hrs:{o:'00:00',c:'23:59'}})")
        chk(t+'open -> no warning',pg.evaluate("!dtH(1).includes('الان بسته است')"))
        pg.evaluate("XF.cp=0")
        chk(t+'needs cp',pg.evaluate("dtH(1)===''&&!dtOn()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
