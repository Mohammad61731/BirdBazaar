# تست 1.9.398 H1: شکستن اسم کارت ، هدف لمس ، ذخیره‌ی ثابت ، حداکثر طول ، هشدار دور ریختن تغییرات
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.add_init_script("localStorage.setItem('bp_tls', JSON.stringify({fw:0}))")
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2300)
        chk(t+'wb adds ZWSP after ZWNJ',pg.evaluate("wb('مولتی\u200cویتامین').includes('\u200c\u200b')&&wb('<b>')=='&lt;b&gt;'"))
        pg.evaluate("S.role='';S.v='';S.tab=0;render()");pg.wait_for_timeout(500)
        r=pg.evaluate("""()=>{const o={small:[],tiny:0};document.querySelectorAll('#scr :is(.hb,.sec .lk,button.lk)').forEach(e=>{const b=e.getBoundingClientRect();if(b.width>1&&b.height<32)o.small.push(e.className+' '+Math.round(b.height))});
          document.querySelectorAll('#scr :is(.stn,.kb,.frs,.tmn)').forEach(e=>{if(parseFloat(getComputedStyle(e).fontSize)<10.4)o.tiny++});o.ovf=document.documentElement.scrollWidth-innerWidth;return o}""")
        chk(t+'home link buttons >=32px '+str(r['small']),not r['small'])
        chk(t+'tiny text fixed',r['tiny']==0)
        chk(t+'home no overflow',r['ovf']<=0)
        pg.evaluate("S.role='admin';S.me='admin';S.pw='x';S.pm=['all'];S.pvu=0;S.tab=4;S.at='br';render()");pg.wait_for_timeout(400)
        pg.evaluate("be('bn:0')");pg.wait_for_timeout(400)
        chk(t+'title maxlength 60 / text 140',pg.evaluate("(()=>{const m=[...document.querySelectorAll('#ovc input[maxlength]')].map(i=>+i.maxLength);return m.includes(60)&&m.includes(140)&&m.includes(20)})()"))
        chk(t+'save sticky',pg.evaluate("getComputedStyle(document.querySelector('#ovc .edsv')).position=='sticky'"))
        chk(t+'save button visible without scrolling',pg.evaluate("document.querySelector('#ovc [data-a=sbe]').getBoundingClientRect().bottom<=innerHeight+2"))
        chk(t+'mode buttons >=36',pg.evaluate("[...document.querySelectorAll('#ovc button.tg')].slice(0,3).every(b=>b.getBoundingClientRect().height>=36)"))
        # not dirty -> backdrop closes at once
        pg.mouse.click(w//2,20);pg.wait_for_timeout(350)
        chk(t+'clean editor closes on backdrop',pg.evaluate("!document.querySelector('#ov').classList.contains('on')"))
        # dirty -> first tap warns, second closes
        pg.evaluate("be('bn:0')");pg.wait_for_timeout(300);pg.evaluate("E.d.t='تغییر آزمایشی'")
        pg.mouse.click(w//2,20);pg.wait_for_timeout(350)
        chk(t+'dirty: 1st backdrop tap keeps sheet',pg.evaluate("document.querySelector('#ov').classList.contains('on')"))
        chk(t+'dirty: warning toast shown',pg.evaluate("/ذخیره نشده/.test((document.querySelector('#toast')||{}).innerText||'')"))
        pg.mouse.click(w//2,20);pg.wait_for_timeout(350)
        chk(t+'dirty: 2nd tap closes',pg.evaluate("!document.querySelector('#ov').classList.contains('on')"))
        chk(t+'dirty edit not saved on discard',pg.evaluate("D.cms.BN[0].t!=='تغییر آزمایشی'"))
        # save path still works
        pg.evaluate("be('bn:0')");pg.wait_for_timeout(300);pg.evaluate("E.d.t='ذخیره آزمایشی'")
        pg.locator('#ovc [data-a=sbe]').click();pg.wait_for_timeout(400)
        chk(t+'save works and closes',pg.evaluate("D.cms.BN[0].t==='ذخیره آزمایشی'&&!document.querySelector('#ov').classList.contains('on')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
