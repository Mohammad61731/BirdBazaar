# تست 1.9.344: استودیو S35 حالت ترکیب ، S88 دید کاربر ، S89 اندازه‌ی گوشی (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\\\"fw\\\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['all'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        b=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.grid .pc,.grid .bxc,.hs'));return b?b.dataset.b:null})()")
        chk(t+'block',bool(b))
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(150)
        chk(t+'blend chips',all(pg.locator('#ov [data-xc$=":bm:%d"]'%k).count()==1 for k in range(5)))
        clk(pg,'#ov [data-xc$=":bm:1"]')
        BM="(i)=>document.querySelector('.hg .hbk[data-b=\\\"'+i+'\\\"]').style.mixBlendMode"
        chk(t+'multiply',pg.evaluate(BM,b)=='multiply')
        clk(pg,'#ov [data-xc$=":bm:0"]')
        chk(t+'blend clears',pg.evaluate(BM,b)=='')
        pg.evaluate("cl()")
        chk(t+'preview btn',pg.locator('.edbar [data-pv="m"]').count()==1)
        clk(pg,'.edbar [data-pv="m"]')
        chk(t+'sheet',pg.locator('#ov [data-pv="u"]').count()==1 and pg.locator('#ov [data-pv^="w:"]').count()==4)
        clk(pg,'#ov [data-pv="w:320"]')
        chk(t+'width 320',pg.evaluate("document.getElementById('app').style.maxWidth")=='320px' and pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'#ov [data-pv="w:0"]')
        chk(t+'width normal',pg.evaluate("document.getElementById('app').style.maxWidth")=='')
        clk(pg,'#ov [data-pv="u"]');pg.wait_for_timeout(250)
        chk(t+'user view on',pg.evaluate("S.pvu==1&&!document.querySelector('.hg.ed')&&!document.querySelector('.edbar')&&!!document.getElementById('pvb')"))
        chk(t+'no admin tools',pg.evaluate("!document.querySelector('.hh,[data-a=\\\"ep\\\"],.dmb')"))
        clk(pg,'#pvb');pg.wait_for_timeout(250)
        chk(t+'back to edit',pg.evaluate("S.pvu==0&&!!document.querySelector('.hg.ed')&&!document.getElementById('pvb')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
