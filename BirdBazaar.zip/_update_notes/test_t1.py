# U10-T1: زیرساخت تم هر تب (D.cms.TH) — بدون تغییر ظاهر در حالت «معمولی»
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
import io
errs=[];R={}
NEW='file:///home/claude/bb/www/index.html';OLD='file:///tmp/orig/www/index.html'
def mk(br,url,w=390):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='light',reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto(url);pg.wait_for_timeout(900);return pg
at=lambda pg:pg.evaluate("(()=>{const a=document.querySelector('#app');return a.dataset.tm+'|'+a.dataset.nc+'|'+a.dataset.bg})()")
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=mk(br,NEW)
    names={}
    for n,k in ((0,'home'),(1,'store'),(2,'ads'),(5,'forum'),(4,'profile')):
        pg.evaluate(f"go({{tab:{n},v:null,pnl:0}})");pg.wait_for_timeout(250);names[k]=at(pg)
    R['default_all_n_green']=all(v=='n|green|0' for v in names.values())
    pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];go({tab:4,v:null,pnl:1})");pg.wait_for_timeout(300)
    R['panel_key']=pg.evaluate("thKey()")=='panel'
    pg.evaluate("go({tab:0,v:null,pnl:0})");pg.wait_for_timeout(200)
    pg.evaluate("thSet('home',{m:'g',c:'purple'})");pg.wait_for_timeout(200)
    R['home_set']=at(pg)=='g|purple|0'
    R['neon_var']=pg.evaluate("getComputedStyle(document.querySelector('#app')).getPropertyValue('--neon').trim()")=='#b983ff'
    pg.evaluate("go({tab:1,v:null})");pg.wait_for_timeout(200)
    R['store_untouched']=at(pg)=='n|green|0'
    pg.evaluate("thSet('store',{m:'p',c:'orange',b:2})");pg.wait_for_timeout(200)
    R['store_set']=at(pg)=='p|orange|2'
    pg.evaluate("thSet('bad',{m:'g'})");R['bad_key_ignored']=pg.evaluate("!('bad' in (D.cms.TH||{}))")
    pg.evaluate("thSet('ads',{m:'zzz',c:'red'})");pg.evaluate("go({tab:2,v:null})");pg.wait_for_timeout(200)
    R['bad_values_fallback']=at(pg)=='n|green|0'
    # ماندگاری بعد از بستن و باز کردن (کاربر عادی/مهمان همان را ببیند)
    pg.reload();pg.wait_for_timeout(900)
    pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200);a1=at(pg)
    pg.evaluate("go({tab:1,v:null})");pg.wait_for_timeout(200);a2=at(pg)
    R['persist_guest']=(a1,a2)==('g|purple|0','p|orange|2') and pg.evaluate("S.role")!='admin'
    # غیرادمین نمی‌تواند عوض کند
    pg.evaluate("thSet('home',{m:'p'})");pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200)
    R['nonadmin_blocked']=at(pg)=='g|purple|0'
    # شیشه‌ی گرادینت با رنگ دلخواه
    pg.evaluate("S.role='admin';S.me='m';S.pm=['all']")
    pg.evaluate("thSet('home',{m:'g',s:'g',g1:'#ff0000',g2:'#0000ff'})");pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200)
    R['grad_attrs']=pg.evaluate("(()=>{const a=document.querySelector('#app'),c=getComputedStyle(a);return a.dataset.gs=='g'&&c.getPropertyValue('--gl1').trim()=='#ff0000'&&c.getPropertyValue('--gl2').trim()=='#0000ff'&&c.getPropertyValue('--glassg').includes('linear-gradient')})()")
    pg.evaluate("thSet('home',{g1:'red'})");R['bad_color_fallback']=pg.evaluate("thGet('home').g1")=='#12805c'
    pg.evaluate("thSet('home',{g1:'#ff0000',s:'s'})");pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(150)
    R['simple_style']=pg.evaluate("document.querySelector('#app').dataset.gs")=='s'
    pg.reload();pg.wait_for_timeout(900);pg.evaluate("S.role='admin';S.pm=['all'];thSet('home',{s:'g'})");pg.reload();pg.wait_for_timeout(900)
    R['grad_persist']=pg.evaluate("thGet('home').s=='g'&&thGet('home').g2=='#0000ff'")
    # ریست
    pg.evaluate("S.role='admin';S.me='m';S.pm=['all']");pg.evaluate("thReset('home')");pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200)
    R['reset_one']=at(pg)=='n|green|0' and pg.evaluate("!!D.cms.TH.store")
    pg.evaluate("thReset()");R['reset_all']=pg.evaluate("D.cms.TH===undefined")
    # کم‌مصرف
    pg.evaluate("thLP(true)");R['lp_on']=pg.evaluate("document.querySelector('#app').dataset.lp")=='1'
    pg.evaluate("thLP(false)");R['lp_off']=pg.evaluate("document.querySelector('#app').dataset.lp")is None
    pg.close()
    # رگرسیون پیکسلی: نسخه‌ی قبل در برابر جدید (حالت معمولی باید یکسان باشد)
    diffs={}
    for n,k in ((0,'home'),(1,'store'),(2,'ads'),(4,'profile')):
        sh=[]
        for u in (OLD,NEW):
            q=mk(br,u);q.evaluate(f"go({{tab:{n},v:null}})");q.wait_for_timeout(500);sh.append(Image.open(io.BytesIO(q.screenshot())).convert('RGB'));q.close()
        d=ImageChops.difference(*sh).getbbox();diffs[k]=d
    R['pixel_same_normal']=all(v is None for v in diffs.values());print('diffs',diffs)
    for w in (320,360,412):
        q=mk(br,NEW,w);q.evaluate("S.role='admin';S.me='m';S.pm=['all'];thSet('home',{m:'g',c:'pink'})");ok=True
        for n in (0,1,2,5,4):
            q.evaluate(f"go({{tab:{n},v:null}})");q.wait_for_timeout(200);ok&=not q.evaluate("document.documentElement.scrollWidth>innerWidth")
        R[f'no_overflow_{w}']=ok;q.close()
    br.close()
for k,v in R.items():print(('PASS ' if v else 'FAIL ')+k)
print('ERRORS',errs);raise SystemExit(0 if all(R.values()) and not errs else 1)
