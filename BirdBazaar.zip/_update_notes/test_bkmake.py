# تست 1.9.83: «گرفتن پشتیبان» ساده هم از bkFileOut (Filesystem+Share) استفاده می‌کند
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.route('**/*',lambda r: r.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}') if r.request.url.startswith('http') else r.continue_())
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        r=await pg.evaluate("""async()=>{S.me='a';S.pw='x';S.role='admin';S.pm=['all'];const L=[];window.Capacitor=window.Capacitor||{};Capacitor.Plugins={Filesystem:{writeFile:async o=>{L.push(o.path+'|'+o.directory+'|'+o.data.length);return {uri:'file:///c/'+o.path}}},Share:{share:async o=>{L.push('share '+o.url)}}};await bkMake();return L}""")
        print(r); ok=len(r)==2 and r[0].startswith('birdbazaar-backup-') and 'CACHE' in r[0] and r[1].startswith('share file:///c/birdbazaar-backup-') and not errs
        print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
