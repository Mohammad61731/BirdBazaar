# تست 1.9.301: AN41 فوکوس فیلد ، AN42 دکمه‌ی ↓ چت ، AN43 پَف نشان‌کردن
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                pg.evaluate("S.tab=1;S.v=null;render()");pg.wait_for_timeout(300)
                pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<label class=\"fld2\" id=\"tl\">x<input id=\"tin\"></label><button class=\"fdn on\" id=\"tfd\">⬇</button><button class=\"heart on pop\" id=\"thh\">♥</button>')")
                pg.focus('#tin');pg.wait_for_timeout(500)
                r=pg.evaluate("(()=>{const g=i=>getComputedStyle(document.getElementById(i));return {tp:g('tin').transitionProperty,lc:g('tl').color,fa:g('tfd').animationName,ha:g('thh').animationName,ov:document.documentElement.scrollWidth<=innerWidth,f:getComputedStyle(document.documentElement).getPropertyValue('--f')}})()")
                t=f"{w}{'d' if dark else 'l'} {rm} "
                chk(t+'no overflow',r['ov'])
                if rm=='no-preference':
                    chk(t+'AN41 input transition','box-shadow' in r['tp'])
                    chk(t+'AN42 fdn anim','anfd' in r['fa'])
                    chk(t+'AN43 heart puff','anbk' in r['ha'])
                else:
                    chk(t+'reduced: no heart puff','anbk' not in r['ha'])
                    chk(t+'reduced: no fdn anim','anfd' not in r['fa'])
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
