# تست 1.9.288: LG8 صفحه‌ی محصول
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const g=document.querySelector('#scr .gal div'),c=document.querySelector('#scr .card'),q=document.querySelector('#scr [data-a=qd]');const gs=g?getComputedStyle(g):null,cs=c?getComputedStyle(c):null,qs=q?getComputedStyle(q):null;return {g:g?parseFloat(gs.borderTopLeftRadius):-1,c:c?parseFloat(cs.borderTopLeftRadius):-1,cb:c?cs.backdropFilter:'',q:q?parseFloat(qs.width):-1,qr:q?qs.borderTopLeftRadius:'',ov:document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();go({v:'prod',id:D.products[0].id})"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'gallery radius 26',r['g']==26)
                    chk(t+'card radius 22 no blur',r['c']==22 and (r['cb'] or 'none')=='none')
                    if r['q']>0: chk(t+'stepper round 44',r['q']==44 and r['qr']=='50%')
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg8_%s.png'%('d' if dark else 'l'))
                if m!='m': chk(t+'sbuy glass if shown',pg.evaluate("(()=>{const b=document.getElementById('sbuy');if(!b)return true;const s=getComputedStyle(b);return s.borderTopLeftRadius=='26px'&&s.backdropFilter.includes('blur')})()"))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
