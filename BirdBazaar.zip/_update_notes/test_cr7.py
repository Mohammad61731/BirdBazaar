# تست 1.9.380 C5f/67: مرتب‌سازی هم‌مسیر در فهرست آماده‌ی پیک
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        h=pg.evaluate("""(()=>{const G={1:{la:35.70,ln:51.40},2:{la:35.90,ln:51.60},3:{la:35.71,ln:51.41},4:{la:35.95,ln:51.70}};cgG=id=>G[id]||null;
        CRM.j={my:[{id:9,s:'acc',bn:'من',b:1,name:'م',phone:'1',addr:'x'}],av:[{id:1,bn:'دور',b:2,n:1,t:1000},{id:2,bn:'نزدیک',b:3,n:1,t:1000},{id:3,bn:'آشنا',b:4,n:1,t:1000,fv:true}]};return crJobsH()})()""")
        a,b,c=h.index('آشنا'),h.index('نزدیک'),h.index('دور')
        chk(t+'order fav, near, far',a<b<c)
        chk(t+'chip only on near',h.count('هم‌مسیر')==1 and h.index('هم‌مسیر')>b-200 and h.index('هم‌مسیر')<c)
        h2=pg.evaluate("(cgG=id=>null,CRM.j={my:[],av:[{id:1,bn:'ا',n:1,t:1},{id:2,bn:'ب',n:1,t:1}]},crJobsH())")
        chk(t+'no coords: no chip, no error','هم‌مسیر' not in h2 and h2.index('ا')>=0)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
