import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';D.ads=[{id:5,title:'ت',price:100,sp:'کاسکو',city:'ق',desc:'د',imgs:[],st:'ok',own:'reza'}];go({v:'ad',id:5})");pg.wait_for_timeout(500)
    chk('متن هشدار نمایش داده می‌شود','هیچ مسئولیتی' in pg.inner_text('.adw'))
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
