# تست 1.9.85 مرحله‌ی ۲: مرکز تنظیمات (بخش‌بندی ، جست‌وجو ، کارت‌ها ، دکمه‌ی عقب)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1000)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='';render()"); await pg.wait_for_timeout(300)
            n=await pg.evaluate("document.querySelectorAll('#sgg .sc').length")
            chk(t+'hub shows 10 cards for main admin', n==10)
            chk(t+'search box exists', await pg.evaluate("!!document.getElementById('ssq')"))
            await pg.fill('#ssq','پشتیبان'); await pg.wait_for_timeout(200)
            chk(t+'search filters to backup', await pg.evaluate("document.querySelectorAll('#sgg .sc').length")==1)
            await pg.fill('#ssq','zzzz'); await pg.wait_for_timeout(150)
            chk(t+'search no result text', 'پیدا نشد' in await pg.evaluate("document.getElementById('sgg').innerText"))
            await pg.fill('#ssq',''); await pg.wait_for_timeout(150)
            chk(t+'no overflow hub', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.evaluate("go({sx:'bk'})"); await pg.wait_for_timeout(250)
            tx=await pg.evaluate("document.body.innerText")
            chk(t+'backup section opens (full+simple+migration)', 'پشتیبان کامل' in tx and 'گرفتن پشتیبان' in tx and 'انتقال به سرور جدید' in tx)
            chk(t+'no overflow backup', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk(t+'ab() goes back to hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx&&S.pnl&&S.at=='set'})()"))
            for k,needle in (('gen','قوانین'),('ver','نسخه'),('img','عکس'),('dg','عیب‌یابی پشتیبان')):
                await pg.evaluate("go({sx:'%s'})"%k); await pg.wait_for_timeout(200)
                chk(t+'section %s opens'%k, needle in await pg.evaluate("document.getElementById('scr').innerText"))
            await pg.evaluate("go({sx:''})")
            await pg.evaluate("go({tab:4,v:null,at:'st',sx:''})"); await pg.wait_for_timeout(250)
            chk(t+'shortcut stats opens', await pg.evaluate("S.at=='st'"))
            chk(t+'ab() from stats returns to settings hub', await pg.evaluate("(()=>{const r=ab();return r==1&&S.at=='set'&&S.pnl})()"))
            chk(t+'chips have no st/xf', not await pg.evaluate("!!document.querySelector('.chip[data-v=st],.chip[data-v=xf]')"))
            await pg.evaluate("S.at='x';render()"); await pg.wait_for_timeout(250)
            chk(t+'dashboard has pointer, not moved cards', 'ابزارهای مدیر اصلی' in await pg.evaluate("document.getElementById('scr').innerText") and not await pg.evaluate("!!document.getElementById('bkf_pw')"))
            # مدیر غیر اصلی: فقط بخش عمومی، مستقیم
            await pg.evaluate("S.role='admin';S.pm=['set'];S.at='set';S.sx='';render()"); await pg.wait_for_timeout(250)
            chk(t+'non-owner sees general directly', not await pg.evaluate("!!document.getElementById('sgg')") and 'قوانین' in await pg.evaluate("document.getElementById('scr').innerText") and 'پشتیبان کامل' not in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'no errors %s'%errs, not errs)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
