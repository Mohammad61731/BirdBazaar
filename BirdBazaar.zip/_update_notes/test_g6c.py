# تست 1.9.418 G6-c: ساعت کاری پیک (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnCrH({act:true})===''"))
        pg.evaluate("XF.pn=1;localStorage.removeItem('bp_crh')")
        chk(t+'no hours -> only chip',pg.evaluate("(()=>{const h=pnCrH({act:true});return h.includes('pncrh')&&!h.includes('bt_crn')})()"))
        chk(t+'in-range logic',pg.evaluate("pnCrIn(10,{f:8,t:20})&&!pnCrIn(21,{f:8,t:20})&&pnCrIn(23,{f:20,t:4})&&pnCrIn(2,{f:20,t:4})&&!pnCrIn(10,{f:20,t:4})"))
        pg.evaluate("window.bzAsk=(m,d,cb)=>cb(window.__ans);window.crSheet=()=>{}")
        def click(ans):
            pg.evaluate("window.__ans=%s"%ans)
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pncrh';b.dataset.v='0';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(200)
        click("'۸-۲۰'")
        chk(t+'persian digits parsed',pg.evaluate("(()=>{const j=pnCrHg();return j&&j.f==8&&j.t==20})()"))
        click("'25-3'")
        chk(t+'bad value ignored',pg.evaluate("(()=>{const j=pnCrHg();return j&&j.f==8&&j.t==20})()"))
        click("'5-5'")
        chk(t+'same hours ignored',pg.evaluate("pnCrHg().f==8"))
        pg.evaluate("localStorage.setItem('bp_crh',JSON.stringify({f:(new Date().getHours()+2)%24,t:(new Date().getHours()+3)%24}))")
        chk(t+'outside+online -> offline btn',pg.evaluate("(()=>{const h=pnCrH({act:true});return h.includes('data-a=\"bt_crn\" data-v=\"0\"')})()"))
        chk(t+'outside+offline -> note only',pg.evaluate("(()=>{const h=pnCrH({act:false});return h.includes('آفلاینی')&&!h.includes('bt_crn')})()"))
        pg.evaluate("localStorage.setItem('bp_crh',JSON.stringify({f:(new Date().getHours()+23)%24,t:(new Date().getHours()+1)%24}))")
        chk(t+'inside+offline -> online btn',pg.evaluate("pnCrH({act:false}).includes('data-a=\"bt_crn\" data-v=\"1\"')"))
        click("''")
        chk(t+'cleared',pg.evaluate("pnCrHg()===null"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
