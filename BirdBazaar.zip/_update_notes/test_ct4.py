# تست 1.9.257: ادغام سبد فروشگاه+غرفه (چیپ‌ها ، bt_cart ، نشان)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("BT.prods=[{id:9,b:1,d:{name:'تست',type:'plain',price:1000}}];BC=[{p:9,q:2,m:'r'}];D.cart=[];S.tab=3;S.v=null;render()");pg.wait_for_timeout(300)
        chk(f'{w}: only booth -> no chips',pg.locator('.chip[data-a=cs]').count()==0 and 'سبد غرفه' in pg.evaluate("cartV()"))
        pid=pg.evaluate("D.products[0]&&D.products[0].id")
        if pid:
            pg.evaluate(f"D.cart=[{{id:{pid},q:1}}];render()");pg.wait_for_timeout(300)
            chk(f'{w}: 3 chips',pg.locator('.chip[data-a=cs]').count()==3)
            h=pg.evaluate("cartV()");chk(f'{w}: all shows two summaries',pg.locator('.card [data-a=cs]').count()==2 and 'مشخصات خریدار' not in h)
            pg.locator('.chip[data-a=cs][data-v=bt]').click();pg.wait_for_timeout(200)
            h=pg.evaluate("cartV()");chk(f'{w}: bt only','سبد غرفه' in h and 'مشخصات خریدار' not in h)
            pg.locator('.chip[data-a=cs][data-v=st]').click();pg.wait_for_timeout(200)
            h=pg.evaluate("cartV()");chk(f'{w}: st only','مشخصات خریدار' in h and 'سبد غرفه' not in h)
            chk(f'{w}: badge sum',pg.evaluate("cbn()")==2)
            chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.evaluate("S.tab=0;S.v=null;render();document.body.insertAdjacentHTML('beforeend','<button id=tb data-a=bt_cart></button>')");pg.locator('#tb').click(force=True);pg.wait_for_timeout(300)
        chk(f'{w}: bt_cart opens cart tab',pg.evaluate("S.tab===3&&!S.v&&S.cs==='bt'"))
    br.close()
print('ERRORS',errs)
