# تست 1.9.436 D2-c3b: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=0")
        chk(t+'off -> no button',pg.evaluate("dtOwnH()===''"))
        pg.evaluate("XF.dt=1")
        chk(t+'on -> button',pg.evaluate("dtOwnH().includes('dtnw')"))
        pg.evaluate("window.__a=['علی','0912 123 4567','دو قفس','۳۰۰۰۰۰'];bzAsk=(m,d,cb)=>cb(window.__a.shift());BT.u='u';BT.p='p';BOR=[1];0")
        RES[0]='{"err":"denied"}'
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtnw';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'denied -> BOR kept',len(calls)==1 and pg.evaluate("Array.isArray(BOR)"))
        pg.evaluate("window.__a=['علی','0912 123 4567','دو قفس','۳۰۰۰۰۰']")
        RES[0]='{"ok":1}'
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtnw';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'ok -> ow_new payload',len(calls)==2 and '"ow_new"' in calls[1] and '"t":"300000"' in calls[1] and '"ph":"09121234567"' in calls[1].replace(' ',''))
        pg.evaluate("window.__a=['x','123','a','5']")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtnw';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(500)
        chk(t+'bad input -> no call',len(calls)==2)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
