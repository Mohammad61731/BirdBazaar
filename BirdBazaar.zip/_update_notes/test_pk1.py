# تست 1.9.454 D3-x: زمان آماده‌سازی و برچسب مراقبت (کلید pk)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("BF=Object.assign(btNew(),{prep:'۲ ساعت',care:'f'});XF.pk=0")
        chk(t+'off: form empty',pg.evaluate("pkForm()===''"))
        chk(t+'off: rows empty',pg.evaluate("pkRows({prep:'x',care:'f'}).length===0"))
        pg.evaluate("XF.pk=1")
        chk(t+'on: form fields',pg.evaluate("pkForm().includes('bfpp')&&pkForm().includes('bfcr')&&pkForm().includes('selected')"))
        chk(t+'on: rows 2',pg.evaluate("pkRows({prep:'۲ ساعت',care:'c'}).length===2"))
        chk(t+'bad care ignored',pg.evaluate("pkRows({care:'zzz'}).length===0"))
        chk(t+'tabs show',pg.evaluate("btTabs({id:1},{name:'a',type:'plain',price:5,prep:'۲ ساعت',care:'h',cat:'x'},null).includes('آماده')"))
        pg.evaluate("XF.pk=0")
        chk(t+'tabs off hide',pg.evaluate("!btTabs({id:1},{name:'a',type:'plain',price:5,prep:'۲ ساعت',care:'h',cat:'x'},null).includes('آماده')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
print('ERRORS',errs)
