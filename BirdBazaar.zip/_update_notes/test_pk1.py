# تست 1.9.510 PK1: کارت سفارش پیک
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.pn=1;XF.qm=1;CRM.u='u';CRM.p='p';CRM.r={st:'ok',name:'پیک',act:true,cap:3};CRM.j={my:[{id:7,b:1,bn:'غرفه یک',bp:'09120000000',s:'pick',f:15000,name:'مشتری',phone:'09121111111',addr:'تهران خیابان آزادی',n:2,t:50000},{id:8,b:1,bn:'غرفه دو',bp:'09123333333',s:'way',f:9000,name:'مشتری ۲',phone:'09124444444',addr:'کرج',n:1,t:1000},{id:9,b:1,bn:'غرفه سه',bp:'09125555555',s:'acc',f:0,name:'م۳',phone:'09126666666',addr:'ری',n:1,t:1000}],av:[]};crSheet()");pg.wait_for_timeout(400)
        chk(t+'cards',pg.evaluate("document.querySelectorAll('.bzkc').length==3"))
        chk(t+'fee big',pg.evaluate("!!document.querySelector('.bzkf b')"))
        chk(t+'primary per step',pg.evaluate("!!document.querySelector('[data-a=bt_crw]')&&!!document.querySelector('[data-a=bt_crd]')"))
        chk(t+'call+route',pg.evaluate("document.querySelectorAll('.bzks a').length>=4"))
        chk(t+'settings folded',pg.evaluate("!!document.querySelector('details.bzkd')&&!document.querySelector('details.bzkd[open]')&&!!document.querySelector('[data-a=bt_crn]')"))
        chk(t+'online header',pg.evaluate("document.querySelector('.bzko').textContent.includes('آنلاین')"))
        chk(t+'msg tabs',pg.evaluate("(()=>{const b=document.querySelector('[data-a=bz_kt][data-v=b]');if(!b)return false;b.click();const m=b.closest('.bzkm');return !m.querySelector('.bzkp[data-k=b]').hidden&&m.querySelector('.bzkp[data-k=c]').hidden})()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none'");pg.screenshot(path='/tmp/claude-0/p/pk1_360.png')
        ctx.close()
    br.close()
print('ERRS',errs)
