# تست 1.9.133: مرجوعی rt
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
calls=[]
def fapp(route,req):
    b=json.loads(req.post_data);o=b['op'];r={'err':'x'}
    if o=='myorders':r={'ok':1,'l':[{'id':7,'dt':'d','tt':1000,'st':'done','it':[{'n':'a','q':1}]}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
def tapp(route,req):
    b=json.loads(req.post_data);calls.append(b['op'])
    r={'ok':1,'l':[{'id':7,'r':2,'t':'اشتباه آمد','s':'new'}]} if b['op'] in('rmine','rlist') else {'ok':1}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.route('**/rpc/fapp',fapp);pg.route('**/rpc/tapp',tapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t='%d%s '%(w,'d' if dark else 'l');calls.clear()
            pg.evaluate("S.me='u1';S.pw='p';XF.rt=0;moOpen()");pg.wait_for_timeout(500)
            chk(t+'off: no tapp call, no button',not calls and 'مرجوعی' not in pg.inner_text('#scr'))
            pg.evaluate("XF.rt=1;moOpen()");pg.wait_for_timeout(700)
            chk(t+'on: status + rmine','اشتباه آمد' in pg.inner_text('#scr') and 'rmine' in calls)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            pg.evaluate("delete RTN[7];render()");pg.wait_for_timeout(150)
            pg.evaluate("document.querySelector('[data-a=rts]').click()");pg.wait_for_timeout(500)
            chk(t+'sheet opens, no prompt',pg.evaluate("!!document.querySelector('#rto')"))
            pg.evaluate("document.querySelector('[data-a=rtgo]').click()");pg.wait_for_timeout(200)
            chk(t+'no type = no rset','rset' not in calls)
            pg.evaluate("document.querySelector('[data-a=rtpick][data-v=\"2\"]').click()");pg.fill('#rtt','x')
            pg.evaluate("document.querySelector('[data-a=rtgo]').click()");pg.wait_for_timeout(500)
            chk(t+'submit sends rset','rset' in calls)
            chk(t+'sheet closed',pg.evaluate("!document.querySelector('#rto')"))
            chk(t+'sheet no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs)
