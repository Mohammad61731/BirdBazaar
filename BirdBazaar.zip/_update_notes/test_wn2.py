# تست 1.9.280: P28 «برای شما» + P38 «خبرم کن» روی کارت ناموجود
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("XF.wn=1;S.me='u';S.pw='p';BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'',bio:'',phone:''}];BT.prods=[{id:11,b:1,s:'on',d:{name:'دان',type:'plain',price:50000,emoji:'🌰',imgs:[],cat:'دان',out:1}},{id:12,b:1,s:'on',d:{name:'قفس',type:'plain',price:10,emoji:'🏠',imgs:[],cat:'دان'}}];D.products.forEach(x=>x.cat='دان');localStorage.setItem(RVK,JSON.stringify(['p'+D.products[0].id]));go({tab:0,v:null})")
            pg.wait_for_timeout(400)
            chk(t+'bell only on sold-out card',pg.locator('.bzwn').count()>=1 and pg.locator('.bxc:not(.soldout) .bzwn').count()==0)
            chk(t+'for-you title with reason','برای شما' in pg.evaluate("document.getElementById('scr').textContent") and pg.locator('.bzwhy').count()>=1)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            if w==360 and not dark: pg.locator('.bzwn').first.scroll_into_view_if_needed();pg.screenshot(path='/tmp/wn360.png')
            pg.locator('.bzwn').first.click();pg.wait_for_timeout(300)
            chk(t+'tap toggles notify, stays on home',pg.evaluate("S.v")!='btp' and pg.evaluate("wnGet().includes(11)"))
            ctx.close()
    br.close()
print('ERRORS',errs)
