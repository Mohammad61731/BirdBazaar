import json
from playwright.sync_api import sync_playwright
errs=[]
B=[{'id':1,'owner':'ali','name':'Ali Shop','city':'A','phone':'1','status':'active','views':5,'n':3,'o':9},
   {'id':2,'owner':'sara','name':'Sara Birds','city':'B','phone':'2','status':'off','views':50,'n':1,'o':2},
   {'id':3,'owner':'reza','name':'Reza Seeds','city':'C','phone':'3','status':'active','views':20,'n':8,'o':0}]
def h(route,req):
    if req.url.endswith('/rpc/bapp'):
        b=json.loads(req.post_data)
        r={'ok':1,'reqs':[],'booths':B} if b['op'].startswith('badm_') else {'ok':1,'booths':[],'prods':[]}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
vis=lambda pg:pg.evaluate("[...document.querySelectorAll('#btl>.card')].filter(x=>x.style.display!='none').map(x=>x.querySelector('b').innerText.trim().split(' ')[0]+x.querySelector('b').innerText.trim().split(' ')[1])")
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else h(r,q))
        pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1';go({tab:4,pnl:1,at:'bt',v:null})");pg.wait_for_timeout(900)
        r={'all3':pg.locator('#btl>.card').count()==3,'orders_shown':'9' in pg.locator('#btl>.card').first.inner_text() or '۹' in pg.locator('#btl>.card').first.inner_text()}
        pg.click('[data-a=bt_af][data-v=active]');pg.wait_for_timeout(300);r['active2']=pg.locator('#btl>.card').count()==2
        pg.click('[data-a=bt_af][data-v=off]');pg.wait_for_timeout(300);r['off1']=pg.locator('#btl>.card').count()==1
        pg.click('[data-a=bt_af][data-v=all]');pg.click('[data-a=bt_as][data-v=views]');pg.wait_for_timeout(300)
        r['sort_views_first_sara']='sara' in pg.locator('#btl>.card').first.inner_text()
        pg.click('[data-a=bt_as][data-v=n]');pg.wait_for_timeout(300);r['sort_n_first_reza']='reza' in pg.locator('#btl>.card').first.inner_text()
        pg.fill('#btq','ali');pg.wait_for_timeout(200)
        r['search_ali']=pg.evaluate("[...document.querySelectorAll('#btl>.card')].filter(x=>x.style.display!='none').length")==1
        r['overflow']=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1")
        print(w,r)
    print('ERRORS',errs);br.close()
