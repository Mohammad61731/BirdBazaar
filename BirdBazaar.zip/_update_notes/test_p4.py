import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[];reqs=[];MODE={'renew':'ok'}
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:b=json.loads(q.post_data or '{}')
    except Exception:b={}
    reqs.append(b);o=b.get('op')
    if o=='adx_list':body={'ok':1,'l':[{'ad':12,'s':True,'r':None},{'ad':13,'s':False,'r':'2026-11-15T10:00:00Z'}]}
    elif o=='adx_renew' and MODE['renew']=='wait':body={'err':'wait'}
    else:body={'ok':1}
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
SETUP="""S.role='user';S.me='ali';S.pw='x';S.pm=[];AX={};AXS='';
D.ads=[{id:11,title:'اول',sp:'x',price:1,desc:'x',imgs:[],st:'ok',own:'ali'},{id:12,title:'دوم-فروخته',sp:'x',price:2,desc:'x',imgs:[],st:'ok',own:'sara'},{id:13,title:'سوم-تمدید',sp:'x',price:3,desc:'x',imgs:[],st:'ok',own:'sara'},{id:14,title:'چهارم',sp:'x',price:4,desc:'x',imgs:[],st:'ok',own:'sara'}]"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_page(viewport={'width':w,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700);pg.evaluate(SETUP)
        pg.evaluate("axPull()");pg.wait_for_timeout(500)
        chk('w%d AX از adx_list پر شد'%w,pg.evaluate("AX[12]&&AX[12].s===true&&AX[13]&&AX[13].r>0"))
        chk('w%d ترتیب: تمدیدشده اول، فروخته‌شده آخر'%w,pg.evaluate("okAds().map(a=>a.id).join()")=='13,11,14,12')
        pg.evaluate("go({tab:2,v:null})");pg.wait_for_timeout(200)
        chk('w%d کارت فروخته‌شده نشان دارد'%w,pg.locator('.ad.soldad').count()==1 and '🔴 فروخته شد' in pg.inner_text('.ad.soldad'))
        pg.evaluate("go({v:'ad',id:11})");pg.wait_for_timeout(200)
        chk('w%d صاحب آگهی دو دکمه می‌بیند'%w,pg.locator('[data-a=axs]').count()==1 and pg.locator('[data-a=axr]').count()==1)
        pg.evaluate("go({v:'ad',id:12})");pg.wait_for_timeout(200)
        chk('w%d غیرصاحب دکمه نمی‌بیند'%w,pg.locator('[data-a=axs]').count()==0)
        chk('w%d بدون سرریز'%w,pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.close()
    pg=br.new_page(viewport={'width':360,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700);pg.evaluate(SETUP)
    pg.evaluate("go({v:'ad',id:11})");pg.wait_for_timeout(200)
    reqs.clear();pg.click('[data-a=axs]');pg.wait_for_timeout(500)
    chk('adx_sold با on=true',any(r.get('op')=='adx_sold' and r['a'].get('ad')==11 and r['a'].get('on') is True for r in reqs))
    chk('آگهی فروخته‌شد علامت خورد و دکمه برگرداندن شد',pg.evaluate("AX[11].s===true")and 'دوباره موجود' in pg.inner_text('[data-a=axs]'))
    reqs.clear();pg.click('[data-a=axs]');pg.wait_for_timeout(500)
    chk('بازگشت: on=false',any(r.get('op')=='adx_sold' and r['a'].get('on') is False for r in reqs) and pg.evaluate("AX[11].s===false"))
    reqs.clear();pg.click('[data-a=axr]');pg.wait_for_timeout(500)
    chk('تمدید: adx_renew و r ثبت شد',any(r.get('op')=='adx_renew' for r in reqs) and pg.evaluate("AX[11].r>0"))
    MODE['renew']='wait';pg.evaluate("AX[11].r=0");pg.click('[data-a=axr]');pg.wait_for_timeout(500)
    chk('پاسخ wait: r تغییر نکرد',pg.evaluate("AX[11].r===0") and 'ساعت' in pg.inner_text('#toast') if pg.locator('#toast').count() else pg.evaluate("AX[11].r===0"))
    br.close()
chk('بدون خطای صفحه',not errs)
print('ALL PASS' if all(ok) else 'SOME FAIL',errs[:2])
