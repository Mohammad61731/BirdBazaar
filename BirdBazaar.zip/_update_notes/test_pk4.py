# تست 1.9.518 PK4: صیقل پنل پیک (کد ۴ رقمی ، نوار مرحله ، متن فارسی ، بخش‌های بازشو)
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
ST="XF.cg=1;XF.cp=1;XF.cr=1;XF.pn=1;XF.qm=1;CRM.u='u';CRM.p='p';CRM.r={st:'ok',name:'محمد',veh:'p',area:'سراوان',act:true,cap:3};CRM.j={my:[{id:6657,b:1,bn:'دلی شاپ',bp:'09396325194',s:'way',f:35000,name:'محمد',phone:'09121111111',addr:'6657 · ارسال با پیک: منطقه‌ی متوسط ؛ کرایه‌ی 35000 تومان در مبلغ سفارش لحاظ شده',n:2,t:50000}],av:[]};crSheet()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate(ST);pg.wait_for_timeout(400)
        chk(t+'close btn',pg.evaluate("!!document.querySelector('.bzkroot [data-a=clo2]')"))
        chk(t+'progress bar 5 segs',pg.evaluate("document.querySelectorAll('.bzkc .bzbar i').length==5&&document.querySelector('.bzbl').textContent.includes('در راه')"))
        chk(t+'deliver disabled until 4 digits',pg.evaluate("(()=>{const i=document.querySelector('.bzcdi'),b=document.querySelector('[data-a=bt_crd]');if(!i||!b||!b.disabled)return false;i.value='12';bzCd(i);if(!b.disabled)return false;i.value='1234';bzCd(i);return !b.disabled})()"))
        chk(t+'persian digits in card',pg.evaluate("(()=>{const c=document.querySelector('.bzkc').innerText;return !/[0-9]/.test(c.replace(/\\s/g,'').replace(/[^0-9]/g,'')?'':'')&&c.includes('۰۹۳۹۶۳۲۵۱۹۴')})()"))
        chk(t+'dest row',pg.evaluate("[...document.querySelectorAll('.bzkw span')].map(x=>x.textContent).join()=='مشتری,مقصد'"))
        chk(t+'sections have chevron+closed',pg.evaluate("document.querySelectorAll('details.bzkd').length>=2&&!document.querySelector('details.bzkd[open]')"))
        chk(t+'no exit at top level',pg.evaluate("!document.querySelector('.bzkroot>[data-a=bt_cro]')&&!!document.querySelector('details.bzkd .bzex')"))
        chk(t+'refresh labeled',pg.evaluate("document.querySelector('[data-a=bt_crj]').textContent.includes('به‌روزرسانی')"))
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.querySelector('.sheet').scrollWidth<=document.querySelector('.sheet').clientWidth+1"))
        if w==360:
            pg.screenshot(path='/tmp/pk4_%s.png'%sch[0])
        ctx.close()
    br.close()
print('ERRS',errs)
