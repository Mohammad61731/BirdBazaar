import json,sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
errs=[];ok=[];MAIN=[True]
ROOMS=[{'id':7,'name':'عمومی','emoji':'🦜','color':''}]
MS=[{'id':1,'u':'reza','k':'text','b':'سلام','md':None,'rt':None,'pin':False,'ed':False,'t':'2026-11-13T08:00:00Z','r':{}}]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);o=b['op'];r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'admin' if MAIN[0] else 'user','main':MAIN[0],'perm':{'txt':True},'avatar':''}
        if o=='fpull':r={'ok':1,'rooms':ROOMS,'msgs':MS,'av':{},'pins':[],'reqn':0}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept());pg.route('**/*',h)
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='adm';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(1500)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    chk('1 نوار قوانین بالای اتاق',pg.locator('.frl').count()==1)
    pg.click('.frl');pg.wait_for_timeout(300)
    chk('2 متن پیش‌فرض قوانین در برگه','تبلیغ' in pg.inner_text('.sheet') and pg.locator('[data-a=fr_ed]').count()==1)
    pg.screenshot(path=P+'/shots/p9_rules.png');pg.evaluate("cl()")
    chk('3 دکمه‌ی ⚡ برای ادمین',pg.locator('[data-a=fr_cn]').count()==1)
    pg.click('[data-a=fr_cn]');pg.wait_for_timeout(300)
    chk('4 چهار پاسخ آماده',pg.locator('[data-a=fr_pk]').count()==4)
    pg.click('[data-a=fr_pk][data-v="2"]');pg.wait_for_timeout(200)
    chk('5 پاسخ در کادر پیام نشست و برگه بسته شد','قوانین انجمن را رعایت' in pg.input_value('#ci') and pg.locator('.sheet').count()==0)
    pg.fill('#ci','')
    pg.click('.frl');pg.click('[data-a=fr_ed]');pg.wait_for_timeout(200)
    pg.fill('#frt','۱) قانون تازه');pg.fill('#frc','پاسخ یک\nپاسخ دو\n\n');pg.click('[data-a=fr_sv]');pg.wait_for_timeout(500)
    chk('6 ذخیره در D.cms.FR',pg.evaluate("JSON.stringify(D.cms.FR)")==json.dumps({'on':1,'rules':'۱) قانون تازه','canned':['پاسخ یک','پاسخ دو']},ensure_ascii=False,separators=(',',':')))
    chk('7 در حافظه‌ی گوشی ذخیره شد',pg.evaluate("JSON.parse(localStorage.getItem(K)).cms.FR.rules")=='۱) قانون تازه')
    pg.click('[data-a=fr_cn]');pg.wait_for_timeout(200)
    chk('8 پاسخ‌های تازه',pg.locator('[data-a=fr_pk]').count()==2);pg.evaluate("cl()")
    # کاربر عادی
    MAIN[0]=False
    pg.evaluate("S.role='user';S.pm=[];S.me='ali';FM.ok=0;FM.main=0;go({tab:5,v:null})");pg.wait_for_timeout(1200)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    chk('9 کاربر عادی نوار را می‌بیند',pg.locator('.frl').count()==1)
    chk('10 کاربر عادی ⚡ ندارد',pg.locator('[data-a=fr_cn]').count()==0)
    pg.click('.frl');pg.wait_for_timeout(300)
    chk('11 کاربر عادی متن تازه را می‌بیند و دکمه‌ی ویرایش ندارد','قانون تازه' in pg.inner_text('.sheet') and pg.locator('[data-a=fr_ed]').count()==0)
    pg.evaluate("cl()")
    # خاموش کردن
    pg.evaluate("D.cms.FR.on=0;render()");pg.wait_for_timeout(300)
    chk('12 خاموش = بدون نوار',pg.locator('.frl').count()==0)
    pg.evaluate("D.cms.FR.on=1;render()");pg.wait_for_timeout(300)
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
