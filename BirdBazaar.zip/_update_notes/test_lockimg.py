# تست 1.9.63: قفل نسخه + کوچک‌کردن عکس‌های موجود
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            saved=[]
            async def h(route):
                u=route.request.url; bd=route.request.post_data or ''
                if not u.startswith('http'): return await route.continue_()
                try: o=json.loads(bd).get('op')
                except Exception: o=None
                if o in ('products_set','stories_set','ad_set'): saved.append(o)
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'s':'a','b':'b'}))
            await pg.route('**/*',h)
            pg.on('dialog',lambda d:asyncio.ensure_future(d.accept()))
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
            # --- قفل نسخه
            await pg.evaluate("S.role='user';S.me='u1';D.cms.MV={min:'9.0.0',url:'https://example.com/a.apk',msg:'تست',f:1};mvCheck()")
            chk('%d lock overlay shown'%w, await pg.evaluate("!!document.getElementById('mvo')") and await pg.evaluate("!document.getElementById('mvx')"))
            chk('%d lock has download btn'%w, await pg.evaluate("!!document.getElementById('mvu')"))
            chk('%d no overflow lock'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.evaluate("S.role='admin';S.pm=['all'];mvCheck()")
            chk('%d main admin never locked'%w, not await pg.evaluate("!!document.getElementById('mvo')"))
            await pg.evaluate("S.role='user';S.pm=[];D.cms.MV={min:'9.0.0',url:'',msg:'',f:0};mvCheck()")
            chk('%d soft lock has later btn'%w, await pg.evaluate("!!document.getElementById('mvx')"))
            await pg.evaluate("document.getElementById('mvx').click()"); chk('%d later dismisses'%w, not await pg.evaluate("!!document.getElementById('mvo')"))
            await pg.evaluate("sessionStorage.clear();D.cms.MV={min:'0.0.1'};mvCheck()"); chk('%d lower min: no lock'%w, not await pg.evaluate("!!document.getElementById('mvo')"))
            chk('%d vCmp'%w, await pg.evaluate("vCmp('1.9.63','1.9.9')==1&&vCmp('1.9.63','1.9.63')==0&&vCmp('1.9.62','1.9.63')==-1&&vCmp('1.10.0','1.9.99')==1"))
            # --- ابزار عکس
            big=await pg.evaluate("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=1200;const x=c.getContext('2d');for(let i=0;i<400;i++){x.fillStyle='hsl('+(i*7%360)+',70%,50%)';x.fillRect(Math.random()*1600,Math.random()*1200,200,150)}return c.toDataURL('image/png')}""")
            await pg.evaluate("(b)=>{S.role='admin';S.me='adm';S.pm=['all'];S.pnl=1;S.at='x';D.products[0].img=b;D.products[0].imgs=[b,b];D.stories[0].img=b;D.ads=[{id:5,title:'t',imgs:[b],st:'ok'}]}",big)
            r=await pg.evaluate("imgShrink(false)")
            print(r['n'],r['b'],r['a'])
            chk('%d dry run finds images'%w, r['n']>=1 and r['a']<r['b']*0.5)
            chk('%d dry run changes nothing'%w, await pg.evaluate("(b)=>D.products[0].img==b",big) and not saved)
            r=await pg.evaluate("imgShrink(true)"); await pg.wait_for_timeout(500)
            chk('%d apply: smaller & saved'%w, await pg.evaluate("D.products[0].img.length")<len(big)*.3 and 'products_set' in saved and 'stories_set' in saved and 'ad_set' in saved)
            chk('%d product img shared with imgs[0]'%w, await pg.evaluate("D.products[0].img===D.products[0].imgs[0]"))
            r2=await pg.evaluate("imgShrink(false)"); chk('%d second run: nothing more'%w, r2['n']==0)
            await pg.evaluate("render()"); await pg.wait_for_timeout(300)
            t=await pg.evaluate("mvCard()+imgCard()"); chk('%d cards render'%w,'قفل نسخه' in t and 'کوچک‌کردن عکس' in t)
            chk('%d no overflow admin'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk('%d no errors %s'%(w,errs), not errs)
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
