import json,datetime
from playwright.sync_api import sync_playwright
errs=[];calls=[]
ST={'perm':{'txt':False,'img':False,'vid':False,'fil':False,'muted':False,'blocked':False},'dup':False,'down':False,'nid':100}
t0=datetime.datetime(2026,11,12,8,0)
MS=[{'id':i,'u':['sara','ali','reza'][i%3],'k':'text','b':'پیام شماره %d'%i,'md':None,'rt':None,'pin':False,'t':(t0+datetime.timedelta(hours=i*2)).isoformat()+'Z','r':{}} for i in range(1,36)]
MS[3]['k']='img';MS[3]['md']='data:image/gif;base64,R0lGODlhAQABAAAAACw=';MS[3]['b']=''
MS[6]['rt']=3
PINS=[{'id':2,'u':'sara','b':'قوانین انجمن را بخوانید'}]
AV={'sara':'data:image/gif;base64,R0lGODlhAQABAAAAACw='}
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        if ST['down']:return route.fulfill(status=404,body='x')
        b=json.loads(req.post_data);calls.append(b);o=b['op'];a=b['a'];r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':False,'perm':ST['perm'],'avatar':''}
        if o=='fpull':
            rows=[m for m in MS if m['id']>a.get('after',0) and m['id']<a.get('before',10**9)];rows=rows[-a.get('n',30):]
            r={'ok':1,'rooms':[{'id':7,'name':'گفتگوی عمومی','emoji':'🦜'},{'id':8,'name':'سلامت','emoji':'🩺'}],'msgs':rows if a.get('room')==7 else [],'av':AV,'pins':PINS,'reqn':0}
        if o=='freq':r={'err':'dup'} if ST['dup'] else {'ok':1};ST['dup']=True
        if o=='fsend':
            ST['nid']+=1;MS.append({'id':ST['nid'],'u':b['u'],'k':'text','b':a['b'],'md':None,'rt':None,'pin':False,'t':datetime.datetime(2026,11,13,9,0).isoformat()+'Z','r':{}});r={'ok':1,'id':ST['nid']}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("go({tab:5,v:null})");pg.wait_for_timeout(300);print('guest gate:',pg.locator('[data-a=gologin]').count()==1)
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(900)
    print('rooms from server:',pg.locator('#rlist .rm').count(),'| demo banner absent:',pg.locator('.demo').count()==0)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    print('messages shown:',pg.locator('.fmr').count(),'| date chips:',pg.locator('.fmd').count(),'| image msg:',pg.locator('.fmb img').count(),'| reply quote:',pg.locator('.fmq').count(),'| pinned bar:',pg.locator('#fpin').is_visible(),'| old button:',pg.locator('[data-a=fold]').count())
    print('avatar img for sara:',pg.evaluate("[...document.querySelectorAll('.fma')].some(e=>e.style.backgroundImage.includes('data:'))"),'| scrolled to bottom:',pg.evaluate("(()=>{const s=document.querySelector('#scr');return s.scrollHeight-s.scrollTop-s.clientHeight<5})()"))
    print('no-permission: input hidden:',pg.locator('#ci').count()==0,'| request btn:',pg.locator('[data-a=freq_go]').count());pg.screenshot(path='../shots/f3_chat_noperm.png')
    pg.click('[data-a=freq_go]');pg.wait_for_timeout(400);print('request sheet opens (F4):',pg.locator('#ov.on').count()==1);pg.click('[data-a=clo2]');pg.wait_for_timeout(300)
    pg.click('[data-a=fold]');pg.wait_for_timeout(600);print('after old: msgs',pg.locator('.fmr').count(),'| before param used:',any(c['op']=='fpull' and 'before' in c['a'] for c in calls))
    ST['perm']['txt']=True;pg.evaluate("FM.perm.txt=true;fOpen(7)");pg.wait_for_timeout(900)
    print('with permission: input shown:',pg.locator('#ci').count()==1)
    pg.fill('#ci','سلام به همه');pg.press('#ci','Enter');pg.wait_for_timeout(900)
    print('sent:',sum(c['op']=='fsend' for c in calls),'| my bubble right (out):',pg.locator('.fmr.out').count(),'| input cleared:',pg.input_value('#ci')=='');pg.screenshot(path='../shots/f3_chat.png')
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(200);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    ST['down']=True;pg.evaluate("FL=0;FM.t=0;go({v:null,tab:5})");pg.wait_for_timeout(900);print('server down -> demo fallback:',pg.locator('#rlist .rm').count()==4,'| banner:',pg.locator('.box b').first.inner_text())
    print('ERRORS',errs);br.close()
