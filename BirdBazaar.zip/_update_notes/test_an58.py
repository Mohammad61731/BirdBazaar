# تست 1.9.306: AN58 پَف انتخاب آیکن در مدیریت آیکن
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.set_default_timeout(8000)
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                # شیت مدیریت آیکن به‌عنوان ادمین ؛ پَف فقط روی ردیف انتخاب‌شده
                ok=pg.evaluate("(()=>{try{S.role='admin';S.pm=['br'];const first=ikS[0][0];window.__icpf=first;icSheet();const n=document.querySelectorAll('#ov .icpf').length;window.__icpf=null;icSheet();const z=document.querySelectorAll('#ov .icpf').length;return [n,z,String(first)]}catch(e){return ['ERR '+e.message]}})()")
                chk(t+'AN58 one puff row',ok[0]==1 and ok[1]==0)
                pg.evaluate("const d=document.createElement('span');d.className='icpf';d.id='tpf';d.textContent='★';document.getElementById('scr').appendChild(d);0")
                a=pg.evaluate("getComputedStyle(document.getElementById('tpf')).animationName")
                if rm=='no-preference': chk(t+'AN58 anim',a=='anpf')
                else: chk(t+'AN58 reduced none',a in ('none',''))
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
