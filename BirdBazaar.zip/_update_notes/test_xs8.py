# تست 1.9.335: استودیو T2-c تاری شیشه‌ای/فیلتر/کپی-چسباندن/اندازه‌ی کارت/ستون/جای عکس (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
            ids=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(b=>b.dataset.b)")
            gid=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.grid .pc,.grid .bxc'));return b?b.dataset.b:null})()")
            b=gid or ids[1];c=[i for i in ids if i!=b][0]
            chk(t+'has grid block',bool(gid))
            pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
            chk(t+'controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-xs="bl"]','#ov [data-xs="fb"]','#ov [data-xs="fc"]','#ov [data-xs="fs"]','#ov [data-xs="fg"]','#ov [data-xc$=":cc:3"]','#ov [data-xc$=":cs:2"]','#ov [data-xc$=":ip:3"]','#ov [data-xg^="cp:"]','#ov [data-xg^="ps:"]')))
            fire(pg,'#ov [data-xs="bl"]',8);fire(pg,'#ov [data-xs="fb"]',120);fire(pg,'#ov [data-xs="fc"]',110);fire(pg,'#ov [data-xs="fs"]',150);fire(pg,'#ov [data-xs="fg"]',30)
            chk(t+'live filter',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return e.style.filter.includes('brightness(1.2)')&&e.style.filter.includes('grayscale(0.3)')&&(e.style.backdropFilter||e.style.webkitBackdropFilter||'').includes('blur(8px)')}",b))
            chk(t+'label unit',pg.evaluate("document.querySelector('#ov [data-xs=\"fb\"]').nextElementSibling.textContent.includes('٪')"))
            clk(pg,'#ov [data-xc$=":cc:3"]');clk(pg,'#ov [data-xc$=":cs:2"]');clk(pg,'#ov [data-xc$=":ip:1"]')
            st=pg.evaluate("(i)=>D.cms.ST['home:'+i]",b)
            chk(t+'saved',st and st['bl']==8 and st['fb']==120 and st['fc']==110 and st['fs']==150 and st['fg']==30 and st['cc']==3 and st['cs']==2 and st['ip']==1)
            pg.evaluate("cl();render()");pg.wait_for_timeout(300)
            r=pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]'),c=getComputedStyle(e),g=e.querySelector('.grid');return [c.filter,e.style.getPropertyValue('--xcc').trim(),e.style.getPropertyValue('--xcs').trim(),e.style.getPropertyValue('--xip').trim(),g?getComputedStyle(g).gridTemplateColumns.split(' ').length:0]}",b)
            chk(t+'applied after render',('brightness(1.2)' in r[0]) and r[1]=='3' and r[2]=='2' and r[3]=='1' and r[4]==3)
            chk(t+'css rules',pg.evaluate("(()=>{const x=document.getElementById('stg').textContent;return x.includes('var(--xcc)')&&x.includes('--xcs')&&x.includes('--xip')})()"))
            chk(t+'no overflow 3col',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            for cc,n in ((1,1),(2,2),(4,4)):
                pg.evaluate("(a)=>{stSet('home:'+a[0],'cc',a[1],1)}",[b,cc]);pg.evaluate("cl();render()");pg.wait_for_timeout(200)
                chk(t+'cols '+str(cc),pg.evaluate("(i)=>{const g=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid');return g&&getComputedStyle(g).gridTemplateColumns.split(' ').length}",b)==n)
                chk(t+'no overflow cc'+str(cc),pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            # live apply without render (inline style serialization with space)
            pg.evaluate("(i)=>{stSet('home:'+i,'cc',3,0)}",b)
            chk(t+'live cols 3',pg.evaluate("(i)=>{const g=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid');return g&&getComputedStyle(g).gridTemplateColumns.split(' ').length}",b)==3)
            # image placement
            pg.evaluate("(i)=>{stSet('home:'+i,'ip',3,0)}",b);pg.wait_for_timeout(150)
            chk(t+'ip background',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid .pc>.pi,.hg .hbk[data-b=\"'+i+'\"] .grid .bxc>.bxi');return !!e&&getComputedStyle(e).position=='absolute'}",b))
            pg.evaluate("(i)=>{stSet('home:'+i,'ip',2,0)}",b);pg.wait_for_timeout(150)
            chk(t+'ip side',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid .pc,.hg .hbk[data-b=\"'+i+'\"] .grid .bxc');return !!e&&getComputedStyle(e).flexDirection=='row'}",b))
            pg.evaluate("(i)=>{stSet('home:'+i,'ip',1,1)}",b)
            # copy / paste
            pg.evaluate("(a)=>{stSet('home:'+a[1],'nm','x',0);D.cms.ST['home:'+a[1]].nm='نام من'}",[b,c])
            pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200);clk(pg,'#ov [data-xg^="cp:"]')
            chk(t+'clip set',pg.evaluate("!!window.XCLIP&&window.XCLIP.bl==8&&window.XCLIP.nm===undefined&&window.XCLIP.lk===undefined"))
            pg.evaluate("(i)=>bsheet(i,'home')",c);pg.wait_for_timeout(200);clk(pg,'#ov [data-xg^="ps:"]');pg.wait_for_timeout(300)
            chk(t+'pasted',pg.evaluate("(i)=>{const s=D.cms.ST['home:'+i];return s&&s.bl==8&&s.fb==120&&s.cs==2&&s.nm=='نام من'}",c))
            chk(t+'pasted applied',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return e.style.filter.includes('brightness(1.2)')}",c))
            # reset
            pg.evaluate("(a)=>{stDel('home:'+a[0]);stDel('home:'+a[1]);cl();render()}",[b,c]);pg.wait_for_timeout(250)
            chk(t+'reset clears',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return !D.cms.ST['home:'+i]&&e.style.filter==''&&e.style.getPropertyValue('--xcc')==''&&e.style.getPropertyValue('--xip')==''}",b))
            # default values don't emit css
            pg.evaluate("(i)=>{stSet('home:'+i,'fb',100,1);stSet('home:'+i,'fg',0,1);cl();render()}",b);pg.wait_for_timeout(200)
            chk(t+'default no filter',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.filter==''",b))
            if w==360 and not dark:
                pg.evaluate("(i)=>{stSet('home:'+i,'cc',3,1);stSet('home:'+i,'ip',3,1);stSet('home:'+i,'bl',6,1);cl();render()}",b);pg.wait_for_timeout(300)
                pg.screenshot(path='/tmp/xs8_home.png')
                pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
                pg.evaluate("document.querySelector('#ov .sheet').scrollTop=520");pg.wait_for_timeout(200)
                pg.screenshot(path='/tmp/xs8_sheet.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
