# تست 1.9.404 H3-c: کنتراست (fc) و کارت ویژه (featc) دیگر کلید مشترک ندارند
from playwright.sync_api import sync_playwright
errs=[]
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':360,'height':780}).new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith('file:') else r.fulfill(status=200,body='{}',content_type='application/json'))
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    r=pg.evaluate("""()=>{D.cms=D.cms||{};D.cms.ST={};stSet('x:1','featc',1,0);stSet('x:1','fc',120,0);const s=D.cms.ST['x:1'];return {featc:s.featc,fc:s.fc,fl:stFl(s)}}""")
    chk('feature card kept after contrast change',r['featc']==1 and r['fc']==120)
    chk('contrast filter applied',r['fl'] and 'contrast(1.2)' in r['fl'])
    ap=pg.evaluate("()=>{const e=document.createElement('div');document.body.appendChild(e);stApply(e,{featc:1,fc:120});return [e.style.getPropertyValue('--xfc'),e.style.filter]}")
    chk('apply: feature card + contrast together',ap[0]=='1' and 'contrast(1.2)' in ap[1])
    br.close()
print('ERRORS',errs)
