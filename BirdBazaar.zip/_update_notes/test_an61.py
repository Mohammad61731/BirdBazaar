# تست 1.9.310: AN61 حذف آیتم سبد با لغزش و جمع‌شدن
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("D.products=[{id:91,name:'a',cat:'c',price:1000,short:'s',img:'',disc:0,out:0},{id:92,name:'b',cat:'c',price:2000,short:'s',img:'',disc:0,out:0}];D.cart=[{id:91,q:1},{id:92,q:1}];S.v=null;S.tab=3;render()");pg.wait_for_timeout(400)
            n=pg.evaluate("D.cart.length");b=pg.evaluate("document.querySelectorAll('#scr [data-a=cd]').length")
            if b<2: print('SKIP '+t+str(b));ctx.close();continue
            pg.evaluate("document.querySelector('#scr [data-a=cd]').click()")
            pg.wait_for_timeout(120)
            mid=pg.evaluate("D.cart.length")
            chk(t+('still there mid-animation' if rm=='no-preference' else 'instant remove'),(mid==2) if rm=='no-preference' else (mid==1))
            pg.wait_for_timeout(700)
            chk(t+'removed exactly one',pg.evaluate("D.cart.length")==1)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
