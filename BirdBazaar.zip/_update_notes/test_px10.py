# تست 1.9.235 PX10: نقطه‌های گالری + دکمه‌ی خرید چسبان
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
J="""(()=>{const mk=(c)=>{const k=document.createElement('canvas');k.width=k.height=60;const x=k.getContext('2d');x.fillStyle=c;x.fillRect(0,0,60,60);return k.toDataURL('image/jpeg',.5)};
BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'تهران'}];
BT.prods=[{id:11,b:1,s:'on',d:{name:'دان ارزان',type:'plain',price:50000,emoji:'🌰',imgs:[mk('#c97b4a'),mk('#8aa04a'),mk('#d9b26a')],cat:'دان',desc:'x'}}];BT.ok=1;go({v:'btp',id:11});})()"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':740},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate(J);pg.wait_for_timeout(400)
            chk(t+'3 dots',pg.evaluate("document.querySelectorAll('#scr .gald i').length")==3)
            pg.evaluate("const g=document.querySelector('#scr .gal');g.scrollTo({left:-g.clientWidth*2})");pg.wait_for_timeout(500)
            chk(t+'dot follows swipe',pg.evaluate("[...document.querySelectorAll('#scr .gald i')].findIndex(e=>e.classList.contains('on'))")==2)
            chk(t+'counter 3',pg.evaluate("document.querySelector('#scr .galn').textContent").startswith('۳'))
            chk(t+'pbuy sticky',pg.evaluate("getComputedStyle(document.querySelector('#scr .btn.pbuy')).position")=='sticky')
            pg.evaluate("go({v:'prod',id:D.products[0].id})");pg.wait_for_timeout(300)
            pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<div style=\"height:900px\"></div>')");pg.wait_for_timeout(300)
            chk(t+'sbuy shown when buy card below',pg.evaluate("document.getElementById('sbuy').classList.contains('on')"))
            if w==360 and not dark: pg.screenshot(path='/tmp/px10_sb.png')
            pg.evaluate("document.querySelector('#sbuy button').click()");pg.wait_for_timeout(1200)
            chk(t+'sbuy hides after reaching card',not pg.evaluate("document.getElementById('sbuy').classList.contains('on')"))
            chk(t+'buy btn visible above nav',pg.evaluate("(()=>{const b=document.querySelector('#scr .btn[data-a=add][data-v=\"0\"]').getBoundingClientRect();return b.top>0&&b.bottom<=innerHeight-60})()"))
            pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(300)
            chk(t+'sbuy off on home',not pg.evaluate("document.getElementById('sbuy').classList.contains('on')"))
            chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs)
