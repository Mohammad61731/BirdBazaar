from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(700)
        pg.evaluate("D.products=Array.from({length:14},(_,i)=>({id:i+1,name:'م'+i,short:'x',price:1000,cat:'a',emoji:'🌰',img:'',imgs:[],disc:0,stock:5}));D.guides=Array.from({length:14},(_,i)=>({id:i+1,title:'ر'+i,name:'ر'+i,cat:'a',emoji:'📘',body:'x',img:'',imgs:[]}));BT.booths=Array.from({length:14},(_,i)=>({id:i+1,name:'غ'+i,n:1,status:'active'}));BT.ok=1;BT.t=Date.now()+9e9;go({tab:0,v:null})");pg.wait_for_timeout(500)
        r=pg.evaluate("[...document.querySelectorAll('#scr .hs')].map(e=>[e.children.length,e.scrollWidth>e.clientWidth])")
        print(w,r,'overflow-page:',pg.evaluate("document.documentElement.scrollWidth>innerWidth+1"))
    print('ERRORS',errs);br.close()
