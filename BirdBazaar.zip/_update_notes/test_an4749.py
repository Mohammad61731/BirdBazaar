# تست 1.9.303: AN47 نوار آفلاین/آنلاین ، AN48 پالس نقطه‌ی اعلان ، AN49 تیک کپی/اشتراک
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.set_default_timeout(8000)
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                # AN47
                pg.evaluate("window.obOn=()=>true;Object.defineProperty(navigator,'onLine',{get:()=>window.__ol!==false,configurable:true});window.__ol=false;obApply();0");pg.wait_for_timeout(350)
                r=pg.evaluate("(()=>{const b=document.getElementById('obar');return b?{an:getComputedStyle(b).animationName,t:b.textContent,ov:document.documentElement.scrollWidth<=innerWidth}:null})()")
                chk(t+'AN47 bar shown',r is not None and 'آفلاین' in r['t'])
                if r:
                    chk(t+'AN47 no overflow',r['ov'])
                    if rm=='no-preference': chk(t+'AN47 slide anim',r['an']=='anob')
                pg.evaluate("window.__ol=true;obApply();0");pg.wait_for_timeout(150)
                r=pg.evaluate("(()=>{const b=document.getElementById('obar');return b?{o:b.classList.contains('out'),t:b.textContent}:null})()")
                chk(t+'AN47 online msg',r is not None and r['o'] and 'آنلاین' in r['t'])
                pg.wait_for_timeout(1700)
                chk(t+'AN47 bar removed',pg.evaluate("!document.getElementById('obar')"))
                pg.evaluate("window.__ol=false;obApply();window.__ol=true;obApply();window.__ol=false;obApply();0");pg.wait_for_timeout(200)
                chk(t+'AN47 re-offline single bar',pg.evaluate("document.querySelectorAll('#obar').length===1 && !document.getElementById('obar').classList.contains('out')"))
                pg.evaluate("window.__ol=true;obApply();0");pg.wait_for_timeout(1700)
                # AN48
                pg.evaluate("window.MSN=0;window.CSN=0;renderTop();0");pg.wait_for_timeout(100)
                pg.evaluate("window.MSN=2;renderTop();0")
                a=pg.evaluate("(()=>{const e=document.querySelector('#top .ib .n');return e?{c:e.classList.contains('npl'),n:getComputedStyle(e).animationName}:null})()")
                chk(t+'AN48 dot exists',a is not None)
                if a:
                    if rm=='no-preference': chk(t+'AN48 pulse',a['c'] and a['n']=='annp')
                    else: chk(t+'AN48 reduced no anim',a['n'] in ('none',''))
                pg.evaluate("renderTop();0")
                chk(t+'AN48 not on same count',pg.evaluate("!document.querySelector('#top .ib .n').classList.contains('npl')"))
                # AN49
                pg.evaluate("const b=document.createElement('button');b.id='tcp';b.className='btn';b.textContent='کپی';b.setAttribute('data-a','t');document.getElementById('scr').appendChild(b);0")
                pg.click('#tcp');pg.wait_for_timeout(100)
                pg.evaluate("tickBtn();0")
                k=pg.evaluate("(()=>{const b=document.getElementById('tcp');return {c:b.classList.contains('tk'),t:b.textContent,n:getComputedStyle(b).animationName}})()")
                chk(t+'AN49 tick shown',k['c'] and k['t'].startswith('✓'))
                if rm=='no-preference': chk(t+'AN49 ring anim',k['n']=='antk')
                pg.wait_for_timeout(1400)
                k=pg.evaluate("(()=>{const b=document.getElementById('tcp');return {c:b.classList.contains('tk'),t:b.textContent}})()")
                chk(t+'AN49 restored',(not k['c']) and k['t']=='کپی')
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
