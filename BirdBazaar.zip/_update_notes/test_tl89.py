# تست 1.9.89 مرحله‌ی ۵: ابزارهای دسته‌ی ۲ (گزارش خطا ، بازبینی داده ، حجم کش)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; reqs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                reqs.append(u)
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("window.confirm=()=>true;S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='tl';render()"); await pg.wait_for_timeout(250)
            chk(t+'er/dv/cs off by default (no forms)', not await pg.evaluate("!!document.getElementById('cs_est')") and 'خطای آزمایشی' not in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'er listener not attached while off', await pg.evaluate("erOnF")==0)
            await pg.evaluate("window.dispatchEvent(new ErrorEvent('error',{message:'off1',filename:'a/b.js',lineno:1}))")
            chk(t+'off: nothing logged', await pg.evaluate("erRd().length")==0)
            for k in ('er','dv','cs'):
                await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=%s]').click()"%k); await pg.wait_for_timeout(150)
            chk(t+'er listener on', await pg.evaluate("erOnF")==1)
            await pg.evaluate("window.dispatchEvent(new ErrorEvent('error',{message:'boom1',filename:'a/b.js',lineno:7}))"); await pg.wait_for_timeout(100)
            chk(t+'error logged', await pg.evaluate("erRd().length==1&&erRd()[0].m=='boom1'&&erRd()[0].s=='b.js:7'"))
            await pg.evaluate("for(let i=0;i<70;i++)erPush('e'+i,'');render()"); await pg.wait_for_timeout(150)
            chk(t+'log capped at 50', await pg.evaluate("erRd().length")==50)
            chk(t+'no overflow with errors', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.evaluate("document.querySelector('[data-a=er_clr]').click()"); await pg.wait_for_timeout(100)
            chk(t+'clear works', await pg.evaluate("erRd().length")==0)
            await pg.evaluate("document.querySelector('[data-a=er_t]').click()"); await pg.wait_for_timeout(100)
            chk(t+'test error button', await pg.evaluate("erRd().length")==1)
            # بازبینی داده
            await pg.evaluate("D.products=[{id:1,name:'الف',price:0,imgs:[]},{id:1,name:'الف',price:5,imgs:['data:x']},{id:2,name:'ب',price:3,img:'u'}];D.ads=[{id:7,title:'',imgs:[]}];D.stories=[{id:1}];render()"); await pg.wait_for_timeout(200)
            r=await pg.evaluate("(()=>{const r=dvScan();const g=t=>r.R.find(x=>x.t==t).n;return [g('محصول بدون عکس'),g('محصول بدون قیمت یا قیمت صفر'),g('محصول با شناسه‌ی تکراری'),g('محصول با نام تکراری'),g('آگهی بدون عکس'),g('آگهی بدون عنوان'),g('استوری بدون عکس')]})()")
            chk(t+'dvScan counts %s'%r, r==[1,1,1,1,1,1,1])
            chk(t+'dv card shows warnings', '⚠️' in await pg.evaluate("document.getElementById('scr').innerText"))
            await pg.evaluate("D.products=[];D.ads=[];D.stories=[];render()")
            chk(t+'dv clean data shows ok', '⚠️' not in await pg.evaluate("document.getElementById('scr').innerText"))
            # حجم کش
            await pg.evaluate("render()"); await pg.wait_for_timeout(300)
            chk(t+'cache card shows localStorage size', 'localStorage' in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'cs_est filled or loading', await pg.evaluate("!!document.getElementById('cs_est')"))
            await pg.evaluate("idbSet('IM:p:1',{a:1}).then(()=>idbSet('keep',{b:1}))"); await pg.wait_for_timeout(300)
            await pg.evaluate("document.querySelector('[data-a=cs_clr]').click()"); await pg.wait_for_timeout(500)
            chk(t+'IM cache cleared', await pg.evaluate("idbGet('IM:p:1')")is None)
            chk(t+'other idb key kept', await pg.evaluate("idbGet('keep')")is not None)
            chk(t+'no overflow cache', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            # خاموش کردن er: فهرست پاک
            await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=er]').click()"); await pg.wait_for_timeout(150)
            chk(t+'er off clears log + detaches', await pg.evaluate("erRd().length==0&&erOnF==0"))
            await pg.evaluate("window.dispatchEvent(new ErrorEvent('error',{message:'after',filename:'x.js',lineno:2}))")
            chk(t+'no logging after off', await pg.evaluate("erRd().length")==0)
            chk(t+'tools made no server requests', not any('rpc' in u for u in reqs[-0:] if False))
            chk(t+'ab() back to hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx})()"))
            chk(t+'no errors %s'%errs, not errs)
            if w==360 and sch=='light':
                await pg.evaluate("S.sx='tl';tlSet('er',1);erSync();erPush('مثال خطا','a.js:3');D.products=[{id:1,name:'الف',price:0,imgs:[]}];S.pnl=1;render()"); await pg.wait_for_timeout(300)
                await pg.evaluate("document.getElementById('scr').scrollTop=520"); await pg.wait_for_timeout(100)
                await pg.screenshot(path='%s/shots/tl89.png'%ROOT)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
