from playwright.sync_api import sync_playwright
errs=[]
P="D.products=[1,2,3,4,5].map(i=>({id:i,name:'دان شماره '+i,short:'توضیح کوتاه',price:50000+i,cat:'دان',emoji:'🌰',img:'',imgs:[],disc:0,stock:5}));delete D.cms.LY2;delete D.cms.PS;"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',has_touch=True).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(700)
        pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"+P+"go({tab:1,v:null})");pg.wait_for_timeout(400)
        r={}
        r['no_btn_for_guest']=True
        pg.click('[data-a=pzt]');pg.wait_for_timeout(300)
        r['overlays']=pg.locator('.pzb').count()
        seq=[]
        for _ in range(4):
            pg.locator('.pzb').first.click();pg.wait_for_timeout(250)
            seq.append((pg.evaluate("document.querySelector('.pw').className"),pg.evaluate("(()=>{const a=document.querySelector('.pw').getBoundingClientRect(),g=document.querySelector('#pgrid').getBoundingClientRect();return Math.round(a.width/g.width*100)})()")))
        r['cycle']=seq
        pg.locator('.pzb').first.click();pg.wait_for_timeout(250)  # -> l
        pg.locator('.pzb').nth(1).click();pg.wait_for_timeout(250);pg.locator('.pzb').nth(1).click();pg.wait_for_timeout(250) # second -> f
        r['saved']=pg.evaluate("JSON.stringify(D.cms.PS)")
        r['overflow']=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1||document.querySelector('#pgrid').scrollWidth>document.querySelector('#pgrid').clientWidth+1")
        r['click_no_open']=pg.evaluate("S.v")
        pg.click('[data-a=pzt]');pg.wait_for_timeout(250)
        r['no_overlay_after']=pg.locator('.pzb').count()
        pg.evaluate("S.role='user';S.pm=[];render()");pg.wait_for_timeout(250)
        r['user_sees']=pg.evaluate("document.querySelectorAll('.pw.z-l,.pw.z-f').length")
        r['user_no_toolbar']=pg.locator('[data-a=pzt]').count()==0
        pg.evaluate("S.role='admin';S.pm=['all'];S.pz=1;render()");pg.wait_for_timeout(250)
        pg.click('[data-a=pzr]');pg.wait_for_timeout(250);r['reset']=pg.evaluate("String(D.cms.PS)")
        pg.evaluate("CURP='store';lySet('grid',b=>b.m='l')");pg.wait_for_timeout(200)
        pg.evaluate("D.cms.PS={p1:'s',p2:'l',p3:'f'};render()");pg.wait_for_timeout(250)
        r['list_thumb_w']=pg.evaluate("[...document.querySelectorAll('.pw .pi')].slice(0,3).map(e=>Math.round(e.getBoundingClientRect().width))")
        r['list_overflow']=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1")
        print(w,r)
    print('ERRORS',errs);br.close()
