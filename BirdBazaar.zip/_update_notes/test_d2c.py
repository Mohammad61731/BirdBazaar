# تست 1.9.435 D2-c: تبدیل رزرو حضوری به پیک (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[]
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}')
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=0;cgG=()=>({lvl:1});localStorage.setItem('bp_rsv',JSON.stringify([{b:1,bn:'غ',ph:'0912',c:'1234',h:6,t:Date.now(),s:'n'}]))")
        chk(t+'off -> no button',pg.evaluate("!cpMyH().includes('dtcv')"))
        pg.evaluate("XF.dt=1")
        chk(t+'on -> button',pg.evaluate("cpMyH().includes('dtcv')&&cpMyH().includes('نرسیدم')"))
        pg.evaluate("cgG=()=>({lvl:0})")
        chk(t+'unverified booth -> no button',pg.evaluate("!cpMyH().includes('dtcv')"))
        pg.evaluate("cgG=()=>({lvl:1});bzAsk=(m,d,cb)=>cb('تهران خیابان آزادی پلاک ۵');0")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtcv';b.dataset.v='1234';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(800)
        chk(t+'server called once with op cv_p',len(calls)==1 and '"cv_p"' in calls[0] and '1234' in calls[0])
        chk(t+'reservation marked converted',pg.evaluate("JSON.parse(localStorage.getItem('bp_rsv'))[0].s=='c'&&cpMyH().includes('تبدیل شد')"))
        chk(t+'no button after convert',pg.evaluate("!cpMyH().includes('dtcv')"))
        pg.evaluate("localStorage.setItem('bp_rsv',JSON.stringify([{b:1,bn:'غ',ph:'0912',c:'5678',h:6,t:Date.now(),s:'n'}]));bzAsk=(m,d,cb)=>cb('abc');0")
        n=len(calls)
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtcv';b.dataset.v='5678';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(500)
        chk(t+'short address -> no server call',len(calls)==n)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
