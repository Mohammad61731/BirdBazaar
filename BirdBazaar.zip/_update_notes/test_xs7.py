# تست 1.9.334: پخش نور رنگی پشت بنر (کلید xs ؛ D.cms.ST.gx.gl/gi/gb/gs/gt/gh)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
def svg(c1,c2):
    import urllib.parse
    s="<svg xmlns='http://www.w3.org/2000/svg' width='400' height='200'><defs><linearGradient id='g'><stop offset='0' stop-color='%s'/><stop offset='1' stop-color='%s'/></linearGradient></defs><rect width='400' height='200' fill='url(#g)'/></svg>"%(c1,c2)
    return 'data:image/svg+xml,'+urllib.parse.quote(s)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            a=svg('#f5b800','#8a5a00');b=svg('#7a2cff','#120022')
            pg.evaluate("(a)=>{S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=0;XF.xs=1;D.cms.BN=[{m:'img',img:a[0],t:'',x:'',bg:'#c9743a',bg2:'#f3e3cf',tc:'#fff'},{m:'img',img:a[1],t:'',x:'',bg:'#222',bg2:'#444',tc:'#fff'}];D.cms.HERO.m='img';D.cms.HERO.img=a[0];render()}",[a,b]);pg.wait_for_timeout(400)
            chk(t+'off by default',pg.locator('.xgl').count()==0)
            pg.evaluate("sgSheet()");pg.wait_for_timeout(200)
            chk(t+'controls',all(pg.locator(s).count()==1 for s in ('#ov [data-sg="x.gi"]','#ov [data-sg="x.gb"]','#ov [data-sg="x.gs"]','#ov [data-sg="x.gt"]','#ov [data-sgc="x.gl:1"]','#ov [data-sgc="x.gh:1"]')))
            clk(pg,'#ov [data-sgc="x.gl:1"]');pg.wait_for_timeout(300)
            chk(t+'layers created',pg.evaluate("(()=>{const h=document.querySelector('.hbk[data-b=hero] > .xgl'),b=document.querySelector('.hbk[data-b=bnrs] > .xgl');return !!h&&h.children.length==1&&!!b&&b.children.length==2&&document.querySelector('.hbk[data-b=bnrs]').classList.contains('xgb')})()"))
            chk(t+'css blur',pg.evaluate("(()=>{const e=document.querySelector('.hbk[data-b=bnrs] > .xgl'),c=getComputedStyle(e);return c.filter.includes('blur(36px)')&&c.position=='absolute'&&parseFloat(c.opacity)>0.5&&c.zIndex=='-1'})()"))
            fire(pg,'#ov [data-sg="x.gb"]',60);fire(pg,'#ov [data-sg="x.gi"]',80)
            chk(t+'settings live',pg.evaluate("(()=>{const c=getComputedStyle(document.querySelector('.hbk[data-b=bnrs] > .xgl'));return c.filter.includes('blur(60px)')&&Math.abs(parseFloat(c.opacity)-.8)<.01})()"))
            chk(t+'saved',pg.evaluate("D.cms.ST.gx.gl==1&&D.cms.ST.gx.gb==60&&D.cms.ST.gx.gi==80"))
            chk(t+'active layer 0',pg.evaluate("[...document.querySelector('.hbk[data-b=bnrs] > .xgl').children].map(d=>d.classList.contains('on')).join()=='true,false'"))
            pg.evaluate("document.querySelector('#ov [data-a=clo2]')&&document.querySelector('#ov [data-a=clo2]').click()");pg.wait_for_timeout(200)
            pg.evaluate("(()=>{const s=document.getElementById('bns');s.scrollTo({left:-s.scrollWidth,behavior:'instant'});s.scrollLeft=-s.scrollWidth;s.dispatchEvent(new Event('scroll'))})()");pg.wait_for_timeout(500)
            chk(t+'active layer follows scroll',pg.evaluate("[...document.querySelector('.hbk[data-b=bnrs] > .xgl').children].map(d=>d.classList.contains('on')).join()=='false,true'"))
            chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.body.scrollWidth<=innerWidth"))
            if w==360 and not dark: pg.screenshot(path='/tmp/xs7_home.png')
            pg.evaluate("sgSheet()");pg.wait_for_timeout(150);clk(pg,'#ov [data-sgc="x.gh:1"]');pg.wait_for_timeout(300)
            chk(t+'only sliders',pg.locator('.hbk[data-b=hero] > .xgl').count()==0 and pg.locator('.hbk[data-b=bnrs] > .xgl').count()==1)
            clk(pg,'#ov [data-sgc="x.gh:2"]');pg.wait_for_timeout(300)
            chk(t+'only hero',pg.locator('.hbk[data-b=hero] > .xgl').count()==1 and pg.locator('.hbk[data-b=bnrs] > .xgl').count()==0)
            clk(pg,'#ov [data-sgc="x.gl:0"]');pg.wait_for_timeout(300)
            chk(t+'off removes',pg.locator('.xgl').count()==0 and pg.locator('.xgb').count()==0)
            ctx.close()
    br.close()
print('ERRORS',errs)
