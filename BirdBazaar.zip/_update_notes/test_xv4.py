# تست 1.9.361: V4/V5 برگردان و فهرست
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(400)
        pg.evaluate("S.tab=0;render()");pg.wait_for_timeout(300)
        pg.evaluate("D.cms.ST=D.cms.ST||{}")
        k=pg.evaluate("(()=>{const p='home';for(const b of lay(p)){try{bsheet(b.id,p);if(document.querySelector('.xsb[data-xk]'))return document.querySelector('.xsb[data-xk]').dataset.xk}catch(e){}}return ''})()")
        chk(t+'found block',bool(k))
        pg.evaluate("(k)=>{window.__k=k;delete D.cms.ST[k];const a=k.split(':');bsheet(a[1],a[0])}",k);pg.wait_for_timeout(300)
        chk(t+'bf button',pg.evaluate("!!document.querySelector('[data-xl=bf]')"))
        pg.evaluate("stSet(window.__k,'o',50,1);document.dispatchEvent(new Event('change'))");pg.wait_for_timeout(400)
        pg.evaluate("stSet(window.__k,'rd',12,1);document.dispatchEvent(new Event('change'))");pg.wait_for_timeout(400)
        op=lambda:pg.evaluate("getComputedStyle(stEl(window.__k)).opacity")
        rd=lambda:pg.evaluate("stEl(window.__k).style.borderRadius")
        chk(t+'two changes',op()=='0.5' and rd()=='12px')
        clk(pg,'[data-xl=lst]')
        chk(t+'list has rows',pg.evaluate("document.querySelectorAll('.xlh .xlr').length==2"))
        chk(t+'list from/to',pg.evaluate("document.querySelector('.xlh').textContent.includes('شفافیت')&&document.querySelector('.xlh').textContent.includes('پیش‌فرض')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'[data-xl=undo]');pg.wait_for_timeout(300)
        chk(t+'undo last',rd()=='' and op()=='0.5')
        chk(t+'live still on',pg.evaluate("ov.classList.contains('xlive')&&!!document.querySelector('.xlbar')"))
        chk(t+'list kept open',pg.evaluate("document.querySelectorAll('.xlh .xlr').length==1"))
        clk(pg,'[data-xl=undo]');pg.wait_for_timeout(300)
        chk(t+'undo again',op()=='1')
        pg.evaluate("stSet(window.__k,'o',60,1);document.dispatchEvent(new Event('change'))");pg.wait_for_timeout(400)
        clk(pg,'[data-xl=all]');pg.wait_for_timeout(300)
        chk(t+'undo all',op()=='1')
        clk(pg,'[data-xl=done]')
        chk(t+'closed clean',pg.evaluate("!ov.classList.contains('xlive')"))
        pg.evaluate("delete D.cms.ST[window.__k]")
        ctx.close()
    br.close()
print('ERRORS',errs)
