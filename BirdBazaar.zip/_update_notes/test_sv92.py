# تست 1.9.92: «🖥 اطلاعات سرور» داخل داشبورد
import asyncio, sys, json, re, os
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/src'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
VG={'ok':1,'db':52428800,'tables':[{'t':'products','sz':30000000},{'t':'ads','sz':9000000},{'t':'users','sz':100000}],'rows':{'users':12,'products':40,'ads':7,'orders':3,'stories':2},'sto':104857600,'stn':80,'con':14,'mx':60,'up':900000,'ver':'15.6','eg':1073741824,'dvc':5}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; ops=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                pd=route.request.post_data or ''
                m=re.search(r'"op":"(\w+)"',pd); op=m.group(1) if m else ''
                ops.append((u.split('/')[-1],op))
                body=VG if op=='vget' else BODY
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("localStorage.removeItem('bp_sv');S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='x';render()"); await pg.wait_for_timeout(300)
            chk(t+'APPV 1.9.92', await pg.evaluate("/^1\.9\.9\d$/.test(APPV)"))
            chk(t+'card shown, nothing fetched yet', 'اطلاعات سرور' in await pg.evaluate("document.body.innerText") and not any(o[1]=='vget' for o in ops))
            await pg.click('[data-a=sv_ref]'); await pg.wait_for_timeout(700)
            txt=await pg.evaluate("document.body.innerText")
            chk(t+'one vget to vapp', [o for o in ops if o[1]=='vget']==[('vapp','vget')])
            chk(t+'shows db/storage/egress', all(k in txt for k in ('دیتابیس','Storage','دانلود ۳۰ روز','PostgreSQL','products')))
            chk(t+'cached in localStorage', await pg.evaluate("!!JSON.parse(localStorage.getItem('bp_sv')).d.db"))
            chk(t+'no horizontal overflow', await pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            chk(t+'no js errors', not errs)
            await pg.evaluate("S.pm=[];S.at='x';render()"); await pg.wait_for_timeout(200)
            chk(t+'hidden for non-main admin', 'اطلاعات سرور' not in await pg.evaluate("document.body.innerText"))
            if w==360:
                await pg.evaluate("S.pm=['all'];render()"); await pg.wait_for_timeout(200)
                await pg.evaluate("document.querySelector('[data-a=sv_ref]').scrollIntoView()")
                os.makedirs(ROOT+'/_update_notes/shots',exist_ok=True)
                await pg.screenshot(path=ROOT+'/_update_notes/shots/sv92_%s.png'%sch)
            await ctx.close()
        await b.close()
    print('ALL OK' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
asyncio.run(main())
