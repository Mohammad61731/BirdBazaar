# تست 1.9.365: P18 قفل پین ، P34 P35 آدرس‌ها ، P36 کدهای تخفیف
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def ens(pg,sel):
    if 'data-px' in sel and 'data-pxl' not in sel and 'data-pxk' not in sel:
        pg.evaluate("if(!document.getElementById('pxs'))document.body.insertAdjacentHTML('beforeend','<div id=pxs style=\"position:fixed;inset:0;overflow:auto;z-index:50;background:var(--bg);padding:8px;box-sizing:border-box\">'+pxBody()+'</div>')")
def clk(pg,sel):
    ens(pg,sel);pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
def setv(pg,sel,v):
    ens(pg,sel);pg.evaluate("([s,v])=>{const e=document.querySelector(s);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))}",[sel,v])
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='user';S.me='ali';S.tab=4;S.pnl=0;S.v=null;XF.xp=1;localStorage.removeItem('bp_px');render()");pg.wait_for_timeout(1800)
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=pxs style=\"position:fixed;inset:0;overflow:auto;z-index:50;background:var(--bg);padding:8px;box-sizing:border-box\">'+pxBody()+'</div>')")
        chk(t+'cards shown',pg.evaluate("/قفل برنامه/.test(document.getElementById('pxs').textContent)&&/آدرس‌های من/.test(document.getElementById('pxs').textContent)&&/کدهای تخفیف من/.test(document.getElementById('pxs').textContent)"))
        # addresses
        pg.evaluate("window.pxRe=function(){document.getElementById('pxs').innerHTML=pxBody()}")
        setv(pg,'[data-pxai=n]','خانه');setv(pg,'[data-pxai=t]','شیراز ، معالی‌آباد ، کوچه‌ی ۳ ، پلاک ۱۲');clk(pg,'[data-pxa=add]')
        chk(t+'addr saved',pg.evaluate("JSON.parse(localStorage.bp_px).ad.length==1&&JSON.parse(localStorage.bp_px).df==0"))
        setv(pg,'[data-pxai=n]','کار');setv(pg,'[data-pxai=t]','شیراز ، خیابان زند ، پلاک ۵');clk(pg,'[data-pxa=add]')
        chk(t+'two addr',pg.evaluate("pxGet().ad.length==2"))
        chk(t+'default is first',pg.evaluate("pxAd().n=='خانه'"))
        clk(pg,'[data-pxa=df][data-v="1"]')
        chk(t+'default changed',pg.evaluate("pxAd().n=='کار'"))
        clk(pg,'[data-pxa=dl][data-v="1"]')
        chk(t+'delete default falls back',pg.evaluate("pxGet().ad.length==1&&pxAd().n=='خانه'"))
        setv(pg,'[data-pxai=t]','ab');clk(pg,'[data-pxa=add]')
        chk(t+'short addr rejected',pg.evaluate("pxGet().ad.length==1"))
        # codes
        setv(pg,'[data-pxci=c]','BAHAR20');setv(pg,'[data-pxci=n]','غرفه‌ی سفال');clk(pg,'[data-pxc=add]')
        chk(t+'code saved',pg.evaluate("pxGet().cd.length==1&&pxGet().cd[0].c=='BAHAR20'"))
        setv(pg,'[data-pxci=c]','BAHAR20');clk(pg,'[data-pxc=add]')
        chk(t+'dup code merged keeps note',pg.evaluate("pxGet().cd.length==1&&pxGet().cd[0].n=='غرفه‌ی سفال'"))
        pg.evaluate("window.__cp='';Object.defineProperty(navigator,'clipboard',{value:{writeText:x=>{window.__cp=x;return Promise.resolve()}},configurable:true})")
        clk(pg,'[data-pxc=cp][data-v="0"]');pg.wait_for_timeout(150)
        chk(t+'copy',pg.evaluate("window.__cp=='BAHAR20'"))
        clk(pg,'[data-pxc=dl][data-v="0"]')
        chk(t+'code deleted',pg.evaluate("pxGet().cd.length==0"))
        # pin set (validation)
        pg.evaluate("window.pxRe=function(){document.getElementById('pxs').innerHTML=pxBody()}")
        clk(pg,'[data-pxl=set]')
        setv(pg,'#pxp1','12');setv(pg,'#pxp2','12');clk(pg,'[data-pxl=sv]')
        chk(t+'short pin rejected',pg.evaluate("!pxGet().pn&&/۴ رقم/.test(document.getElementById('pxpe').textContent)"))
        setv(pg,'#pxp1','۱۲۳۴');setv(pg,'#pxp2','1235');clk(pg,'[data-pxl=sv]')
        chk(t+'mismatch rejected',pg.evaluate("!pxGet().pn"))
        setv(pg,'#pxp1','۱۲۳۴');setv(pg,'#pxp2','1234');clk(pg,'[data-pxl=sv]')
        chk(t+'pin saved hashed',pg.evaluate("pxGet().pn&&pxGet().pn!='1234'&&pxGet().pn==pxH('1234')"))
        # lock overlay
        pg.evaluate("pxLock()");pg.wait_for_timeout(150)
        chk(t+'lock shown',pg.evaluate("!!document.getElementById('pxlk')"))
        for d in '1111': clk(pg,'#pxlk [data-pxk="'+d+'"]')
        chk(t+'wrong pin keeps lock',pg.evaluate("!!document.getElementById('pxlk')&&/درست نیست/.test(document.querySelector('[data-pxm2]').textContent)"))
        chk(t+'lock no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.getElementById('pxs').scrollWidth<=document.getElementById('pxs').clientWidth&&document.querySelector('#pxlk .pxk').getBoundingClientRect().right<=innerWidth"))
        for d in '1234': clk(pg,'#pxlk [data-pxk="'+d+'"]')
        chk(t+'right pin unlocks',pg.evaluate("!document.getElementById('pxlk')"))
        # 5 wrong -> wait
        pg.evaluate("pxLock()")
        for i in range(5):
            for d in '9999': clk(pg,'#pxlk [data-pxk="'+d+'"]')
        for d in '1234': clk(pg,'#pxlk [data-pxk="'+d+'"]')
        chk(t+'5 wrong blocks right pin',pg.evaluate("!!document.getElementById('pxlk')"))
        # forgot
        clk(pg,'#pxlk [data-pxk=fg]');pg.wait_for_timeout(300)
        chk(t+'forgot clears',pg.evaluate("!document.getElementById('pxlk')&&!localStorage.getItem('bp_px')"))
        # off switch: key off => no lock
        pg.evaluate("localStorage.setItem('bp_px',JSON.stringify({pn:pxH('1234')}));XF.xp=0;pxLock()")
        chk(t+'key off: no lock',pg.evaluate("!document.getElementById('pxlk')"))
        # turn off pin
        pg.evaluate("XF.xp=1;document.body.insertAdjacentHTML('beforeend','<div id=pxs style=\"position:fixed;inset:0;overflow:auto;z-index:50;background:var(--bg);padding:8px;box-sizing:border-box\">'+pxBody()+'</div>')")
        pg.evaluate("window.pxRe=function(){}")
        clk(pg,'[data-pxl=off]');setv(pg,'#pxp0','0000');clk(pg,'[data-pxl=off2]')
        chk(t+'off wrong pin kept',pg.evaluate("!!pxGet().pn"))
        setv(pg,'#pxp0','1234');clk(pg,'[data-pxl=off2]')
        chk(t+'pin removed',pg.evaluate("!pxGet().pn"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.getElementById('pxs').scrollWidth<=document.getElementById('pxs').clientWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
