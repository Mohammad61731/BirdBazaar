# تست 1.9.319: AN71 ذره‌های قلب (anHeart)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("window.__an=0;const o=Element.prototype.animate;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};0")
            pg.evaluate("const b=document.createElement('button');b.id='th';b.className='heart on';b.style.cssText='position:fixed;top:120px;left:100px;width:30px;height:30px;z-index:9';document.body.appendChild(b);0")
            pg.evaluate("window.__an=0;window.__anHt=0;anHeart(document.getElementById('th'))")
            n=pg.evaluate("window.__an");c=pg.evaluate("document.querySelectorAll('.anhp i').length")
            if rm=='no-preference':
                chk(t+'6 particles animate',n==6 and c==6)
                pg.evaluate("window.__an=0;anHeart(document.getElementById('th'))")
                chk(t+'dedupe fast repeat',pg.evaluate("window.__an")==0)
                pg.wait_for_timeout(900)
                chk(t+'particles removed',pg.evaluate("document.querySelectorAll('.anhp').length")==0)
            else:
                chk(t+'reduced: no particles',n==0 and c==0)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
