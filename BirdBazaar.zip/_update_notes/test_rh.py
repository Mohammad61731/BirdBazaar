# تست 1.9.128: مرکز گزارش‌ها rh
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fapp(route,req):
    b=json.loads(req.post_data);o=b['op']
    r={'err':'x'}
    if o=='arep_list':r={'ok':1,'l':[{'ad':5,'n':3,'why':['x']},{'ad':6,'n':1,'why':[]}]}
    if o=='freport_list':r={'ok':1,'reports':[{'id':1}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.route('**/rpc/fapp',fapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['all'];S.me='adm';XF.rh=undefined;D.ads=[];go({tab:4,pnl:1,v:null,at:'x'})");pg.wait_for_timeout(300)
            chk(t+'button shown on dashboard',pg.locator('[data-a=rph]').count()==1)
            pg.click('[data-a=rph]');pg.wait_for_timeout(400)
            tx=pg.evaluate("document.getElementById('ovc').textContent")
            chk(t+'sheet shows both counts ('+tx[:60]+')','(۲)' in tx and '(۱)' in tx)
            chk(t+'sheet no overflow',pg.evaluate("document.getElementById('ovc').scrollWidth<=innerWidth+1"))
            pg.evaluate("cl();localStorage.setItem('bp_kr','1');go({tab:4,pnl:1,v:null,at:'x'})");pg.wait_for_timeout(250)
            chk(t+'kr card on real dashboard',pg.locator('[data-a=kr_ok]').count()==1)
            pg.evaluate("localStorage.removeItem('bp_kr')")
            pg.evaluate("cl();XF.rh=0;go({tab:4,pnl:1,v:null,at:'x'})");pg.wait_for_timeout(250)
            chk(t+'rh=0 hides button',pg.locator('[data-a=rph]').count()==0)
            pg.evaluate("XF.rh=undefined;S.pm=[];go({tab:4,pnl:1,v:null,at:'x'})");pg.wait_for_timeout(250)
            chk(t+'no ads permission hides button',pg.locator('[data-a=rph]').count()==0)
            ctx.close()
    br.close()
print('ERRORS',errs)
