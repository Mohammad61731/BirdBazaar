# تست 1.9.234 PX9: هیرو بدون کادر + بنر با گرادیان
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1000)
            t=str(w)+('d' if dark else 'l')+' '
            chk(t+'hero no box',pg.evaluate("(()=>{const h=document.querySelector('#scr .hero');return !!h&&getComputedStyle(h).backgroundImage=='none'&&getComputedStyle(h).boxShadow=='none'})()"))
            chk(t+'banner overlay',pg.evaluate("getComputedStyle(document.querySelector('#scr .bn'),'::after').backgroundImage.includes('gradient')"))
            chk(t+'banner radius 24',pg.evaluate("getComputedStyle(document.querySelector('#scr .bn')).borderTopLeftRadius")=='24px')
            chk(t+'hero btn still there',pg.evaluate("!!document.querySelector('#scr .hero .hb')"))
            chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs)
