import json,time
from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    # get default cms
    pg0=br.new_context().new_page();pg0.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=500,body='x'))
    pg0.goto('file:///tmp/bb/www/index.html');pg0.wait_for_timeout(500)
    cms=pg0.evaluate("D.cms");prods=pg0.evaluate("D.products");cms['BR']['name']='نام سروری آزمایشی'
    for w in (320,360,412):
        for mode in ('fresh','returning','fresh_offline'):
            ctx=br.new_context(viewport={'width':w,'height':740},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            delay=0 if mode=='returning' else 1200
            init="""(()=>{const R=%s;const MODE='%s';window.fetch=(u,o)=>new Promise((res,rej)=>setTimeout(()=>{if(MODE=='fresh_offline')return rej(new Error('off'));let d={};try{d=JSON.parse(o.body)}catch(e){}res(new Response(JSON.stringify(d.op=='public'?R:{err:'x'}),{status:200,headers:{'Content-Type':'application/json'}}))},%d))})();"""%(json.dumps({'cms':cms,'products':prods,'stories':[],'ads':[],'guides':[]}),mode,delay)
            pg.add_init_script(init)
            if mode=='returning':
                pg.goto('file:///tmp/bb/www/index.html');pg.wait_for_timeout(2500)
                pg.reload()
            else:pg.goto('file:///tmp/bb/www/index.html')
            pg.wait_for_timeout(250)
            spl=pg.locator('#spl').count()
            t0=pg.inner_text('#app')[:0]
            pg.wait_for_timeout(3000 if mode!='fresh_offline' else 5500)
            spl2=pg.locator('#spl').count()
            txt=pg.evaluate("document.body.innerText")
            print(w,mode,'splash@250ms',spl,'| splash after',spl2,'| server name shown','نام سروری آزمایشی' in txt,'| overflow',pg.evaluate('document.documentElement.scrollWidth>innerWidth'))
            ctx.close()
    print('ERRORS',errs);br.close()
