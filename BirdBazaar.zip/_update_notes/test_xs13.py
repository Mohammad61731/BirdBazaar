# تست 1.9.340: استودیو T3-a عرض/ارتفاع/چینش خودکار هر بخش (ST.wd wj ht lo ؛ کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        b=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.grid .pc,.grid .bxc'));return b?b.dataset.b:null})()")
        h=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.hs'));return b?b.dataset.b:null})()")
        chk(t+'grid block',bool(b))
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        chk(t+'controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-xs="wd"]','#ov [data-xs="ht"]','#ov [data-xc$=":wj:1"]','#ov [data-xc$=":lo:1"]','#ov [data-xc$=":lo:3"]')))
        fire(pg,'#ov [data-xs="wd"]',60);clk(pg,'#ov [data-xc$=":wj:1"]')
        r=pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]'),pw=e.parentElement.getBoundingClientRect().width,c=getComputedStyle(e);return [e.getBoundingClientRect().width/pw,c.justifySelf,e.style.width]}",b)
        chk(t+'width 60% right',abs(r[0]-0.6)<0.08 and r[1]=='start' and r[2]=='60%')
        clk(pg,'#ov [data-xc$=":wj:2"]')
        chk(t+'align left',pg.evaluate("(i)=>getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')).justifySelf",b)=='end')
        chk(t+'no overflow w',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        fire(pg,'#ov [data-xs="wd"]',100)
        chk(t+'width 100 clears',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.width==''",b))
        fire(pg,'#ov [data-xs="ht"]',150)
        chk(t+'fixed height',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return Math.abs(e.getBoundingClientRect().height-150)<4&&e.style.height=='150px'&&getComputedStyle(e).overflowY=='hidden'}",b))
        fire(pg,'#ov [data-xs="ht"]',20)
        chk(t+'height <60 clears',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.height==''",b))
        # auto layout on grid
        clk(pg,'#ov [data-xc$=":lo:1"]');pg.evaluate("cl();render()");pg.wait_for_timeout(250)
        r=pg.evaluate("(i)=>{const g=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid'),c=getComputedStyle(g);return [c.display,g.scrollWidth>g.clientWidth,document.documentElement.scrollWidth<=innerWidth]}",b)
        chk(t+'lo row scroller',r[0]=='flex' and r[1] and r[2])
        pg.evaluate("(i)=>{stSet('home:'+i,'lo',2,1);cl();render()}",b);pg.wait_for_timeout(250)
        chk(t+'lo column',pg.evaluate("(i)=>getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid')).gridTemplateColumns.split(' ').length",b)==1)
        pg.evaluate("(i)=>{stSet('home:'+i,'lo',3,1);cl();render()}",b);pg.wait_for_timeout(250)
        chk(t+'lo grid2',pg.evaluate("(i)=>getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid')).gridTemplateColumns.split(' ').length",b)==2)
        if h:
            pg.evaluate("(i)=>{stSet('home:'+i,'lo',2,1);cl();render()}",h);pg.wait_for_timeout(250)
            chk(t+'hs column',pg.evaluate("(i)=>getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hs')).flexDirection",h)=='column')
            pg.evaluate("(i)=>{stSet('home:'+i,'lo',3,1);cl();render()}",h);pg.wait_for_timeout(250)
            chk(t+'hs grid2',pg.evaluate("(i)=>{const c=getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hs'));return c.display=='grid'&&c.gridTemplateColumns.split(' ').length==2}",h))
            chk(t+'no overflow hs',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            pg.evaluate("(i)=>{stDel('home:'+i);cl();render()}",h)
        pg.evaluate("(i)=>{stSet('home:'+i,'wd',70,1);stSet('home:'+i,'ht',200,1);cl();render()}",b);pg.wait_for_timeout(200)
        pg.evaluate("(i)=>{stDel('home:'+i);cl();render()}",b);pg.wait_for_timeout(250)
        chk(t+'reset clears',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return e.style.width==''&&e.style.height==''&&e.style.getPropertyValue('--xlo')==''}",b))
        if w==360 and not dark:
            pg.evaluate("(i)=>{stSet('home:'+i,'lo',1,1);stSet('home:'+i,'wd',80,1);stSet('home:'+i,'wj',1,1);cl();render();S.ed=0;render()}",b);pg.wait_for_timeout(300)
            pg.evaluate("(i)=>{document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').scrollIntoView({block:'start'});}",b);pg.wait_for_timeout(300)
            pg.screenshot(path='/tmp/xs13_a.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
