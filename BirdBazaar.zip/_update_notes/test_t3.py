# U10-T3: صفحه‌ها/کارت‌ها/برگه‌های شیشه‌ای
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
import io,re
errs=[];R={}
NEW='file:///home/claude/bb/www/index.html';OLD='file:///tmp/orig/www/index.html'
def mk(br,url,w=390,cs='light'):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=cs,reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto(url);pg.wait_for_timeout(900);return pg
sh=lambda pg:Image.open(io.BytesIO(pg.screenshot()))
ADM="S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"
PROBE="""(()=>{document.querySelectorAll('.pbx,.pbs').forEach(e=>e.remove());const c=document.createElement('div');c.className='card pbx';c.style.cssText='height:70px;width:100%;flex:none';document.querySelector('#scr').prepend(c);const s=document.createElement('div');s.className='sheet pbs';s.style.cssText='height:90px;z-index:40';document.querySelector('#app').appendChild(s)})()"""
def cs(pg,sel,prop):return pg.evaluate(f"getComputedStyle(document.querySelector('{sel}'))['{prop}']")
def lum(c):
    f=lambda v:(v/255/12.92) if v/255<=.03928 else (((v/255)+.055)/1.055)**2.4
    r,g,b=[f(x) for x in c[:3]];return .2126*r+.7152*g+.0722*b
def ratio(a,b):
    la,lb=lum(a),lum(b);hi,lo=max(la,lb),min(la,lb);return (hi+.05)/(lo+.05)
def rgb(s):return tuple(int(float(x)) for x in re.findall(r'[\d.]+',s)[:3])
def min_contrast(pg,sel):
    ink=rgb(pg.evaluate("getComputedStyle(document.body).color"))
    bb=pg.evaluate(f"(()=>{{const r=document.querySelector('{sel}').getBoundingClientRect();return [r.x,r.y,r.width,r.height]}})()")
    im=Image.open(io.BytesIO(pg.screenshot())).convert('RGB');x,y,w,h=bb;m=99
    for fx in (.12,.5,.88):
        for fy in (.2,.5,.8):
            m=min(m,ratio(ink,im.getpixel((int(x+w*fx),int(y+h*fy)))))
    return m
with sync_playwright() as p:
    br=p.chromium.launch()
    a=mk(br,NEW);b=mk(br,OLD)
    R['normal_pixel_same']=ImageChops.difference(sh(a).convert('RGB'),sh(b).convert('RGB')).getbbox() is None
    for pg in (a,b):pg.evaluate(ADM+"go({tab:1})");pg.wait_for_timeout(400)
    R['normal_store_pixel_same']=ImageChops.difference(sh(a).convert('RGB'),sh(b).convert('RGB')).getbbox() is None
    a.evaluate("thLP(1);thApply()");a.wait_for_timeout(300)
    PR="(()=>{const c=document.createElement('div');c.className='prod prb';document.querySelector('#scr').prepend(c)})()"
    a.evaluate(PR);b.evaluate(PR)
    R['normal_lp_cards_untouched']=cs(a,'.prb','backdropFilter')=='none' and cs(a,'.prb','backgroundColor')==cs(b,'.prb','backgroundColor')
    a.evaluate("thLP(0);thApply()")
    a.evaluate("thSet('store',{m:'g',c:'blue'})");a.wait_for_timeout(300);a.evaluate(PROBE)
    R['card_blur_g']='blur' in cs(a,'.pbx','backdropFilter')
    R['card_neon_shadow_g']='56, 189, 248' in cs(a,'.pbx','boxShadow')
    R['card_radius_g']=cs(a,'.pbx','borderTopLeftRadius')=='20px'
    R['sheet_blur_g']='blur' in cs(a,'.pbs','backdropFilter')
    R['sheet_radius_g']=cs(a,'.pbs','borderTopLeftRadius')=='20px'
    R['plain_no_gradient']='gradient' not in cs(a,'.pbx','backgroundImage')
    a.screenshot(path='shots/t3_glass_plain.png')
    a.evaluate("thSet('store',{s:'g',g1:'#0ea5e9',g2:'#6366f1'})");a.wait_for_timeout(300)
    R['grad_on']='linear-gradient' in cs(a,'.pbx','backgroundImage') and 'linear-gradient' in cs(a,'.pbs','backgroundImage')
    a.screenshot(path='shots/t3_glass_grad.png')
    a.evaluate("thSet('store',{m:'p',c:'orange',s:'s'})");a.wait_for_timeout(300)
    R['p_blur']='blur' in cs(a,'.pbx','backdropFilter');R['p_neon_orange']='255, 159, 67' in cs(a,'.pbx','boxShadow')
    a.screenshot(path='shots/t3_p_orange.png')
    a.evaluate("thSet('store',{m:'g',s:'g'});thLP(1);thApply()");a.wait_for_timeout(300)
    R['lp_card_no_blur']=cs(a,'.pbx','backdropFilter')=='none' and cs(a,'.pbs','backdropFilter')=='none'
    R['lp_keeps_gradient']='linear-gradient' in cs(a,'.pbx','backgroundImage')
    a.evaluate("thLP(0);thReset();thApply()");a.wait_for_timeout(300)
    R['pc_glass']=(a.evaluate("thSet('store',{m:'g'});(()=>{const c=document.createElement('div');c.className='pc pcb';document.querySelector('#scr').prepend(c)})()") or True) and 'blur' in cs(a,'.pcb','backdropFilter')
    a.evaluate("thReset();thApply()");a.wait_for_timeout(200)
    R['pc_plain_after_reset']=cs(a,'.pcb','backdropFilter')=='none'
    R['reset_card_plain']=cs(a,'.pbx','backdropFilter')=='none' and cs(a,'.pbx','borderTopLeftRadius')=='16px'
    # تضاد متن (ink) روی شیشه
    from itertools import product
    GR=[('#0ea5e9','#6366f1'),('#f97316','#ec4899'),('#22c55e','#8b5cf6'),('#f43f5e','#a855f7'),('#10b981','#06b6d4'),('#ffffff','#ffffff'),('#000000','#000000')]
    worst=99;bad=[]
    for scheme in ('light','dark'):
        q=mk(br,NEW,390,scheme);q.evaluate(ADM+"go({tab:1})");q.wait_for_timeout(300)
        for m,s,(g1,g2) in product(('g','p'),('s','g'),GR):
            if s=='s' and (g1,g2)!=GR[0]:continue
            q.evaluate(f"thSet('store',{{m:'{m}',s:'{s}',g1:'{g1}',g2:'{g2}',c:'green'}})");q.wait_for_timeout(120);q.evaluate(PROBE)
            c=min_contrast(q,'.pbx');cs_=min_contrast(q,'.pbs')
            worst=min(worst,c,cs_)
            if min(c,cs_)<4.5:bad.append((scheme,m,s,g1,g2,round(c,2),round(cs_,2)))
    print('worst contrast',round(worst,2));print('bad',bad)
    R['contrast_ink_ge_4.5']=not bad
    for w in (320,360,412):
        for sc in ('light','dark'):
            q=mk(br,NEW,w,sc);q.evaluate(ADM+"thSet('home',{m:'g',c:'green',s:'g'});thSet('store',{m:'p',c:'pink'});thSet('ads',{m:'g'});thSet('profile',{m:'g'});thSet('panel',{m:'p'})");ok=True
            for t in (0,1,2,4,5):
                q.evaluate(f"go({{tab:{t},pnl:0,v:null}})");q.wait_for_timeout(250);ok=ok and q.evaluate("document.documentElement.scrollWidth<=innerWidth && document.querySelector('#scr').scrollWidth<=document.querySelector('#scr').clientWidth+1")
            R[f'noover_{w}_{sc}']=ok
            if w==360:q.evaluate("go({tab:0})");q.wait_for_timeout(250);q.screenshot(path=f'shots/t3_home_{sc}.png')
    br.close()
for k,v in R.items():print(('OK  ' if v else 'FAIL'),k)
print('errors:',errs);print('ALL PASS' if all(R.values()) and not errs else 'SOME FAIL')
