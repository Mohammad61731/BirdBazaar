# تست 1.9.352: F: راحتی و پروفایل xp
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("localStorage.removeItem('bp_px');localStorage.removeItem('bp_pxn');S.role='admin';S.pm=['all'];S.ed=0;S.tab=0;XF.xp=0;render()");pg.wait_for_timeout(300)
        chk(t+'off hint',pg.evaluate("pxSec().includes('خاموش است')"))
        chk(t+'off no apply',pg.evaluate("(()=>{pxSave({ts:120,rm:1});pxApply();const r=document.documentElement.dataset.rm=='0'&&document.getElementById('scr').style.zoom=='';localStorage.removeItem('bp_px');return r})()"))
        pg.evaluate("XF.xp=1;S.sx='px';S.tab=4;render();document.getElementById('scr').insertAdjacentHTML('afterbegin',pxSec())");pg.wait_for_timeout(200)
        chk(t+'section',pg.evaluate("!!document.querySelector('#pxs [data-px=ts]')&&!!document.querySelector('#pxs [data-px=nt]')"))
        pg.evaluate("const r=document.querySelector('[data-px=ts]');r.value=120;r.dispatchEvent(new Event('input',{bubbles:true}))")
        chk(t+'zoom 1.2',pg.evaluate("document.getElementById('scr').style.zoom=='1.2'&&pxGet().ts==120"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'#pxs [data-px=rm]')
        chk(t+'reduce motion',pg.evaluate("document.documentElement.dataset.rm=='1'&&pxGet().rm==1&&document.querySelector('[data-px=rm]').classList.contains('on')"))
        pg.evaluate("render()");pg.wait_for_timeout(200)
        chk(t+'kept after render',pg.evaluate("document.getElementById('scr').style.zoom=='1.2'&&document.documentElement.dataset.rm=='1'"))
        pg.evaluate("document.getElementById('scr').insertAdjacentHTML('afterbegin',pxSec())")
        clk(pg,'#pxs [data-px=tr]')
        chk(t+'reset',pg.evaluate("pxGet().ts==100&&document.getElementById('scr').style.zoom==''"))
        pg.evaluate("const n=document.querySelector('[data-px=nt]');n.value='سلام';n.dispatchEvent(new Event('input',{bubbles:true}))")
        chk(t+'note saved',pg.evaluate("localStorage.getItem('bp_pxn')=='سلام'"))
        pg.evaluate("S.role=null;S.pm=[]");
        chk(t+'no note for user',pg.evaluate("!pxBody().includes('pxn')"))
        chk(t+'row in settings',pg.evaluate("SETSEC.some(x=>x.k=='px')"))
        pg.evaluate("XF.xp=0;pxApply()")
        ctx.close()
    br.close()
print('ERRORS',errs)
