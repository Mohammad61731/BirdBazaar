import json,sys
from playwright.sync_api import sync_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/tmp/bb'
errs=[];res=[]
DB=[]  # {id,b,cu,s,body,t}
SEEN={}
def capp(d):
    op=d['op'];u=d['u'];a=d['a'];owner='bob'
    if op=='ccount':
        n=0
        for m in DB:
            if m['cu']==u and m['s']=='b' and m['id']>SEEN.get((m['b'],m['cu'],'u'),0):n+=1
            if u==owner and m['s']=='u' and m['id']>SEEN.get((m['b'],m['cu'],'b'),0):n+=1
        return {'ok':1,'n':n}
    if op=='clist':
        keys={}
        for m in DB:
            if m['cu']==u or u==owner:keys[(m['b'],m['cu'])]=m
        l=[]
        for (b,cu),m in keys.items():
            r='u' if cu==u else 'b'
            un=sum(1 for q in DB if q['b']==b and q['cu']==cu and q['s']!=r and q['id']>SEEN.get((b,cu,r),0))
            l.append({'b':b,'cu':cu,'lid':m['id'],'r':r,'lb':m['body'],'lk':'t','ls':m['s'],'lt':'2026-11-14T10:00:00Z','un':un})
        return {'ok':1,'l':l}
    if op in('cmsgs','csend'):
        if u==owner:
            s='b';cu=a.get('cu')
            if cu==u:return {'err':'self'}
        else:s='u';cu=u
        b=a['b']
        if op=='cmsgs':
            ms=[m for m in DB if m['b']==b and m['cu']==cu and m['id']>a.get('after',0)]
            allm=[m for m in DB if m['b']==b and m['cu']==cu]
            if allm:SEEN[(b,cu,s)]=max(m['id'] for m in allm)
            ps=SEEN.get((b,cu,'b' if s=='u' else 'u'),0)
            return {'ok':1,'ps':ps,'m':[{'id':m['id'],'s':m['s'],'b':m['body'],'k':'t','t':'2026-11-14T10:00:00Z'} for m in ms]}
        if s=='b' and not any(m['b']==b and m['cu']==cu for m in DB):return {'err':'perm'}
        DB.append({'id':len(DB)+1,'b':b,'cu':cu,'s':s,'body':a['body']})
        return {'ok':1,'id':len(DB)}
    return {'err':'unknown'}
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    d=json.loads(q.post_data or '{}')
    body={'err':'x'}
    if 'rpc/capp' in q.url:body=capp(d)
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        DB.clear();SEEN.clear()
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',h)
        pg.goto('file://'+ROOT+'/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("""S.me='ali';S.pw='x';BT.ok=1;BT.booths=[{id:7,name:'غرفه ارزن',phone:'09120001122',city:'سراوان',n:1,views:0}];BT.prods=[];BT.t=Date.now()+1e9;btNav({v:'bts',id:7})""");pg.wait_for_timeout(300)
        res.append((w,'booth btn',pg.locator('#scr button[data-a=ct_bm]').count()))
        pg.click('#scr button[data-a=ct_bm]');pg.wait_for_timeout(500)
        res.append((w,'chat view',pg.evaluate('S.v'),pg.locator('#cmi').count()))
        pg.fill('#cmi','سلام، ارزن سفید دارید؟');pg.keyboard.press('Enter');pg.wait_for_timeout(600)
        res.append((w,'bubble out',pg.locator('#msgs .fmr.out').count(),'text ok','ارزن سفید' in pg.inner_text('#msgs')))
        res.append((w,'overflow',pg.evaluate('document.documentElement.scrollWidth>innerWidth')))
        if w==360:pg.screenshot(path='shots/y3_chat.png')
        # back -> booth
        pg.evaluate('ab()');pg.wait_for_timeout(200);res.append((w,'back to booth',pg.evaluate('S.v')))
        # owner side
        pg.evaluate("S.me='bob'");pg.evaluate('cPoll()');pg.wait_for_timeout(400)
        res.append((w,'owner CSN',pg.evaluate('window.CSN')))
        pg.evaluate("cListOpen()");pg.wait_for_timeout(500)
        res.append((w,'owner list rows',pg.locator('#scr .cvr').count(),'unread badge',pg.locator('#scr .cvu').count()))
        if w==360:pg.screenshot(path='shots/y3_list.png')
        pg.click('#scr .cvr');pg.wait_for_timeout(500)
        pg.fill('#cmi','بله موجود است');pg.click('button[data-a=ct_s]');pg.wait_for_timeout(600)
        res.append((w,'owner reply out',pg.locator('#msgs .fmr.out').count(),'in',pg.locator('#msgs .fmr.in').count()))
        pg.evaluate('ab()');pg.wait_for_timeout(200);res.append((w,'back to list',pg.evaluate('S.v')))
        # customer sees unread + ticks
        pg.evaluate("S.me='ali'");pg.evaluate('cLoad()');pg.wait_for_timeout(400)
        res.append((w,'customer unread',pg.locator('#scr .cvu').count()))
        pg.click('#scr .cvr');pg.wait_for_timeout(500)
        res.append((w,'customer thread bubbles',pg.locator('#msgs .fmr').count(),'ticks2','✓✓' in pg.inner_text('#msgs')))
        res.append((w,'overflow end',pg.evaluate('document.documentElement.scrollWidth>innerWidth')))
        # self-chat error
        pg.evaluate("S.me='bob'");pg.evaluate("cOpen(7,'bob','u')");pg.wait_for_timeout(500)
        res.append((w,'self err',pg.evaluate('CS.ce')))
    for r in res:print(r)
    print('ERRORS',errs);br.close()
