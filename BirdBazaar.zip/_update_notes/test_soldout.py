# تست مورد ۱: کلاس .soldout فقط روی محصول؛ پیام‌ها (.fmr.out / .bb.out) خاکستری نشوند
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
JS = """() => {
  const mk=(cls)=>{const d=document.createElement('div');d.className=cls;d.textContent='x';document.body.appendChild(d);return d};
  const q=(el)=>({f:getComputedStyle(el).filter, a:getComputedStyle(el,'::after').content});
  const r={};
  const m1=mk('fmr out'); r.fmr_out=q(m1);
  const m2=mk('bb out');  r.bb_out=q(m2);
  const p=mk('pc soldout'); r.pc_soldout=q(p);
  const e=mk('bxc soldout'); r.bxc_soldout=q(e);
  const o=mk('out'); r.plain_out=q(o);
  return r;
}"""
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch()
        pg = await b.new_page(viewport={'width':360,'height':740})
        await pg.route('**/*', lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
        await pg.goto('file://%s/www/index.html' % ROOT)
        await pg.wait_for_timeout(800)
        r = await pg.evaluate(JS)
        for k,v in r.items(): print(k, v)
        gray = lambda x: 'grayscale' in x['f']
        lbl  = lambda x: 'اتمام' in x['a']
        ok = (not gray(r['fmr_out']) and not lbl(r['fmr_out'])
              and not gray(r['bb_out']) and not lbl(r['bb_out'])
              and gray(r['pc_soldout']) and lbl(r['pc_soldout'])
              and gray(r['bxc_soldout']) and lbl(r['bxc_soldout'])
              and not gray(r['plain_out']))
        print('PASS' if ok else 'FAIL')
        await b.close()
        sys.exit(0 if ok else 1)
asyncio.run(main())
