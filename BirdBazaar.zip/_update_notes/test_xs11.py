# تست 1.9.338: استودیو T2-f روشن/تاریک جدا برای هر بخش (ST.md) + حرکت هنگام اسکرول (x.sm/x.sd) ؛ کلید xs
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        ids=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(b=>b.dataset.b)");b=ids[1]
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        chk(t+'md controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-xc$=":md:1"]','#ov [data-xc$=":md:2"]')))
        pg.evaluate("(i)=>{stSet('home:'+i,'bg','#ff0000',1);stSet('home:'+i,'md',2,1);cl();render()}",b);pg.wait_for_timeout(300)
        bg=pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.background",b)
        chk(t+'md=2 (only dark) '+('on in dark' if dark else 'off in light'),(('255, 0, 0' in bg) if dark else bg==''))
        pg.evaluate("(i)=>{stSet('home:'+i,'md',1,1);cl();render()}",b);pg.wait_for_timeout(300)
        bg=pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.background",b)
        chk(t+'md=1 (only light) '+('off in dark' if dark else 'on in light'),(bg=='') if dark else ('255, 0, 0' in bg))
        # live theme switch
        pg.evaluate("(i)=>{stSet('home:'+i,'md',2,1);cl();render()}",b);pg.wait_for_timeout(200)
        pg.evaluate("localStorage.setItem('bp_th','dark');sysThA()");pg.wait_for_timeout(200)
        chk(t+'live to dark',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.background.includes('255, 0, 0')",b))
        pg.evaluate("localStorage.setItem('bp_th','light');sysThA()");pg.wait_for_timeout(200)
        chk(t+'live to light',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.background==''",b))
        pg.evaluate("(i)=>{stSet('home:'+i,'md',0,1);cl();render();localStorage.removeItem('bp_th');sysThA()}",b);pg.wait_for_timeout(200)
        chk(t+'md=0 both',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.background.includes('255, 0, 0')",b))
        pg.evaluate("(i)=>{stDel('home:'+i);cl()}",b)
        # scroll motion
        pg.evaluate("S.ed=0;render()");pg.wait_for_timeout(300)
        pg.evaluate("sgSheet()");pg.wait_for_timeout(200)
        chk(t+'sm controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-sgc="x.sm:2"]','#ov [data-sg="x.sd"]')))
        pg.evaluate("cl();sgSetV('x','sm',2,1);sgSetV('x','sd',300,1)");pg.wait_for_timeout(300)
        n=pg.evaluate("document.querySelectorAll('#scr .xsm0').length")
        chk(t+'hidden below fold',n>=1)
        o=pg.evaluate("()=>{const e=document.querySelector('#scr .xsm0');return e?getComputedStyle(e).opacity:'x'}")
        chk(t+'opacity 0',o=='0')
        chk(t+'above fold not hidden',pg.evaluate("()=>{const e=document.querySelector('#scr .hbk');return !e.classList.contains('xsm0')}"))
        chk(t+'no overflow hidden state',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("(()=>{const m=document.getElementById('scr');m.scrollTop=m.scrollHeight})()");pg.wait_for_timeout(250)
        pg.evaluate("(()=>{const m=document.getElementById('scr');m.scrollTop=m.scrollHeight})()");pg.wait_for_timeout(900)
        chk(t+'revealed after scroll',pg.evaluate("document.querySelectorAll('#scr .xsm0').length")==0 and pg.evaluate("document.querySelectorAll('#scr .xst').length")==0)
        # off clears
        pg.evaluate("document.getElementById('scr').scrollTop=0;render()");pg.wait_for_timeout(300)
        pg.evaluate("sgSetV('x','sm',0,1)");pg.wait_for_timeout(300)
        chk(t+'off clears',pg.evaluate("document.querySelectorAll('#scr .xsm0,#scr .xst').length")==0)
        # reduced motion / edit mode skip
        pg.evaluate("sgSetV('x','sm',1,1);S.ed=1;render()");pg.wait_for_timeout(300)
        chk(t+'edit mode skips',pg.evaluate("document.querySelectorAll('#scr .xsm0').length")==0)
        pg.evaluate("sgSetV('x','sm',0,1)")
        ctx.close()
    br.close()
print('ERRORS',errs)
