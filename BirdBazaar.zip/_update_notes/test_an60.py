# تست 1.9.311: AN60 پرواز عکس به آیکن سبد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("D.products=[{id:91,name:'a',cat:'c',price:1000,short:'s',img:'',disc:0,out:0}];D.cart=[];S.v=null;S.tab=1;D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'m'}]));thApply();render()");pg.wait_for_timeout(500)
            b=pg.evaluate("document.querySelectorAll('#scr [data-a=qadd]').length")
            if not b: print('SKIP '+t);ctx.close();continue
            pg.evaluate("window.__f=0;const o=Element.prototype.animate;Element.prototype.animate=function(k,op){if(op&&op.duration==520)window.__f++;return o.call(this,k,op)};0")
            pg.evaluate("document.querySelector('#scr [data-a=qadd]').click()");pg.wait_for_timeout(150)
            f=pg.evaluate("window.__f")
            chk(t+('fly started' if rm=='no-preference' else 'no fly reduced'),(f==1) if rm=='no-preference' else (f==0))
            pg.wait_for_timeout(900)
            chk(t+'clone removed',pg.evaluate("document.querySelectorAll('body>div[aria-hidden=true][style*=\"z-index:9999\"]').length")==0)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
