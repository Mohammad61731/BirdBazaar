import json,urllib.parse
from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        def h(r,q):
            if q.url.startswith('file:'):return r.continue_()
            d=q.post_data or ''
            if 'rpc/bapp' in q.url and '"bord"' in d:return r.fulfill(status=200,content_type='application/json',body='{"ok":1}')
            r.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
        pg.route('**/*',h)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("""BT.ok=1;BT.booths=[{id:7,name:'غرفه ارزن',phone:'09120001122',city:'سراوان',n:1,views:0}];
BT.prods=[{id:11,b:7,s:'ok',d:{type:'plain',name:'ارزن سفید',emoji:'🌾',cat:'دان',price:50000,imgs:[],wh:{on:0},rt:{on:0}}}];
window.__s=[];BC=[{p:11,m:'r',q:2}];BT.t=Date.now()+1e9;go({v:'btc'})""");pg.wait_for_timeout(300)
        pg.fill('#bcn','علی رضایی');pg.fill('#bcp','09123456789');pg.fill('#bca','سراوان، خیابان اصلی')
        pg.click('button[data-a=bt_co]');pg.wait_for_timeout(600)
        v=pg.evaluate("S.v");ov=pg.evaluate("document.documentElement.scrollWidth>innerWidth")
        sms=pg.locator('#scr button[data-a=bt_sms]').count();txt=pg.inner_text('#scr .inv')
        # capture sms url
        pg.evaluate("window.sendSms=undefined")
        url=pg.evaluate("btInvT?smsUrl(S.binv.bp,btInvT(S.binv)):''")
        print(w,'view',v,'| sms btn',sms,'| overflow',ov,'| has booth/buyer/total',all(x in txt for x in ['غرفه ارزن','علی رضایی','جمع کل']),'| sms ok',url.startswith('sms:09120001122?body='),'| cart cleared',pg.evaluate("BC.length"))
        if w==360:pg.screenshot(path='shots/y2_inv.png')
        # owner order buttons
        pg.evaluate("BOR=[{id:1,name:'الف',phone:'0912',addr:'x',lines:[{n:'ارزن',m:'r',q:2,u:'عدد',pr:5,t:10}],total:10,s:'new',t:Date.now()},{id:2,name:'ب',phone:'0913',addr:'y',lines:[],total:0,s:'done',t:Date.now()}]")
        h2=pg.evaluate("btOrdH()")
        print('  owner: close btn on new',h2.count('1:done'),'| reopen on done',h2.count('2:new'),'| no close on done',h2.count('2:done')==0)
    print('ERRORS',errs);br.close()
