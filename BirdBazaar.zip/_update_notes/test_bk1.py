# تست 1.9.357: برگشت گوشی در پنل مدیریت بخش به بخش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=br.new_page(viewport={'width':360,'height':780},locale='fa-IR');pg.route('**/*',handle)
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    st="[S.pnl,S.at,S.sx]"
    clk=lambda at:pg.evaluate("(a)=>{const b=document.createElement('button');b.dataset.a='adm';b.dataset.v=a;document.getElementById('scr').appendChild(b);b.click();b.remove()}",at)
    pg.evaluate("PTH.length=0;S.role='admin';S.pm=['all'];S.tab=4;S.v=null;S.pnl=1;S.at='x';S.sx='';render()");pg.wait_for_timeout(300)
    clk('bt');pg.wait_for_timeout(200);clk('u');pg.wait_for_timeout(200)
    chk('at u',pg.evaluate(st)==[1,'u',''])
    pg.evaluate("ab()");chk('back -> bt',pg.evaluate(st)==[1,'bt',''])
    pg.evaluate("ab()");chk('back -> x',pg.evaluate(st)==[1,'x',''])
    pg.evaluate("ab()");chk('back -> leaves panel',pg.evaluate("S.pnl")==0)
    chk('stack empty',pg.evaluate("PTH.length")==0)
    pg.evaluate("S.pnl=1;S.at='set';S.sx='ch'");pg.evaluate("ab()");chk('settings sub -> settings',pg.evaluate(st)==[1,'set',''])
    br.close()
print('ERRORS',errs)
