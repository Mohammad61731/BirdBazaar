# تست 1.9.514 A34: فروش حضوری سریع (کلید pn)
# تست 1.9.460 A33: رسید فروش حضوری (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;window.__ops=[];window.fetch=async function(u,o){try{window.__ops.push(String((o&&o.body)||''))}catch(e){}return new Response(JSON.stringify({ok:1}),{headers:{'content-type':'application/json'}})};BM={booth:{name:'t'},prods:[{id:5,name:'دانه',s:'on',d:{stock:'۱۲'}},{id:6,name:'قفس',s:'on',d:{stock:'1'}},{id:7,name:'بدون عدد',s:'on',d:{stock:'کم'}}]};BOR=[]")
        chk(t+'chip in panel',pg.evaluate('pnExp().includes(\'data-a="pnqs"\')'))
        chk(t+'qsNum',pg.evaluate("qsNum(BM.prods[0])==12&&qsNum(BM.prods[1])==1&&qsNum(BM.prods[2])===null"))
        chk(t+'list has 2 numeric rows',pg.evaluate("(qsH().match(/qsr/g)||[]).length==2"))
        pg.evaluate("qsOpen()");pg.wait_for_timeout(200)
        chk(t+'sheet shown',pg.evaluate("!!document.querySelector('.sheet .qsr')"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        pg.screenshot(path='/tmp/qs_%d.png'%w)
        pg.evaluate("qsDo('5:-1')");pg.wait_for_timeout(300)
        chk(t+'decrement keeps persian digits',pg.evaluate("BM.prods[0].d.stock=='۱۱'&&__ops.filter(x=>x.includes('bprod_set')).length==1&&__ops.some(x=>x.includes('۱۱'))"))
        pg.evaluate("qsDo('6:-1')");pg.wait_for_timeout(300)
        chk(t+'zero sets out',pg.evaluate("BM.prods[1].d.stock=='0'&&BM.prods[1].d.out==1"))
        pg.evaluate("qsDo('6:-1')");pg.wait_for_timeout(200)
        chk(t+'no negative / no extra op',pg.evaluate("BM.prods[1].d.stock=='0'&&__ops.filter(x=>x.includes('bprod_set')).length==2"))
        pg.evaluate("qsDo('6:1')");pg.wait_for_timeout(300)
        chk(t+'plus from zero clears out',pg.evaluate("BM.prods[1].d.stock=='1'&&!BM.prods[1].d.out"))
        pg.evaluate("XF.pn=0");pg.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=tq data-a=pnqs></button>');document.getElementById('tq').click()");pg.wait_for_timeout(200)
        chk(t+'off: key pn off does nothing',pg.evaluate("__ops.filter(x=>x.includes('bprod_set')).length==3"))
        ctx.close()
print('ERRORS',errs)
