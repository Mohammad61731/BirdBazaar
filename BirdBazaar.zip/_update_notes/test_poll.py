# تست مورد ۱۴ (مرحله ۲): livePull هر ۴۵ ثانیه + هنگام بازگشت؛ fPoll تطبیقی
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        cnt={'pub':0,'f':0}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if u.startswith('http'):
                if '"public"' in bd or 'public' in bd: cnt['pub']+=1
                if 'fapp' in u: cnt['f']+=1
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}))
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        c0=cnt['pub']; await pg.wait_for_timeout(8000)
        n=cnt['pub']-c0; print('public calls in 8s (outside chat):',n); ok&=n<=1
        src=await pg.evaluate("document.documentElement.outerHTML.includes('setInterval(livePull,180000)')")
        print('interval 180s:',src); ok&=src
        d=await pg.evaluate("typeof FQ=='object'"); ok&=d; print('FQ ok',d)
        c0=cnt['pub']
        await pg.evaluate("LV.at=0;document.dispatchEvent(new Event('visibilitychange'))"); await pg.wait_for_timeout(800)
        print('visibility pull:',cnt['pub']-c0); ok&=cnt['pub']-c0>=1
        print('errors',errs); ok&=not errs
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
