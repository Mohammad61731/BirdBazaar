# تست 1.9.343: استودیو S6 S7 S8 S9 لایه‌ها (اول/آخر ، تکثیر id#n ، حذف+برگشت ، گروه ؛ کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\\\"fw\\\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        LAY="()=>lay('home').map(x=>x.id)"
        o0=pg.evaluate(LAY)
        chk(t+'has prods',('prods' in o0))
        pg.evaluate("bsheet('prods','home')");pg.wait_for_timeout(150)
        chk(t+'controls',all(pg.locator('#ov [data-xg="%s"]'%x).count()==1 for x in ('ly:top:home:prods','ly:end:home:prods','ly:dup:home:prods','ly:g:home:prods:1')))
        clk(pg,'#ov [data-xg="ly:dup:home:prods"]')
        o1=pg.evaluate(LAY)
        chk(t+'dup after orig',o1.index('prods#2')==o1.index('prods')+1)
        chk(t+'dup in dom',pg.evaluate("!!document.querySelector('.hg .hbk[data-b=\\\"prods#2\\\"]')"))
        chk(t+'unique ids',pg.evaluate("(()=>{const a=[...document.querySelectorAll('[id]')].map(e=>e.id);return a.length==new Set(a).size})()"))
        chk(t+'title copy',pg.evaluate("lnm('home','prods#2')").endswith('(کپی)'))
        pg.evaluate("bsheet('prods#2','home')");pg.wait_for_timeout(150)
        clk(pg,'#ov [data-xg="ly:top:home:prods#2"]')
        chk(t+'to top',pg.evaluate(LAY)[0]=='prods#2')
        pg.evaluate("bsheet('prods#2','home')");clk(pg,'#ov [data-xg="ly:end:home:prods#2"]')
        chk(t+'to end',pg.evaluate(LAY)[-1]=='prods#2')
        pg.evaluate("bsheet('prods#2','home')");clk(pg,'#ov [data-xg="ly:g:home:prods#2:1"]')
        pg.evaluate("bsheet('prods','home')");clk(pg,'#ov [data-xg="ly:g:home:prods:1"]')
        clk(pg,'#ov [data-xg="ly:gg:home:prods"]')
        o2=pg.evaluate(LAY)
        chk(t+'group gathered',o2.index('prods#2')==o2.index('prods')+1)
        clk(pg,'#ov [data-xg="ly:gh:home:prods"]')
        chk(t+'group hidden',pg.evaluate("lay('home').filter(x=>x.g==1).every(x=>x.hide)"))
        clk(pg,'#ov [data-xg="ly:gh:home:prods"]')
        chk(t+'group shown',pg.evaluate("lay('home').filter(x=>x.g==1).every(x=>!x.hide)"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("bsheet('prods#2','home')");clk(pg,'#ov [data-xg="ly:del:home:prods#2"]')
        chk(t+'deleted',('prods#2' not in pg.evaluate(LAY)))
        pg.evaluate("bsheet('prods','home')");clk(pg,'#ov [data-xg="ly:und:home:prods"]')
        chk(t+'undo restores',('prods#2' in pg.evaluate(LAY)))
        pg.evaluate("render()");pg.wait_for_timeout(200)
        chk(t+'persist render',pg.evaluate("!!document.querySelector('.hg .hbk[data-b=\\\"prods#2\\\"]')"))
        pg.evaluate("bsheet('prods','home')");clk(pg,'#ov [data-xg="ly:dup:home:prods"]');pg.evaluate("bsheet('prods','home')");clk(pg,'#ov [data-xg="ly:dup:home:prods"]')
        chk(t+'max 3 clones',len([x for x in pg.evaluate(LAY) if x.startswith('prods#')])==3)
        ctx.close()
    br.close()
print('ERRORS',errs)
