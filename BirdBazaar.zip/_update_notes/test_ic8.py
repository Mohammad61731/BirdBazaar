# تست 1.9.204: تنظیم عمومی پک (IC8)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.effect_mandelbrot((400,400),(-2,-1.5,1,1.5),30).convert('RGBA').save('/home/claude/w/tmp/i8.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();icPick('nav.home')})()");pg.wait_for_timeout(300)
        for i in range(3):
            pg.evaluate("icPick('nav.home')");pg.wait_for_timeout(200)
            with pg.expect_file_chooser() as fc: pg.click('[data-a=ica]')
            fc.value.set_files('/home/claude/w/tmp/i8.png');pg.wait_for_timeout(700)
        ks=pg.evaluate("Object.keys(ikLib)");chk(f'{w}: 3 icons',len(ks)==3)
        pg.evaluate(f"icSet('nav.cart','{ks[1]}')")
        u0=pg.evaluate("Object.values(ikLib).map(e=>e.u)")
        pg.evaluate("icPk('nav.home','عمومی')");pg.click('[data-a=icgg]');pg.wait_for_timeout(600)
        chk(f'{w}: pack editor',pg.locator('#icep').count()==1)
        pg.evaluate("(()=>{const z=document.getElementById('ice_z');z.value=160;z.dispatchEvent(new Event('input',{bubbles:true}));const m=document.getElementById('ice_m');m.value='1';m.dispatchEvent(new Event('change',{bubbles:true}))})()")
        pg.click('[data-a=icgA]');pg.wait_for_function("document.getElementById('icep')==null");pg.wait_for_timeout(400)
        chk(f'{w}: all baked',pg.evaluate("Object.values(ikLib).every(e=>e.o&&e.p.z==160&&e.c===0&&e.u.length<=7000)"))
        chk(f'{w}: originals kept',pg.evaluate("Object.values(ikLib).map(e=>e.o)")==u0)
        chk(f'{w}: slot refreshed',pg.evaluate(f"D.cms.IKL['{ks[1]}'].u==ikLib['{ks[1]}'].u&&D.cms.IKL['{ks[1]}'].c===0"))
        pg.evaluate("icPg('nav.home','عمومی')");pg.wait_for_timeout(500);pg.click('[data-a=icgR]');pg.wait_for_function("document.getElementById('icep')==null");pg.wait_for_timeout(400)
        chk(f'{w}: pack reset',pg.evaluate("Object.values(ikLib).every(e=>!e.o&&!e.p&&e.c==1)")and pg.evaluate("Object.values(ikLib).map(e=>e.u)")==u0)
    br.close()
print('ERRORS',errs)
