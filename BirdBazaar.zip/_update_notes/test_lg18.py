# تست 1.9.299: LG18 یخی ؛ لبه‌ی براق و سایه‌ی آبی فقط روی ice
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('ice','i'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light');pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=1;S.v=null;render()"%m);pg.wait_for_timeout(450)
                t=f"{w}{'d' if dark else 'l'}{m} "
                r=pg.evaluate("(()=>{const c=document.querySelector('#scr .pc:not(.sk)');if(!c)return null;const s=getComputedStyle(c),a=getComputedStyle(c,'::after');return {sh:s.boxShadow,ac:a.content,ov:document.documentElement.scrollWidth<=innerWidth,nav:getComputedStyle(document.getElementById('nav')).boxShadow}})()")
                chk(t+'card exists',r is not None)
                if r:
                    chk(t+'no overflow',r['ov'])
                    if m=='ice':
                        chk(t+'inset shine','inset' in r['sh'])
                        chk(t+'sheen layer',r['ac'] not in ('none','normal'))
                    else:
                        chk(t+'simple untouched',not ('inset' in r['sh'] and '59, 130' in r['sh']) and r['ac'] in ('none','normal'))
                if w==360 and not dark and m=='ice': pg.screenshot(path='/tmp/lg18.png')
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
