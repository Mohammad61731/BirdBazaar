# تست 1.9.376 C5d: آنلاین/آفلاین ، ظرفیت ، آمار ارسال
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[];ME={'name':'رضا','veh':'m','area':'مرکز','st':'ok','act':True,'cap':3}
def hy(route,req):
    b=json.loads(req.post_data or '{}');o=b['op'];a=b.get('a') or {};CALLS.append((o,a))
    r={'err':'op'}
    if o=='yme':r={'ok':1,'me':ME}
    elif o=='yset':
        if 'act' in a:ME['act']=a['act']=='1'
        if 'cap' in a:ME['cap']=int(a['cap'])
        r={'ok':1}
    elif o=='yjobs':r={'ok':1,'av':[],'my':[]}
    elif o=='yinc':r={'ok':1,'d':2,'w':5,'m':9,'l':[{'bn':'غرفه یک','t':'2026-11-24T08:00:00Z','tot':50000}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/yapp',hy)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        ME.update(act=True,cap=3);CALLS.clear()
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;localStorage.setItem('bp_cru','{\"u\":\"0912\",\"p\":\"1234\"}');crSheet()");pg.wait_for_timeout(600)
        txt=lambda:pg.evaluate("document.querySelector('.sheet').innerText")
        chk(t+'controls shown',pg.locator('[data-a=bt_crn]').count()==2 and pg.locator('[data-a=bt_crc]').count()==3)
        pg.locator('[data-a=bt_crn][data-v="0"]').dispatch_event('click');pg.wait_for_timeout(600)
        sent=[c for c in CALLS if c[0]=='yset'][-1][1]
        chk(t+'offline sent with profile kept',sent.get('act')=='0' and sent.get('area')=='مرکز')
        chk(t+'offline note',('آفلاین هستی' in txt()))
        pg.locator('[data-a=bt_crc][data-v="2"]').dispatch_event('click');pg.wait_for_timeout(600)
        chk(t+'cap set',ME['cap']==2)
        pg.locator('[data-a=bt_cri]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'stats shown',('آمار ارسال' in txt()) and pg.evaluate("CRM.i.w==5") and ('غرفه یک' in txt()))
        chk(t+'stats one call',[c[0] for c in CALLS].count('yinc')==1)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
