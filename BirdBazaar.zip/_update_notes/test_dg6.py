# تست 1.9.506 DG6: جزئیات سفارش
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        L=[{'id':5,'st':'new','it':[{'id':1,'n':'کالای الف','q':2},{'id':2,'n':'کالای ب','q':1}],'tt':25000,'dt':'1405/09/02'},{'id':6,'st':'done','it':[{'n':'بدون شناسه','q':1}],'tt':1000,'dt':'1405/09/01'}]
        pg.evaluate("XF.tr=1;S.me='u1';TRN[5]={c:'ABC123',n:'پست'};MO.l=%s;MO.ld=0;MO.er='';S.v='mo';render()"%json.dumps(L,ensure_ascii=False));pg.wait_for_timeout(300)
        chk(t+'card opens detail',pg.evaluate("(document.querySelector('.bzoc').click(),S.v=='mod')"))
        pg.wait_for_timeout(300)
        chk(t+'detail content',pg.evaluate("(()=>{const x=document.getElementById('scr').textContent;return x.includes('جزئیات سفارش')&&x.includes('کالای الف')&&x.includes('ABC123')&&x.includes('قابل پرداخت')&&!!document.querySelector('[data-a=mo_re]')})()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';window.scrollTo(0,0)");pg.screenshot(path='/tmp/claude-0/p/dg6_360.png')
        pg.evaluate("MODI=1;render()")
        chk(t+'no-id order has no re-add',pg.evaluate("!document.querySelector('[data-a=mo_re]')&&document.getElementById('scr').textContent.includes('تحویل شد')"))
        pg.evaluate("MODI=9;render()")
        chk(t+'bad index -> empty',pg.evaluate("document.getElementById('scr').textContent.includes('سفارش پیدا نشد')"))
        ctx.close()
    br.close()
print('ERRS',errs)
