import json
from playwright.sync_api import sync_playwright
errs=[];calls=[]
ST={'main':False,'perm':{'txt':False,'img':False,'vid':False,'fil':False,'muted':False,'blocked':False},
    'reqs':[{'id':1,'u':'sara','want':{'txt':True,'img':True},'t':'2026-11-13T08:00:00Z','av':''},{'id':2,'u':'reza','want':{'txt':True},'t':'2026-11-13T09:00:00Z','av':''}],
    'plist':[{'uname':'ali','txt':True,'img':False,'vid':False,'fil':False,'muted':False,'blocked':False}]}
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);calls.append(b);o=b['op'];a=b['a'];r={'err':'x'}
        adm=ST['main'];den={'err':'denied'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'admin' if adm else 'user','main':adm,'perm':ST['perm'],'avatar':''}
        if o=='fpull':r={'ok':1,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜'}],'msgs':[],'av':{},'pins':[],'reqn':len(ST['reqs']) if adm else 0}
        if o=='freq':r={'ok':1}
        if o=='freq_list':r={'ok':1,'reqs':ST['reqs']} if adm else den
        if o=='freq_ok':ST['reqs']=[q for q in ST['reqs'] if q['id']!=a['id']];r={'ok':1}
        if o=='freq_no':ST['reqs']=[q for q in ST['reqs'] if q['id']!=a['id']];r={'ok':1}
        if o=='fperm_list':r={'ok':1,'perms':ST['plist']} if adm else den
        if o in('fperm_set','fmute','fblock'):r={'ok':1}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    if '/rpc/app' in u:
        b=json.loads(req.post_data)
        if b['op']=='users':return route.fulfill(status=200,content_type='application/json',body=json.dumps([{'u':'ali','vip':0},{'u':'sara','vip':1}]))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def last(op):return [c for c in calls if c['op']==op][-1]['a'] if any(c['op']==op for c in calls) else None
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    # --- normal user requests
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(900)
    print('normal user sees admin card:',pg.locator('[data-a=freqs]').count()==1)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(700);pg.click('[data-a=freq_go]');pg.wait_for_timeout(300)
    print('request sheet ticks:',pg.locator('#ovc input[type=checkbox]').count(),'| text pre-checked:',pg.locator('#fq_t').is_checked());pg.screenshot(path='../shots/f4_user_request.png')
    pg.uncheck('#fq_t');pg.check('#fq_i');pg.click('[data-a=freq_send]');pg.wait_for_timeout(500)
    print('freq want sent:',last('freq'),'| button now:',pg.locator('[data-a=freq_go]').inner_text())
    # permission refresh on entering room after approval
    ST['perm'].update({'txt':True});pg.evaluate("go({v:null,tab:5})");pg.wait_for_timeout(300);pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    print('after approval input appears on room open:',pg.locator('#ci').count()==1)
    # --- main admin
    ST['main']=True;pg.evaluate("S.role='admin';S.pm=['all'];FM.me='';FL=0;FM.t=0;go({v:null,tab:5})");pg.wait_for_timeout(1000)
    print('admin card + badge:',pg.locator('[data-a=freqs]').inner_text().replace('\n',' '))
    pg.click('[data-a=freqs]');pg.wait_for_timeout(500)
    print('requests in sheet:',pg.locator('#ovc .card').count(),'| sara pre-ticked img:',pg.evaluate("FM.rq[0].sel.img"),'| reza img:',pg.evaluate("FM.rq[1].sel.img"));pg.screenshot(path='../shots/f4_admin_requests.png')
    pg.locator('[data-a=frt][data-v="1:vid"]').click();pg.wait_for_timeout(200)
    pg.locator('[data-a=fra][data-v="1"]').click();pg.wait_for_timeout(500)
    print('approved with:',last('freq_ok'),'| remaining:',pg.locator('#ovc .card').count())
    pg.locator('[data-a=frn][data-v="2"]').click();pg.wait_for_timeout(500)
    print('rejected sent:',last('freq_no'),'| sheet closed:',not pg.locator('#ov.on').count(),'| badge gone:',pg.locator('[data-a=freqs]').inner_text().strip())
    # --- admin users tab ticks
    pg.evaluate("UL=[{u:'ali',vip:0},{u:'sara',vip:1}];S.at='u';S.pnl=1;go({tab:4,v:null})");pg.wait_for_timeout(500)
    print('💬 buttons in users list:',pg.locator('[data-a=fpm]').count())
    pg.locator('[data-a=fpm][data-v=ali]').click();pg.wait_for_timeout(500)
    print('perm sheet loaded ali txt on:',pg.evaluate("FM.pe.txt"),'| chips:',pg.locator('#ovc .chip').count())
    pg.locator('[data-a=fpt][data-v=img]').click();pg.locator('[data-a=fpt][data-v=muted]').click();pg.wait_for_timeout(200);pg.screenshot(path='../shots/f4_perm_sheet.png')
    pg.click('[data-a=fps]');pg.wait_for_timeout(700)
    print('fperm_set:',last('fperm_set'),'| fmute:',last('fmute'),'| fblock called:',last('fblock') is not None)
    # non-main admin
    pg.evaluate("S.pm=['p'];UL=[{u:'ali',vip:0}];S.at='u';go({tab:4,v:null})");pg.wait_for_timeout(400);print('limited admin sees 💬:',pg.locator('[data-a=fpm]').count())
    for w in (320,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("S.pm=['all'];go({tab:5,v:null})");pg.wait_for_timeout(200);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
