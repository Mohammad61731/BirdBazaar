# تست 1.9.360: F92 میان‌بر پنل
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=4;S.pnl=1;S.v=null;S.at='br';XF.xp=1;render()");pg.wait_for_timeout(400)
        chk(t+'pin button',pg.locator('[data-pxm=pin]').count()==1)
        clk(pg,'[data-pxm=pin]')
        chk(t+'chip shown',pg.locator('.pxss [data-a=adm]').count()==1 and pg.evaluate("JSON.parse(localStorage.bp_px).ms[0]=='br'"))
        pg.evaluate("S.at='me';render()");pg.wait_for_timeout(300)
        chk(t+'chip stays on other tab',pg.locator('.pxss [data-a=adm]').count()==1 and pg.locator('[data-pxm=pin]').count()==1)
        pg.evaluate("document.querySelector('.pxss [data-a=adm]').click()");pg.wait_for_timeout(300)
        chk(t+'shortcut navigates',pg.evaluate("S.at=='br'"))
        clk(pg,'[data-pxm=un]')
        chk(t+'unpinned',pg.locator('.pxss [data-a=adm]').count()==0 and pg.evaluate("JSON.parse(localStorage.bp_px).ms.length==0"))
        pg.evaluate("XF.xp=0;render()");pg.wait_for_timeout(200)
        chk(t+'off: nothing',pg.locator('[data-pxm]').count()==0)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
