# تست 1.9.327: استودیو T1 (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
D0="dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;render()");pg.wait_for_timeout(400)
            bid=pg.evaluate("(document.querySelector('#scr .hbk')||{dataset:{}}).dataset.b||''")
            chk(t+'has block',bool(bid))
            pg.evaluate("bsheet('%s','home')"%bid);pg.wait_for_timeout(300)
            chk(t+'off: no studio sliders',pg.locator('#ov .xsb').count()==0)
            pg.evaluate("XF.xs=1;bsheet('%s','home')"%bid);pg.wait_for_timeout(300)
            chk(t+'on: sliders shown',pg.locator('#ov .xsb input[type=range]').count()==18 and pg.locator('#ov .xsb [data-a=xsh]').count()==4)
            chk(t+'sheet no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            pg.evaluate("(()=>{const i=document.querySelector('#ov .xsb [data-xs=o]');i.value=50;i.dispatchEvent(new Event('input',{bubbles:true}));const r=document.querySelector('#ov .xsb [data-xs=rd]');r.value=20;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))})()");pg.wait_for_timeout(200)
            chk(t+'live opacity+radius',pg.evaluate("(()=>{const e=document.querySelector('.hg .hbk[data-b=\"%s\"]');return e.style.opacity=='0.5'&&e.style.borderRadius=='20px'})()"%bid))
            chk(t+'saved in cms',pg.evaluate("D.cms.ST['home:%s'].rd==20"%bid))
            pg.evaluate("document.querySelector('#ov [data-a=xsh][data-v$=\":2\"]').click()");pg.wait_for_timeout(300)
            chk(t+'shadow set',pg.evaluate("D.cms.ST['home:%s'].sh==2"%bid) and pg.evaluate("!!document.querySelector('.hg .hbk[data-b=\"%s\"]').style.boxShadow"%bid))
            pg.evaluate("stSet('home:%s','bg','#ffeecc',1);stSet('home:%s','bc','nope',1);stSet('home:%s','rot',99,1);render()"%(bid,bid,bid));pg.wait_for_timeout(300)
            chk(t+'bad color ignored, bg kept',pg.evaluate("(()=>{const s=D.cms.ST['home:%s'];return !s.bc&&s.bg=='#ffeecc'})()"%bid))
            chk(t+'rot over 10 not applied',pg.evaluate("document.querySelector('.hg .hbk[data-b=\"%s\"]').style.rotate==''"%bid))
            chk(t+'applied after render (user view)',pg.evaluate("document.querySelector('.hg .hbk[data-b=\"%s\"]').style.opacity=='0.5'"%bid))
            pg.evaluate("XF.xs=0;render()");pg.wait_for_timeout(200)
            chk(t+'key off: no style',pg.evaluate("document.querySelector('.hg .hbk[data-b=\"%s\"]').style.opacity==''"%bid))
            pg.evaluate("XF.xs=1;render();stDel('home:%s');render()"%bid);pg.wait_for_timeout(200)
            chk(t+'reset block',pg.evaluate("!D.cms.ST['home:%s'] && document.querySelector('.hg .hbk[data-b=\"%s\"]').style.opacity==''"%(bid,bid)))
            pg.evaluate("stSet('home:a','o',60,0);stSet('store:b','o',60,0);stDel('home:*')")
            chk(t+'reset all keeps other page',pg.evaluate("!D.cms.ST['home:a'] && !!D.cms.ST['store:b']"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
