# تست 1.9.59: مهر کل (psig) ← دانلود کامل فقط وقتی مهر عوض شود
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(name,cond):
        nonlocal ok; print(('PASS ' if cond else 'FAIL ')+name); ok&=bool(cond)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        st={'pub':0,'bpub':0,'psig':0,'s':'S1','b':'B1','has':True}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if not u.startswith('http'): return await route.continue_()
            try: o=json.loads(bd).get('op')
            except Exception: o=None
            hd={'access-control-allow-origin':'*'}
            if u.endswith('/rpc/fapp') and o=='psig':
                st['psig']+=1
                if not st['has']: return await route.fulfill(status=404,headers=hd,body='{}')
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'s':st['s'],'b':st['b']}))
            if o=='public2': return await route.fulfill(status=404,headers=hd,body='{}')  # 1.9.66: سرور قدیمی بدون public2
            if u.endswith('/rpc/app') and o=='public': st['pub']+=1
            if u.endswith('/rpc/bapp') and o=='bpublic': st['bpub']+=1
            if u.endswith('/rpc/bapp'): body={'ok':1,'booths':[{'id':'b1','name':'غرفه','logo':'🐦'}],'prods':[]}
            else: body={'ok':1,'msgs':[],'rooms':[],'products':[{'id':9,'name':'محصول','price':1000,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
            return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2500)
        chk('boot: public downloaded',st['pub']>=1)
        base=st['pub']
        # 1) مهر ثابت
        for _ in range(4):
            await pg.evaluate("LV.act=Date.now();LV.busy=0;livePull()"); await pg.wait_for_timeout(500)
        await pg.evaluate("pull()"); await pg.wait_for_timeout(500)
        chk('fixed seal: no extra public (%d->%d)'%(base,st['pub']),st['pub']==base)
        chk('fixed seal: psig was asked',st['psig']>=4)
        # 2) مهر عوض شد
        st['s']='S2'; await pg.evaluate("LV.act=Date.now();LV.busy=0;livePull()"); await pg.wait_for_timeout(1000)
        chk('seal changed: exactly +1 public',st['pub']==base+1)
        await pg.evaluate("LV.act=Date.now();LV.busy=0;livePull()"); await pg.wait_for_timeout(600)
        chk('after refresh: stable again',st['pub']==base+1)
        # 3) تعویض کاربر/نقش
        b2=st['pub']; await pg.evaluate("S.me='ali';S.role='user';pull()"); await pg.wait_for_timeout(800)
        chk('user/role change: full download',st['pub']>b2)
        b3=st['pub']; await pg.evaluate("S.role='admin';pull()"); await pg.wait_for_timeout(800)
        chk('role change again: full download',st['pub']>b3)
        # 4) bpull با مهر b
        await pg.evaluate("localStorage.removeItem('bp_psigb');BT.ok=0;BT.booths=[];bpull()"); await pg.wait_for_timeout(800)
        chk('bpull first: downloads',st['bpub']>=1)
        bb=st['bpub']
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        chk('bpull same b-seal: skipped (%d->%d)'%(bb,st['bpub']),st['bpub']==bb)
        st['b']='B2'; await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('bpull b-seal changed: +1',st['bpub']==bb+1)
        # 5) psig روی سرور نیست ← رفتار قدیمی
        st['has']=False; await pg.evaluate("localStorage.removeItem('bp_psig');localStorage.removeItem('bp_psigb')")
        b4=st['pub']; bb4=st['bpub']
        await pg.evaluate("pull()"); await pg.wait_for_timeout(600)
        chk('no psig op: pull downloads (old behavior)',st['pub']>b4)
        await pg.evaluate("pull()"); await pg.wait_for_timeout(600)
        chk('no psig op: downloads every time',st['pub']>=b4+2)
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        chk('no psig op: bpull downloads',st['bpub']>=bb4+2)
        chk('no page errors %s'%errs,not errs)
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
