import json
from playwright.sync_api import sync_playwright
errs=[];res=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        mode={'m':'ok'}
        def h(r,q):
            if q.url.startswith('file:'):return r.continue_()
            if '/functions/v1/ai' in q.url:
                d=json.loads(q.post_data);res.append(('req',d['kind'],d.get('name') or d.get('title')))
                if mode['m']=='noai':return r.fulfill(status=200,content_type='application/json',body='{"err":"noai"}')
                out={'ok':1,'r':{'short':'ارزن سفید مرغوب','use':'غذای پایه','def':'','ben':'انرژی','cau':'خشک نگه دارید'}} if d['kind']=='product' else {'ok':1,'r':{'text':'متن آموزشی نمونه'}}
                return r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
            r.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
        pg.route('**/*',h);pg.goto('file:///tmp/bb/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("S.me='admin';S.pw='1';S.role='admin';S.pm=['all'];go({tab:4,v:'pf',id:0})");pg.wait_for_timeout(300)
        res.append((w,'btn',pg.locator('#aib').count()))
        pg.click('#aib');pg.wait_for_timeout(300);res.append((w,'empty-name toast',pg.locator('#toast, .toast').count()>=0))
        pg.fill('#pn','ارزن سفید');pg.fill('#pu','کاربرد دستی');pg.click('#aib');pg.wait_for_timeout(500)
        res.append((w,'short filled',pg.input_value('#ps'),'use kept',pg.input_value('#pu')))
        mode['m']='noai';pg.fill('#ps','');pg.click('#aib');pg.wait_for_timeout(400);res.append((w,'noai leaves empty',pg.input_value('#ps')=='' ))
        pg.evaluate("go({tab:4,v:'gf',id:0})");pg.wait_for_timeout(300);mode['m']='ok'
        pg.fill('#gt','تغذیه‌ی قناری');pg.click('#aib');pg.wait_for_timeout(500);res.append((w,'guide text',pg.input_value('#gx')))
        res.append((w,'overflow',pg.evaluate('document.documentElement.scrollWidth>innerWidth')))
    for r in res:print(r)
    print('ERRORS',errs);br.close()
