# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        calls=[]
        pg.route('**/rpc/fapp',lambda r:(calls.append(1),r.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"l":[]}')))
        pg.evaluate("XF.cg=1;XF.sc=1;S.me='u1';S.pw='x';MO.l=[{id:1,st:'new',it:[],tt:1,dt:'d'}];S.v='mo';render()");pg.wait_for_timeout(400)
        chk(t+'refresh btn',pg.evaluate("!!document.querySelector('#scr .scrf [data-a=scrf]')"))
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='scrf';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(500)
        chk(t+'stamp shown',pg.evaluate("SCRF>0&&document.querySelector('#scr .scrf small').textContent.includes('آخرین')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("XF.sc=0;render()");pg.wait_for_timeout(300)
        chk(t+'off: none',pg.evaluate("!document.querySelector('#scr .scrf')"))
        ctx.close()
print('ERRORS',errs)
