# تست 1.9.423 G8-a: بررسی سفارش‌ها (کلید og)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
import time
NOW=int(time.time()*1000)
H=3600000
ORD=[{'id':1,'bid':1,'bn':'غرفه الف','bp':'0912','cn':'م','cp':'0935','tt':100000,'t':NOW-8*H,'pk':False,'ps':'wait','cs':None},
     {'id':2,'bid':1,'bn':'غرفه ب','bp':'0912','cn':'م','cp':'0935','tt':200000,'t':NOW-3*H,'pk':False,'ps':'sent','cs':None},
     {'id':3,'bid':2,'bn':'غرفه ج','bp':'','cn':'م','cp':'','tt':300000,'t':NOW-5*H,'pk':False,'ps':'ok','cs':None},
     {'id':4,'bid':2,'bn':'غرفه د','bp':'','cn':'م','cp':'','tt':50000,'t':NOW-20*H,'pk':False,'ps':'ok','cs':'way'},
     {'id':5,'bid':3,'bn':'غرفه ه','bp':'','cn':'م','cp':'','tt':10000,'t':NOW-60*H,'pk':True,'ps':None,'cs':None},
     {'id':6,'bid':3,'bn':'تازه','bp':'','cn':'م','cp':'','tt':10000,'t':NOW-1*H,'pk':False,'ps':'wait','cs':None}]
calls=[]
def gapp(route):
    b=json.loads(route.request.post_data or '{}');calls.append(b.get('op'))
    if b.get('op')=='ostk': body={'ok':1,'l':ORD,'d':{'n':7,'ok':3,'x':1}}
    else: body={'ok':1}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(body))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.route('**/rpc/gapp*',gapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        calls.clear()
        pg.evaluate("XF.og=0;OG={ld:0,er:'',l:null,d:null,t:0,c:''};localStorage.removeItem('bp_gfu')")
        chk(t+'off -> hint only, no call',pg.evaluate("ogSec().includes('خاموش')&&!ogSec().includes('ogld')")and calls==[])
        pg.evaluate("XF.og=1")
        chk(t+'on -> load button',pg.evaluate("ogSec().includes('ogld')&&!ogSec().includes('ogcat')"))
        pg.evaluate("S.me='a';S.pw='b'")
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(350)
        click('ogld')
        chk(t+'one ostk call',calls==['ostk'])
        chk(t+'categories',pg.evaluate("(()=>{const m={};ogRows().forEach(x=>m[x.o.id]=x.k);return m[1]=='wp'&&m[2]=='uc'&&m[3]=='np'&&m[4]=='lg'&&m[5]=='nd'&&m[6]===undefined})()"))
        chk(t+'section shows stats+chips',pg.evaluate("(()=>{const h=ogSec();return h.includes('امروز')&&h.includes('ogcat')&&h.includes('#۱٬۰۰۱')&&!h.includes('#۱٬۰۰۶')})()"))
        chk(t+'colors yellow/red',pg.evaluate("(()=>{const h=ogSec();return h.includes('#e0a800')&&h.includes('#c0392b')})()"))
        click('ogcat','lg')
        chk(t+'filter lg',pg.evaluate("(()=>{const h=ogSec();return h.includes('#۱٬۰۰۴')&&!h.includes('#۱٬۰۰۱')})()"))
        click('ogcat','zzz')
        chk(t+'bad cat -> all',pg.evaluate("OG.c===''"))
        pg.evaluate("localStorage.setItem('bp_gfu',JSON.stringify({1:{t:Date.now(),n:'زنگ زدم',r:Date.now()-1000}}))")
        click('ogcat','td')
        chk(t+'today follow-ups',pg.evaluate("(()=>{const h=ogSec();return h.includes('#۱٬۰۰۱')&&!h.includes('#۱٬۰۰۲')&&h.includes('زنگ زدم')})()"))
        click('ogrm','1')
        chk(t+'remind toggles off',pg.evaluate("!ogGf()[1].r"))
        click('ogrm','1')
        chk(t+'remind tomorrow set',pg.evaluate("ogGf()[1].r>Date.now()"))
        click('ogcat','')
        calls.clear()
        pg.evaluate("window.bzAsk=(m,d,cb)=>cb('بله')") if False else None
        chk(t+'tel links present',pg.evaluate("ogSec().includes('tel:0912')&&ogSec().includes('tel:0935')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
