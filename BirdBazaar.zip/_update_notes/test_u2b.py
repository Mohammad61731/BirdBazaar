import json
from playwright.sync_api import sync_playwright
errs=[];calls=[]
B=[{'id':1,'owner':'ali','name':'Ali Shop','bio':'bio1','city':'A','phone':'1','status':'active','views':5,'n':3,'o':2}]
O=[{'id':11,'name':'Reza','phone':'0912','addr':'Tehran addr','lines':[{'n':'Millet','q':2,'u':'kg','pr':1,'t':50000,'m':'w'}],'total':50000,'s':'new','t':'2026-11-10T10:00:00Z'},
   {'id':12,'name':'Sara','phone':'0913','addr':'Karaj','lines':[],'total':0,'s':'new','t':'2026-11-11T10:00:00Z'}]
def h(route,req):
    if req.url.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);calls.append(b)
        o=b['op']
        if o=='badm_list': r={'ok':1,'reqs':[],'booths':B}
        elif o=='badm_ords': r={'ok':1,'orders':O}
        elif o=='badm_ord_st':
            [x.update(s=b['a']['s']) for x in O if x['id']==b['a']['id']];r={'ok':1}
        elif o=='badm_edit': B[0].update(name=b['a']['name'],city=b['a']['city']);r={'ok':1}
        else: r={'ok':1,'booths':B,'prods':[]}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else h(r,q))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1';go({tab:4,pnl:1,at:'bt',v:null})");pg.wait_for_timeout(900)
        r={}
        pg.click('[data-a=bt_ao]');pg.wait_for_timeout(500)
        r['orders_sheet']=pg.locator('.sheet .card').count()==2
        pg.click('[data-a=bt_aos][data-v="11:done"]');pg.wait_for_timeout(500)
        r['status_done']='انجام شد' in pg.locator('.sheet .card').first.inner_text()
        r['sheet_overflow']=pg.evaluate("(()=>{const s=document.querySelector('.sheet');return s.scrollWidth>s.clientWidth+1})()")
        if w==360: pg.screenshot(path='shots/u2_orders.png')
        pg.click('.sheet [data-a=clo2]');pg.wait_for_timeout(300)
        pg.click('[data-a=bt_ae]');pg.wait_for_timeout(400)
        r['edit_prefill']=pg.input_value('#baen')=='Ali Shop' and pg.input_value('#baeb')=='bio1'
        pg.fill('#baen','Ali New');pg.fill('#baec','Zahedan')
        pg.click('[data-a=bt_ae2]');pg.wait_for_timeout(900)
        r['edit_sent']=any(c['op']=='badm_edit' and c['a']['name']=='Ali New' for c in calls)
        r['list_updated']='Ali New' in pg.locator('#btl').inner_text()
        r['overflow']=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1")
        print(w,r, 'FAIL' if not all(v for k,v in r.items() if k not in('sheet_overflow','overflow')) or r['sheet_overflow'] or r['overflow'] else 'PASS')
        B[0].update(name='Ali Shop',city='A')
    print('ERRORS',errs);br.close()
