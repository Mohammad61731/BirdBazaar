# تست 1.9.375 C5c: هزینه‌ی ارسال پیک ، پرداخت‌کننده ، مسیر پیک
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
CALLS=[];BORD=[]
def hb(route,req):
    b=json.loads(req.post_data or '{}')
    if b.get('op')=='bord':
        BORD.append(b['a']);route.fulfill(status=200,content_type='application/json',body='{"ok":1,"id":1}')
    else:h2(route,req)
FEE=[{'n':'الف','f':10000,'m':15},{'n':'ب','f':40000,'m':50}]
def hy(route,req):
    b=json.loads(req.post_data or '{}');o=b['op'];CALLS.append((o,b.get('a')))
    r={'err':'op'}
    if o=='yfee_get':r={'ok':1,'l':FEE}
    elif o=='yadm_fee':r={'ok':1}
    elif o=='yme':r={'ok':1,'me':{'name':'رضا','veh':'m','area':'','st':'ok'}}
    elif o=='yjobs':r={'ok':1,'av':[],'my':[{'id':7,'s':'acc','f':40000,'b':1,'bn':'غرفه یک','bp':'0912','name':'م','phone':'0935','addr':'x','k':'1234'}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb);pg.route('**/rpc/yapp',hy)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("['bp_crf','bp_crt','bp_cpl'].forEach(k=>localStorage.removeItem(k))");CALLS.clear()
        pg.evaluate("BT.t=Date.now()+60000;BT.booths=[{id:1,name:'غرفه یک',phone:'1',city:'س'}];BT.prods=[%s];BC=[{p:11,m:'r',q:2}]"%json.dumps(PR(11,1,'الف',0)))
        pg.evaluate("XF.cg=1;XF.cp=1;cgSaveC({t:Date.now(),g:{1:%s}})"%json.dumps(G[0]))
        pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(300)
        chk(t+'cr off: no zone UI',pg.evaluate("!document.getElementById('scr').innerHTML.includes('bt_crt')"))
        pg.evaluate("XF.cr=1;btRe()");pg.wait_for_timeout(600)
        chk(t+'zones shown (defaults/fetched)',pg.evaluate("document.getElementById('scr').innerHTML.includes('bt_crt')"))
        chk(t+'yfee_get once',[c[0] for c in CALLS].count('yfee_get')==1)
        pg.evaluate("CPM[1]='g';btRe()");pg.wait_for_timeout(300)
        pg.locator('[data-a=bt_crt][data-v="1:1"]').first.dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'fee+minutes shown',pg.evaluate("document.getElementById('scr').innerText.includes('۴۰٬۰۰۰')||document.getElementById('scr').innerText.includes('۴۰,۰۰۰')||/۴۰/.test(document.getElementById('scr').innerText)"))
        chk(t+'ship pay customer default',pg.evaluate("crShip(1).pay==40000"))
        chk(t+'no payer chips',pg.evaluate("!document.getElementById('scr').innerHTML.includes('bt_crp')"))
        chk(t+'total with ship shown',pg.evaluate("document.getElementById('scr').innerText.includes('جمع با ارسال')"))
        chk(t+'note says fee included',pg.evaluate("crNote(1).includes('40000')"))
        pg.evaluate("CPM[1]='g';btRe()");pg.wait_for_timeout(200)
        BORD.clear()
        pg.evaluate("document.getElementById('bcn')&&0");pg.fill('#bcn','علی');pg.fill('#bcp','09120000000');pg.fill('#bca','خیابان یک')
        pg.locator('[data-a=bt_co][data-v="1"]').first.dispatch_event('click');pg.wait_for_timeout(600)
        o=BORD[-1] if BORD else {}
        chk(t+'order has ship line',any(l.get('ship')==1 and l['t']==40000 for l in o.get('lines',[])))
        chk(t+'order total includes ship',o.get('total')==2000+40000)
        chk(t+'in-person: no ship',pg.evaluate("(CPM[1]='h',crShip(1)===null)"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        pg.evaluate("localStorage.setItem('bp_cru','{\"u\":\"0912\",\"p\":\"1234\"}');CRM.r=null;CRM.j=null;crSheet()");pg.wait_for_timeout(600)
        chk(t+'courier sees fee',pg.evaluate("document.querySelector('.sheet').innerText.includes('کرایه‌ی تو')"))
        chk(t+'courier nav link',pg.evaluate("!!document.querySelector('.sheet a[href^=\"geo:\"]')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
