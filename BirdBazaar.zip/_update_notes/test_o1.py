import json,re
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
mid="\nDB['prods'].append({'id':2,'b':1,'d':{'name':'دان فنچ','type':'plain','price':50000,'emoji':'🌰','disc':20,'imgs':[]},'s':'on'});DB['prods'].append({'id':3,'b':1,'d':{'name':'ارزن قرمز','type':'wt','unit':'kg','rt':{'on':1,'price':100000,'steps':[]},'wh':{'on':0},'emoji':'🌾','imgs':[]},'s':'on'});DB['nid']=3\n"
ORD=[]
def handle2(route,req):
    if req.url.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op'];a=b.get('a') or {}
        r=None
        if o=='bord':
            ORD.append({'id':len(ORD)+1,'b':a['b'],'name':a['name'],'phone':a['phone'],'addr':a['addr'],'lines':a['lines'],'total':a['total'],'s':'new','t':'2026-11-13T10:00:00Z'});r={'ok':1}
        elif o=='bords':r={'ok':1,'orders':[x for x in ORD if x['b']==1]}
        elif o=='bord_st':
            for x in ORD:
                if x['id']==a['id']:x['s']=a['s']
            r={'ok':1}
        if r is not None:return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return handle(route,req)
errs=[]
from playwright.sync_api import sync_playwright
exec(mid)
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',handle2);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1000)
    pg.evaluate("S.role=null;go({tab:1,v:null,sv:'b'})");pg.wait_for_timeout(500)
    ids=pg.evaluate("BT.prods.map(x=>x.id+':'+x.d.type+':'+x.d.name)");print('prods',ids)
    # plain product
    pg.evaluate("BO={id:0,m:'r',q:1};btNav({v:'btp',id:2})");pg.wait_for_timeout(300)
    print('add btn:',pg.locator('[data-a=bt_ac]').count());pg.click('[data-a=bt_ac]');pg.wait_for_timeout(200)
    print('cart size',pg.evaluate("BC.length"),'cart btn:',pg.locator('[data-a=bt_cart]').count())
    # weight product retail then wholesale
    wid=[x.split(':')[0] for x in ids if ':wt:' in x][0]
    pg.evaluate(f"BO={{id:0,m:'r',q:1}};go({{v:'btp',id:{wid}}})");pg.wait_for_timeout(300)
    pg.click('[data-a=bt_ac]');pg.wait_for_timeout(200)
    if pg.locator('[data-a=bt_m][data-v=w]').count():
        pg.click('[data-a=bt_m][data-v=w]');pg.click('[data-a=bt_ac]');pg.wait_for_timeout(200)
    print('cart lines',pg.evaluate("JSON.stringify(BC)"))
    pg.click('[data-a=bt_cart]');pg.wait_for_timeout(300);print('cart rows:',pg.locator('[data-a=bt_cd]').count(),'order btns:',pg.locator('[data-a=bt_co]').count());pg.screenshot(path='../shots/o1_cart.png')
    pg.click('[data-a=bt_co]');pg.wait_for_timeout(200);print('empty form blocked, orders on server:',len(ORD))
    pg.fill('#bcn','علی رضایی');pg.fill('#bcp','09121234567');pg.fill('#bca','سراوان، خیابان اصلی')
    pg.click('[data-a=bt_co]');pg.wait_for_timeout(500)
    print('orders on server:',len(ORD),'total',ORD[0]['total'] if ORD else None,'cart left',pg.evaluate("BC.length"));print(json.dumps(ORD[0]['lines'],ensure_ascii=False) if ORD else '')
    # owner panel
    pg.evaluate("BT.u='ali';BT.p='1234';BM=null;go({tab:4,pnl:0,v:'btm',btt:'o'})");pg.wait_for_timeout(1200)
    print('owner order cards:',pg.locator('[data-a=bt_os]').count()//3);pg.screenshot(path='../shots/o1_orders.png')
    if pg.locator('[data-a=bt_os]').count():
        pg.locator('[data-a=bt_os][data-v$=":done"]').first.click();pg.wait_for_timeout(300);print('status on server:',ORD[0]['s'])
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
