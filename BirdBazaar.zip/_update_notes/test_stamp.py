# تست 1.9.103: مهر جدا غرفه/پرنده + شکست‌ساز ایمن + کلید سروری sf/cm
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ops=[]; mode={'psig':{"ok":1,"s":"S1","b":"B1","bb":"BB1","r":"R1"},'fail':False}
        async def mk():
            ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                req=route.request; u=req.url
                if u.startswith('file:'): return await route.continue_()
                try: bd=json.loads(req.post_data or '{}')
                except Exception: bd={}
                ops.append(bd.get('op'))
                try:
                    if mode['fail']: return await route.abort()
                    if bd.get('op')=='psig': return await route.fulfill(status=200,content_type='application/json',body=json.dumps(mode['psig']))
                    if bd.get('op')=='bpublic': return await route.fulfill(status=200,content_type='application/json',body='{"ok":1,"booths":[{"id":1,"name":"a"}],"products":[]}')
                    if bd.get('op')=='rpublic': return await route.fulfill(status=200,content_type='application/json',body='{"ok":1,"birds":[{"id":1}]}')
                    await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
                except Exception: pass
            await pg.route('**/*',h)
            await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1500)
            return pg,errs
        cnt=lambda n: sum(1 for o in ops if o==n)
        pg,errs=await mk()
        # --- مهر جدا ---
        await pg.evaluate("localStorage.removeItem(PSB);localStorage.removeItem(PSR);BDL.ok=0;BT.ok=0")
        ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('first: booths+birds downloaded', cnt('bpublic')>=1 and cnt('rpublic')>=1)
        chk('stamps stored separately', await pg.evaluate("[localStorage.getItem(PSB),localStorage.getItem(PSR)]")==['BB1','R1'])
        ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        chk('same stamps: nothing downloaded', cnt('bpublic')==0 and cnt('rpublic')==0)
        mode['psig']={"ok":1,"s":"S1","b":"B2","bb":"BB1","r":"R2"}
        ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('only birds changed: only birds downloaded (%s)'%ops, cnt('rpublic')>=1 and cnt('bpublic')==0)
        mode['psig']={"ok":1,"s":"S1","b":"B3","bb":"BB3","r":"R2"}
        ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('only booths changed: only booths downloaded (%s)'%ops, cnt('bpublic')>=1 and cnt('rpublic')==0)
        # سرور قدیمی بدون bb/r ← همان رفتار قدیمی با b
        mode['psig']={"ok":1,"s":"S1","b":"OLD1"}
        await pg.evaluate("localStorage.removeItem(PSB)"); ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('old server (no bb/r): falls back to b', cnt('bpublic')>=1 and cnt('rpublic')>=1)
        ops.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(600)
        chk('old server: same b -> nothing', cnt('bpublic')==0 and cnt('rpublic')==0)
        # --- شکست‌ساز ---
        await pg.evaluate("SF.nf=0;SF.bk=0;S.role='user';S.me='ali';S.v=null;S.tab=0")
        mode['fail']=True
        for i in range(3): await pg.evaluate("psig()")
        chk('breaker open after 3 failures', await pg.evaluate("sfBlocked()")==True)
        mode['fail']=False; ops.clear()
        await pg.evaluate("SF.pl=0;SF.t={};LV.act=Date.now();sfTick();sfEnter()"); await pg.wait_for_timeout(500)
        chk('blocked: no requests (%s)'%ops, not [o for o in ops if o in ('psig','ping','public','bpublic')])
        await pg.evaluate("dispatchEvent(new Event('online'))")
        chk('online resets breaker', await pg.evaluate("sfBlocked()")==False)
        await pg.evaluate("SF.bk=Date.now()-1;SF.nf=3")
        chk('backoff expires', await pg.evaluate("sfBlocked()")==False)
        await pg.evaluate("psig()"); await pg.wait_for_timeout(300)
        chk('success resets counter', await pg.evaluate("SF.nf")==0)
        # --- کلید سروری ---
        chk('server flag default on', await pg.evaluate("[xf('sf'),xf('cm')]")==[1,1] or await pg.evaluate("!!xf('sf')&&!!xf('cm')"))
        await pg.evaluate("XF.sf=0;XF.cm=0")
        chk('server sf off -> sfOn false', await pg.evaluate("sfOn()")==False)
        chk('server cm off -> cmOn false', await pg.evaluate("cmOn()")==False)
        await pg.evaluate("XF.sf=1;XF.cm=1")
        chk('server on -> on', await pg.evaluate("sfOn()&&cmOn()"))
        chk('tlSf shows stamp status', 'مهرهای سرور' in await pg.evaluate("tlSf()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
