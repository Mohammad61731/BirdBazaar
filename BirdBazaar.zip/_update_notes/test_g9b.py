# تست 1.9.426 G9-b: پاسخ/سنجاق/کپی در چت (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("localStorage.removeItem('bp_cpn');XF.pn=0;CS.cur={b:1,cu:'x',r:'u'};CS.m=[{id:5,s:'b',b:'نشانی: تهران ، خیابان آزادی',t:Date.now(),k:'t'},{id:6,s:'u',b:'ممنون',t:Date.now(),k:'t'}];CS.ps=0")
        chk(t+'off -> no hooks',pg.evaluate("!cMsgsH().includes('ct_mt')&&pnPnH()===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'on -> bubbles tappable',pg.evaluate("(cMsgsH().match(/ct_mt/g)||[]).length==2"))
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.body.appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(250)
        pg.evaluate("document.getElementById('scr').innerHTML='<div id=msgs>'+cMsgsH()+'</div><input id=cmi>'")
        click('ct_mt','5')
        chk(t+'sheet opens with 3 actions',pg.evaluate("document.body.innerHTML.includes('ct_mr')&&document.body.innerHTML.includes('ct_mp')&&document.body.innerHTML.includes('ct_mc')"))
        click('ct_mr','5')
        chk(t+'reply quotes',pg.evaluate("document.getElementById('cmi').value.startsWith('«نشانی')"))
        click('ct_mp','5')
        chk(t+'pinned',pg.evaluate("pnPnH().includes('نشانی')&&pnPnH().includes('ct_pu')&&cMsgsH().includes('pnkPin')"))
        pg.evaluate("CS.cur={b:2,cu:'x',r:'u'}")
        chk(t+'pin per chat',pg.evaluate("pnPnH()===''"))
        pg.evaluate("CS.cur={b:1,cu:'x',r:'u'}")
        click('ct_pu')
        chk(t+'unpin',pg.evaluate("pnPnH()===''"))
        click('ct_mt','999');click('ct_mr','999')
        chk(t+'bad id ignored',pg.evaluate("document.getElementById('cmi').value.startsWith('«نشانی')"))
        pg.evaluate("localStorage.setItem('bp_cpn','{broken')")
        chk(t+'broken storage safe',pg.evaluate("pnPnH()===''&&typeof cMsgsH()=='string'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
