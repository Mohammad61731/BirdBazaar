import json,sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
errs=[];ok=[]
ROOMS=[{'id':7,'name':'عمومی','emoji':'🦜','color':''},{'id':8,'name':'دوم','emoji':'🐦','color':''}]
MS=[{'id':1,'u':'reza','k':'text','b':'سلام','md':None,'rt':None,'pin':False,'ed':False,'t':'2026-11-13T08:00:00Z','r':{}}]
FAQ=[{'id':1,'qu':'کاربر نمونه 1','q':'پرسش یک؟','a':'پاسخ یک'}]
calls=[]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);o=b['op'];a=b['a'];r={'err':'x'};calls.append((o,a))
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'admin','main':True,'perm':{'txt':True},'avatar':''}
        if o=='fpull':r={'ok':1,'rooms':ROOMS,'msgs':MS,'av':{},'pins':[],'reqn':0}
        if o=='ffaq':r={'ok':1,'faq':FAQ}
        if o=='froom_set':
            if a.get('id'):
                for x in ROOMS:
                    if x['id']==a['id']:x.update(name=a['name'],emoji=a['emoji'],color=a['color'])
            else:ROOMS.append({'id':9,'name':a['name'],'emoji':a['emoji'],'color':a['color']})
            r={'ok':1}
        if o=='froom_del':ROOMS[:]=[x for x in ROOMS if x['id']!=a['id']];r={'ok':1}
        if o=='fedit':MS[0]['b']=a['b'];MS[0]['ed']=True;r={'ok':1}
        if o=='ffaq_set':
            if a.get('id'):FAQ[0].update(q=a['q'],a=a['a'],qu=a['qu'])
            else:FAQ.append({'id':5,'qu':a['qu'],'q':a['q'],'a':a['a']})
            r={'ok':1}
        if o=='ffaq_del':FAQ[:]=[x for x in FAQ if x['id']!=a['id']];r={'ok':1}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept());pg.route('**/*',h)
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.me='adm';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(1500)
    chk('1 دکمه مدیریت گروه‌ها برای ادمین',pg.locator('[data-a=frmg]').count()==1)
    pg.click('[data-a=frmg]');pg.wait_for_timeout(300)
    chk('2 لیست گروه‌ها در برگه',pg.locator('.sheet [data-a=frme]').count()==3)  # 2 edit + add
    pg.click('.sheet [data-a=frme][data-v="0"]');pg.wait_for_timeout(200)
    pg.fill('#rmn','گروه تازه');pg.fill('#rme','🦆');pg.click('[data-a=frmc][data-v="#2563eb"]');pg.wait_for_timeout(200)
    chk('3 نام بعد از انتخاب رنگ حفظ شد',pg.input_value('#rmn')=='گروه تازه')
    pg.click('[data-a=frms]');pg.wait_for_timeout(700)
    chk('4 گروه ساخته شد با رنگ',any(c[0]=='froom_set' and c[1].get('color')=='#2563eb' and 'id' not in c[1] for c in calls) and len(ROOMS)==3)
    pg.click('.sheet [data-a=frme][data-v="8"]');pg.wait_for_timeout(200);pg.fill('#rmn','نام نو');pg.click('[data-a=frms]');pg.wait_for_timeout(700)
    chk('5 ویرایش گروه',ROOMS[1]['name']=='نام نو')
    pg.click('.sheet [data-a=frmd][data-v="9"]');pg.wait_for_timeout(700)
    chk('6 حذف گروه با تأیید',len(ROOMS)==2)
    pg.screenshot(path=P+'/shots/fadm_rooms.png');pg.evaluate("cl()")
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    pg.click('[data-a=fqa]');pg.wait_for_timeout(400)
    chk('7 FAQ با برچسب نمونه',pg.locator('.sheet .pill').count()==1 and 'نمونه' in pg.inner_text('.sheet'))
    pg.click('.sheet [data-a=fqe][data-v="1"]');pg.wait_for_timeout(200);pg.fill('#fqq','پرسش ویرایش');pg.click('[data-a=fqs]');pg.wait_for_timeout(700)
    chk('8 ویرایش FAQ',FAQ[0]['q']=='پرسش ویرایش' and 'پرسش ویرایش' in pg.inner_text('.sheet'))
    pg.click('.sheet [data-a=fqe][data-v="0"]');pg.fill('#fqq','جدید');pg.fill('#fqn','جواب');pg.click('[data-a=fqs]');pg.wait_for_timeout(700)
    chk('9 افزودن FAQ',len(FAQ)==2)
    pg.click('.sheet [data-a=fqd][data-v="5"]');pg.wait_for_timeout(500)
    chk('10 حذف FAQ',len(FAQ)==1)
    pg.screenshot(path=P+'/shots/fadm_faq.png');pg.evaluate("cl()")
    pg.click('.fmr[data-id]');pg.wait_for_timeout(300)
    chk('11 دکمه ویرایش پیام برای ادمین',pg.locator('[data-a=fed]').count()==1)
    pg.click('[data-a=fed]');pg.fill('#fedt','متن اصلاح‌شده');pg.click('[data-a=feds]');pg.wait_for_timeout(700)
    chk('12 پیام ویرایش و علامت «ویرایش شد»','متن اصلاح‌شده' in pg.inner_text('#msgs') and 'ویرایش شد' in pg.inner_text('#msgs'))
    pg.screenshot(path=P+'/shots/fadm_edit.png')
    # کاربر عادی
    pg.evaluate("FM.main=0");pg.click('.fmr[data-id]');pg.wait_for_timeout(300)
    chk('13 کاربر عادی دکمه ویرایش ندارد',pg.locator('[data-a=fed]').count()==0);pg.evaluate("cl()")
    pg.click('[data-a=fqa]');pg.wait_for_timeout(400)
    chk('14 کاربر عادی FAQ را بدون دکمه‌ی مدیریت می‌بیند',pg.locator('[data-a=fqe]').count()==0 and pg.locator('.sheet .card').count()==1);pg.evaluate("cl()")
    pg.evaluate("FM.main=1")
    for th in ('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in (320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150)
            pg.evaluate("fRmSheet()");a=pg.evaluate("document.documentElement.scrollWidth>innerWidth");pg.evaluate("FM.rg={id:0,name:'x',emoji:'🦜',color:''};fRmEdit()");b=pg.evaluate("document.querySelector('.sheet').scrollWidth>document.querySelector('.sheet').clientWidth")
            pg.evaluate("fFaqSheet()");c=pg.evaluate("document.querySelector('.sheet').scrollWidth>document.querySelector('.sheet').clientWidth")
            chk('15 بدون سرریز %s %d'%(th,w),not(a or b or c))
    pg.screenshot(path=P+'/shots/fadm_dark.png')
    chk('16 بدون خطای صفحه',not errs)
    print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
