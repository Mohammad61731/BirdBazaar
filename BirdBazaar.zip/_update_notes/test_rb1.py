# تست 1.9.470: مرجوعی با پیک برگشت (کلید rb)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("BT.booths=[{id:1,phone:'09120000000'}]")
        X="{b:1,bn:'غرفه',t:Date.now()}"
        chk(f'{w}: off -> empty',pg.evaluate(f"rbH({X})===''"))
        pg.evaluate("XF.rb=1")
        chk(f'{w}: on -> sms chip',pg.evaluate(f"rbH({X}).includes('sms:09120000000?body=')"))
        pg.evaluate("BT.booths=[{id:1}]")
        chk(f'{w}: no phone -> empty',pg.evaluate(f"rbH({X})===''"))
        pg.evaluate("BT.booths=[{id:1,phone:'09120000000'}]")
        pg.evaluate(f"document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+rbH({X})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: chip shown',pg.locator('#scr a.chip').count()==1)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    br.close()
print('ERRORS',errs)
