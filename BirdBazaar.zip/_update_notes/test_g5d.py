# تست 1.9.413 G5-d: چک‌لیست بسته‌بندی ، پرفروش‌ها ، کالای رو به اتمام (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnPk({id:1,s:'new',lines:[{n:'a'}]})===''&&pnStat()===''"))
        pg.evaluate("XF.pn=1")
        pg.evaluate("window.BOR=null;localStorage.removeItem('bp_opk');localStorage.removeItem('bp_lowth')")
        chk(t+'pk 2 chips',pg.evaluate("(pnPk({id:7,s:'new',lines:[{n:'x'},{n:'y'}]}).match(/<button/g)||[]).length==2"))
        chk(t+'pk hidden when closed',pg.evaluate("pnPk({id:7,s:'done',lines:[{n:'x'}]})===''"))
        def click(a,v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(250)
        click('pnpk','7:0')
        chk(t+'pk set',pg.evaluate("pnLs('bp_opk',{})[7].includes(0)&&pnPk({id:7,s:'new',lines:[{n:'x'},{n:'y'}]}).includes('۱/۲')"))
        click('pnpk','7:0')
        chk(t+'pk toggle off',pg.evaluate("!pnLs('bp_opk',{})[7]"))
        pg.evaluate("(()=>{const m={};for(let i=1;i<=230;i++)m[i]=[0];pnPkS(m)})()")
        chk(t+'pk cap 200',pg.evaluate("Object.keys(pnLs('bp_opk',{})).length===200"))
        chk(t+'top empty without BOR',pg.evaluate("(window.BOR=null,pnTop()==='')"))
        pg.evaluate("BOR=[{id:1,s:'new',lines:[{n:'A <b>',q:2,t:20},{n:'B',q:5,t:50}]},{id:2,s:'done',lines:[{n:'A <b>',q:4,t:40}]},{id:3,s:'cancel',lines:[{n:'B',q:99,t:1}]}]")
        chk(t+'top order+escape',pg.evaluate("(()=>{const h=pnTop();return h.indexOf('A &lt;b&gt;')>0&&h.indexOf('A &lt;b&gt;')<h.indexOf('>B<')||h.indexOf('A &lt;b&gt;')>0&&!h.includes('۹۹')})()"))
        chk(t+'top skips cancel',pg.evaluate("!pnTop().includes('۱۰۴')&&!pnTop().includes('۹۹')"))
        pg.evaluate("BM={booth:{name:'t',views:0},prods:[{id:1,s:'on',d:{name:'p1',stock:'2'}},{id:2,s:'on',d:{name:'p2',stock:'abc'}},{id:3,s:'on',d:{name:'p3',stock:'9'}},{id:4,s:'on',d:{name:'p4',stock:'1',out:1}},{id:5,s:'on',d:{name:'p5',stock:''}}],days:[]}")
        chk(t+'low only numeric<=3',pg.evaluate("(()=>{const h=pnLow();return h.includes('p1')&&!h.includes('p2')&&!h.includes('p3')&&!h.includes('p4')&&!h.includes('p5')})()"))
        click('pnlt','10')
        chk(t+'low threshold 10',pg.evaluate("pnLow().includes('p3')&&localStorage.getItem('bp_lowth')==='10'"))
        click('pnlt','99')
        chk(t+'low bad value ignored',pg.evaluate("localStorage.getItem('bp_lowth')==='10'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
