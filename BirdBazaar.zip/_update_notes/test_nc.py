# تست 1.9.158: کلید nc (سقف اعلان)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[];calls=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
def tapp(route,req):
    calls.append(json.loads(req.post_data));route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR')
    pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',handle);pg.route('**/rpc/tapp',tapp);pg.goto('file:///home/claude/bb2/www/index.html');pg.wait_for_timeout(1500)
    N=lambda:[c for c in calls if c['op']=='ncset']
    pg.evaluate("S.me='u1';S.pw='p';XF.nc=0;drawer()");pg.wait_for_timeout(200)
    chk('off: no drawer item',pg.locator('[data-a=ncs]').count()==0)
    pg.evaluate("cl();XF.nc=1;drawer()");pg.wait_for_timeout(200)
    chk('on: drawer item',pg.locator('[data-a=ncs]').count()==1)
    pg.evaluate("document.querySelector('[data-a=ncs]').click()");pg.wait_for_timeout(300)
    chk('sheet has 4 options',pg.locator('[data-a=ncp]').count()==4)
    pg.evaluate("document.querySelector('[data-a=ncp][data-v=\"3\"]').click()");pg.wait_for_timeout(300)
    chk('one ncset with c=3',len(N())==1 and N()[0]['a']['c']==3)
    chk('saved locally',pg.evaluate("localStorage.getItem('bp_nc')")=='3')
    pg.evaluate("S.me='';cl();drawer()");pg.wait_for_timeout(200)
    chk('no login: no item',pg.locator('[data-a=ncs]').count()==0)
    br.close()
print('ERRORS',errs)
