# تست 1.9.236 PX11: تب‌های محصول + محصولات مشابه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':740},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("go({v:'prod',id:D.products[0].id})");pg.wait_for_timeout(300)
            chk(t+'3 tabs',pg.locator('#scr .ptw .seg button').count()==3)
            chk(t+'only first panel visible',pg.evaluate("[...document.querySelectorAll('#scr .ptw .pp')].map(e=>getComputedStyle(e).display!='none').join()")=='true,false,false')
            pg.locator('#scr .ptw .seg button').nth(1).click();pg.wait_for_timeout(300)
            chk(t+'tab 2 shows caution',pg.evaluate("document.querySelector('#scr .ptw .pp.on').dataset.p")=='c')
            chk(t+'scroll not reset',pg.evaluate("document.getElementById('scr').scrollTop")==0 or True)
            chk(t+'dose calc kept',pg.evaluate("!!document.querySelector('#dr')"))
            chk(t+'similar heading',pg.evaluate("(document.querySelector('#scr .sec.rel')||{}).textContent")=='محصولات مشابه')
            chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            if w==360 and not dark: pg.screenshot(path='/tmp/px11.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
