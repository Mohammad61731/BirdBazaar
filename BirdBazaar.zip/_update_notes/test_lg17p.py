# تست 1.9.297: پیش‌نمایش تم لیکویید در thSheet
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for m in ('i','ice','m','g'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page()
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            pg.evaluate("S.role='admin';S.me='ادمین';S.pm=['all'];D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=0;S.v=null;render()"%m);pg.wait_for_timeout(300)
            try:
                pg.evaluate("thSheet()");pg.wait_for_timeout(400)
                r=pg.evaluate("(()=>{const e=document.getElementById('thpv');if(!e)return null;const s=getComputedStyle(e);return {bd:s.borderTopColor,bf:s.backdropFilter,ov:document.documentElement.scrollWidth<=innerWidth}})()")
                chk(f'{w}{m} preview exists',r is not None)
                if r:
                    chk(f'{w}{m} no overflow',r['ov'])
                    if m in('i','ice'): chk(f'{w}{m} glass preview','blur' in r['bf'])
                    if w==360 and m=='ice': pg.screenshot(path='/tmp/lg17p.png')
            except Exception as e: chk(f'{w}{m} sheet '+str(e)[:60],False)
            ctx.close()
    br.close()
print('ERRORS',errs)
