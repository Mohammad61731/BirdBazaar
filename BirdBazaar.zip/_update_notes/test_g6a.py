# تست 1.9.416 G6-a: مسیر تا مشتری و پیام‌های آماده‌ی پیک (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnCrX({s:'way',phone:'0912',addr:'x'})===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'hidden before pickup',pg.evaluate("pnCrX({s:'acc',phone:'0912',addr:'x'})===''&&pnCrX({s:'rdy',phone:'0912',addr:'x'})===''"))
        chk(t+'route link encoded',pg.evaluate("pnCrX({s:'pick',phone:'0912',addr:'تهران & کوچه'}).includes('geo:0,0?q='+encodeURIComponent('تهران & کوچه'))"))
        chk(t+'4 sms chips',pg.evaluate("(pnCrX({s:'way',phone:'+98 912-1',addr:'a'}).match(/href=\"sms:\\+989121\\?body=/g)||[]).length==4"))
        chk(t+'no phone no chips',pg.evaluate("!pnCrX({s:'way',phone:'',addr:'a'}).includes('sms:')"))
        chk(t+'no addr no route',pg.evaluate("!pnCrX({s:'way',phone:'1',addr:''}).includes('geo:')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
