# تست 1.9.325: A-7 پنل‌های کشویی اکسپلورر (کلید xe)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
D0="dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("D.products=[1,2,3,4,5,6].map(i=>({id:900+i,name:'کالا '+i,cat:i%%2?'مکمل':'دان',price:50000*i,img:'',vol:{},%s}));BT.booths=[];BT.prods=[];BT.ok=1;BT.t=Date.now();S.role=null;go({tab:1,v:null,sv:'a',prf:0})"%D0)
            pg.wait_for_timeout(400)
            chk(t+'off by default: no rails',pg.locator('#scr .xrw').count()==0)
            pg.evaluate("XF.xe=1;render()");pg.wait_for_timeout(300)
            chk(t+'on: rails shown for categories',pg.locator('#scr .xrr').count()>=1 and pg.locator('#scr .xrl .pc').count()>=3)
            chk(t+'rail scrolls horizontally inside itself',pg.evaluate("(()=>{const l=document.querySelector('#scr .xrl');return getComputedStyle(l).overflowX=='auto'})()"))
            chk(t+'user has no switch',pg.locator('#scr .xrs').count()==0)
            chk(t+'no page overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth && document.getElementById('scr').scrollWidth<=document.getElementById('scr').clientWidth+1"))
            pg.evaluate("S.cat='مکمل';render()");pg.wait_for_timeout(200)
            chk(t+'category filter hides rails',pg.locator('#scr .xrw').count()==0)
            pg.evaluate("S.cat='';D.cms.XR={'مکمل':0};render()");pg.wait_for_timeout(200)
            chk(t+'off category hidden for user',pg.locator('#scr .xrr').count()==pg.evaluate("cats().filter(c=>c!='مکمل'&&D.products.some(p=>p.cat==c)).length"))
            pg.evaluate("D.cms.XR={};XF.xe=0;render()");pg.wait_for_timeout(200)
            chk(t+'master off again: none',pg.locator('#scr .xrw').count()==0)
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
