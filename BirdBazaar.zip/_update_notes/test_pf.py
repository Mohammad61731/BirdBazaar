# تست 1.9.145: کلید pf
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[];calls=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
def tapp(route,req):
    calls.append(json.loads(req.post_data));route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR')
    pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',handle);pg.route('**/rpc/tapp',tapp);pg.goto('file:///home/claude/bb2/www/index.html');pg.wait_for_timeout(1500)
    pg.evaluate("S.me='u1';S.pw='p';XF.bf=1;XF.pf=0;fbToggle(1)");pg.wait_for_timeout(300)
    print('ops',[c['op'] for c in calls]);F=lambda:[c for c in calls if c['op']=='fsync']
    chk('off: no fsync',not F())
    pg.evaluate("XF.pf=1;fbToggle(2)");pg.wait_for_timeout(300)
    chk('on: one fsync with ids',len(F())==1 and F()[0]['a']['ids']==[1,2])
    pg.evaluate("S.me=''");calls.clear();pg.evaluate("fbToggle(3)");pg.wait_for_timeout(200)
    chk('no login: no fsync',not F())
    br.close()
print('ERRORS',errs)
