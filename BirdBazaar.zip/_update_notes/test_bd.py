# تست 1.9.125: کشوی پرنده‌ها در ویترین (cfg.bd) و دسته‌های عمومی خانه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            D0="dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}"
            pg.evaluate("BDL.list=[{id:1,k:'sale',b:1,d:{name:'کاناری',price:900000,sx:'m'}},{id:2,k:'show',b:1,d:{name:'فنچ'}}];BDL.ok=1;D.cms.CT=[];D.cms.LY2=[{id:'search',w:'f'},{id:'grid',w:'f'}];D.products=[{id:901,name:'ویتامین',cat:'مکمل',price:200000,img:'',vol:{},%s},{id:902,name:'کفش',cat:'پوشاک',price:70000,img:'',vol:{},%s}];S.role=null;go({tab:1,v:null,sv:'a',cat:''})"%(D0,D0))
            pg.wait_for_timeout(300)
            ids=pg.evaluate("[...document.querySelectorAll('#scr .hbk')].map(e=>e.dataset.b).join(',')")
            chk(t+'birds block present before chips/grid with saved layout ('+ids+')','birds' in ids and ids.index('birds')<ids.index('grid'))
            chk(t+'2 bird cards (sale+show)',pg.evaluate("document.querySelectorAll('[data-b=birds] .pc').length")==2)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            pg.evaluate("go({tab:1,v:null,cat:'مکمل'})");pg.wait_for_timeout(200)
            chk(t+'hidden when a category is chosen',pg.evaluate("document.querySelectorAll('[data-b=birds]').length")==0)
            pg.evaluate("XF.bd=0;go({tab:1,v:null,cat:''})");pg.wait_for_timeout(200)
            chk(t+'bd=0 hides',pg.evaluate("document.querySelectorAll('[data-b=birds]').length")==0)
            pg.evaluate("XF.bd=1;D.cfg.salon=0;go({tab:1,v:null,cat:''})");pg.wait_for_timeout(200)
            chk(t+'salon=0 hides birds',pg.evaluate("document.querySelectorAll('[data-b=birds]').length")==0)
            pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(300)
            tiles=pg.evaluate("[...document.querySelectorAll('[data-a=ct]')].map(e=>e.textContent.trim()).join('|')")
            chk(t+'home categories built from real product cats ('+tiles+')','مکمل' in tiles and 'پوشاک' in tiles and 'غذا' not in tiles)
            pg.locator('[data-a=ct]',has_text='پوشاک').first.click();pg.wait_for_timeout(300)
            chk(t+'tapping tile filters store by that category',pg.evaluate("S.tab==1&&S.cat=='پوشاک'"))
            pg.evaluate("D.cfg.salon=1;D.cms.CT=[];go({tab:0,v:null})");pg.wait_for_timeout(200)
            chk(t+'salon=1 keeps old default pet categories',pg.evaluate("[...document.querySelectorAll('[data-a=ct]')].map(e=>e.textContent).join('').includes('غذا')"))
            ctx.close()
    br.close()
print('ERRORS',errs)
