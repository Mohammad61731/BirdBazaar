from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='text/css',body=''))
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(900)
    print('1) FN count:',pg.evaluate("FN.length"),'| has iphone/samsung/xiaomi:',pg.evaluate("['SF Pro','SamsungOne','MiSans'].every(k=>FN.some(x=>x[0].includes(k)))"))
    pg.click('#top [data-a=dr]');pg.wait_for_timeout(300);print('2) drawer has font item:',pg.locator('[data-a=ffs]').count()==1)
    pg.click('[data-a=ffs]');pg.wait_for_timeout(400);print('   sheet options:',pg.locator('[data-a=ffp]').count())
    pg.screenshot(path='../shots/u8_sheet.png')
    ff=lambda:pg.evaluate("getComputedStyle(document.body).fontFamily")
    print('   default font:',ff()[:30])
    idx=pg.evaluate("FN.findIndex(x=>x[0].includes('SamsungOne'))");pg.click(f'[data-a=ffp][data-v="{idx}"]');pg.wait_for_timeout(400)
    print('3) samsung applied:',ff()[:40],'| saved:',pg.evaluate("localStorage.getItem('bp_ff')")[:20])
    links=pg.evaluate("[...document.querySelectorAll('link[href*=\"fonts.googleapis\"]')].map(l=>l.href).length");print('   google links (no system stack link):',links, pg.evaluate("[...document.querySelectorAll('link[href*=\"fonts.googleapis\"]')].some(l=>/SamsungOne|apple/i.test(l.href))")==False)
    pg.reload();pg.wait_for_timeout(900);print('4) persists after reload:',ff()[:40])
    pg.click('#top [data-a=dr]');pg.click('[data-a=ffs]');pg.wait_for_timeout(300)
    idx=pg.evaluate("FN.findIndex(x=>x[0]==\"'Tajawal'\")");pg.click(f'[data-a=ffp][data-v="{idx}"]');pg.wait_for_timeout(400);print('5) google font applied:',ff()[:30],'| link added:',pg.evaluate("[...document.querySelectorAll('link[href*=\"Tajawal\"]')].length==1"))
    pg.click('#top [data-a=dr]');pg.click('[data-a=ffs]');pg.wait_for_timeout(300);pg.click('[data-a=ffp][data-v="0"]');pg.wait_for_timeout(400)
    print('6) reset:',ff()[:30],'| storage cleared:',pg.evaluate("localStorage.getItem('bp_ff')")is None)
    pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];go({tab:0,v:null})");pg.wait_for_timeout(300)
    print('7) admin CMS select shows new fonts (BR):',pg.evaluate("(()=>{be('br');return document.querySelectorAll('select option').length})()")>=20)
    pg.evaluate("cl&&0");pg.click('#top [data-a=dr]') if False else None
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("cl();go({tab:0,v:null})");pg.wait_for_timeout(200);pg.evaluate("ffSheet()");pg.wait_for_timeout(300)
        print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'| sheet overflow:',pg.evaluate("(()=>{const e=document.querySelector('.sheet');return e.scrollWidth>e.clientWidth+1})()"))
    pg.screenshot(path='../shots/u8_320.png')
    print('ERRORS',errs);br.close()
