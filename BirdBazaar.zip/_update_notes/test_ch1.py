# تست 1.9.387 D1/146+135+133: cb cq cu
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.ch=0;D.products.forEach(p=>p.out=0);D.cart=[{id:D.products[0].id,q:1}];S.tab=3;S.v=0;render()")
        chk(t+'ch off: no chips',not pg.evaluate("!!document.querySelector('#scr [data-a=sbs]')") and pg.evaluate("sbTxt(D.cart[0])")=='')
        pg.evaluate("XF.ch=1;render()");chk(t+'ch on: 3 chips',pg.evaluate("document.querySelectorAll('#scr [data-a=sbs]').length")==3)
        pg.evaluate("document.querySelector('#scr [data-a=sbs][data-v$=\":c\"]').click()")
        chk(t+'ch choice stored',pg.evaluate("D.cart[0].sb")=='c' and 'زنگ' in pg.evaluate("sbTxt(D.cart[0])"))
        pg.evaluate("document.querySelector('#scr [data-a=sbs][data-v$=\":c\"]').click()")
        chk(t+'ch toggle clears',pg.evaluate("D.cart[0].sb")==None and pg.evaluate("sbTxt(D.cart[0])")=='')
        pg.evaluate("document.querySelector('#scr [data-a=sbs][data-v$=\":s\"]').click()")
        chk(t+'ch similar text','مشابه' in pg.evaluate("sbTxt(D.cart[0])"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
