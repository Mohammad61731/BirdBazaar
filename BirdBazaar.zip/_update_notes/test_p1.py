import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[];reqs=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:b=json.loads(q.post_data or '{}')
    except Exception:b={}
    reqs.append(b);o=b.get('op')
    if o=='myorders':body={'ok':1,'l':[{'id':7,'dt':'1405/08/24','tt':250000,'st':'done','it':[{'n':'A','q':2}]},{'id':5,'dt':'1405/08/20','tt':90000,'st':'x','it':[{'n':'B','q':1}]},{'id':3,'dt':'1405/08/10','tt':10000,'st':'new','it':[]}]}
    elif o=='order_add':body={'id':9}
    else:body={'ok':1}
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            pg=br.new_page(viewport={'width':w,'height':760},locale='fa-IR',color_scheme='dark' if dark else 'light');pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700)
            pg.evaluate("S.role='user';S.me='ali';S.pw='x';S.pm=[];go({tab:4,v:null})");pg.wait_for_timeout(250)
            chk('w%d d%d دکمه‌ی سفارش‌های من در پروفایل'%(w,dark),pg.locator('[data-a=moO]').count()==1)
            pg.evaluate("document.querySelector('[data-a=moO]').click()");pg.wait_for_timeout(600)
            t=pg.inner_text('#scr')
            chk('w%d d%d سه سفارش با وضعیت'%(w,dark),pg.locator('#scr .card').count()==3 and 'انجام شد' in t and 'لغو شد' in t and 'در انتظار بررسی' in t)
            chk('w%d d%d بدون سرریز'%(w,dark),pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360 and dark==0:pg.screenshot(path=P+'/shots/p1.png')
            pg.close()
    # مهمان دکمه ندارد
    pg=br.new_page(viewport={'width':360,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700)
    pg.evaluate("S.role=null;S.me='';go({tab:4,v:null})");pg.wait_for_timeout(250)
    chk('مهمان دکمه ندارد',pg.locator('[data-a=moO]').count()==0)
    # ثبت سفارش u می‌فرستد
    pg.evaluate("S.role='user';S.me='ali';S.pw='x';D.cfg.guestOrder=1;const p=D.products[0];if(p){D.cart=[{id:p.id,w:0,v:0,q:1}]}S.f={cn:'a',cf:'b',cp:'09120000000',ca:'x'};go({tab:3,v:null})");pg.wait_for_timeout(250)
    if pg.evaluate("D.cart.length"):
        pg.evaluate("document.querySelector('[data-a=co]')&&document.querySelector('[data-a=co]').click()");pg.wait_for_timeout(500)
        oa=[r for r in reqs if r.get('op')=='order_add']
        chk('order_add شامل u=ali',bool(oa) and oa[-1].get('a',{}).get('u')=='ali')
    else:print('SKIP order_add (no products in test data)')
    chk('بدون خطای صفحه',not errs)
    if errs:print(errs)
    br.close()
sys.exit(0 if all(ok) else 1)
