import json,re,sys
from playwright.sync_api import sync_playwright
DB={'booths':[{'id':1,'owner':'ali','pw':'1234','name':'غرفه علی','bio':'ارزن و کتان عمده','logo':'','cover':'','city':'سراوان','phone':'09120000000','status':'active','views':5}],'prods':[],'reqs':[{'id':1,'name':'رضا','phone':'09151112233','city':'زاهدان','shop':'دان رضا','about':'دان','status':'new'}],'nid':1}
def handle(route,req):
    u=req.url
    if u.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op'];a=b.get('a') or {};U=b.get('u');P=b.get('p')
        def bo():
            return next((x for x in DB['booths'] if x['owner']==U and x['pw']==P),None)
        def pub(x):return {k:x[k] for k in ['id','name','bio','logo','cover','city','phone','views']}|{'n':len([q for q in DB['prods'] if q['b']==x['id'] and q['s']=='on'])}
        r={'err':'unknown'}
        if o=='bpublic':r={'ok':1,'booths':[pub(x) for x in DB['booths'] if x['status']=='active'],'prods':[{'id':q['id'],'b':q['b'],'d':q['d'],'t':'x'} for q in reversed(DB['prods']) if q['s']=='on']}
        elif o=='bview':r={'ok':1}
        elif o=='breq':DB['reqs'].append({'id':len(DB['reqs'])+1,'name':a['name'],'phone':a['phone'],'city':a.get('city'),'shop':a.get('shop'),'about':a.get('about'),'status':'new'});r={'ok':1}
        elif o in('blogin','bme'):
            x=bo()
            r={'err':'denied'} if not x else {'ok':1,'booth':{**pub(x),'status':x['status']},'prods':[{'id':q['id'],'d':q['d'],'s':q['s'],'t':'x'} for q in DB['prods'] if q['b']==x['id']],'days':[{'day':'2026-11-13','n':3}]}
        elif o=='bprod_set':
            x=bo()
            if a.get('id'):
                for q in DB['prods']:
                    if q['id']==a['id']:q['d']=a['d'];q['s']=a.get('s','on')
                r={'ok':1,'id':a['id']}
            else:
                DB['nid']+=1;DB['prods'].append({'id':DB['nid'],'b':x['id'],'d':a['d'],'s':a.get('s','on')});r={'ok':1,'id':DB['nid']}
        elif o=='bprod_del':DB['prods']=[q for q in DB['prods'] if q['id']!=a['id']];r={'ok':1}
        elif o=='bset':
            x=bo();x.update({k:a[k] for k in ['name','bio','city','phone','logo','cover'] if k in a});r={'ok':1}
        elif o.startswith('badm_'):
            if a.get('k')!='sec':r={'err':'denied'}
            elif o=='badm_list':r={'ok':1,'reqs':[x for x in DB['reqs'] if x['status']=='new'],'booths':[{'id':x['id'],'owner':x['owner'],'name':x['name'],'city':x['city'],'phone':x['phone'],'status':x['status'],'views':x['views'],'n':len([q for q in DB['prods'] if q['b']==x['id']])} for x in DB['booths']]}
            elif o=='badm_approve':
                q=next(x for x in DB['reqs'] if x['id']==a['id']);q['status']='ok';DB['booths'].append({'id':len(DB['booths'])+1,'owner':a['owner'],'pw':a['pw'],'name':q['shop'],'bio':'','logo':'','cover':'','city':q['city'],'phone':q['phone'],'status':'active','views':0});r={'ok':1}
            else:r={'ok':1}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    if '/rpc/app' in u:
        route.fulfill(status=200,content_type='application/json',body='{"err":"x"}');return
    route.continue_()

errs=[]
DB['prods'].append({'id':2,'b':1,'d':{'name':'دان فنچ','type':'plain','price':50000,'emoji':'🌰','disc':20,'imgs':[]},'s':'on'});DB['prods'].append({'id':3,'b':1,'d':{'name':'ارزن قرمز','type':'wt','unit':'kg','rt':{'on':1,'price':100000,'steps':[]},'wh':{'on':0},'emoji':'🌾','imgs':[]},'s':'on'});DB['nid']=3
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',handle);pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(1000)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';go({tab:4,pnl:1,at:'bt',v:null})");pg.wait_for_timeout(300)
    print('has key prompt:',pg.locator('#bak').count())
    pg.fill('#bak','sec');pg.click('[data-a=bt_ak]');pg.wait_for_timeout(700)
    print('reqs shown:',pg.locator('[data-a=bt_ap]').count(),'booth rows:',pg.locator('[data-a=bt_rs]').count());pg.screenshot(path='shots/admin.png')
    pg.click('[data-a=bt_ap]');pg.wait_for_timeout(200);pg.click('[data-a=bt_ap2]');pg.wait_for_timeout(700)
    print('booths in db:',len(DB['booths']),'cred sheet:',pg.locator('[data-a=bt_cc]').count())
    pg.click('[data-a=clo2]')
    # explore edit mode
    pg.evaluate("go({tab:1,pnl:0,v:null,sv:'b'})");pg.wait_for_timeout(400)
    pg.click('[data-a=bt_bxe]');pg.wait_for_timeout(200)
    pg.locator('.ext').first.click();pg.wait_for_timeout(200);print('size sheet chips:',pg.locator('[data-a=bt_sz]').count())
    pg.click('[data-a=bt_sz][data-v$=":fw"]');pg.wait_for_timeout(300)
    print('BX:',pg.evaluate("JSON.stringify(D.cms.BX)"))
    pg.locator('.ext').nth(1).click();pg.click('[data-a=bt_pin]');pg.wait_for_timeout(300);print('BX pin:',pg.evaluate("JSON.stringify(D.cms.BX.pin)"),'first tile name:',pg.locator('.ext .exo b').first.inner_text())
    pg.click('[data-a=bt_ord][data-v=disc]');pg.wait_for_timeout(200);print('order',pg.evaluate("D.cms.BX.ord"));pg.screenshot(path='shots/explore_ed.png')
    # hidden by admin then public view
    pg.locator('.ext').first.click();pg.click('[data-a=bt_hd]');pg.wait_for_timeout(200)
    pg.evaluate("S.role=null;S.pm=[];S.bxe=0;btRe()");pg.wait_for_timeout(200);print('public tiles after hide:',pg.locator('.ext').count())
    # admin: delete product on product page
    pg.evaluate("S.role='admin';S.pm=['all'];go({v:'btp',id:2})");pg.wait_for_timeout(200)
    print('link box:',pg.locator('input[readonly]').first.input_value());pg.click('[data-a=bt_pda]');pg.wait_for_timeout(400);print('after admin delete v=',pg.evaluate("S.v"))
    # home layout block resize via existing LY
    print('home lay has booth:',pg.evaluate("lay('home').some(x=>x.id=='booth')"))
    print('ERRORS',errs);br.close()
