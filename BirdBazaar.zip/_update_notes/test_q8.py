import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("""S.role='user';S.me='ali';S.pm=[];D.ads=[
{id:11,title:'جفت مرغ عشق',sp:'مرغ عشق',price:900000,desc:'سالم',imgs:[],st:'ok',own:'sara',city:'تهران'},
{id:12,title:'قفس بزرگ',sp:'لوازم',price:300000,desc:'نو',imgs:[],st:'ok',own:'sara'},
{id:13,title:'در انتظار',sp:'x',price:1,desc:'x',imgs:[],st:'wait',own:'sara'},
{id:14,title:'آگهی دیگران',sp:'x',price:1,desc:'x',imgs:[],st:'ok',own:'reza'}];
FM.msgs=[{id:1,u:'sara',t:'سلام'},{id:2,u:'sara',t:'x'},{id:3,u:'reza',t:'y'}];FM.av={sara:'data:image/gif;base64,R0lGODlhAQABAAAAACw='};
go({v:'ad',id:11})""");pg.wait_for_timeout(300)
    chk('1 جعبه‌ی آگهی‌دهنده قابل لمس',pg.locator('.ao[data-a=upf]').count()==1)
    pg.click('.ao[data-a=upf]');pg.wait_for_timeout(250)
    t=pg.inner_text('.sheet')
    chk('2 نام کاربر',  'sara' in t)
    chk('3 فقط آگهی‌های تأییدشده‌ی خودش (۲)', pg.locator('.sheet .upr').count()==2 and 'در انتظار' not in t and 'دیگران' not in t)
    chk('4 تعداد آگهی ۲ و پیام اخیر ۲',pg.evaluate("upAds('sara').length==2") and pg.locator('.sheet .stg .card').count()==2)
    chk('5 آواتار',pg.evaluate("!!document.querySelector('.sheet .upf .av').style.backgroundImage"))
    pg.screenshot(path=P+'/shots/q8.png')
    pg.click('.sheet .upr[data-v="12"]');pg.wait_for_timeout(300)
    chk('6 باز شدن آگهی و بسته شدن برگه',pg.evaluate("S.v=='ad'&&S.id==12")and pg.locator('.sheet').count()==0)
    pg.evaluate("go({v:'ad',id:14})");pg.wait_for_timeout(200);pg.click('.ao[data-a=upf]');pg.wait_for_timeout(200)
    chk('7 بدون پیام انجمن: فقط کارت آگهی',pg.locator('.sheet .stg .card').count()==2 or pg.locator('.sheet .stg .card').count()==1)
    pg.evaluate("D.ads=D.ads.filter(a=>a.own!='reza');upSheet('reza')");pg.wait_for_timeout(200)
    chk('8 بدون آگهی: پیام خالی',pg.locator('.sheet .upr').count()==0 and 'آگهی فعالی ندارد' in pg.inner_text('.sheet'))
    pg.click('.sheet [data-a=clo2]');pg.wait_for_timeout(150)
    chk('9 بستن',pg.locator('.sheet').count()==0)
    for th in('light','dark'):
        for w in(320,360,412):
            pg.evaluate("document.documentElement.setAttribute('data-theme','%s');upSheel=0"%th) if False else pg.evaluate("document.documentElement.setAttribute('data-theme','%s');upSheet('sara')"%th)
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth||[...document.querySelectorAll('.sheet *')].some(e=>e.getBoundingClientRect().right>innerWidth+1)"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
