# تست 1.9.513 A28+A29: نظرات غرفه
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
LST={'ok':1,'n':2,'av':4.5,'l':[{'id':5,'nm':'علی','s':5,'t':'عالی بود','rep':'ممنون','d':'2026-11-20'},{'id':4,'nm':'سارا','s':4,'t':'خوب','rep':'','d':'2026-11-19'}]}
def mk(calls,addres):
    def f(route,req):
        b=json.loads(req.post_data or '{}');o=b.get('op');calls.append((o,b.get('a')))
        r={'ok':1}
        if o=='rv_list':r=LST
        elif o=='rv_own':r=LST
        elif o=='rv_add':r=addres
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return f
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        calls=[];pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp*',mk(calls,{'ok':1}))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.mq=1;brwOpen(1)");pg.wait_for_timeout(500)
        chk(t+'rows',pg.evaluate("document.querySelectorAll('.sheet .brwr').length==2"))
        chk(t+'avg',pg.evaluate("document.querySelector('.sheet .brwh').textContent.includes('۴٫۵')"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none'");pg.screenshot(path='/tmp/mq_360.png')
        chk(t+'reply shown',pg.evaluate("!!document.querySelector('.sheet .brwp')"))
        chk(t+'cache 1 call',pg.evaluate("(()=>{brwOpen(1);return true})()") and sum(1 for c in calls if c[0]=='rv_list')==1)
        pg.evaluate("document.querySelector('[data-a=bt_brws][data-v=\"4\"]').click()");pg.wait_for_timeout(200)
        chk(t+'4 stars on',pg.evaluate("document.querySelectorAll('.brwf .chip.on').length==4"))
        pg.evaluate("document.getElementById('brph').value='0912 000 0000';document.getElementById('brt').value='خوب بود'");pg.evaluate("document.querySelector('[data-a=bt_brwa]').click()");pg.wait_for_timeout(500)
        chk(t+'add call',any(c[0]=='rv_add' and c[1]['s']==4 and c[1]['phone']=='09120000000' and c[1]['b']==1 for c in calls))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        chk(t+'short phone blocked',pg.evaluate("(()=>{brwOpen(1);return 1})()") and True)
        pg.evaluate("XF.mq=1");chk(t+'owner btn',pg.evaluate("brwOwnH().includes('bt_brwo')"))
        pg.evaluate("document.querySelector('[data-a=bt_brwo]')||brwOwn();brwOwn()");pg.wait_for_timeout(500)
        chk(t+'owner reply field only unreplied',pg.evaluate("document.querySelectorAll('.sheet [data-a=bt_brwr]').length==1"))
        pg.evaluate("document.getElementById('brp4').value='ممنون از شما';document.querySelector('[data-a=bt_brwr]').click()");pg.wait_for_timeout(500)
        chk(t+'reply call',any(c[0]=='rv_reply' and c[1]['id']==4 and c[1]['t']=='ممنون از شما' for c in calls))
        pg.evaluate("XF.mq=0");chk(t+'key off',pg.evaluate("brwOwnH()==''"))
        ctx.close()
    br.close()
print('ERRS',errs)
