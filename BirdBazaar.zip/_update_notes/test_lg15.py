# تست 1.9.295: LG15 حرکت آیفونی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for m in ('i','ice','m'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',has_touch=True);pg=ctx.new_page()
            pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+m+' '
            pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=0;S.v=null;render()"%m);pg.wait_for_timeout(400)
            lg=pg.evaluate("!!document.getElementById('app').dataset.lg")
            chk(t+'lg attr',lg==(m!='m'))
            # push forward/back
            pg.evaluate("window.__x=[];go({v:'guides'})")
            f=pg.evaluate("document.getElementById('scr').classList.contains('lgpf')")
            chk(t+'push fwd',f==(m!='m'))
            pg.wait_for_timeout(550)
            chk(t+'push cleared',not pg.evaluate("/lgp[fb]/.test(document.getElementById('scr').className)"))
            pg.evaluate("go({v:null})")
            b=pg.evaluate("document.getElementById('scr').classList.contains('lgpb')")
            chk(t+'push back',b==(m!='m'))
            pg.wait_for_timeout(550)
            # press scale
            pc=pg.evaluate("(()=>{const c=document.querySelector('#scr .pc:not(.sk)');return c?1:0})()")
            if m!='m' and pc:
                pg.evaluate("document.querySelector('#scr .pc:not(.sk)').scrollIntoView({block:'center'})");pg.wait_for_timeout(300)
                bx=pg.evaluate("(()=>{const r=document.querySelector('#scr .pc:not(.sk) .pb').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()")
                pg.mouse.move(bx[0],bx[1]);pg.mouse.down();pg.wait_for_timeout(250)
                tf=pg.evaluate("getComputedStyle(document.querySelector('#scr .pc:not(.sk)')).scale")
                chk(t+'press scale .96',tf=='0.96')
                pg.mouse.up();pg.wait_for_timeout(100)
            # long-press menu
            if m!='m' and pc:
                pg.evaluate("document.querySelector('#scr .pc:not(.sk) [data-a=prod]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,clientX:100,clientY:300,pointerType:'touch'}))")
                pg.wait_for_timeout(700)
                chk(t+'menu open',pg.evaluate("!!document.querySelector('#ovc .lgm')"))
                n=pg.evaluate("document.querySelectorAll('#ovc .lgm button').length")
                chk(t+'menu 2-3 buttons',n in (2,3))
                ov=pg.evaluate("document.documentElement.scrollWidth<=innerWidth")
                chk(t+'no overflow',ov)
                if w==360 and m=='i': pg.screenshot(path='/tmp/lg15_menu.png')
                before=pg.evaluate("D.cart.length+':'+(D.cart[0]?D.cart[0].q:0)")
                if n==3:
                    pg.wait_for_timeout(450);pg.evaluate("document.querySelector('#ovc .lgm [data-v^=\"c:\"]').click()");pg.wait_for_timeout(300)
                    after=pg.evaluate("D.cart.length+':'+(D.cart[0]?D.cart[0].q:0)")
                    chk(t+'menu add cart',before!=after)
                    chk(t+'menu closed',not pg.evaluate("document.getElementById('ov').classList.contains('on')"))
            # menu must not appear on minimal
            if m=='m':
                pg.evaluate("document.querySelector('#scr .pc:not(.sk) [data-a=prod]') && document.querySelector('#scr .pc:not(.sk) [data-a=prod]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,clientX:100,clientY:300,pointerType:'touch'}))")
                pg.wait_for_timeout(700)
                chk(t+'no menu in minimal',not pg.evaluate("!!document.querySelector('#ovc .lgm')"))
            # edge swipe back
            if m!='m':
                pg.evaluate("go({v:'guides'})");pg.wait_for_timeout(500)
                pg.evaluate("""(()=>{const mk=(ty,x)=>{const t=new Touch({identifier:1,target:document.body,clientX:x,clientY:300});document.dispatchEvent(new TouchEvent(ty,{bubbles:true,touches:ty=='touchend'?[]:[t],changedTouches:[t]}))};mk('touchstart',innerWidth-8);mk('touchend',innerWidth-120)})()""")
                pg.wait_for_timeout(300)
                chk(t+'edge swipe back',pg.evaluate("!S.v"))
            ctx.close()
    br.close()
print('ERRORS',errs)
