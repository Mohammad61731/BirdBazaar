# تست 1.9.368 C1: نقشه‌ی سبک غرفه (کلید cg)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
G=[{'id':1,'lvl':1,'rm':0,'acc':'x','la':25.3,'ln':61.6,'hrs':{'o':'00:00','c':'23:59'},'ad':'خیابان اصلی'}]
GEO={'lat':25.3,'lng':61.6,'acc':'x','hrs':{'o':'08:00','c':'20:00','off':[5]},'ad':'پشت مسجد','rm':0}
def h2(route,req):
    b=json.loads(req.post_data or '{}');o=b.get('op','')
    if o in('cg_pub','cg_set','cg_get'):
        CALLS.append((o,b.get('a')))
        r={'ok':1,'g':G} if o=='cg_pub' else ({'ok':1,'geo':(b.get('a') or GEO) if o=='cg_set' else GEO,'lvl':0})
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    route.fallback()
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',geolocation={'latitude':25.31,'longitude':61.61},permissions=['geolocation'])
        pg=ctx.new_page();CALLS.clear()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',h2)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        # کلید خاموش
        pg.evaluate("S.tab=1;S.v=null;render();btNav({v:'bts',id:1})");pg.wait_for_timeout(600)
        chk(t+'off: no cg box',pg.evaluate("document.querySelectorAll('.cgbx').length")==0 and not any(c[0]=='cg_pub' for c in CALLS))
        # روشن
        pg.evaluate("XF.cg=1;btRe()");pg.wait_for_timeout(700)
        chk(t+'cg_pub once',sum(1 for c in CALLS if c[0]=='cg_pub')==1)
        chk(t+'box + map',pg.evaluate("!!document.querySelector('.cgbx svg.cgmap')"))
        chk(t+'open status',pg.evaluate("document.querySelector('.cgbx').innerText.includes('الان باز است')"))
        chk(t+'address',pg.evaluate("document.querySelector('.cgbx').innerText.includes('خیابان اصلی')"))
        pg.evaluate("btRe()");pg.wait_for_timeout(200)
        chk(t+'no 2nd cg_pub',sum(1 for c in CALLS if c[0]=='cg_pub')==1)
        pg.locator('[data-cg=me]').dispatch_event('click');pg.wait_for_timeout(600)
        txt=pg.evaluate("document.querySelector('.cgbx').innerText")
        chk(t+'distance shown',('کیلومتر' in txt) and ('🚶' in txt) and ('شمال' in txt or 'جنوب' in txt or 'شرق' in txt or 'غرب' in txt))
        chk(t+'dot on map after me',pg.evaluate("document.querySelectorAll('.cgmap circle').length")>=2)
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        chk(t+'box inside screen',pg.evaluate("(()=>{const r=document.querySelector('.cgbx').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1})()"))
        # مسیریابی + برنامه
        pg.evaluate("window.__nav=[];const oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){window.__nav.push(this.href)}")
        pg.locator('[data-cg=nav]').dispatch_event('click');pg.wait_for_timeout(150)
        chk(t+'nav geo link',pg.evaluate("window.__nav.filter(x=>x).length==1&&window.__nav.filter(x=>x)[0].startsWith('geo:25.3,61.6')"))
        pg.locator('[data-cg=app]').dispatch_event('click');pg.wait_for_timeout(250)
        pg.locator('[data-cg=appset][data-v=gm]').dispatch_event('click');pg.wait_for_timeout(200)
        pg.locator('[data-cg=nav]').dispatch_event('click');pg.wait_for_timeout(150)
        chk(t+'nav google after choice',pg.evaluate("window.__nav.filter(x=>x)[1].includes('google.com/maps/dir')&&localStorage.getItem('bp_cgm')=='gm'"))
        # کارت: نقطه
        chk(t+'cgDot open',pg.evaluate("cgDot(1).includes('cgd')&&!cgDot(1).includes('off')")and pg.evaluate("cgDot(9)")=='')
        # فرم غرفه‌دار
        pg.evaluate("BT.u='ali';BT.p='1234';CGM.ld=0;CGM.r=null")
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tw\">'+cgOwnH()+'</div>')");pg.wait_for_timeout(500)
        pg.evaluate("document.getElementById('tw').innerHTML=cgOwnH()");pg.wait_for_timeout(100)
        chk(t+'owner form filled',pg.evaluate("document.getElementById('cgla').value=='25.3'&&document.getElementById('cgho').value=='08:00'&&document.querySelectorAll('#cgoff .chip.on').length==1"))
        pg.locator('#cgla').fill('۲۶.۵');pg.locator('#cglo').fill('60.25')
        pg.locator('#cgacc [data-v="n"]').dispatch_event('click')
        pg.locator('#cgoff [data-v="6"]').dispatch_event('click')
        n=len(CALLS)
        pg.locator('#tw [data-cg=save]').dispatch_event('click');pg.wait_for_timeout(500)
        a=next((c[1] for c in reversed(CALLS) if c[0]=='cg_set'),{})
        chk(t+'save payload',a.get('lat')==26.5 and a.get('lng')==60.25 and a.get('acc')=='n' and a['hrs'].get('off')==[5,6] and a['hrs'].get('o')=='08:00')
        # here
        pg.evaluate("document.getElementById('tw').innerHTML=cgOwnH()")
        pg.locator('#tw [data-cg=here]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'here fills gps',pg.evaluate("document.getElementById('cgla').value=='25.31'"))
        ctx.close()
    br.close()
print('ERRORS',errs)
