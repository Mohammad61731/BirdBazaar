# تست 1.9.436 D2-c3c: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.route('**/rpc/bapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=1;localStorage.removeItem('bp_rsv');BT.prods=[{id:1,b:1,d:{name:'الف',type:'plain',price:1000}},{id:2,b:1,d:{name:'ب',type:'plain',price:2000}}];BT.booths=[{id:1,name:'غ',phone:'0912'}];BC=[{p:1,m:'r',q:1},{p:2,m:'r',q:1}];BCF={n:'علی',p:'09121234567',a:'سراوان خیابان'};CPM[1]='g';cgG=id=>({lvl:1,id});cgVer=id=>1;DTSP={};D.cart=[];S.tab=3;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'chips shown',pg.evaluate("dtSplH(1,BC.map(btCLine)).includes('dtsp')"))
        pg.evaluate("XF.dt=0")
        chk(t+'off -> nothing',pg.evaluate("dtSplH(1,BC.map(btCLine))===''&&dtSplN(1,BC.map(btCLine))==0"))
        pg.evaluate("XF.dt=1")
        nb=lambda:len([c for c in calls if '"bord"' in c]);bc=lambda:[c for c in calls if '"bord"' in c]
        def click(a,v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(500)
        click('dtsp','1|1:r')
        chk(t+'toggle -> one pickup',pg.evaluate("dtSplN(1,BC.map(btCLine))==1"))
        click('dtsp','1|2:r')
        click('bt_co','1')
        chk(t+'all pickup -> refused, no call',nb()==0 and pg.evaluate("dtSplN(1,BC.map(btCLine))==0&&BC.length==2"))
        click('dtsp','1|1:r')
        RES[0]='{"err":"off"}'
        click('bt_co','1')
        chk(t+'err -> cart kept',nb()==1 and pg.evaluate("BC.length==2&&cpRsv().length==0"))
        RES[0]='{"ok":1}'
        click('bt_co','1')
        chk(t+'ok -> pickup order sent',nb()==2 and '"pk":1' in bc()[1] and '"total":1000' in bc()[1] and '"addr":"🏪 حضوری"' in bc()[1])
        chk(t+'ok -> reservation + rest stays',pg.evaluate("cpRsv().length==1&&BC.length==1&&BC[0].p==2&&dtSplN(1,BC.map(btCLine))==0"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
