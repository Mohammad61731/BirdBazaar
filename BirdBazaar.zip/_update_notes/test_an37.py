# تست 1.9.252 AN37
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.wait_for_timeout(3000)
        r=await pg.evaluate("""()=>{const f=document.getElementById('fab');const cs=getComputedStyle(f);return [cs.animationName,cs.animationFillMode,document.getElementById('app').dataset.tm]}""")
        print(r)
        chk('fab appear anim',r[0]=='anfb' or r[2]!='m'); chk('fab no forwards fill',r[1]!='forwards' and r[1]!='both')
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
