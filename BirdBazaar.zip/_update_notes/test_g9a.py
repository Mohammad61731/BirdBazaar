# تست 1.9.425 G9-a: پیام‌های آماده در چت (کلید pn)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("localStorage.removeItem('bp_qrm');XF.pn=0;CS.cur={b:1,cu:'x',r:'u'}")
        chk(t+'off -> empty',pg.evaluate("pnQrH()===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'customer chips',pg.evaluate("(()=>{const h=pnQrH();return h.includes('کالا موجود است؟')&&h.includes('ct_qa')&&!h.includes('ct_qd')&&!h.includes('رسید واضح')})()"))
        pg.evaluate("CS.cur.r='b'")
        chk(t+'booth owner chips',pg.evaluate("(()=>{const h=pnQrH();return h.includes('رسید واضح')&&!h.includes('کالا موجود است؟')})()"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div class=cin>'+pnQrH()+'<input id=cmi></div>'")
        pg.evaluate("document.querySelector('[data-a=ct_qr]').click()")
        chk(t+'tap fills input',pg.evaluate("document.getElementById('cmi').value.includes('پرداخت دریافت شد')"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('سلام <b>x'))")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='ct_qa';document.getElementById('scr').appendChild(b);b.click()})()")
        chk(t+'custom saved + sanitized',pg.evaluate("JSON.stringify(pnQrC())==JSON.stringify(['سلام bx'])")and pg.evaluate("pnQrH().includes('ct_qd')"))
        for i in range(6):
            pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('م%d'))"%i)
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='ct_qa';document.getElementById('scr').appendChild(b);b.click()})()")
        chk(t+'max 5',pg.evaluate("pnQrC().length==5&&!pnQrH().includes('ct_qa\"')"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('بله'))")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='ct_qd';document.getElementById('scr').appendChild(b);b.click()})()")
        chk(t+'clear',pg.evaluate("pnQrC().length==0"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div class=cin>'+pnQrH()+'<input id=cmi></div>'")
        chk(t+'chips no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.querySelector('.pnkQr').getBoundingClientRect().right<=innerWidth+1"))
        ctx.close()
    br.close()
print('ERRORS',errs)
