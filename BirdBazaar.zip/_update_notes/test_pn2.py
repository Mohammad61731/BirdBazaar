# تست 1.9.395 G2: تب پنل + ورود/ثبت‌نام ساده (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.pn=0;S.role='';S.lg=0")
        chk(t+'off: label profile',pg.evaluate("pnLbl()")=='پروفایل')
        chk(t+'off: acctNew guest card',pg.evaluate("acctNew().includes('lgf')"))
        pg.evaluate("XF.pn=1")
        chk(t+'on: label panel',pg.evaluate("pnLbl()")=='پنل')
        chk(t+'on: big card two tiles',pg.evaluate("(()=>{const s=acctNew();return (s.match(/pnkT/g)||[]).length==2&&s.includes('data-v=\"l\"')&&s.includes('data-v=\"r\"')})()"))
        clk(pg,'pnrg','l')
        chk(t+'login form',pg.evaluate("(()=>{const s=acctNew();return S.lg==1&&s.includes('id=\"lu\"')&&s.includes('id=\"lp\"')&&s.includes('data-a=\"login\"')&&!s.includes('data-a=\"reg\"')})()"))
        clk(pg,'pnrg','r')
        chk(t+'register form',pg.evaluate("(()=>{const s=acctNew();return S.pnm=='r'&&s.includes('data-a=\"reg\"')&&!s.includes('data-a=\"login\"')})()"))
        chk(t+'admin login hidden',pg.evaluate("!acctNew().includes('id=\"ap2\"')"))
        clk(pg,'pna')
        chk(t+'admin login shown',pg.evaluate("acctNew().includes('id=\"ap2\"')&&acctNew().includes('data-a=\"alog\"')"))
        clk(pg,'pnrg','')
        chk(t+'back to card',pg.evaluate("S.lg==0&&acctNew().includes('pnkT')"))
        pg.evaluate("XF.pn=0");clk(pg,'pnrg','l')
        chk(t+'off: pnrg ignored',pg.evaluate("S.lg==0"))
        pg.evaluate("XF.pn=1;S.role='user'")
        chk(t+'logged in: normal account',pg.evaluate("!acctNew().includes('pnkT')"))
        pg.evaluate("S.role='';S.lg=0;S.tab=4;render()");pg.wait_for_timeout(250)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
