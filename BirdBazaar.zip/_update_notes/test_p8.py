import json,re,sys
from playwright.sync_api import sync_playwright
DB={'booths':[{'id':1,'owner':'ali','pw':'1234','name':'غرفه علی','bio':'ارزن و کتان عمده','logo':'','cover':'','city':'سراوان','phone':'09120000000','status':'active','views':5}],'prods':[],'reqs':[{'id':1,'name':'رضا','phone':'09151112233','city':'زاهدان','shop':'دان رضا','about':'دان','status':'new'}],'nid':1}
def handle(route,req):
    u=req.url
    if u.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op'];a=b.get('a') or {};U=b.get('u');P=b.get('p')
        def bo():
            return next((x for x in DB['booths'] if x['owner']==U and x['pw']==P),None)
        def pub(x):return {k:x[k] for k in ['id','name','bio','logo','cover','city','phone','views']}|{'n':len([q for q in DB['prods'] if q['b']==x['id'] and q['s']=='on'])}
        r={'err':'unknown'}
        if o=='bpublic':r={'ok':1,'booths':[pub(x) for x in DB['booths'] if x['status']=='active'],'prods':[{'id':q['id'],'b':q['b'],'d':q['d'],'t':'x'} for q in reversed(DB['prods']) if q['s']=='on']}
        elif o=='bview':r={'ok':1}
        elif o=='breq':DB['reqs'].append({'id':len(DB['reqs'])+1,'name':a['name'],'phone':a['phone'],'city':a.get('city'),'shop':a.get('shop'),'about':a.get('about'),'status':'new'});r={'ok':1}
        elif o in('blogin','bme'):
            x=bo()
            r={'err':'denied'} if not x else {'ok':1,'booth':{**pub(x),'status':x['status']},'prods':[{'id':q['id'],'d':q['d'],'s':q['s'],'t':'x'} for q in DB['prods'] if q['b']==x['id']],'days':[{'day':'2026-11-13','n':3}]}
        elif o=='bprod_set':
            x=bo()
            if a.get('id'):
                for q in DB['prods']:
                    if q['id']==a['id']:q['d']=a['d'];q['s']=a.get('s','on')
                r={'ok':1,'id':a['id']}
            else:
                DB['nid']+=1;DB['prods'].append({'id':DB['nid'],'b':x['id'],'d':a['d'],'s':a.get('s','on')});r={'ok':1,'id':DB['nid']}
        elif o=='bprod_del':DB['prods']=[q for q in DB['prods'] if q['id']!=a['id']];r={'ok':1}
        elif o=='bset':
            x=bo();x.update({k:a[k] for k in ['name','bio','city','phone','logo','cover'] if k in a});r={'ok':1}
        elif o.startswith('badm_'):
            if b.get('u')!='admin' or b.get('p')!='pw1':r={'err':'denied'}
            elif o=='badm_list':r={'ok':1,'reqs':[x for x in DB['reqs'] if x['status']=='new'],'booths':[{'id':x['id'],'owner':x['owner'],'name':x['name'],'city':x['city'],'phone':x['phone'],'status':x['status'],'views':x['views'],'n':len([q for q in DB['prods'] if q['b']==x['id']])} for x in DB['booths']]}
            elif o=='badm_approve':
                q=next(x for x in DB['reqs'] if x['id']==a['id']);q['status']='ok';DB['booths'].append({'id':len(DB['booths'])+1,'owner':a['owner'],'pw':a['pw'],'name':q['shop'],'bio':'','logo':'','cover':'','city':q['city'],'phone':q['phone'],'status':'active','views':0});r={'ok':1}
            else:r={'ok':1}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    if '/rpc/app' in u:
        route.fulfill(status=200,content_type='application/json',body='{"err":"x"}');return
    route.continue_()

errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
for i,nm in ((2,'دان فنچ'),(3,'ارزن قرمز'),(4,'کتان'),(5,'ماش'),(6,'سیاه‌دانه')):
    DB['prods'].append({'id':i,'b':1,'d':{'name':nm,'type':'plain','price':50000,'emoji':'🌰','imgs':[]},'s':'on'})
DB['nid']=6
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w'
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',handle);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(1000)
    pg.evaluate("S.role=null;go({tab:1,v:null})");pg.wait_for_timeout(300)
    pg.evaluate("btNav({v:'btm'})") if False else None
    pg.click('[data-a=bt_pan]') if pg.locator('[data-a=bt_pan]').count() else pg.evaluate("btNav({v:'btm'})")
    pg.wait_for_timeout(300);pg.fill('#bu','ali');pg.fill('#bpw','1234');pg.click('[data-a=bt_li]');pg.wait_for_timeout(600)
    pg.evaluate("S.btt='p';btRe()");pg.wait_for_timeout(300)
    chk('دکمه‌ی سنجاق برای هر محصول',pg.locator('[data-a=bt_pn]').count()==5)
    pg.locator('[data-a=bt_pn][data-v="4"]').click();pg.wait_for_timeout(500)
    chk('d.pin روی سرور ذخیره شد',DB['prods'][2]['d'].get('pin')==1 and DB['prods'][2]['d']['name']=='کتان')
    chk('سنجاق‌شده اول لیست مالک',pg.locator('.card.row b').first.inner_text()=='کتان')
    chk('نشان 📌 دیده می‌شود','📌 سنجاق' in pg.inner_text('body'))
    for i in (2,3,5):
        pg.locator('[data-a=bt_pn][data-v="%d"]'%i).click();pg.wait_for_timeout(400)
    pins=[q['id'] for q in DB['prods'] if q['d'].get('pin')]
    chk('حداکثر ۳ سنجاق',len(pins)==3 and 5 not in pins)
    pg.locator('[data-a=bt_pn][data-v="4"]').click();pg.wait_for_timeout(400)
    chk('برداشتن سنجاق',not DB['prods'][2]['d'].get('pin'))
    # صفحه‌ی عمومی غرفه
    pg.evaluate("BT.prods=[];bpull().then(()=>{S.bq='';S.bc='';btNav({v:'bts',id:1})})");pg.wait_for_timeout(900)
    names=pg.evaluate("[...document.querySelectorAll('.bll .bli b, .bll b, .bxg1 b')].map(x=>x.textContent)")
    pn=[q['d']['name'] for q in DB['prods'] if q['d'].get('pin')]
    print('names',names[:5],'pinned',pn)
    chk('سنجاق‌شده‌ها بالای صفحه‌ی غرفه',len(pn)==2 and set(names[:2])==set(pn))
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
