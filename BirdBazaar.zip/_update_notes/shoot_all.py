from playwright.sync_api import sync_playwright
import json
OUT='shots/g/'
jobs=[ # name, role, js, extra wait, scheme
('home','g',"go({tab:0,v:null})",'light'),
('home_dark','g',"go({tab:0,v:null})",'dark'),
('store','g',"go({tab:1,v:null,sub:0})",'light'),
('ads','g',"go({tab:2,sub:0,v:null})",'light'),
('ad_detail','u',"go({tab:2,sub:0,v:null})|click:#scr .ad",'light'),
('forum','u',"go({tab:5,v:null})",'light'),
('forum_room','u',"fOpen(0)",'light'),
('profile','g',"go({tab:4,v:null})",'light'),
('drawer','u',"go({tab:0,v:null});drawer()",'light'),
('guides','g',"go({v:'guides'})",'light'),
('admin_home','a',"go({tab:0,v:null})",'light'),
('admin_edit','a',"go({tab:0,v:null,ed:1})",'light'),
('theme_sheet','a',"go({tab:0,v:null});thSheet()",'light'),
('glass_home','a',"thSet('home',{m:'g',c:'p',b:1});go({tab:0,v:null})",'dark'),
('photo_bg','a',"thSet('home',{m:'p',c:'b',b:2});go({tab:0,v:null})",'light'),
('fonts','u',"go({tab:0,v:null});ffSheet()",'light'),
('booth','u',"btNav({v:'bts',id:7})",'light'),
('booth_prod','u',"btNav({v:'btp',id:11})",'light'),
('inbox','u',"msOpen()",'light'),
('chats','u',"cListOpen()",'light'),
('chat','u',"cOpen(7,'ali','u')",'light'),
('chat_pick','u',"cOpen(7,'ali','u')|click:button[data-a=ct_pp]",'light'),
('owner_list','o',"cListOpen()",'light'),
]
with sync_playwright() as p:
    br=p.chromium.launch()
    for name,role,js,scheme in jobs:
        ctx=br.new_context(viewport={'width':360,'height':740},locale='fa-IR',color_scheme=scheme);pg=ctx.new_page();errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('file:///tmp/bb/_update_notes/demo_app.html');pg.wait_for_timeout(900)
        pre="BT.ok=1;BT.t=Date.now()+1e9;"
        if role=='a':pre+="S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"
        elif role=='u':pre+="S.role='user';S.me='ali';S.pw='1';"
        elif role=='o':pre+="S.role='user';S.me='bob';S.pw='1';"
        try:
            pg.evaluate("bpull()");pg.wait_for_timeout(300)
            pg.evaluate(pre)
            parts=js.split('|click:')
            pg.evaluate(parts[0]);pg.wait_for_timeout(700)
            if len(parts)>1:
                pg.click(parts[1]);pg.wait_for_timeout(600)
            pg.screenshot(path=OUT+name+'.png')
            print(name,pg.evaluate("S.v"),errs[:1])
        except Exception as e:print(name,'FAIL',str(e)[:120])
        ctx.close()
    br.close()
