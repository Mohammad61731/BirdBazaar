#!/bin/sh
# اجرای تست‌های ضروری. استفاده: cd _update_notes && sh run_core.sh /home/claude/bb
P=${1:-/home/claude/bb}
ls test_*.py | sed 's/\.py$//' | grep -v -e '^test_h$' -e '^test_r1$' | xargs -P3 -I{} sh -c "timeout 150 python3 {}.py $P . > /tmp/{}.out 2>&1; echo {} rc=\$? FAIL=\$(grep -c '^FAIL' /tmp/{}.out)"
timeout 150 python3 test_h.py $P . > /tmp/test_h.out 2>&1; echo test_h rc=$? FAIL=$(grep -c '^FAIL' /tmp/test_h.out)
timeout 150 python3 test_r1.py $P . > /tmp/test_r1.out 2>&1; echo test_r1 rc=$? FAIL=$(grep -c '^FAIL' /tmp/test_r1.out)
