# تست 1.9.84: قفل نسخه (MV) واقعاً صفحه‌ی بروزرسانی را نشان می‌دهد/برمی‌دارد
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
          for dark in (0,1):
            if len(sys.argv)>2 and sys.argv[2]=='q' and (w,dark)!=(320,0): continue
            ctx=await b.new_context(viewport={'width':w,'height':700},color_scheme='dark' if dark else 'light'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)+' @'+str(getattr(e,'stack',''))[:300]))
            tp=await ctx.new_page(); await tp.route('http*://**',lambda r:r.abort()); await tp.goto('file://%s/www/index.html'%ROOT); await tp.wait_for_timeout(500); base=await tp.evaluate('cmsDef()'); await tp.close()
            st={'mv':{'min':'9.9.9','url':'https://example.com/a.apk','msg':'نسخه جدید آماده است','f':0},'off':False,'n':0}
            async def h(route):
                u=route.request.url
                if u.startswith('http'):
                    if st['off']: return await route.abort()
                    st['n']+=1
                    body={'ok':1,'products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':dict(base,**({'MV':st['mv']} if st['mv'] else {})),'guides':[]}
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1800)
            # ۱) آیا MV از سرور به D.cms رسید و صفحه آمد؟
            r=await pg.evaluate("({mv:!!(D.cms&&D.cms.MV),o:!!document.getElementById('mvo'),ov:document.documentElement.scrollWidth>innerWidth,later:!!document.getElementById('mvx'),dl:!!document.getElementById('mvu')})")
            print(w,dark,'locked',r,'errs so far',len(errs)); ok&=r['mv'] and r['o'] and not r['ov'] and r['later'] and r['dl']
            # ۲) «بعداً» برمی‌دارد؛ بعد از ۲۰ث دوباره نیاید (همان نشست)
            await pg.evaluate("document.getElementById('mvx').click()"); await pg.evaluate("mvCheck()")
            r2=await pg.evaluate("!!document.getElementById('mvo')"); print(w,dark,'after later',r2); ok&=not r2
            # ۳) اجباری: دکمه‌ی بعداً نیست
            st['mv']['f']=1; await pg.evaluate("D.cms.MV.f=1;sessionStorage.clear();mvCheck()")
            r3=await pg.evaluate("({o:!!document.getElementById('mvo'),later:!!document.getElementById('mvx')})"); print(w,dark,'forced',r3); ok&=r3['o'] and not r3['later']
            # ۴) آفلاین + بارگذاری دوباره: از کش هم قفل بماند
            st['off']=True; await ctx.set_offline(True); await pg.reload(); await pg.wait_for_timeout(1800)
            r4=await pg.evaluate("!!document.getElementById('mvo')"); print(w,dark,'offline reload',r4); ok&=r4
            # ۵) مدیر اصلی قفل نمی‌شود
            await pg.evaluate("S.role='admin';S.pm=['all'];mvCheck()")
            r5=await pg.evaluate("!!document.getElementById('mvo')"); print(w,dark,'admin exempt',r5); ok&=not r5
            await pg.evaluate("S.role='';S.pm=[];mvCheck()")
            # ۶) برداشتن قفل از سرور: MV=null ← صفحه برداشته شود
            await pg.evaluate("D.cms.MV=null;mvCheck()")
            r6=await pg.evaluate("!!document.getElementById('mvo')"); print(w,dark,'unlock',r6); ok&=not r6
            # ۷) حداقل نسخه‌ی کمتر/مساوی نسخه‌ی فعلی
            r7=await pg.evaluate("[vCmp(APPV,'1.9.84'),vCmp(APPV,'1.10'),vCmp('1.9.100','1.9.84'),vCmp('2','1.9.84.1')]"); print('vCmp',r7); ok&=r7==[0,-1,1,1]
            print(w,dark,'errs',errs); ok&=not errs
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
