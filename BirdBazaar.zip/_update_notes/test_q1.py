import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("""localStorage.removeItem('bp_fw');localStorage.removeItem('bp_fn');S.role='user';S.me='ali';S.pm=[];
D.ads=[{id:11,title:'جفت مرغ عشق',sp:'x',price:900000,desc:'x',imgs:[],st:'ok',own:'sara'},{id:12,title:'قفس',sp:'x',price:300000,desc:'x',imgs:[],st:'ok',own:'sara'}];
D.products.forEach(p=>{p.k='n';p.disc=0;p.out=false;p.price=100000});D.products[0].out=true;
S.fav=['a11','a12','p'+D.products[0].id,'p'+D.products[1].id];fwWatch()""")
    chk('1 اولین اجرا فقط عکس می‌گیرد (بدون اعلان)',pg.evaluate("fwGet('bp_fn',[]).length==0&&Object.keys(fwGet('bp_fw',{})).length==4")and pg.locator('#bpn').count()==0)
    pg.evaluate("D.ads[0].price=800000;fwWatch()");pg.wait_for_timeout(200)
    chk('2 کاهش قیمت آگهی: اعلان',pg.locator('#bpn').count()==1 and 'قیمت کم شد' in pg.inner_text('#bpn'))
    chk('3 رویداد ذخیره شد',pg.evaluate("fwGet('bp_fn',[]).length==1&&fwGet('bp_fn',[])[0].t=='drop'"))
    pg.evaluate("fwWatch()");chk('4 بدون تغییر: رویداد تکراری نه',pg.evaluate("fwGet('bp_fn',[]).length==1"))
    pg.evaluate("D.ads[1].price=400000;fwWatch()");chk('5 افزایش قیمت: رویداد نه',pg.evaluate("fwGet('bp_fn',[]).length==1"))
    pg.evaluate("D.products[0].out=false;fwWatch()");pg.wait_for_timeout(200)
    chk('6 موجود شدن محصول',pg.evaluate("fwGet('bp_fn',[])[0].t=='back'")and 'موجود شد' in pg.inner_text('#bpn'))
    pg.evaluate("D.products[1].price=70000;fwWatch()");chk('7 کاهش قیمت محصول',pg.evaluate("fwGet('bp_fn',[])[0].t=='drop'&&fwGet('bp_fn',[])[0].isP"))
    pg.evaluate("go({v:'favs'})");pg.wait_for_timeout(250)
    chk('8 جعبه‌ی تغییرات در نشان‌شده‌ها',pg.locator('.box .upr[data-a=fwo]').count()==3)
    pg.screenshot(path=P+'/shots/q1.png')
    pg.click('.box .upr[data-a=fwo] >> nth=2');pg.wait_for_timeout(300)
    chk('9 لمس = باز شدن آگهی',pg.evaluate("S.v=='ad'&&S.id==11"))
    pg.evaluate("S.fav=['a12'];go({v:'favs'})");pg.wait_for_timeout(200)
    chk('10 غیر علاقه‌مندی‌ها در فهرست نیست',pg.locator('.box .upr[data-a=fwo]').count()==0)
    pg.evaluate("S.me='';S.fav=['a11'];localStorage.removeItem('bp_fw');fwWatch()");chk('11 مهمان: بدون اجرا',pg.evaluate("localStorage.getItem('bp_fw')===null"))
    pg.evaluate("S.me='ali';S.fav=['a11'];D.ads[0].price=500000;fwWatch();D.ads[0].price=300000;fwFloat({k:'a11',nm:'x',t:'drop'})");pg.wait_for_timeout(100)
    for th in('light','dark'):
        for w in(320,360,412):
            pg.evaluate("document.documentElement.setAttribute('data-theme','%s');fwFloat({k:'a11',nm:'جفت مرغ عشق خیلی خوش‌رنگ و سالم',t:'drop'})"%th);pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth||(()=>{const r=document.getElementById('bpn').getBoundingClientRect();return r.left<0||r.right>innerWidth+1})()"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
