# تست 1.9.387 D1/146+135+133: cb cq cu
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_cuq');XF.cb=0;XF.cq=0;XF.cu=0;D.cart=[{id:(D.products[0]||{id:1}).id,q:2}]")
        chk(t+'cq off: normal buttons',' cqb' not in pg.evaluate("cartV0()"))
        pg.evaluate("XF.cq=1");chk(t+'cq on: big buttons',' cqb' in pg.evaluate("cartV0()"))
        pg.evaluate("window.prompt=()=>'7'");pg.evaluate("cqAsk('0:1')");chk(t+'cq custom qty',pg.evaluate("D.cart[0].q")==7)
        pg.evaluate("window.prompt=()=>'abc'");pg.evaluate("cqAsk('0:1')");chk(t+'cq bad input ignored',pg.evaluate("D.cart[0].q")==7)
        pg.evaluate("window.__cqLP=Date.now()");clk(pg,'cq','0:1');chk(t+'cq click after longpress ignored',pg.evaluate("D.cart[0].q")==7)
        pg.evaluate("window.__cqLP=0");clk(pg,'cq','0:1');chk(t+'cq normal click works',pg.evaluate("D.cart[0].q")>7)
        pg.evaluate("D.cart=[];XF.cb=0;localStorage.removeItem('bp_ro')")
        chk(t+'cb off: nothing',pg.evaluate("cbBox()")=='')
        pg.evaluate("XF.cb=1;const pid=D.products[0].id;localStorage.setItem(RO_K,JSON.stringify([{id:5,dt:'x',tt:1,u:S.me||'',it:[{id:pid,q:3,w:0,v:0}]}]))")
        chk(t+'cb on: box in empty cart','cbl' in pg.evaluate("cartV0()"))
        clk(pg,'cbl','0');chk(t+'cb adds to cart',pg.evaluate("D.cart.length")==1 and pg.evaluate("D.cart[0].q")==3)
        pg.evaluate("XF.cu=0;S.id=D.products[0].id;S.v='prod';S.qp=0;cuRec(S.id,4)")
        chk(t+'cu off: no record',pg.evaluate("Object.keys(cuGet()).length")==0)
        pg.evaluate("XF.cu=1;cuRec(D.products[0].id,4);S.qp=0;buyBox(getP(D.products[0].id))")
        chk(t+'cu on: prefill',pg.evaluate("S.qt")==4)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
