# تست 1.9.458 S5: خانه ← ادامه‌ی دیدن + شخصی‌سازی خانه + بالای خلوت‌تر
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}');localStorage.removeItem('bp_hh');localStorage.removeItem('bp_rv');localStorage.removeItem('bp_rs')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("S.tab=0;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'no resume when nothing viewed',pg.evaluate("document.querySelectorAll('#scr .hrm').length==0"))
        chk(t+'personalize button',pg.evaluate("document.querySelectorAll('#scr .hhb').length==1"))
        chk(t+'cats chips shown (no recent searches)',pg.evaluate("document.querySelectorAll('#scr .hsr ~ .chips .chip').length<=4"))
        pg.evaluate("D.products=D.products&&D.products.length?D.products:[{id:77,name:'دانه تست',price:1000,up:1000,un:'kg',disc:0}];localStorage.setItem('bp_rv',JSON.stringify(['p'+D.products[0].id]));render()");pg.wait_for_timeout(300)
        chk(t+'resume card',pg.evaluate("document.querySelectorAll('#scr .hrm').length==1&&document.querySelector('#scr .hrm').dataset.a=='prod'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("go&&0;document.querySelector('.hhb').click()");pg.wait_for_timeout(300)
        chk(t+'sheet opens',pg.evaluate("document.querySelectorAll('.hhr').length>=10"))
        pg.evaluate("document.querySelector('.hhr[data-v=rm]').click()");pg.wait_for_timeout(300)
        chk(t+'resume hidden after toggle',pg.evaluate("document.querySelectorAll('#scr .hrm').length==0&&JSON.parse(localStorage.bp_hh).includes('rm')"))
        pg.evaluate("document.querySelector('[data-a=hhr]').click()");pg.wait_for_timeout(300)
        chk(t+'reset restores',pg.evaluate("document.querySelectorAll('#scr .hrm').length==1&&!localStorage.bp_hh"))
        chk(t+'sheet no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:
            pg.screenshot(path='/tmp/s5_sheet.png')
            pg.evaluate("document.querySelector('[data-a=clo2]').click()");pg.wait_for_timeout(300)
            pg.evaluate("document.querySelector('#scr .hrm').scrollIntoView({block:'center'})");pg.wait_for_timeout(300);pg.screenshot(path='/tmp/s5_rm.png')
        ctx.close()
print('ERRORS',errs)
