# تست 1.9.431 G13-a: امنیت قرار حضوری ، کارت هدیه ، ساعت‌های شلوغ (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',permissions=['geolocation'],geolocation={'latitude':35.7,'longitude':51.4})
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("localStorage.clear();XF.pn=0;BOR=null")
        chk(t+'off -> nothing',pg.evaluate("pnSafeH()===''&&pnBusy()===''&&pnDlTxt('g')===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'safe card has 2 buttons',pg.evaluate("(pnSafeH().match(/pnsf/g)||[]).length==2"))
        chk(t+'texts',pg.evaluate("pnSafeT('s',{latitude:35.7,longitude:51.4}).includes('🆘')&&pnSafeT('g',{latitude:35.7,longitude:51.4}).includes('maps.google.com/?q=35.70000,51.40000')&&pnSafeT('g',null).includes('موقعیت در دسترس نبود')"))
        pg.evaluate("window._c=null;Object.defineProperty(navigator,'share',{value:undefined,configurable:true});navigator.clipboard.writeText=x=>{window._c=x;return Promise.resolve()}")
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(600)
        click('pnsf','s')
        chk(t+'SOS copies with location',pg.evaluate("!!window._c&&window._c.includes('maps.google.com')&&window._c.includes('🆘')"))
        pg.evaluate("window._c=null");click('pnsf','zzz')
        chk(t+'bad kind ignored',pg.evaluate("window._c===null"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('تولدت مبارک <b>'))");click('pngf')
        chk(t+'gift saved + sanitized + in text',pg.evaluate("pnDl().g=='تولدت مبارک b'&&pnDlTxt('g').includes('🎁')&&pnDlH(1).includes('pngf')"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb(''))");click('pngf')
        chk(t+'gift cleared',pg.evaluate("!pnDl().g"))
        pg.evaluate("BOR=[]")
        chk(t+'busy needs 5+ orders',pg.evaluate("pnBusy()===''"))
        pg.evaluate("(()=>{const d=new Date();d.setHours(18,10,0,0);const a=[];for(let i=0;i<4;i++)a.push({id:i,s:'new',t:d.getTime(),total:1});d.setHours(19,5,0,0);a.push({id:9,s:'done',t:d.getTime(),total:1});d.setHours(3,0,0,0);a.push({id:10,s:'cancel',t:d.getTime(),total:1});BOR=a})()")
        chk(t+'busy = 18-20 with 5 orders',pg.evaluate("(()=>{const h=pnBusy();return h.includes('۱۸ تا ۲۰')&&h.includes('۵ سفارش')})()"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div class=wrap>'+pnSafeH()+pnBusy()+pnDlH(1)+'</div>'")
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
