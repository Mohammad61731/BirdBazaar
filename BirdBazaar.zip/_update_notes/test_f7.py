import json
from playwright.sync_api import sync_playwright
errs=[]
MS=[{'id':i,'u':'reza' if i%2 else 'sara','k':'text','b':'پیام شماره %d با کمی متن بیشتر'%i,'md':None,'rt':None,'pin':False,'t':'2026-11-13T08:%02d:00Z'%(i%60),'r':{}} for i in range(1,41)]
MS2=[{'id':100,'u':'reza','k':'text','b':'اتاق دوم','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:00:00Z','r':{}}]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);o=b['op'];a=b['a'];r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':False,'perm':{'txt':True,'img':False,'vid':False,'fil':False,'muted':False,'blocked':False},'avatar':''}
        if o=='fpull':
            src=MS if a.get('room')==7 else MS2
            rows=[m for m in src if m['id']>a.get('after',0)]
            rows=rows[-a.get('n',30):] if not a.get('before') else [m for m in rows if m['id']<a['before']][-a.get('n',30):]
            r={'ok':1,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜'},{'id':8,'name':'دوم','emoji':'🐦'}],'msgs':rows,'av':{},'pins':[],'reqn':0}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(1500)
    print('1) first visit: no badge:',pg.locator('.fub').count()==0)
    MS2.append({'id':101,'u':'sara','k':'text','b':'جدید','md':None,'rt':None,'pin':False,'t':'2026-11-13T09:00:00Z','r':{}});MS2.append({'id':102,'u':'ali','k':'text','b':'خودم','md':None,'rt':None,'pin':False,'t':'2026-11-13T09:01:00Z','r':{}})
    pg.evaluate("fUnread()");pg.wait_for_timeout(1200)
    print('2) unread badge on room 2 =1 (own msg ignored):',pg.locator('.fub').count()==1,pg.locator('.fub').inner_text() if pg.locator('.fub').count() else '')
    pg.screenshot(path='../shots/f7_list.png')
    pg.click('[data-a=froom][data-v="8"]');pg.wait_for_timeout(900);pg.evaluate("ab()");pg.wait_for_timeout(400)
    pg.evaluate("fUnread()");pg.wait_for_timeout(1200);print('3) after reading, badge gone:',pg.locator('.fub').count()==0)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    print('4) at bottom: down btn hidden:',not pg.locator('#fdn').is_visible())
    pg.evaluate("$('#scr').scrollTop=0");pg.wait_for_timeout(300)
    print('   scrolled up: btn visible:',pg.locator('#fdn').is_visible())
    MS.append({'id':41,'u':'sara','k':'text','b':'پیام تازه','md':None,'rt':None,'pin':False,'t':'2026-11-13T09:30:00Z','r':{}});pg.evaluate("fPoll()");pg.wait_for_timeout(700)
    print('5) new msg counter on btn:',pg.locator('#fdn b').inner_text() if pg.locator('#fdn b').count() else None,'| view not yanked:',pg.evaluate("$('#scr').scrollTop<50"))
    pg.screenshot(path='../shots/f7_down.png')
    pg.click('#fdn');pg.wait_for_timeout(1200)
    print('6) click -> bottom:',pg.evaluate("$('#scr').scrollHeight-$('#scr').scrollTop-$('#scr').clientHeight<10"),'| btn hidden:',not pg.locator('#fdn').is_visible())
    pg.evaluate("thm()");pg.wait_for_timeout(300);pg.evaluate("document.documentElement.setAttribute('data-theme','dark')")
    pg.evaluate("fOpen(7)");pg.wait_for_timeout(700);pg.screenshot(path='../shots/f7_dark.png')
    MS.append({'id':42,'u':'ali','k':'text','b':'پیام من','md':None,'rt':None,'pin':False,'t':'2026-11-13T09:31:00Z','r':{}});pg.evaluate("fPoll(1)");pg.wait_for_timeout(600)
    print('7) dark own bubble bg:',pg.evaluate("getComputedStyle(document.querySelector('.fmr.out .fmb')).backgroundColor"))
    pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("ab();");pg.wait_for_timeout(300);pg.evaluate("fOpen(7)");pg.wait_for_timeout(500);pg.evaluate("$('#scr').scrollTop=0");pg.wait_for_timeout(250)
        print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'btn inside screen:',pg.evaluate("(()=>{const r=document.getElementById('fdn').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth})()"))
    print('ERRORS',errs);br.close()
