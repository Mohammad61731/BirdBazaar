# تست 1.9.432 F-a: خبرم‌کن‌های من در پروفایل (xp)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
calls=[]
def tapi(route):
    calls.append(json.loads(route.request.post_data or '{}').get('op'));route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' ';calls.clear()
        pg.evaluate("localStorage.removeItem('bp_wn')")
        chk(t+'none -> no card',pg.evaluate("pxWn()===''"))
        pg.evaluate("localStorage.setItem('bp_wn','[3,5,7]')")
        chk(t+'card with count',pg.evaluate("pxWn().includes('۳ کالا')&&pxWn().includes('pnwx')&&pxBody().includes('pnwx')"))
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(250)
        pg.evaluate("XF.xp=0");click('pnwx')
        chk(t+'xp off -> ignored',pg.evaluate("wnGet().length==3"))
        pg.evaluate("XF.xp=1;void(window.bzAsk=(m,d,cb)=>cb('نه'))");click('pnwx')
        chk(t+'wrong confirm keeps',pg.evaluate("wnGet().length==3"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('بله'))");click('pnwx')
        chk(t+'confirm clears',pg.evaluate("wnGet().length==0&&pxWn()===''"))
        pg.evaluate("localStorage.setItem('bp_wn','{bad')")
        chk(t+'broken storage safe',pg.evaluate("pxWn()===''"))
        pg.evaluate("localStorage.setItem('bp_wn','[1,2]');document.getElementById('scr').innerHTML='<div class=wrap>'+pxWn()+'</div>'")
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
