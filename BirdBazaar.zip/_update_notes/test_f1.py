import json
from playwright.sync_api import sync_playwright
errs=[];calls=[]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);calls.append((b['op'],b['u']))
        r={'err':'x'}
        if b['op']=='fwho':r={'ok':1,'me':b['u'],'role':'admin','main':True,'perm':{'txt':True,'img':True,'vid':True,'fil':True,'muted':False,'blocked':False},'avatar':''}
        if b['op']=='fpull':r={'ok':1,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜'}],'msgs':[],'av':{'ali':'data:x'},'pins':[],'reqn':2}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780}).new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    print('SB3:',pg.evaluate("SB3.endsWith('/rpc/fapp')"),'| SB untouched:',pg.evaluate("SB.endsWith('/rpc/app')"))
    print('fwho ->',pg.evaluate("S.me='ali';S.pw='1';fwho().then(()=>[FM.ok,FM.me,FM.main,FM.perm.txt])"))
    print('fpull ->',pg.evaluate("fpull().then(r=>[FM.ok,FM.room,FM.rooms.length,FM.reqn,FM.av.ali])"))
    print('server down ->',pg.evaluate("(window.fetch=()=>Promise.reject(1),fwho().then(()=>FM.ok))"))
    print('calls',calls[:3],'| forum tab still renders:',pg.evaluate("typeof forum==='function'"),'ERRORS',errs);br.close()
