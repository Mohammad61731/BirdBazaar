# تست 1.9.403 H3-b: تایمرهای پس‌زمینه وقتی document.hidden است کار نمی‌کنند
import asyncio
errs=[]
from playwright.async_api import async_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
async def main():
  async with async_playwright() as p:
    br=await p.chromium.launch()
    ctx=await br.new_context(viewport={'width':360,'height':780},locale='fa-IR');pg=await ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith('file:') else r.fulfill(status=200,body='{}',content_type='application/json'))
    await pg.clock.install()
    await pg.goto('file:///home/claude/bb/www/index.html')
    await pg.evaluate("""()=>{window.__c={mv:0,fw:0,ra:0};const a=window.mvCheck,b=window.fwWatch,c=window.reAuth;window.mvCheck=function(){__c.mv++;return a&&a.apply(this,arguments)};window.fwWatch=function(){__c.fw++;return b&&b.apply(this,arguments)};window.reAuth=function(){__c.ra++;return c&&c.apply(this,arguments)};Object.defineProperty(document,'hidden',{get:()=>!!window.__hid,configurable:true})}""")
    await pg.evaluate("window.__hid=true")
    await pg.clock.run_for(65000)
    h=await pg.evaluate("window.__c")
    chk('hidden: no mvCheck/fwWatch/reAuth ticks',h['mv']==0 and h['fw']==0 and h['ra']==0)
    await pg.evaluate("window.__hid=false")
    await pg.clock.run_for(65000)
    v=await pg.evaluate("window.__c")
    chk('visible: mvCheck ticks',v['mv']>=2)
    chk('visible: fwWatch ticks',v['fw']>=2)
    chk('visible: reAuth ticks',v['ra']>=1)
    await br.close()
asyncio.run(main())
print('ERRORS',errs)
