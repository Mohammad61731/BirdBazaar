# تست 1.9.65: کش IndexedDB روی گوشی + عدم دانلود دوباره‌ی غرفه‌ها هنگام باز شدن برنامه
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(name,cond):
        nonlocal ok; print(('PASS ' if cond else 'FAIL ')+name); ok&=bool(cond)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        st={'pub':0,'bpub':0,'rpub':0}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if not u.startswith('http'): return await route.continue_()
            try: o=json.loads(bd).get('op')
            except Exception: o=None
            hd={'access-control-allow-origin':'*'}
            if u.endswith('/rpc/fapp') and o=='psig':
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'s':'S1','b':'B1'}))
            if o=='public2': return await route.fulfill(status=404,headers=hd,body='{}')  # 1.9.66: سرور قدیمی بدون public2
            if u.endswith('/rpc/app') and o=='public': st['pub']+=1
            if u.endswith('/rpc/bapp') and o=='bpublic': st['bpub']+=1
            if u.endswith('/rpc/rapp') and o=='rpublic':
                st['rpub']+=1; body={'ok':1,'birds':[{'id':'r1','d':{'n':'ب'}}]}
            elif u.endswith('/rpc/bapp'): body={'ok':1,'booths':[{'id':'b1','name':'غرفه','logo':'🐦'}],'prods':[]}
            else: body={'ok':1,'msgs':[],'rooms':[],'products':[{'id':9,'name':'محصول','price':1000,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
            return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
        await pg.route('**/*',h)
        url='file://%s/www/index.html'%ROOT
        # 1) اولین باز شدن
        await pg.goto(url); await pg.wait_for_timeout(2500)
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('first boot: public downloaded',st['pub']>=1)
        chk('first boot: booths downloaded',st['bpub']>=1)
        await pg.wait_for_timeout(2500)  # مهلت آینه‌ی IDB
        d=await pg.evaluate("idbGet('D').then(x=>x?x.products.length:-1)")
        bt=await pg.evaluate("idbGet('BT').then(x=>x?x.b.length:-1)")
        chk('IDB has D mirror (%s)'%d,d==1)
        chk('IDB has booths mirror (%s)'%bt,bt==1)
        # 2) بستن و باز کردن برنامه (مهر ثابت) ← هیچ دانلود تازه‌ای نباید باشد
        p0,b0=st['pub'],st['bpub']
        await pg.goto(url); await pg.wait_for_timeout(2500)
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(800)
        chk('relaunch: public NOT re-downloaded (%d->%d)'%(p0,st['pub']),st['pub']==p0)
        chk('relaunch: booths NOT re-downloaded (%d->%d)'%(b0,st['bpub']),st['bpub']==b0)
        nb=await pg.evaluate("BT.booths.length")
        chk('relaunch: booths restored from cache (%s)'%nb,nb==1)
        # 3) localStorage اصلی پاک شد ولی IDB هست ← برگرداندن از IDB، بدون دانلود
        await pg.evaluate("localStorage.removeItem('bp4');localStorage.removeItem('bp_bc')")
        p1,b1=st['pub'],st['bpub']
        await pg.goto(url); await pg.wait_for_timeout(2500)
        await pg.evaluate("BT.ok=0;BT.booths=[];bpull()"); await pg.wait_for_timeout(800)
        pid=await pg.evaluate("D.products[0]&&D.products[0].id")
        chk('ls wiped: products restored from IDB (id=%s)'%pid,pid==9)
        chk('ls wiped: no public download (%d->%d)'%(p1,st['pub']),st['pub']==p1)
        chk('ls wiped: booths from IDB, no download (%d->%d)'%(b1,st['bpub']),st['bpub']==b1)
        # 4) هر دو پاک شد (IDB هم) ← دانلود کامل
        await pg.evaluate("idbOpen().then(db=>db&&db.close());IDBX.p=null")
        await pg.evaluate("new Promise(r=>{const q=indexedDB.deleteDatabase('bpdb');q.onsuccess=q.onerror=q.onblocked=()=>r(1)})")
        await pg.evaluate("localStorage.removeItem('bp4')")
        p2=st['pub']
        await pg.goto(url); await pg.wait_for_timeout(3000)
        chk('both wiped: full download happens (%d->%d)'%(p2,st['pub']),st['pub']>p2)
        # 5) quota پر شد ← خطای قرمز نباشد و IDB ذخیره کند
        await pg.evaluate("window.__o=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='bp4')throw new Error('quota');return window.__o.call(this,k,v)};D.products[0].name='جدید';save()")
        await pg.wait_for_timeout(2500)
        nm=await pg.evaluate("idbGet('D').then(x=>x&&x.products[0].name)")
        chk('quota full: IDB still saved (%s)'%nm,nm=='جدید')
        chk('no page errors %s'%errs,not errs)
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
