# تست 1.9.85: شمارنده‌ی حجم دانلود (بخش «امروز» همیشه داده دارد + ماندگاری) و توضیح پشتیبان + چک‌لیست انتقال
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            ctx=await b.new_context(viewport={'width':w,'height':700}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            await pg.evaluate("S.me='adm';S.role='admin';S.pm=['all'];S.pnl=0")
            await pg.evaluate("pull()"); await pg.wait_for_timeout(900)
            chk('%d NM off but ST has bytes today'%w, not await pg.evaluate("NM.on") and await pg.evaluate("ST.cur.b>0"))
            hh=await pg.evaluate("nmCard()")
            chk('%d card shows today block with KB'%w, 'امروز (همیشه فعال)' in hh and 'KB' in hh)
            chk('%d card hides empty text when data exists'%w, 'هنوز چیزی ثبت نشده' not in hh)
            # ماندگاری شمارنده‌ی دقیق
            await pg.evaluate("NM.on=1;localStorage.setItem('bp_nm','1');NM.o={};pull()"); await pg.wait_for_timeout(700)
            n1=await pg.evaluate("Object.keys(NM.o).length"); await pg.evaluate("NM.sv()")
            chk('%d NM counted and saved'%w, n1>0 and await pg.evaluate("!!localStorage.getItem('bp_nmd')"))
            await pg.route('**/*',h)
            await pg.reload(); await pg.wait_for_timeout(1500)
            chk('%d NM restored after reload'%w, await pg.evaluate("NM.on && Object.keys(NM.o).length>0"))
            await pg.evaluate("NM.on=0;NM.sv()")
            chk('%d turning off clears saved'%w, await pg.evaluate("!localStorage.getItem('bp_nmd')"))
            # متن پشتیبان
            await pg.evaluate("S.me='adm';S.role='admin';S.pm=['all'];S.pnl=1;S.at='x';render()"); await pg.wait_for_timeout(400)
            bk=await pg.evaluate("bkfCard()")
            chk('%d backup card explains + has migration button'%w, 'سطل Storage' in bk and 'bkf_mig' in bk and 'پرندگان' in bk)
            await pg.evaluate("bkMig()"); await pg.wait_for_timeout(400)
            tx=await pg.evaluate("document.body.innerText")
            chk('%d migration checklist opens'%w, 'انتقال به سرور جدید' in tx and 'ALL_SQL.sql' in tx and 'rpc/app' in tx)
            chk('%d no overflow'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk('%d no errors %s'%(w,errs), not errs)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
