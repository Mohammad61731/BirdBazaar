# تست 1.9.424 G8-b: بازگشایی لغوشده + غرفه‌داران بی‌پاسخ (کلید og)
import json,time
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
NOW=int(time.time()*1000);H=3600000
ORD=[{'id':1,'bid':1,'bn':'غرفه الف','bp':'0912','cn':'م','cp':'0935','tt':100000,'t':NOW-30*H,'pk':False,'ps':'wait','cs':None},
     {'id':2,'bid':1,'bn':'غرفه الف','bp':'0912','cn':'م','cp':'0935','tt':200000,'t':NOW-14*H,'pk':False,'ps':'ok','cs':None},
     {'id':3,'bid':2,'bn':'غرفه ب','bp':'','cn':'م','cp':'','tt':300000,'t':NOW-20*H,'pk':False,'ps':'ok','cs':'way'},
     {'id':4,'bid':3,'bn':'تازه','bp':'','cn':'م','cp':'','tt':10000,'t':NOW-2*H,'pk':False,'ps':'wait','cs':None}]
CX=[{'id':9,'bn':'غرفه ج','cn':'علی','cp':'0936','tt':5000,'t':NOW-5*H}]
calls=[]
def gapp(route):
    b=json.loads(route.request.post_data or '{}');calls.append(b.get('op'))
    body={'ok':1}
    if b.get('op')=='ostk': body={'ok':1,'l':ORD,'d':{'n':1,'ok':0,'x':0}}
    if b.get('op')=='oxl': body={'ok':1,'l':CX}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(body))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/gapp*',gapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' ';calls.clear()
        pg.evaluate("XF.og=0;OG={ld:0,er:'',l:null,d:null,t:0,c:'',x:null,xl:0}")
        chk(t+'off -> no new boxes',pg.evaluate("ogXH()===''&&ogUrH()===''"))
        pg.evaluate("XF.og=1;S.me='a';S.pw='b'")
        chk(t+'on -> xl button, no list, no call',pg.evaluate("ogXH().includes('ogxl')&&!ogXH().includes('ogrp')")and calls==[])
        chk(t+'unresponsive hidden before load',pg.evaluate("ogUrH()===''"))
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(350)
        click('ogld')
        chk(t+'ostk only',calls==['ostk'])
        chk(t+'unresponsive = booth Alef (2 orders, >=12h) ; booth B has courier ; new one too young',pg.evaluate("(()=>{const L=ogUr();return L.length==1&&L[0].c==2&&L[0].n=='غرفه الف'})()"))
        chk(t+'unresponsive box renders+tel',pg.evaluate("ogUrH().includes('بی‌پاسخ')&&ogUrH().includes('tel:0912')"))
        chk(t+'ogSec includes all three parts',pg.evaluate("(()=>{const h=ogSec();return h.includes('ogld')&&h.includes('بی‌پاسخ')&&h.includes('ogxl')})()"))
        calls.clear();click('ogxl')
        chk(t+'oxl one call',calls==['oxl'])
        chk(t+'cancelled list shown',pg.evaluate("ogXH().includes('ogrp')&&ogXH().includes('#۱٬۰۰۹')&&ogXH().includes('tel:0936')"))
        calls.clear()
        pg.evaluate("window.__a=null");
        # bzAsk: answer yes
        pg.evaluate("(()=>{const o=window.bzAsk;window.bzAsk=(m,d,cb)=>cb('بله');window.__o=o})()")
        click('ogrp','9')
        chk(t+'orp call + removed from list',calls==['orp'] and pg.evaluate("OG.x.length==0&&OG.l===null"))
        click('ogrp','0');chk(t+'bad id ignored',calls==['orp'])
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
