# تست مورد ۱۰: سالن فروش و پرورش (پنل غرفه‌دار + نمایش عمومی)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
SH = sys.argv[2] if len(sys.argv) > 2 else None
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for th in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=th); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            db=[{'id':1,'d':{'name':'کاکتیل زرد','sp':'کاکتیل','sx':'m','age':'۴ ماهه','mt':'yg','price':1500000,'imgs':[]},'k':'sale','s':'on','t':'x'}]
            calls=[]
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                try: bd=json.loads(route.request.post_data or '{}')
                except: bd={}
                hd={'access-control-allow-origin':'*'}
                if 'rapp' in u:
                    o=bd.get('op'); calls.append(o)
                    if o=='rpublic': body={'ok':1,'birds':[{'id':x['id'],'b':1,'bn':'غرفه آزمون','ph':'0912','city':'تهران','d':x['d'],'k':x['k'],'t':'x'} for x in db if x['s']=='on']}
                    elif o=='rme': body={'ok':1,'birds':db}
                    elif o=='rset':
                        a=bd['a']; db.append({'id':len(db)+1,'d':a['d'],'k':a['k'],'s':a.get('s','on'),'t':'x'}) if not a.get('id') else None; body={'ok':1,'id':1}
                    elif o=='rdel': body={'ok':1}
                    else: body={'err':'op'}
                elif 'bapp' in u: body={'ok':1,'booths':[{'id':1,'name':'غرفه آزمون','logo':'','cover':'','city':'تهران','phone':'0912','views':3,'n':0}],'prods':[]}
                else: body={'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}
                await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            # عمومی: نوار سالن در آگهی‌ها
            await pg.evaluate("S.tab=2;S.v=null;S.sub=0;render()"); await pg.wait_for_timeout(400)
            a=await pg.evaluate("({strip:!!document.querySelector('#scr .hs .pc[data-a=br_v]'),txt:document.querySelector('#scr').textContent.includes('سالن فروش و پرورش')})")
            # جزئیات
            await pg.evaluate("document.querySelector('[data-a=br_v]').click()"); await pg.wait_for_timeout(300)
            d=await pg.evaluate("({s:S.v,t:document.querySelector('#scr').textContent.includes('کاکتیل زرد')&&document.querySelector('#scr').textContent.includes('پیام به غرفه‌دار')})")
            await pg.evaluate("ab()"); 
            # پنل غرفه‌دار
            await pg.evaluate("BT.u='u';BT.p='p';BM={booth:{id:1,name:'غرفه آزمون',status:'active',views:3},prods:[],days:[]};S.tab=4;S.v='btm';S.btt='r';RB=null;render()"); await pg.wait_for_timeout(600)
            m=await pg.evaluate("({list:document.querySelector('#scr').textContent.includes('کاکتیل زرد'),add:!!document.querySelector('[data-a=br_f]')})")
            await pg.evaluate("document.querySelector('[data-a=br_f][data-v=\"0\"]').click()"); await pg.wait_for_timeout(300)
            f1=await pg.evaluate("!!document.getElementById('rfp')")
            await pg.evaluate("document.querySelector('[data-a=br_k][data-v=show]').click()"); await pg.wait_for_timeout(200)
            f2=await pg.evaluate("!document.getElementById('rfp')")
            await pg.evaluate("document.querySelector('[data-a=br_k][data-v=sale]').click()"); await pg.wait_for_timeout(200)
            await pg.evaluate("document.getElementById('rfn').value='مینا';document.getElementById('rfx').value='f';document.getElementById('rfp').value='۲٬۰۰۰٬۰۰۰'")
            if SH and w==360 and th=='light': await pg.screenshot(path=SH)
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            # قیمت خالی → خطا؛ بعد ذخیره
            await pg.evaluate("document.querySelector('[data-a=br_s]').click()"); await pg.wait_for_timeout(500)
            sv=len(db)==2 and db[1]['d']['price']==2000000 and db[1]['d']['sx']=='f' and 'rset' in calls
            await pg.wait_for_timeout(500)
            back=await pg.evaluate("S.v")
            print(w,th,a,d,m,'form',f1,f2,'saved',sv,'back',back,'ov',ov,errs)
            ok&=a['strip'] and a['txt'] and d['t'] and m['list'] and m['add'] and f1 and f2 and sv and not ov and not errs
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
