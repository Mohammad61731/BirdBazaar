# تست 1.9.366: P37 فاکتور قابل ذخیره ، P38 غرفه‌های دنبال‌شده
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
WRAP="document.body.insertAdjacentHTML('beforeend','<div id=pxs style=\\\"position:fixed;inset:0;overflow:auto;z-index:100003;background:var(--bg);padding:8px;box-sizing:border-box\\\">'+pxBody()+'</div>')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='user';S.me='ali';S.tab=4;S.pnl=0;XF.xp=1;XF.bf=1;localStorage.removeItem('bp_px');S.inv={id:7,dt:'۱۴۰۵/۰۹/۰۳',cu:'علی',ph:'0917',ad:'شیراز',it:[{n:'قفس',q:2,u:150000}],tt:300000};S.v='inv';render()");pg.wait_for_timeout(1800)
        chk(t+'save button shown',pg.evaluate("!!document.querySelector('[data-a=pxiv]')"))
        pg.evaluate("document.querySelector('[data-a=pxiv]').click()");pg.wait_for_timeout(200)
        chk(t+'invoice saved',pg.evaluate("pxGet().iv.length==1&&/فاکتور فروش/.test(pxGet().iv[0].t)&&pxGet().iv[0].i"))
        pg.evaluate("document.querySelector('[data-a=pxiv]').click()");pg.wait_for_timeout(200)
        chk(t+'duplicate not saved',pg.evaluate("pxGet().iv.length==1"))
        pg.evaluate("XF.xp=0;render()");pg.wait_for_timeout(500)
        chk(t+'key off: no button',pg.evaluate("!document.querySelector('[data-a=pxiv]')"))
        pg.evaluate("XF.xp=1;S.v=null;BT.booths=[{id:3,name:'غرفه‌ی سفال',n:2},{id:4,name:'غرفه‌ی پرنده',n:1}];if(!fbGet().includes(3))fbToggle(3);if(!fbGet().includes(4))fbToggle(4)")
        pg.evaluate(WRAP)
        chk(t+'cards shown',pg.evaluate("/فاکتورهای ذخیره‌شده/.test(document.getElementById('pxs').textContent)&&/غرفه‌ی سفال/.test(document.getElementById('pxs').textContent)&&/جمع کل|۳۰۰/.test(document.getElementById('pxs').textContent)"))
        pg.evaluate("window.pxRe=function(){document.getElementById('pxs').innerHTML=pxBody()}")
        pg.evaluate("window.__cp='';Object.defineProperty(navigator,'clipboard',{value:{writeText:x=>{window.__cp=x;return Promise.resolve()}},configurable:true})")
        pg.evaluate("document.querySelector('[data-pxv2=cp]').click()");pg.wait_for_timeout(150)
        chk(t+'invoice copy',pg.evaluate("/فاکتور فروش/.test(window.__cp)"))
        pg.evaluate("document.querySelector('[data-pxb=un][data-v=\"3\"]').click()");pg.wait_for_timeout(150)
        chk(t+'unfollow',pg.evaluate("!fbGet().includes(3)&&fbGet().includes(4)&&!/غرفه‌ی سفال/.test(document.getElementById('pxs').textContent)"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.getElementById('pxs').scrollWidth<=document.getElementById('pxs').clientWidth"))
        pg.evaluate("document.querySelector('[data-pxv2=dl]').click()")
        chk(t+'invoice deleted',pg.evaluate("pxGet().iv.length==0&&/هنوز فاکتوری/.test(document.getElementById('pxs').textContent)"))
        ctx.close()
    br.close()
print('ERRORS',errs)
