# تست 1.9.194: عکس‌های اضافه روی لوگوی سردر (L2)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.new('RGBA',(900,300),(200,98,42,255)).save('/home/claude/w/tmp/l.png')
Image.new('RGBA',(300,300),(30,120,60,255)).save('/home/claude/w/tmp/m.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2000)
        chk(f'{w}: funcs',pg.evaluate("typeof lgEa=='function'&&typeof lgEd=='function'&&typeof lgSetE=='function'&&typeof lgEx=='function'"))
        chk(f'{w}: non-admin add no-op',pg.evaluate("(()=>{lgEd(0);lgSetE('lge0_x',5);return !(D.cms.BR&&D.cms.BR.ex)})()"))
        chk(f'{w}: default no lex',pg.evaluate("hnBrand().indexOf('class=\"lex\"')<0"))
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();lgSheet()})()");pg.wait_for_timeout(200)
        chk(f'{w}: add button shown',pg.locator('[data-a=lgea]').count()==1)
        for f in ('l.png','m.png'):
            with pg.expect_file_chooser() as fc: pg.click('[data-a=lgea]')
            fc.value.set_files('/home/claude/w/tmp/'+f);pg.wait_for_timeout(900)
        chk(f'{w}: 2 layers saved small',pg.evaluate("Array.isArray(D.cms.BR.ex)&&D.cms.BR.ex.length==2&&D.cms.BR.ex.every(c=>c.u.length<24000&&c.u.indexOf('data:image/webp')==0)"))
        chk(f'{w}: rendered',pg.evaluate("(hnBrand().match(/<img src=\"data:image/g)||[]).length>=2&&hnBrand().indexOf('class=\"lex\"')>0&&hnBrand().indexOf('class=\"lb\"')>0"))
        chk(f'{w}: sliders shown',pg.locator('#lge0_x').count()==1 and pg.locator('#lge1_s').count()==1)
        pg.evaluate("(()=>{const e=document.getElementById('lge1_x');e.value=60;e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        pg.evaluate("(()=>{const e=document.getElementById('lge0_s');e.value=150;e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        chk(f'{w}: x/size saved',pg.evaluate("D.cms.BR.ex[1].x==60&&D.cms.BR.ex[0].s==1.5"))
        chk(f'{w}: sheet still open',pg.locator('#lge0_x').count()==1)
        pg.evaluate("(()=>{const e=document.getElementById('lge0_y');e.value=999;e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        chk(f'{w}: y clamped',pg.evaluate("D.cms.BR.ex[0].y==60"))
        chk(f'{w}: bad data rejected',pg.evaluate("(()=>{const o=D.cms.BR.ex[0].u;D.cms.BR.ex[0].u='javascript:x';const r=lgEx()[0]===null&&lgEx()[1]!==null;D.cms.BR.ex[0].u=o;return r})()"))
        for _ in range(2):
            with pg.expect_file_chooser() as fc: pg.click('[data-a=lgea]')
            fc.value.set_files('/home/claude/w/tmp/m.png');pg.wait_for_timeout(700)
        chk(f'{w}: max 4',pg.evaluate("D.cms.BR.ex.length==4")and pg.locator('[data-a=lgea]').count()==0)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.evaluate("(()=>{const e=document.getElementById('lge0_x');e.value=200;e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        chk(f'{w}: no overflow at extreme x',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.click('[data-a=lgxd][data-v="0"]');pg.wait_for_timeout(200)
        chk(f'{w}: delete one',pg.evaluate("D.cms.BR.ex.length==3"))
        pg.evaluate("(()=>{D.cms.BR.cu={u:'data:image/webp;base64,AAAA',x:0,y:0,s:1};save()})()")
        chk(f'{w}: edit-BR keeps ex',pg.evaluate("(()=>{const n=D.cms.BR.ex.length;E={t:'br',i:0,d:cl2(D.cms.BR)};delete E.d.ex;sbe();return D.cms.BR.ex&&D.cms.BR.ex.length==n})()"))
        while pg.evaluate("D.cms.BR.ex&&D.cms.BR.ex.length>0"):
            pg.evaluate("lgEd(0)")
        chk(f'{w}: all deleted',pg.evaluate("!D.cms.BR.ex&&hnBrand().indexOf('class=\"lex\"')<0"))
        ctx.close()
    br.close()
print('ERRORS',errs)
