# تست 1.9.282: LG2 مصالح شیشه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
INJ="""document.getElementById('scr').insertAdjacentHTML('afterbegin','<div id=lgt style="background:linear-gradient(135deg,#ff6b6b,#4dabf7,#ffd43b);padding:16px;display:grid;gap:10px"><div class="lgl thin" id=g1 style="height:50px">a</div><div class="lgl" id=g2 style="height:50px">b<div class="lgl" id=g2n style="height:20px">n</div></div><div class="lgl thick" id=g3 style="height:50px">c</div><div class=lgl>4</div><div class=lgl>5</div><div class=lgl>6</div><div class=lgl id=g7>7</div><div class=lgl id=g8>8</div></div>')"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH={home:{m:'%s'}};thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(300)
                pg.evaluate(INJ);pg.wait_for_timeout(300)
                bf=lambda i:pg.evaluate("getComputedStyle(document.getElementById('%s')).backdropFilter||getComputedStyle(document.getElementById('%s')).webkitBackdropFilter"%(i,i))
                chk(t+'regular blurs',('blur' in bf('g2')))
                chk(t+'thin < regular < thick',float(bf('g1').split('blur(')[1].split('px')[0])<float(bf('g2').split('blur(')[1].split('px')[0])<float(bf('g3').split('blur(')[1].split('px')[0]))
                chk(t+'nested blur off',bf('g2n') in ('none',''))
                chk(t+'cap: 7th/8th flat',pg.evaluate("document.getElementById('g7').classList.contains('lgf')&&document.getElementById('g8').classList.contains('lgf')&&!document.getElementById('g3').classList.contains('lgf')") and bf('g8') in ('none',''))
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
                if w==360 and not dark: pg.screenshot(path='/tmp/lg2_%s.png'%m)
                pg.evaluate("document.getElementById('app').dataset.lp='1'");pg.wait_for_timeout(100)
                chk(t+'data-lp disables blur',bf('g2') in ('none',''))
                pg.evaluate("D.cms.TH={home:{m:'m'}};thApply();go({tab:0,v:null})");pg.wait_for_timeout(200);pg.evaluate(INJ)
                chk(t+'minimal theme: .lgl has no effect',bf('g2') in ('none',''))
                ctx.close()
    br.close()
print('ERRORS',errs)
