#!/bin/sh
# سبک‌سازی خودکار قبل از هر زیپ (از ریشه‌ی پروژه): sh _update_notes/lighten.sh
find . -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null
find . \( -name '*.zip' -o -name '*.bak' -o -name '*.orig' -o -name '*.tmp' -o -name '*~' -o -name '.DS_Store' -o -name '*.log' \) -type f -delete 2>/dev/null
rm -rf shots _update_notes/shots _update_notes/out _update_notes/tmp node_modules 2>/dev/null
find _update_notes -type f \( -name '*.png' -o -name '*.jpg' -o -name '*.mp4' -o -name '*.webm' \) -delete 2>/dev/null
# هرگز پاک نشوند: android-res/mipmap-*/ic_launcher*.png و keystore
du -sk . | cut -f1
