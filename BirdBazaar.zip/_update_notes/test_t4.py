# U10-T4: انتخاب‌گر تم
from playwright.sync_api import sync_playwright
errs=[];R={}
NEW='file:///home/claude/bb/www/index.html'
ADM="S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"
def mk(br,w=390):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto(NEW);pg.wait_for_timeout(900);return pg
def at(pg,k):return pg.evaluate("[document.querySelector('#app').dataset.tm,document.querySelector('#app').dataset.nc,document.querySelector('#app').dataset.gs]")
with sync_playwright() as p:
    br=p.chromium.launch()
    # کاربر عادی: دکمه نیست
    pg=mk(br);pg.evaluate("drawer()");R['user_no_btn']=pg.locator('[data-a=ths]').count()==0
    pg=mk(br);pg.evaluate(ADM+"renderTop();drawer()");R['admin_btn']=pg.locator('[data-a=ths]').count()==1
    pg.click('[data-a=ths]');pg.wait_for_timeout(200)
    R['sheet']=pg.locator('#thpv').count()==1
    pg.click('[data-a=thm2][data-v=g]');R['glass']=at(pg,0)[0]=='g'
    pg.click('[data-a=thc][data-v=purple]');R['purple']=at(pg,0)[1]=='purple'
    pg.click('[data-a=ths2][data-v=g]');R['grad']=at(pg,0)[2]=='g'
    pg.click('[data-a=thg][data-v=sunset]');R['preset']=pg.evaluate("thGet(thKey()).g1")=='#f97316'
    pg.fill('#thg2','#112233');pg.dispatch_event('#thg2','change');pg.wait_for_timeout(100)
    R['custom']=pg.evaluate("thGet(thKey()).g2")=='#112233'
    pg.check('#thlp');R['lp']=pg.evaluate("document.querySelector('#app').dataset.lp")=='1'
    pg.screenshot(path='shots/t4_sheet.png')
    pg.click('[data-a=thm2][data-v=p]');R['photo']=at(pg,0)[0]=='p';R['gs_off']=at(pg,0)[2]=='s'
    # هر تب مستقل
    pg.evaluate("go({tab:1,v:null,sub:0})");pg.wait_for_timeout(200);R['store_normal']=at(pg,0)[0]=='n'
    pg.evaluate("go({tab:0,v:null,sub:0})");pg.wait_for_timeout(200);R['home_kept']=at(pg,0)[0]=='p'
    pg.evaluate("drawer()");pg.click('[data-a=ths]');pg.click('[data-a=thr]');R['reset']=at(pg,0)[0]=='n'
    # غیرادمین نمی‌تواند
    pg2=mk(br);pg2.evaluate("thSet('home',{m:'g'})");R['user_blocked']=at(pg2,0)[0]=='n'
    # عرض‌ها بدون سرریز
    for w in (320,360,412):
        q=mk(br,w);q.evaluate(ADM+"renderTop();thSet('home',{m:'g',s:'g'});drawer();document.querySelector('[data-a=ths]').click()")
        R[f'ov{w}']=q.evaluate("(()=>{const e=document.querySelector('.sheet');return e.scrollWidth<=e.clientWidth+1})()")
        if w==320:q.screenshot(path='shots/t4_320.png')
    br.close()
print(R);print('errs',errs);print('PASS' if all(R.values()) and not errs else 'FAIL')
