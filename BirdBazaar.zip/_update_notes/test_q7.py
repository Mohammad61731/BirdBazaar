import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[];reqs=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:reqs.append(json.loads(q.post_data or '{}'))
    except Exception:pass
    r.fulfill(status=200,content_type='application/json',body='{"ok":1,"msgs":[],"rooms":[],"pins":[],"av":{}}')
SETUP="""S.role='user';S.me='ali';S.pw='x';FM.rooms=[{id:1,name:'عمومی',emoji:'💬'}];FM.room=1;FM.perm={txt:1};FM.main=0;FM.pins=[];FM.av={};FM.mine={};FM.q=0;FM.qf=0;
FM.msgs=[{id:1,u:'ali',k:'text',b:'سلام',t:new Date().toISOString(),r:{}},{id:2,u:'ali',k:'text',b:'جوجه چرا نمی‌خورد؟',q:true,s:false,t:new Date().toISOString(),r:{}},{id:3,u:'sara',k:'text',b:'چرا آب نمی‌خورند؟',q:true,s:true,t:new Date().toISOString(),r:{}}];
go({v:'chat',id:1,fr:1});fDraw(1)"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_page(viewport={'width':w,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700)
        pg.evaluate(SETUP);pg.wait_for_timeout(200)
        t=pg.inner_text('#msgs')
        chk('w%d برچسب پرسش و حل‌شد'%w,'❓ پرسش' in t and '✅ حل شد' in t)
        chk('w%d پیام عادی برچسب ندارد'%w,pg.locator('.fqb').count()==2)
        chk('w%d ردیف فیلتر دیده می‌شود'%w,pg.locator('#fqf').is_visible() and pg.locator('#fqf button').count()==3)
        pg.evaluate("go({v:'chat',id:1,fr:1});FM.qf=1;fDraw(1)");chk('w%d فیلتر حل‌نشده: فقط یک پیام'%w,pg.locator('#msgs .fmr').count()==1)
        pg.evaluate("FM.qf=2;fDraw(1)");chk('w%d فیلتر حل‌شده: فقط یک پیام'%w,pg.locator('#msgs .fmr').count()==1)
        pg.evaluate("FM.qf=0;fDraw(1)");chk('w%d فیلتر همه: سه پیام'%w,pg.locator('#msgs .fmr').count()==3)
        chk('w%d بدون سرریز افقی'%w,pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.close()
    pg=br.new_page(viewport={'width':360,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700);pg.evaluate(SETUP);pg.wait_for_timeout(200)
    pg.evaluate("fMsgSheet(2)");chk('نویسنده‌ی پرسش دکمه‌ی «حل شد» دارد',pg.locator('[data-a=fsol]').count()==1)
    pg.evaluate("cl()");pg.evaluate("fMsgSheet(3)");chk('کاربر دیگر دکمه‌ی «حل شد» ندارد',pg.locator('[data-a=fsol]').count()==0)
    pg.evaluate("cl()");pg.evaluate("fMsgSheet(1)");chk('پیام عادی دکمه‌ی «حل شد» ندارد',pg.locator('[data-a=fsol]').count()==0)
    pg.evaluate("cl()");pg.evaluate("FM.main=1;fMsgSheet(3)");chk('ادمین روی پرسش دیگران دکمه دارد (برگرداندن)',pg.locator('[data-a=fsol]').count()==1 and 'برگرداندن' in pg.inner_text('[data-a=fsol]'));pg.evaluate("cl();FM.main=0")
    reqs.clear();pg.evaluate("fMsgSheet(2)");pg.click('[data-a=fsol]');pg.wait_for_timeout(400)
    chk('fsolve فرستاده شد (id=2 on=true)',any(r.get('op')=='fsolve' and r['a'].get('id')==2 and r['a'].get('on') is True for r in reqs))
    chk('پرسش حالا حل‌شده است',pg.evaluate("FM.msgs[1].s===true")and '✅ حل شد' in pg.inner_text('#msgs'))
    pg.evaluate("document.querySelector('#fqt').click()");chk('دکمه‌ی 🙋 روشن شد',pg.evaluate("FM.q===1")and pg.evaluate("document.querySelector('#fqt').classList.contains('on')"))
    chk('placeholder تغییر کرد','پرسشت' in pg.evaluate("document.querySelector('#ci').placeholder"))
    reqs.clear();pg.fill('#ci','پرسش تازه');pg.evaluate("snd()");pg.wait_for_timeout(400)
    chk('fsend با q=1',any(r.get('op')=='fsend' and r['a'].get('q')==1 for r in reqs))
    chk('بعد از ارسال حالت پرسش خاموش شد',pg.evaluate("FM.q===0"))
    reqs.clear();pg.fill('#ci','پیام عادی');pg.evaluate("snd()");pg.wait_for_timeout(400)
    chk('پیام بعدی بدون q',any(r.get('op')=='fsend' and r['a'].get('q') is None for r in reqs))
    reqs.clear();pg.evaluate("FM.q=1;FM.rp={id:2,u:'ali',t:'x'}");pg.fill('#ci','جواب');pg.evaluate("snd()");pg.wait_for_timeout(400)
    chk('پاسخ (reply) هرگز q نمی‌فرستد',any(r.get('op')=='fsend' and r['a'].get('q') is None for r in reqs))
    br.close()
chk('بدون خطای صفحه',not errs)
print('ALL PASS' if all(ok) else 'SOME FAIL',errs[:2])
