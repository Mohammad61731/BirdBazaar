import json,re,sys
from playwright.sync_api import sync_playwright
DB={'booths':[{'id':1,'owner':'ali','pw':'1234','name':'غرفه علی','bio':'ارزن و کتان عمده','logo':'','cover':'','city':'سراوان','phone':'09120000000','status':'active','views':5}],'prods':[],'reqs':[{'id':1,'name':'رضا','phone':'09151112233','city':'زاهدان','shop':'دان رضا','about':'دان','status':'new'}],'nid':1}
def handle(route,req):
    u=req.url
    if u.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op'];a=b.get('a') or {};U=b.get('u');P=b.get('p')
        def bo():
            return next((x for x in DB['booths'] if x['owner']==U and x['pw']==P),None)
        def pub(x):return {k:x[k] for k in ['id','name','bio','logo','cover','city','phone','views']}|{'n':len([q for q in DB['prods'] if q['b']==x['id'] and q['s']=='on'])}
        r={'err':'unknown'}
        if o=='bpublic':r={'ok':1,'booths':[pub(x) for x in DB['booths'] if x['status']=='active'],'prods':[{'id':q['id'],'b':q['b'],'d':q['d'],'t':'x'} for q in reversed(DB['prods']) if q['s']=='on']}
        elif o=='bview':r={'ok':1}
        elif o=='breq':DB['reqs'].append({'id':len(DB['reqs'])+1,'name':a['name'],'phone':a['phone'],'city':a.get('city'),'shop':a.get('shop'),'about':a.get('about'),'status':'new'});r={'ok':1}
        elif o in('blogin','bme'):
            x=bo()
            r={'err':'denied'} if not x else {'ok':1,'booth':{**pub(x),'status':x['status']},'prods':[{'id':q['id'],'d':q['d'],'s':q['s'],'t':'x'} for q in DB['prods'] if q['b']==x['id']],'days':[{'day':'2026-11-13','n':3}]}
        elif o=='bprod_set':
            x=bo()
            if a.get('id'):
                for q in DB['prods']:
                    if q['id']==a['id']:q['d']=a['d'];q['s']=a.get('s','on')
                r={'ok':1,'id':a['id']}
            else:
                DB['nid']+=1;DB['prods'].append({'id':DB['nid'],'b':x['id'],'d':a['d'],'s':a.get('s','on')});r={'ok':1,'id':DB['nid']}
        elif o=='bprod_del':DB['prods']=[q for q in DB['prods'] if q['id']!=a['id']];r={'ok':1}
        elif o=='bset':
            x=bo();x.update({k:a[k] for k in ['name','bio','city','phone','logo','cover'] if k in a});r={'ok':1}
        elif o.startswith('badm_'):
            if b.get('u')!='admin' or b.get('p')!='pw1':r={'err':'denied'}
            elif o=='badm_list':r={'ok':1,'reqs':[x for x in DB['reqs'] if x['status']=='new'],'booths':[{'id':x['id'],'owner':x['owner'],'name':x['name'],'city':x['city'],'phone':x['phone'],'status':x['status'],'views':x['views'],'n':len([q for q in DB['prods'] if q['b']==x['id']])} for x in DB['booths']]}
            elif o=='badm_approve':
                q=next(x for x in DB['reqs'] if x['id']==a['id']);q['status']='ok';DB['booths'].append({'id':len(DB['booths'])+1,'owner':a['owner'],'pw':a['pw'],'name':q['shop'],'bio':'','logo':'','cover':'','city':q['city'],'phone':q['phone'],'status':'active','views':0});r={'ok':1}
            else:r={'ok':1}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    if '/rpc/app' in u:
        route.fulfill(status=200,content_type='application/json',body='{"err":"x"}');return
    route.continue_()
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR')
    pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.on('console',lambda m:errs.append('CONSOLE '+m.text) if m.type=='error' and 'Failed to load' not in m.text and 'ERR_' not in m.text else None)
    pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',handle)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(1200)
    def shot(n):pg.screenshot(path=f'/home/claude/work/shots/{n}.png')
    # home block
    pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(300)
    print('home has booth block:',pg.evaluate("document.body.innerText.includes('غرفه‌داران')"), 'mini:',pg.locator('.bm').count())
    shot('home')
    # list
    pg.evaluate("go({v:'booth'})");pg.wait_for_timeout(300);print('list cards',pg.locator('.bbc').count());shot('list')
    # request form
    pg.click('[data-a=bt_req]');pg.fill('#bqn','محمد تست');pg.fill('#bqp','09123334455');pg.fill('#bqs','غرفه تست');pg.click('[data-a=bt_rq]');pg.wait_for_timeout(400)
    print('reqs in db',len(DB['reqs']),'view after submit',pg.evaluate("S.v"))
    # vendor login
    pg.click('[data-a=bt_pan]');pg.wait_for_timeout(200);pg.fill('#bu','ali');pg.fill('#bpw','1234');pg.click('[data-a=bt_li]');pg.wait_for_timeout(500)
    print('panel title:',pg.locator('h2').first.inner_text());shot('panel_dash')
    # add weight product with retail+wholesale
    pg.click('[data-a=bt_tb][data-v=p]');pg.click('[data-a=bt_pf][data-v="0"]');pg.wait_for_timeout(200)
    pg.fill('#bfn','ارزن سفید');pg.fill('#bfe','🌾');pg.click('[data-a=bt_ty][data-v=wt]');pg.wait_for_timeout(100)
    print('name kept after type switch:',pg.input_value('#bfn'))
    pg.fill('#bfrp','120000');pg.fill('#bfwp','95000');pg.fill('#bfwm','10');pg.fill('#bft0m','25');pg.fill('#bft0p','90000');pg.check('#bfw');shot('form')
    pg.click('[data-a=bt_ps]');pg.wait_for_timeout(500)
    print('products in db',len(DB['prods']),DB['prods'][0]['d']['wh'] if DB['prods'] else None,'view',pg.evaluate("S.v"))
    # plain product
    pg.click('[data-a=bt_pf][data-v="0"]');pg.fill('#bfn','قفس مرغ عشق');pg.fill('#bfp','850000');pg.fill('#bfdc','10');pg.click('[data-a=bt_ps]');pg.wait_for_timeout(500)
    # volume product
    pg.click('[data-a=bt_pf][data-v="0"]');pg.fill('#bfn','روغن کنجد');pg.click('[data-a=bt_ty][data-v=vol]');pg.fill('#bfrp','300');pg.click('[data-a=bt_ps]');pg.wait_for_timeout(500)
    print('products',len(DB['prods']),[ (q['d']['name'],q['d']['type'],q['d']['unit']) for q in DB['prods']])
    shot('plist')
    # public
    pg.evaluate("btLoad()");pg.wait_for_timeout(500)
    pg.evaluate("go({v:null,tab:1,sub:0})");pg.wait_for_timeout(200)
    pg.click('[data-a=bt_sv][data-v=b]');pg.wait_for_timeout(300);print('explore tiles',pg.locator('.ext').count());shot('explore')
    pg.locator('.ext').first.click();pg.wait_for_timeout(300);print('prod view',pg.evaluate("S.v"),pg.locator('h2').first.inner_text())
    # wholesale ordering on millet
    pid=DB['prods'][0]['id']
    pg.evaluate(f"BO={{id:0,m:'r',q:1}};go({{v:'btp',id:{pid}}})");pg.wait_for_timeout(300)
    print('retail sum:',pg.inner_text('#btsum').replace('\n',' '))
    pg.click('[data-a=bt_m][data-v=w]');pg.wait_for_timeout(100);pg.fill('#btq','30');pg.wait_for_timeout(100)
    print('wholesale 30kg sum:',pg.inner_text('#btsum').replace('\n',' '));shot('prod_w')
    pg.fill('#btq','5');print('below min:',pg.inner_text('#btsum').replace('\n',' '))
    # back button chain
    pg.evaluate("ab()");print('after back v=',pg.evaluate("S.v"))
    # single booth
    pg.evaluate("go({v:'bts',id:1})");pg.wait_for_timeout(300);print('booth page cards',pg.locator('.bxc').count());shot('booth')
    # link open
    pg.evaluate("openLink('bprod:%d')"%pid);pg.wait_for_timeout(200);print('openLink bprod ->',pg.evaluate("S.v"))
    # width tests
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780})
        for v in ({'v':'booth'},{'v':'bts','id':1},{'v':'btp','id':pid},{'tab':1,'v':None},{'v':'btm'}):
            pg.evaluate("o=>go(o)",v);pg.wait_for_timeout(150)
            ov=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1||$('#scr').scrollWidth>$('#scr').clientWidth+1")
            if ov:print('OVERFLOW',w,v)
    print('ERRORS',errs)
    br.close()
