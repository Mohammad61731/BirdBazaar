# تست 1.9.359: P28 پوشه‌ی علاقه‌مندی (کلید xp)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("localStorage.removeItem('bp_px');XF.xp=0;S.pxf='';S.tab=0;render()");pg.wait_for_timeout(300)
        has=pg.evaluate("D.products.length>0")
        if not has:
            pg.evaluate("D.products.push({id:9901,name:'گلدان تست',price:1000,cat:'',img:'',out:0,imgs:[]})")
        pg.evaluate("S.fav=['p'+D.products[0].id]")
        k=pg.evaluate("'p'+D.products[0].id")
        chk(t+'off: no folder UI',pg.evaluate("!favs().includes('data-pxf')"))
        pg.evaluate("XF.xp=1;document.getElementById('scr').innerHTML=favs()");pg.wait_for_timeout(200)
        chk(t+'on: bar + mv button',pg.evaluate("!!document.querySelector('[data-pxf=new]')&&!!document.querySelector('[data-pxf=mv]')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'[data-pxf=new]')
        pg.evaluate("document.getElementById('pxfn').value='سفال'");clk(pg,'[data-pxf=mk]')
        chk(t+'folder made',pg.evaluate("JSON.stringify(pxGet().fd)==JSON.stringify([{n:'سفال',k:[]}])&&S.pxf=='سفال'"))
        chk(t+'filtered empty',pg.evaluate("favs().includes('این پوشه خالی است')"))
        pg.evaluate("document.getElementById('scr').innerHTML=favs()")
        pg.evaluate("S.pxf='';document.getElementById('scr').innerHTML=favs()")
        clk(pg,'[data-pxf=mv]')
        chk(t+'mv sheet lists folder',pg.evaluate("document.querySelectorAll('[data-pxf=put]').length==1"))
        clk(pg,'[data-pxf=put]')
        chk(t+'item put',pg.evaluate("pxGet().fd[0].k.length==1&&pxGet().fd[0].k[0]=='%s'"%k))
        chk(t+'filtered shows item',pg.evaluate("(S.pxf='سفال',!favs().includes('این پوشه خالی است')&&favs().includes('data-pxf=\"mv\"'))"))
        pg.evaluate("S.pxf='سفال';document.getElementById('scr').innerHTML=favs()");clk(pg,'[data-pxf=del]')
        chk(t+'folder deleted',pg.evaluate("pxGet().fd.length==0&&!S.pxf"))
        chk(t+'no overflow end',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("XF.xp=0")
        ctx.close()
    br.close()
print('ERRORS',errs)
