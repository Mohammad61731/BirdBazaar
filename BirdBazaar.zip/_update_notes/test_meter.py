# تست 1.9.62: شمارنده‌ی حجم دانلود در داشبورد ادمین
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            chk('%d off by default: nothing counted'%w, await pg.evaluate("Object.keys(NM.o).length")==0 and not await pg.evaluate("NM.on"))
            await pg.evaluate("S.me='adm';S.role='admin';S.pm=['all'];S.pnl=1;S.at='x';NM.on=1;NM.o={}")
            await pg.evaluate("pull()"); await pg.wait_for_timeout(800)
            ks=await pg.evaluate("Object.keys(NM.o)"); print(ks)
            chk('%d counted public & psig'%w, any('public' in k for k in ks) and any('psig' in k for k in ks))
            chk('%d bytes>0'%w, await pg.evaluate("Object.values(NM.o).every(x=>x.b>0)"))
            h=await pg.evaluate("nmCard()"); chk('%d card renders'%w, 'شمارنده' in h and 'KB' in h)
            await pg.evaluate("NM.on=0;NM.o={}"); await pg.evaluate("pull()"); await pg.wait_for_timeout(500)
            chk('%d off: nothing counted'%w, await pg.evaluate("Object.keys(NM.o).length")==0)
            await pg.evaluate("NM.on=1;render()"); await pg.wait_for_timeout(300)
            chk('%d no overflow'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk('%d no errors %s'%(w,errs), not errs)
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
