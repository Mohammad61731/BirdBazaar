# U3: صندوق پیام و اعلان (mapp mock)
from playwright.sync_api import sync_playwright
import json
errs=[];R={};calls=[]
NEW='file:///home/claude/bb_in/www/index.html'
DB={'in':[{'id':3,'f':'admin','g':'all','b':'اعلان آزمایشی برای همه','t':'2026-11-13T10:00:00Z','r':False},{'id':2,'f':'m','g':None,'b':'سلام کاربر عزیز','t':'2026-11-12T10:00:00Z','r':False},{'id':1,'f':'m','g':'booth','b':'پیام قدیمی','t':'2026-11-10T10:00:00Z','r':True}],'sent':[{'id':9,'to':'ali','g':None,'b':'ارسالی من','t':'2026-11-12T10:00:00Z'}],'adm':False,'main':False,'booth':False}
def handler(r,q):
    if q.url.startswith('file:'):return r.continue_()
    if q.url.endswith('/rpc/mapp'):
        d=json.loads(q.post_data);calls.append(d);o=d['op']
        if o=='mcount':return r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1,'n':sum(1 for x in DB['in'] if not x['r']),'adm':DB['adm'],'main':DB['main'],'booth':False}))
        if o=='minbox':return r.fulfill(status=200,content_type='application/json',body=json.dumps(dict(DB,ok=1)))
        return r.fulfill(status=200,content_type='application/json',body='{"ok":1}')
    return r.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def mk(br,w=390,cs='light'):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=cs,reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',handler);pg.goto(NEW);pg.wait_for_timeout(700);return pg
USR="S.role='user';S.me='ali';S.pw='1';S.pm=[];"
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=mk(br);pg.evaluate(USR+"render()");pg.evaluate("msPoll()");pg.wait_for_timeout(400)
    R['badge_dot']=pg.evaluate("window.MSN")==2 and pg.locator('#top [data-a=dr] i').count()==1
    pg.evaluate("drawer()");R['drawer_btn']='(2)' in pg.inner_text('[data-a=minb]')
    pg.click('[data-a=minb]');pg.wait_for_timeout(500)
    R['view']=pg.evaluate("S.v")=='inbox' and pg.locator('#scr .card').count()==3
    R['no_compose_user']=pg.locator('[data-a=ms_w]').count()==0
    pg.click('[data-a=ms_r][data-v="2"]');pg.wait_for_timeout(200)
    R['mark_read']=pg.evaluate("MS.n")==1 and any(c['op']=='mread' and c['a'].get('id')==2 for c in calls)
    pg.click('[data-a=ms_ra]');pg.wait_for_timeout(200)
    R['read_all']=pg.evaluate("MS.n")==0 and any(c['op']=='mread' and c['a'].get('all') for c in calls)
    pg.screenshot(path='shots/u3_inbox.png')
    R['back']=pg.evaluate("ab()")==1 and pg.evaluate("S.v")is None
    # ادمین
    DB['adm']=True;DB['main']=True
    pg=mk(br);pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];render()");pg.evaluate("msOpen()");pg.wait_for_timeout(500)
    R['admin_compose']=pg.locator('[data-a=ms_w]').count()==1
    pg.click('[data-a=ms_w]');R['opt_all']=pg.locator('#ms_to option[value="g:all"]').count()==1
    pg.fill('#ms_u','ali');pg.fill('#ms_b','تست');pg.click('[data-a=ms_s]');pg.wait_for_timeout(500)
    R['sent_call']=any(c['op']=='msend' and c['a'].get('to')=='ali' for c in calls)
    pg.evaluate("msWrite()");pg.select_option('#ms_to','g:booth');pg.fill('#ms_b','سلام غرفه‌دارها');pg.click('[data-a=ms_s]');pg.wait_for_timeout(400)
    R['grp_call']=any(c['op']=='msend' and c['a'].get('g')=='booth' for c in calls)
    pg.click('[data-a=ms_t][data-v=sent]');R['sent_tab']=pg.locator('[data-a=ms_d]').count()==1
    # غیر اصلی: گزینه‌ی «همه» نباشد
    DB['main']=False
    pg=mk(br);pg.evaluate("S.role='admin';S.me='sub';S.pw='1';S.pm=['p'];render()");pg.evaluate("msOpen()");pg.wait_for_timeout(500);pg.click('[data-a=ms_w]')
    R['no_all_for_sub']=pg.locator('#ms_to option[value="g:all"]').count()==0
    # عرض‌ها
    for w in (320,360,412):
        q=mk(br,w,'dark');q.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];render()");q.evaluate("msOpen()");q.wait_for_timeout(500)
        ok=q.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&(()=>{const s=document.querySelector('#scr');return s.scrollWidth<=s.clientWidth+1})()")
        q.click('[data-a=ms_w]');ok2=q.evaluate("(()=>{const e=document.querySelector('.sheet');return e.scrollWidth<=e.clientWidth+1})()")
        R[f'w{w}']=ok and ok2
    # مهمان
    pg=mk(br);pg.evaluate("S.me='';render();msOpen()");R['guest_no_crash']=True
    # سرور آماده نیست
    pg=mk(br);pg.evaluate(USR+"render()");pg.route('**/rpc/mapp',lambda r,q:r.fulfill(status=404,body='{}'));pg.evaluate("msOpen()");pg.wait_for_timeout(500)
    R['offline_msg']='ارتباط' in pg.inner_text('#scr') or 'فعال نیست' in pg.inner_text('#scr')
    br.close()
print({k:v for k,v in R.items() if not v});print('errors:',errs);print('ALL PASS' if all(R.values()) and not errs else 'FAIL')
