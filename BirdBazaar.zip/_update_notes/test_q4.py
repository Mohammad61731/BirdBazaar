import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(route,req):
    if req.url.startswith('file:'):return route.continue_()
    b=req.post_data or ''
    r={'err':'x'}
    if '"order_add"' in b:r={'ok':1,'id':55}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',h)
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.pm=[];S.me='ali';localStorage.removeItem('bp_ro');go({tab:3,v:null})");pg.wait_for_timeout(300)
    chk('1 سبد خالی و بدون سفارش قبلی: دکمه‌ی تکرار نیست',pg.locator('[data-a=roO]').count()==0)
    ids=pg.evaluate("D.products.map(p=>p.id)");a,b=ids[0],ids[1]
    pg.evaluate("D.cart=[{id:%d,w:0,v:0,q:2},{id:%d,w:0,v:0,q:1}];S.f={cn:'علی',cf:'رضایی',cp:'09120000000',ca:'سراوان'};D.cfg.guestOrder=1;go({tab:3,v:null})"%(a,b));pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('[data-a=co]')&&document.querySelector('[data-a=co]').click()");pg.wait_for_timeout(700)
    ro=pg.evaluate("JSON.parse(localStorage.getItem('bp_ro')||'[]')")
    chk('2 بعد از ثبت سفارش، نسخه‌ی محلی ذخیره شد',len(ro)==1 and ro[0]['id']==55 and len(ro[0]['it'])==2 and ro[0]['u']=='ali')
    chk('3 سبد بعد از سفارش خالی است',pg.evaluate("D.cart.length")==0)
    pg.evaluate("go({tab:3,v:null})");pg.wait_for_timeout(300)
    chk('4 سبد خالی: دکمه‌ی تکرار سفارش قبلی',pg.locator('[data-a=roO]').count()==1)
    pg.click('[data-a=roO]');pg.wait_for_timeout(300)
    chk('5 صفحه‌ی سفارش‌های قبلی با یک کارت',pg.locator('[data-a=ro_re]').count()==1 and '۱٬۰۵۵' in pg.inner_text('#scr'))
    pg.screenshot(path=P+'/shots/q4.png')
    pg.click('[data-a=ro_re]');pg.wait_for_timeout(500)
    cart=pg.evaluate("D.cart.map(c=>[c.id,c.q])")
    chk('6 همه‌ی اقلام به سبد برگشت و صفحه‌ی سبد باز شد',cart==[[a,2],[b,1]] and pg.evaluate("S.tab==3&&!S.v"))
    pg.click('[data-a=roO]') if pg.locator('[data-a=roO]').count() else pg.evaluate("go({v:'ro'})");pg.wait_for_timeout(300)
    pg.click('[data-a=ro_re]');pg.wait_for_timeout(400)
    chk('7 سفارش مجدد روی سبد پر جمع می‌شود',pg.evaluate("D.cart.map(c=>c.q)")==[4,2])
    # ناموجود
    pg.evaluate("D.cart=[];getP(%d).out=1;go({v:'ro'})"%b);pg.wait_for_timeout(300)
    pg.click('[data-a=ro_re]');pg.wait_for_timeout(400)
    chk('8 محصول ناموجود رد می‌شود',pg.evaluate("D.cart.map(c=>c.id)")==[a])
    # کاربر دیگر
    pg.evaluate("S.me='sara';go({v:'ro'})");pg.wait_for_timeout(300)
    chk('9 سفارش کاربر دیگر دیده نمی‌شود',pg.locator('[data-a=ro_re]').count()==0)
    pg.evaluate("S.me='ali';go({v:'ro'})")
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
