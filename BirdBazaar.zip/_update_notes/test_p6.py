import sys,json,time
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
now=time.time()
def iso(d):return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(now-d*86400))
ORD=[{'id':1,'name':'الف','phone':'0912','addr':'x','lines':[{'n':'ارزن','q':2,'u':'kg','pr':1,'t':100},{'n':'کتان','q':1,'u':'kg','pr':1,'t':50}],'total':150000,'s':'new','t':iso(1)},
{'id':2,'name':'ب','phone':'0913','addr':'x','lines':[{'n':'ارزن','q':1,'u':'kg','pr':1,'t':100}],'total':50000,'s':'done','t':iso(3)},
{'id':3,'name':'ج','phone':'0914','addr':'x','lines':[{'n':'ارزن','q':1,'u':'kg','pr':1,'t':100}],'total':999000,'s':'cancel','t':iso(2)},
{'id':4,'name':'د','phone':'0915','addr':'x','lines':[{'n':'قدیمی','q':1,'u':'kg','pr':1,'t':100}],'total':777000,'s':'done','t':iso(20)}]
MODE={'o':ORD}
def h(route,req):
    u=req.url
    if u.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op']
        if o in('blogin','bme'):r={'ok':1,'booth':{'id':1,'name':'غرفه','bio':'','logo':'','cover':'','city':'','phone':'','views':5,'status':'active'},'prods':[],'days':[]}
        elif o=='bords':r={'ok':1,'orders':MODE['o']} if MODE['o'] is not None else {'err':'x'}
        else:r={'ok':1,'booths':[],'prods':[]}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    if u.startswith('file:'):route.continue_();return
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("BT.u='ali';BT.p='1234';BM=null;BOR=null;S.btt='d';go({v:'btm'})");pg.wait_for_timeout(1200)
    t=pg.inner_text('#scr')
    chk('1 سفارش ۷ روز اخیر (۳ تا؛ قدیمی نه)','سفارش ۷ روز اخیر' in t and pg.evaluate("btSt().includes('<b>۳</b>')"))
    chk('2 سفارش جدید ۱',pg.evaluate("btSt().includes('<b>۱</b><span class=\"mu\">سفارش جدید')"))
    chk('3 جمع هفته بدون لغوشده (۲۰۰۰۰۰)',pg.evaluate("btSt().includes('۲۰۰٬۰۰۰')||btSt().includes('۲۰۰,۰۰۰')||btSt().includes('۲۰۰۰۰۰')"))
    chk('4 پرسفارش‌ترین: ارزن اول',pg.evaluate("btSt().indexOf('ارزن')<btSt().indexOf('کتان')&&btSt().includes('۲ سفارش')") and 'قدیمی' not in pg.evaluate("btSt()"))
    pg.screenshot(path=P+'/shots/p6.png')
    pg.evaluate("BOR=[];btRe()");pg.wait_for_timeout(200)
    chk('5 بدون سفارش: صفر و بدون بخش پرسفارش',pg.evaluate("!btSt().includes('پرسفارش')&&btSt().includes('<b>۰</b>')"))
    pg.evaluate("BOR=false;btRe()");pg.wait_for_timeout(200)
    chk('6 خطای سرور: بدون آمار و بدون خطا',pg.evaluate("btSt()===''"))
    pg.evaluate("BOR=null;S.btt='o';btRe()");pg.wait_for_timeout(800)
    chk('7 تب سفارش‌ها هنوز کار می‌کند',pg.locator('[data-a=bt_os]').count()>=1)
    for th in('light','dark'):
        for w in(320,360,412):
            pg.evaluate("document.documentElement.setAttribute('data-theme','%s');BOR=%s;S.btt='d';btRe()"%(th,json.dumps(ORD)));pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
