# تست 1.9.361: V3 قبل/بعد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.tab=0;render()");pg.wait_for_timeout(300)
        pg.evaluate("S.tab=0;render()");pg.wait_for_timeout(300)
        k=pg.evaluate("(()=>{const e=document.querySelector('.hg .hbk[data-b]');return e?e.closest('.hg').dataset.p+':'+e.dataset.b:''})()")
        chk(t+'found block',bool(k))
        pg.evaluate("(k)=>{window.__k=k;D.cms.ST=D.cms.ST||{};delete D.cms.ST[k];sheet(`<h3>t</h3><div class='xsb' data-xk='${k}'><input type='range' data-xs='o' min='20' max='100' value='100'></div>`)}",k);pg.wait_for_timeout(250)
        chk(t+'bf button',pg.evaluate("!!document.querySelector('[data-xl=bf]')"))
        pg.evaluate("stSet(window.__k,'o',50,0)");pg.wait_for_timeout(100)
        op=lambda:pg.evaluate("getComputedStyle(stEl(window.__k)).opacity")
        chk(t+'changed 0.5',op()=='0.5')
        pg.evaluate("document.querySelector('[data-xl=bf]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true}))")
        chk(t+'hold shows before',op()=='1')
        pg.evaluate("document.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}))")
        chk(t+'release restores',op()=='0.5')
        chk(t+'sheet still open',pg.evaluate("ov.classList.contains('on')"))
        pg.evaluate("document.querySelector('[data-xl=bf]').click()")
        chk(t+'click bf keeps sheet',pg.evaluate("ov.classList.contains('on')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'[data-xl=done]')
        chk(t+'closed clean',pg.evaluate("!ov.classList.contains('xlive')&&!document.querySelector('.xbf')"))
        pg.evaluate("delete D.cms.ST[window.__k]")
        ctx.close()
    br.close()
print('ERRORS',errs)
