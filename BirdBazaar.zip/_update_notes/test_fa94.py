# تست 1.9.94: حالت سریع مدیر + عیب‌یابی سرور
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/src'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; vg=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                d=json.loads(route.request.post_data or '{}'); op=d.get('op','')
                body=BODY
                if op=='vget': vg.append(1); body={'ok':1,'db':1}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("localStorage.removeItem('bp_tls');S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='tl';render()"); await pg.wait_for_timeout(300)
            chk(t+'APPV', await pg.evaluate("/^1\\.9\\.9\\d$/.test(APPV)"))
            chk(t+'off by default', await pg.evaluate("!faOn()"))
            chk(t+'tool card shown', '\u062d\u0627\u0644\u062a \u0633\u0631\u06cc\u0639 \u0645\u062f\u06cc\u0631' in await pg.evaluate("document.body.innerText"))
            await pg.evaluate("tlSet('fa',1);LV.act=Date.now()-900000"); await pg.wait_for_timeout(100)
            chk(t+'fast on: not idle after 15 min', await pg.evaluate("faOn()&&bgIdle(300000)===document.hidden"))
            chk(t+'fast on: poll gap 20s', await pg.evaluate("(()=>{PD.zz=0;const a=pollDue('zz');const c=pollDue('zz');PD.zz=Date.now()-16000;const d=pollDue('zz');return a&&!c&&d})()"))
            await pg.evaluate("S.pm=[]"); 
            chk(t+'not main admin: fast off', await pg.evaluate("!faOn()&&bgIdle(300000)"))
            await pg.evaluate("S.pm=['all'];S.at='set';S.sx='tl';render()"); await pg.wait_for_timeout(200)
            n=len(vg); await pg.click('[data-a=fa_diag]'); await pg.wait_for_timeout(800)
            txt=await pg.evaluate("document.body.innerText")
            chk(t+'diag: one vget, shows results', len(vg)-n==1 and '\u2705' in txt and '\u0646\u0634\u0633\u062a' in txt)
            await pg.evaluate("tlSet('fa',0);LV.act=Date.now()-900000")
            chk(t+'off again: idle limit back', await pg.evaluate("!faOn()&&bgIdle(300000)"))
            chk(t+'no overflow', await pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            chk(t+'no js errors', not errs)
            await ctx.close()
        await b.close()
    print('ALL OK' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
asyncio.run(main())
