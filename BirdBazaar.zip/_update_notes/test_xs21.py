# تست 1.9.351: S5 S10 لایه‌ها
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['all'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(400)
        ids=lambda:pg.evaluate("lay('home').map(b=>b.id)")
        chk(t+'btn',pg.locator('.edbar [data-a="lyr"]').count()==1)
        clk(pg,'.edbar [data-a="lyr"]');pg.wait_for_timeout(600)
        n=pg.locator('#lyl .lyr').count()
        chk(t+'rows',n==len(ids()) and n>3)
        a=ids();clk(pg,'#lyl .lyr:nth-child(2) [data-ly="dn"]');b=ids()
        chk(t+'down',b[1]==a[2] and b[2]==a[1])
        clk(pg,'#lyl .lyr:nth-child(3) [data-ly="up"]');chk(t+'up',ids()==a)
        pg.evaluate("document.querySelectorAll('.epg,#spl').forEach(x=>x.remove())");h=pg.locator('#lyl .lyr:nth-child(2) .lyh').bounding_box();h2=pg.locator('#lyl .lyr:nth-child(4)').bounding_box()
        pg.mouse.move(h['x']+8,h['y']+8);pg.mouse.down();pg.mouse.move(h['x']+8,h2['y']+h2['height']-3,steps=6);pg.mouse.up();pg.wait_for_timeout(300)
        c=ids();chk(t+'drag',c[3]==a[1] and c!=a)
        clk(pg,'#lyl .lyr:nth-child(1) [data-ly="ey"]');chk(t+'eye',pg.evaluate("!!lay('home')[0].hide"))
        clk(pg,'#lyl .lyr:nth-child(1) [data-ly="ey"]')
        clk(pg,'#lyl .lyr:nth-child(2) [data-ly="sel"]');pg.wait_for_timeout(300)
        chk(t+'select',pg.evaluate("document.querySelectorAll('.hbk.xsel').length==1&&!document.querySelector('#ov.on')"))
        pg.evaluate("document.querySelector('.hg .hbk:last-child').click()");pg.wait_for_timeout(200)
        chk(t+'tap sel',pg.evaluate("document.querySelectorAll('.hbk.xsel').length==1&&document.querySelector('.hbk.xsel')===document.querySelector('.hg .hbk:last-child')"))
        pg.evaluate("cl();S.ed=0;render()");pg.wait_for_timeout(200)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
