# تست 1.9.307: AN63 پیل لغزان نوار پایین در تم نهایی (غیر LG)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const n=document.getElementById('nav'),b=n.querySelector('button.on'),c=getComputedStyle(n,'::before'),d=b?getComputedStyle(b,'::after').display:'';return {lgx:parseFloat(n.style.getPropertyValue('--lgx')||'-1'),lgw:parseFloat(n.style.getPropertyValue('--lgw')||'0'),lgo:n.style.getPropertyValue('--lgo'),bw:b?b.offsetWidth:0,bl:b?b.offsetLeft:-1,cw:parseFloat(c.width),tp:c.transitionProperty,dot:d,ov:document.documentElement.scrollWidth<=innerWidth,tm:document.getElementById('app').dataset.tm,lg:document.getElementById('app').dataset.lg||''}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.set_default_timeout(8000)
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'m'}]));thApply();S.v=null;S.tab=0;render()");pg.wait_for_timeout(500)
                r=pg.evaluate(Q)
                chk(t+'minimal non-LG',r['tm']=='m' and r['lg']=='')
                chk(t+'pill vars set',r['lgo']=='1' and abs(r['lgw']-r['bw'])<1 and abs(r['lgx']-r['bl'])<1)
                chk(t+'pill drawn width',abs(r['cw']-r['bw'])<1.5)
                chk(t+'dot hidden',r['dot']=='none')
                if rm=='no-preference': chk(t+'pill transition','transform' in r['tp'])
                else: chk(t+'reduced no transition',r['tp'] in ('all','none','') or 'transform' not in r['tp'])
                x0=r['lgx']
                pg.evaluate("S.tab=1;render()");pg.wait_for_timeout(450)
                r2=pg.evaluate(Q)
                chk(t+'pill moved to new tab',abs(r2['lgx']-r2['bl'])<1 and abs(r2['lgx']-x0)>5)
                chk(t+'no overflow',r2['ov'])
                # صفحه‌ی داخلی (بدون تب فعال) ← پیل محو
                pg.evaluate("S.v='chat';render()") if False else None
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
