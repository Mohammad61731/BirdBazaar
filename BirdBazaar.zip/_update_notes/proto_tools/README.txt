سازنده‌ی پروتوتایپ HTML (اختیاری؛ فقط وقتی کاربر پروتوتایپ خواست)
- پروتوتایپ = یک صفحه‌ی HTML با دو تب: «مراحل» (اسکرین‌شات‌ها) و «اپ زنده» (iframe از برنامه با داده‌ی نمایشی بدون سرور).
- demo_app.html و پوشه‌ی shots/ برای کم کردن حجم حذف شدند؛ لازم شد دوباره بساز:
  ۱) demo_app.html = کپی www/index.html با افزودن <script>window.fetch=()=>Promise.reject(new Error('demo'))</script> درست بعد از <head>.
  ۲) اسکرین‌شات‌ها را با shoot_all.py / build_all_shots.py / shots_final.py (Playwright، موبایل ۳۶۰×۷۴۰) در shots/ بساز.
  ۳) build_proto_full.py یا build_proto_y.py را اجرا کن تا prototype_*.html ساخته شود.
- مسیرها داخل اسکریپت‌ها ثابت است (مثل /home/claude/...)؛ قبل از اجرا اصلاحشان کن.
- فایل خروجی را فقط به کاربر بده؛ داخل BirdBazaar.zip نگذار (حجم زیاد).
