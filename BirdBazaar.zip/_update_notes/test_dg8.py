# تست 1.9.508 DG8: صفحه‌ی غرفه
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:25,views:5,logo:'',city:'تهران',bio:'',phone:'0912'}];BT.prods=Array.from({length:25},(_,i)=>({id:100+i,b:1,s:'on',d:{name:'کالا '+i,type:'plain',price:1000+i,disc:i%5==0?10:0,out:i%7==0,emoji:'📦',cat:i%2?'الف':'ب'}}));BT.ok=1;BT.t=Date.now();S.role=null;S.bf='';S.bq='';S.bc='';go({v:'bts',id:1})");pg.wait_for_timeout(400)
        chk(t+'stats+tabs',pg.evaluate("!!document.querySelector('.bzshs')&&!!document.querySelector('.bzsht')&&!!document.getElementById('bzsp')"))
        chk(t+'paged 20',pg.evaluate("document.querySelectorAll('#bvl .bxc,#bvl .bll>*,#bvl .bxg1>*').length==20&&!!document.querySelector('[data-a=bz_mr]')"))
        pg.evaluate("document.querySelector('[data-a=bz_mr]').click()");pg.wait_for_timeout(200)
        chk(t+'more -> 25',pg.evaluate("document.querySelectorAll('#bvl .bxc,#bvl .bll>*,#bvl .bxg1>*').length==25&&!document.querySelector('[data-a=bz_mr]')"))
        pg.evaluate("document.querySelector('[data-a=bz_bf][data-v=d]').click()");pg.wait_for_timeout(200)
        chk(t+'discount filter',pg.evaluate("document.querySelectorAll('#bvl .bxc,#bvl .bll>*,#bvl .bxg1>*').length==5"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';window.scrollTo(0,0)")
            pg.screenshot(path='/tmp/claude-0/p/dg8_360.png')
        ctx.close()
    br.close()
print('ERRS',errs)
