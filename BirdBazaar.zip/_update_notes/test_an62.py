# تست 1.9.308: AN62 ظاهرشدن بخش‌های خانه هنگام اسکرول
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const s=document.getElementById('scr'),b=[...s.querySelectorAll('.hg>.hbk')];return {n:b.length,anr:b.filter(e=>e.classList.contains('anr')).length,hid:b.filter(e=>e.classList.contains('anr')&&!e.classList.contains('anv')&&getComputedStyle(e).opacity==='0').length,first:b[0]?b[0].classList.contains('anr'):false,ov:document.documentElement.scrollWidth<=innerWidth}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("S.v=null;S.tab=0;render()");pg.wait_for_timeout(300)
            r=pg.evaluate(Q)
            chk(t+'first block visible',not r['first'])
            if rm=='no-preference':
                if r['n']>3:
                    chk(t+'below-fold hidden',r['anr']>0 and r['hid']>0)
                    pg.evaluate("(async()=>{const s=document.getElementById('scr');for(let i=0;i<40;i++){s.scrollTop+=300;await new Promise(r=>setTimeout(r,60))}})()");pg.wait_for_timeout(2800);chk(t+'scr is scroller',pg.evaluate("document.getElementById('scr').scrollTop")>0)
                    r2=pg.evaluate(Q);chk(t+'revealed after scroll',r2['hid']==0)
            else: chk(t+'reduced: none hidden',r['anr']==0)
            chk(t+'no overflow',r['ov'])
            pg.evaluate("S.tab=1;render()");pg.wait_for_timeout(200)
            chk(t+'other tab untouched',pg.evaluate("document.querySelectorAll('#scr .hbk.anr').length")==0)
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
