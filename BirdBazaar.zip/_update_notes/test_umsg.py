# تست مورد ۷: دکمه‌ی ✉️ در لیست کاربران؛ نام کاربری پر می‌شود؛ بدون دسترسی دکمه نیست
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for scheme in ('light','dark'):
                pg=await b.new_page(viewport={'width':w,'height':700},color_scheme=scheme)
                errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
                h=await pg.evaluate("()=>{UL=[{u:'ali',vip:1},{u:'sara'}];MS.adm=0;const a=usersMgr();MS.adm=1;const b=usersMgr();return [a.includes('umsg'),b.includes('umsg')]}")
                await pg.evaluate("()=>{MS.adm=1;document.body.insertAdjacentHTML('beforeend','<div id=tt style=\"position:fixed;top:0;left:0;right:0;z-index:99998;background:var(--bg)\">'+usersMgr()+'</div>')}")
                await pg.click('#tt [data-a=umsg][data-v=sara]'); await pg.wait_for_timeout(200)
                v=await pg.evaluate("[$('#ms_u')&&$('#ms_u').value,$('#ms_to')&&$('#ms_to').value]")
                over=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
                good=h==[False,True] and v==['sara','u'] and not over and not errs
                ok&=good; print(w,scheme,'OK' if good else 'BAD',h,v,over,errs[:1])
                await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
