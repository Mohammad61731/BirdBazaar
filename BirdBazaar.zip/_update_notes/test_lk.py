# تست 1.9.106 قدم ۵: پیش‌دریافت خوش‌شانس
import asyncio, sys, json, re
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def run(b, net, on):
    ctx=await b.new_context(viewport={'width':360,'height':760}); pg=await ctx.new_page(); ops=[]; errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    async def h(r):
        u=r.request.url
        if not u.startswith('http'): return await r.continue_()
        if r.request.method=='OPTIONS': return await r.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
        pd=r.request.post_data or ''; m=re.search(r'"op":"(\w+)"',pd); op=m.group(1) if m else ''; ops.append(op)
        body={'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
        if op=='pimg': body={'ok':1,'img':'data:image/png;base64,AAAA','imgs':[]}
        await r.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
    await pg.route('**/*',h)
    await pg.add_init_script("Object.defineProperty(navigator,'connection',{get:()=>({type:'%s',effectiveType:'4g',saveData:false}),configurable:true})"%net)
    await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(800)
    await pg.evaluate("tlSet('lk',%d);D.products=[1,2,3].map(i=>({id:900+i,name:'x',price:1,cat:'x',imgs:[],lite:1,thk:'t'+i}));S.tab=1;S.v='';S.pnl=0;LV.act=0;LK.t=0;lkRun()"%on)
    await pg.wait_for_timeout(1200)
    n=ops.count('pimg'); await ctx.close(); return n,errs
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        n,e=await run(b,'wifi',1); chk('wifi+on → 1 pimg (%d)'%n, n==1 and not e)
        n,e=await run(b,'cellular',1); chk('cellular → 0 pimg (%d)'%n, n==0)
        n,e=await run(b,'wifi',0); chk('off → 0 pimg (%d)'%n, n==0)
        await b.close()
    print('ALL PASS' if ok else 'SOME FAIL')
asyncio.run(main())
