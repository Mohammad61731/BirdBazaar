# تست 1.9.415 G5-f: افزودن کالا با عکس دوربین (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnCamB()===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'btn shown',pg.evaluate("pnCamB().includes('data-a=\"pncam\"')"))
        pg.evaluate("BM={booth:{id:1},prods:[]};window._pk=null;window.pick=function(cb,el){window._pk=cb}")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pncam';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(250)
        chk(t+'pick called',pg.evaluate("typeof window._pk==='function'"))
        pg.evaluate("window._pk('data:image/png;base64,AAAA')");pg.wait_for_timeout(400)
        chk(t+'form opens with photo',pg.evaluate("S.v==='btf'&&T.imgs[0]==='data:image/png;base64,AAAA'&&!BF.id"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
