import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[];reqs=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:b=json.loads(q.post_data or '{}')
    except Exception:b={}
    reqs.append(b);r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1}))
MOCK="""window.__pn={L:{},calls:[]};window.Capacitor=window.Capacitor||{};Capacitor.Plugins=Capacitor.Plugins||{};
Capacitor.Plugins.PushNotifications={addListener:(e,f)=>{__pn.L[e]=f},requestPermissions:async()=>{__pn.calls.push('perm');return{receive:'granted'}},register:async()=>{__pn.calls.push('reg')}}"""
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=br.new_page(viewport={'width':360,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(700)
    pg.evaluate(MOCK)
    pg.evaluate("S.role='user';S.me='ali';S.pw='x';pushInit();pushInit()");pg.wait_for_timeout(300)
    chk('مجوز و ثبت فقط یک بار',pg.evaluate("__pn.calls.join()")=='perm,reg')
    pg.evaluate("__pn.L.registration({value:'T'.repeat(40)})");pg.wait_for_timeout(300)
    r=[x for x in reqs if x.get('op')=='ptoken']
    chk('ptoken با نام کاربر فرستاده شد',bool(r) and r[-1]['u']=='ali' and len(r[-1]['a']['t'])==40)
    pg.evaluate("pushOff();S.me=''");pg.wait_for_timeout(200)
    chk('ptoken_del هنگام خروج',any(x.get('op')=='ptoken_del' for x in reqs))
    pg.evaluate("S.me='sara';pushInit()");pg.wait_for_timeout(500)
    chk('کاربر دیگر دوباره ثبت می‌شود',pg.evaluate("__pn.calls.length")==4)
    pg.evaluate("S.me='';PUSH.u='';pushInit()")
    chk('بدون ورود کاری نمی‌کند',pg.evaluate("__pn.calls.length")==4)
    # بدون افزونه (مرورگر) خطا نمی‌دهد
    pg2=br.new_page();pg2.on('pageerror',lambda e:errs.append(str(e)));pg2.route('**/*',h);pg2.goto('file://'+P+'/www/index.html');pg2.wait_for_timeout(600)
    pg2.evaluate("S.me='ali';pushInit()")
    chk('بدون افزونه بی‌خطا',not errs)
    br.close()
sys.exit(0 if all(ok) else 1)
