# تست 1.9.268 P34 آواتار ، P51 کارت فروشنده ، P56 تماس یک‌لمس
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
DB['prods'].append({'id':2,'b':1,'d':{'name':'دان فنچ','type':'plain','price':50000,'emoji':'🌰','disc':20,'imgs':[]},'s':'on'});DB['nid']=2
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':760},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("S.tab=0;S.v=null;render();try{btFresh()}catch(e){}");pg.wait_for_timeout(1500)
            pg.evaluate("btNav({v:'bts',id:BT.booths[0].id})");pg.wait_for_timeout(900)
            chk(f'{w}/{dark}: booth actions',pg.locator('.bact .btn').count()>=2 and pg.locator('.bact a[href^=tel]').count()==1 and pg.locator('[data-a=ct_bm]').count()==1)
            chk(f'{w}/{dark}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            chk(f'{w}/{dark}: avatar 76',pg.evaluate("Math.round(document.querySelector('.bhd .bl').getBoundingClientRect().width)")==76)
            if w==360 and not dark: pg.screenshot(path='/tmp/p34.png')
            pg.evaluate("btNav({v:'btp',id:BT.prods[0].id})");pg.wait_for_timeout(700)
            chk(f'{w}/{dark}: seller card',pg.locator('.slr .sla .btn').count()==2 and pg.locator('.slr a[href^=tel]').count()==1)
            chk(f'{w}/{dark}: p no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360 and not dark: pg.screenshot(path='/tmp/p51.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
