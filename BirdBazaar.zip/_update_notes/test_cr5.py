# تست 1.9.378 C5e: امتیاز به پیک ، پیک مورد علاقه ، ⭐ در فهرست پیک
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
def hy(route,req):
    b=json.loads(req.post_data or '{}');o=b['op']
    r={'err':'op'}
    if o=='yme':r={'ok':1,'me':{'name':'رضا','veh':'m','area':'','st':'ok','act':True,'cap':3,'rt':4.5,'rn':6}}
    elif o=='yjobs':r={'ok':1,'av':[{'id':1,'bn':'عادی','city':'','n':1,'t':1000,'f':0,'fv':False},{'id':2,'bn':'آشنا','city':'','n':1,'t':1000,'f':0,'fv':True}],'my':[]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
def hb(route,req):
    b=json.loads(req.post_data or '{}')
    if b.get('op') in('cr_rate','cr_fav'):
        CALLS.append((b['op'],b['a']));route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
    else:handle(route,req)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb);pg.route('**/rpc/yapp',hy)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900);CALLS.clear()
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1")
        h=pg.evaluate("crOwnH({id:5,s:'done',cr:{s:'done',c:'9',cn:'علی'}})")
        chk(t+'owner done: name, stars, fav btn','علی' in h and h.count('bt_crrt')==5 and 'bt_crf' in h)
        h2=pg.evaluate("crOwnH({id:5,s:'done',cr:{s:'done',c:'9',cn:'علی',rt:4,fv:true}})")
        chk(t+'rated+fav: no buttons','bt_crrt' not in h2 and 'bt_crf' not in h2 and 'مورد علاقه' in h2)
        pg.evaluate("BOR=[{id:5,name:'م',phone:'1',s:'done',t:new Date().toISOString(),lines:[],total:1,cr:{s:'done',c:'9',cn:'علی'}}];BM={booth:{id:1}};btAct('bt_crrt','5:4')");pg.wait_for_timeout(300)
        pg.evaluate("btAct('bt_crf','9')");pg.wait_for_timeout(300)
        chk(t+'ops sent',CALLS==[('cr_rate',{'id':5,'n':'4'}),('cr_fav',{'c':'9'})])
        pg.evaluate("localStorage.setItem('bp_cru','{\"u\":\"0912\",\"p\":\"1234\"}');CRM.r=null;CRM.j=null;crSheet()");pg.wait_for_timeout(700)
        txt=pg.evaluate("document.querySelector('.sheet').innerText")
        chk(t+'courier rating shown','۴٫۵' in txt or '4.5' in txt or '۴.۵' in txt or 'نظر' in txt)
        chk(t+'fav job first with star',pg.evaluate("(()=>{const b=[...document.querySelectorAll('.sheet .card b')].map(x=>x.innerText);return b.findIndex(x=>x.includes('⭐'))==b.findIndex(x=>x.includes('آشنا'))&&b.findIndex(x=>x.includes('آشنا'))<b.findIndex(x=>x.includes('عادی'))})()"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
