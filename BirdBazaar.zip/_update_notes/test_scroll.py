import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_page(viewport={'width':w,'height':760},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800);pg.add_style_tag(content="#scr::after{content:'';display:block;height:2500px}")
        for tab in (0,1,2):
            pg.evaluate("go({tab:%d,v:null})"%tab);pg.wait_for_timeout(200)
            pg.evaluate("document.querySelector('#scr').scrollTop=700");y0=pg.evaluate("document.querySelector('#scr').scrollTop")
            pg.evaluate("pull()");pg.wait_for_timeout(300)
            y1=pg.evaluate("document.querySelector('#scr').scrollTop")
            chk('w%d tab%d بعد از pull جای اسکرول می‌ماند (%d→%d)'%(w,tab,y0,y1),y0<=100 or y1>=y0*0.5)
        pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200)
        pg.evaluate("document.querySelector('#scr').scrollTop=700;ov.classList.add('on')")
        pg.evaluate("pull()");pg.wait_for_timeout(300)
        chk('w%d با برگه‌ی باز render نمی‌شود'%w,pg.evaluate("document.querySelector('#scr').scrollTop")>300)
        pg.close()
    br.close()
chk('بدون خطای صفحه',not errs)
print('ALL PASS' if all(ok) else 'SOME FAIL',errs[:2])
