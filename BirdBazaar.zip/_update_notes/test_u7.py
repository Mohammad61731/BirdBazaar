from playwright.sync_api import sync_playwright
errs=[]
def lum(c):
    import re;r,g,b=[int(x) for x in re.findall(r'\d+',c)[:3]];f=lambda v:((v/255)/12.92 if v/255<=.03928 else (((v/255)+.055)/1.055)**2.4);return .2126*f(r)+.7152*f(g)+.0722*f(b)
def cr(a,b):
    la,lb=sorted([lum(a),lum(b)],reverse=True);return (la+.05)/(lb+.05)
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR',color_scheme='light').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(900)
    g=lambda sel,pr:pg.evaluate(f"getComputedStyle(document.querySelector('{sel}')).{pr}")
    print('body bg:',g('body','backgroundColor'),'| top:',g('#top','backgroundColor'),'| nav:',g('nav','backgroundColor'))
    for t in ('home','store','market','acct','forum'):
        pass
    for n,name in ((0,'home'),(1,'store'),(2,'market'),(4,'acct')):
        pg.evaluate(f"go({{tab:{n},v:null}})");pg.wait_for_timeout(500);pg.screenshot(path=f'../shots/u7_{name}.png')
    print('card bg:',pg.evaluate("(()=>{const e=document.querySelector('.card,.box,.pc');return e?getComputedStyle(e).backgroundColor:null})()"))
    print('contrast ink/bg %.1f ink/card %.1f mu/card %.1f'%(cr('rgb(28,43,37)','rgb(232,235,233)'),cr('rgb(28,43,37)','rgb(246,247,244)'),cr('rgb(102,118,111)','rgb(246,247,244)')))
    pg.evaluate("S.role='user';S.me='a';go({tab:4,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='../shots/u7_profile.png')
    print('input bg:',pg.evaluate("(()=>{const e=document.querySelector('input');return e?getComputedStyle(e).backgroundColor:null})()"))
    pg.evaluate("document.documentElement.setAttribute('data-theme','dark')");pg.wait_for_timeout(300);pg.screenshot(path='../shots/u7_dark.png')
    print('dark top:',g('#top','backgroundColor'),'dark body:',g('body','backgroundColor'))
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(200);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
