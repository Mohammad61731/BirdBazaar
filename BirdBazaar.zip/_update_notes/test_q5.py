import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("const b=D.products[0];window.mk=(id,name,cat,out)=>Object.assign({},b,{id,name,cat,out:out||0});D.products=[mk(1,'الف','x'),mk(2,'ب','x'),mk(3,'ج','y',1),mk(4,'د','y')];go({v:'prod',id:1})");pg.wait_for_timeout(500)
    names=pg.evaluate("[...document.querySelectorAll('.hs.rel .pc h4')].map(e=>e.textContent)")
    print(names)
    chk('مرتبط: همان دسته اول، خودش و ناموجود نه',names==['ب','د'])
    pg.evaluate("go({v:'prod',id:4})");pg.wait_for_timeout(300)
    chk('برای محصول دیگر هم',pg.evaluate("[...document.querySelectorAll('.hs.rel .pc h4')].map(e=>e.textContent)")==['الف','ب'])
    pg.locator('.hs.rel .pc h4').first.click();pg.wait_for_timeout(400)
    chk('کلیک → صفحه‌ی محصول دیگر',pg.evaluate("S.id")==1)
    pg.evaluate("D.products=D.products.slice(0,1);go({v:'prod',id:1})");pg.wait_for_timeout(300)
    chk('بدون محصول دیگر → بخش نیست',pg.locator('.rel').count()==0)
    pg.evaluate("D.products=[mk(1,'الف','x'),mk(2,'ب','x')];go({v:'prod',id:1})");pg.wait_for_timeout(300)
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
