# تست 1.9.436 D2-c2: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=0;localStorage.removeItem('bp_cdo');localStorage.removeItem('bp_rsv')")
        pg.evaluate("dtCdAdd({bid:1,bn:'غ',p:'0912',t:Date.now()})")
        chk(t+'off -> not recorded, no card',pg.evaluate("dtCdL().length==0&&dtCdH()===''"))
        pg.evaluate("XF.dt=1")
        pg.evaluate("dtCdAdd({bid:1,bn:'غ',p:'0912',t:Date.now(),rv:{c:'1'}})")
        chk(t+'reservation not recorded as delivery',pg.evaluate("dtCdL().length==0"))
        pg.evaluate("dtCdAdd({bid:1,bn:'غ',p:'0912',t:Date.now()})")
        chk(t+'on -> card + button',pg.evaluate("dtCdL().length==1&&dtCdH().includes('dtch')&&dtCdH().includes('خودم میام می‌برم')"))
        pg.evaluate("bzAsk=(m,d,cb)=>cb('نه');0")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtch';b.dataset.v='0';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(500)
        chk(t+'no confirm -> no server call',len(calls)==0)
        RES[0]='{"err":"late"}'
        pg.evaluate("bzAsk=(m,d,cb)=>cb('بله');0")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtch';b.dataset.v='0';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'late -> stays, no reservation',len(calls)==1 and pg.evaluate("dtCdL().length==1&&cpRsv().length==0"))
        RES[0]='{"ok":1}'
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtch';b.dataset.v='0';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'ok -> server op cv_h with code',len(calls)==2 and '"cv_h"' in calls[1] and '"c":"' in calls[1])
        chk(t+'ok -> moved to reservation',pg.evaluate("dtCdL().length==0&&cpRsv().length==1&&cpRsv()[0].s=='n'&&/^\\d{4}$/.test(cpRsv()[0].c)"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
