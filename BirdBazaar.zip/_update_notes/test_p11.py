import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR',accept_downloads=True);pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='adm';go({tab:4,v:null,pnl:1,at:'set'})");pg.wait_for_timeout(500)
    chk('دکمه‌ها برای ادمین اصلی',pg.locator('[data-a=bkup]').count()==1 and pg.locator('[data-a=bkrs]').count()==1)
    pg.evaluate("navigator.canShare=undefined")
    with pg.expect_download() as d:pg.click('[data-a=bkup]')
    path=d.value.path();j=json.load(open(path,encoding='utf-8'))
    chk('فایل پشتیبان معتبر است',j['app']=='birdbazaar' and len(j['data']['products'])>=1 and d.value.suggested_filename.endswith('.json'))
    n=pg.evaluate("D.products.length")
    pg.evaluate("D.products=D.products.slice(0,1);save()")
    with pg.expect_file_chooser() as fc:pg.click('[data-a=bkrs]')
    fc.value.set_files(path);pg.wait_for_timeout(600)
    chk('بازگردانی محصولات',pg.evaluate("D.products.length")==n)
    bad='/tmp/bad.json';open(bad,'w').write('{"x":1}')
    with pg.expect_file_chooser() as fc:pg.click('[data-a=bkrs]')
    fc.value.set_files(bad);pg.wait_for_timeout(400)
    chk('فایل نامعتبر رد شد و اطلاعات سالم ماند',pg.evaluate("D.products.length")==n)
    pg.evaluate("S.pm=['p'];render()");pg.wait_for_timeout(300)
    chk('مدیر غیراصلی دکمه ندارد',pg.locator('[data-a=bkup]').count()==0)
    pg.evaluate("S.pm=['all'];render()")
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
