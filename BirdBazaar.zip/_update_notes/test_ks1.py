# تست 1.9.472: «پول خرد دارم / ندارم» (کلید ks)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("XF.cg=1;XF.ks=0;XF.hz=0")
        chk(f'{w}: off -> nothing',pg.evaluate("ksBtn({})===''&&ksT({kh:1})===''&&dtWhen({kh:1})===''"))
        pg.evaluate("XF.ks=1")
        chk(f'{w}: 3 buttons',pg.evaluate("(ksBtn({}).match(/data-cg=\"ks\"/g)||[]).length===3"))
        chk(f'{w}: kh1 text',pg.evaluate("ksT({kh:1}).includes('دارد')&&!ksT({kh:1}).includes('ندارد')"))
        chk(f'{w}: kh2 text',pg.evaluate("ksT({kh:2}).includes('ندارد')"))
        chk(f'{w}: none -> empty',pg.evaluate("ksT({})===''"))
        chk(f'{w}: hours keep + ks',pg.evaluate("(()=>{const t=dtWhen({o:'08:00',c:'20:00',kh:2});return t.includes('🕘')&&t.includes('ندارد')})()"))
        chk(f'{w}: only ks no hours',pg.evaluate("dtWhen({kh:1}).includes('پول خرد')"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+ksBtn({kh:1})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: selected chip on',pg.locator('#scr .chip.on').count()==1)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    br.close()
print('ERRORS',errs)
