# تست 1.9.99: بعد از نصب تازه، صفحه‌ی نمونه نشان داده/ذخیره نمی‌شود؛ شکست ← تلاش دوباره؛ کلید خاموش ← رفتار قبلی
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
SEED='کلسیم پرندگان'; REAL='محصول آزمون'
COV="""const cov=()=>{const sp=document.getElementById('spl');if(!sp)return false;let ok=true;for(const x of [.1,.5,.9])for(const y of [.1,.3,.5,.7,.9]){const e=document.elementFromPoint(innerWidth*x,innerHeight*y);if(!e||!sp.contains(e))ok=false}return ok};"""
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            async def mk(delay=0,fail=False,off_key=False):
                ctx=await b.new_context(viewport={'width':w,'height':700}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                st={'fail':fail,'delay':delay}
                async def h(route):
                    u=route.request.url
                    if u.startswith('http'):
                        if st['fail']: return await route.abort()
                        if st['delay']: await asyncio.sleep(st['delay'])
                        body={'ok':1,'products':[{'id':9,'name':REAL,'cat':'x','price':1000,'imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[]}
                        try: return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
                        except Exception: return
                    return await route.continue_()
                await pg.route('**/*',h)
                if off_key: await pg.add_init_script("try{localStorage.getItem('bp4')||localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                await pg.goto('file://%s/www/index.html'%ROOT)
                return ctx,pg,st,errs
            # A) سرور کند (7 ثانیه): تا آن موقع فقط بارگذاری، نه نمونه
            ctx,pg,st,errs=await mk(delay=7)
            await pg.wait_for_timeout(5800)
            r=await pg.evaluate("(()=>{%s return {spl:!!document.getElementById('spl'),cov:cov(),bp4:!!localStorage.getItem('bp4')}})()"%COV)
            chk('%d slow: splash covers screen, nothing saved'%w, r['spl'] and r['cov'] and not r['bp4'])
            await pg.wait_for_timeout(3500)
            r=await pg.evaluate("({spl:!!document.getElementById('spl'),real:document.body.innerText.includes('%s'),seed:document.body.innerText.includes('%s'),bp4:(localStorage.getItem('bp4')||'').includes('%s'),ov:document.documentElement.scrollWidth>innerWidth})"%(REAL,SEED,REAL))
            chk('%d slow: real data shown'%w, (not r['spl']) and r['real'] and not r['seed'] and r['bp4'] and not r['ov'])
            if w==360: await pg.screenshot(path='%s/_update_notes/shots/fw_ok_360.png'%ROOT)
            chk('%d slow: no errors %s'%(w,errs), not errs); await ctx.close()
            # B) سرور قطع: پیام و تلاش دوباره؛ نمونه ذخیره نمی‌شود
            ctx,pg,st,errs=await mk(fail=True)
            await pg.wait_for_timeout(2500)
            r=await pg.evaluate("(()=>{%s return {btn:!!document.getElementById('fwr'),cov:cov(),bp4:!!localStorage.getItem('bp4')}})()"%COV)
            chk('%d fail: retry screen covers screen, not saved'%w, r['btn'] and r['cov'] and not r['bp4'])
            if w==360: await pg.screenshot(path='%s/_update_notes/shots/fw_fail_360.png'%ROOT)
            st['fail']=False; await pg.click('#fwr'); await pg.wait_for_timeout(2500)
            r=await pg.evaluate("({spl:!!document.getElementById('spl'),real:document.body.innerText.includes('%s'),bp4:(localStorage.getItem('bp4')||'').includes('%s')})"%(REAL,REAL))
            chk('%d fail->retry works'%w, (not r['spl']) and r['real'] and r['bp4']); await ctx.close()
            # C) کلید خاموش: رفتار قبلی (بعد از 4.5s نمونه)
            if w==360:
                ctx,pg,st,errs=await mk(delay=7,off_key=True)
                await pg.wait_for_timeout(5800)
                r=await pg.evaluate("({spl:!!document.getElementById('spl'),seed:document.body.innerText.includes('%s')})"%SEED)
                chk('key off: old behaviour (seed after 4.5s)', (not r['spl']) and r['seed']); await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
