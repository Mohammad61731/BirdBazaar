# تست 1.9.341: استودیو S37 قالب کارت هر بخش (ST.ct ؛ کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\\\"fw\\\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        b=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.grid .pc,.grid .bxc'));return b?b.dataset.b:null})()")
        chk(t+'grid block',bool(b))
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        chk(t+'chips',all(pg.locator('#ov [data-xc$=":ct:%d"]'%k).count()==1 for k in range(7)))
        Q="(i)=>{const e=document.querySelector('.hg .hbk[data-b=\\\"'+i+'\\\"]'),c=e.querySelector('.pc,.bxc'),im=c.querySelector('.pi,.bxi'),pb=c.querySelector('.pb,.bxt');return [e.style.getPropertyValue('--xct'),getComputedStyle(c).flexDirection,getComputedStyle(im).display,pb?getComputedStyle(pb).display:'none',document.documentElement.scrollWidth<=innerWidth]}"
        clk(pg,'#ov [data-xc$=":ct:1"]');r=pg.evaluate(Q,b)
        chk(t+'horizontal',r[0]=='1' and r[1]=='row' and r[4])
        if w==360 and not dark: pg.screenshot(path='/tmp/xs14.png')
        clk(pg,'#ov [data-xc$=":ct:2"]');r=pg.evaluate(Q,b)
        chk(t+'vertical',r[0]=='2' and r[1]=='column')
        clk(pg,'#ov [data-xc$=":ct:5"]');r=pg.evaluate(Q,b)
        chk(t+'image only',r[0]=='5' and r[3]=='none' and r[2]!='none' and r[4])
        clk(pg,'#ov [data-xc$=":ct:6"]');r=pg.evaluate(Q,b)
        chk(t+'text only',r[0]=='6' and r[2]=='none' and r[4])
        clk(pg,'#ov [data-xc$=":ct:3"]');clk(pg,'#ov [data-xc$=":ct:4"]');r=pg.evaluate(Q,b)
        chk(t+'small no overflow',r[0]=='4' and r[4])
        clk(pg,'#ov [data-xc$=":ct:0"]')
        chk(t+'default clears',pg.evaluate(Q,b)[0]=='')
        pg.evaluate("(i)=>{stSet('home:'+i,'ct',2,1);cl();render()}",b);pg.wait_for_timeout(250)
        chk(t+'persists after render',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\\\"'+i+'\\\"]').getAttribute('style').indexOf('--xct:2')>-1",b))
        ctx.close()
    br.close()
print('ERRORS',errs)
