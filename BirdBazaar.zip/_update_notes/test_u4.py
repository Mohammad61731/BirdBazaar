import json
from playwright.sync_api import sync_playwright
errs=[];calls=[]
def h(route,req):
    u=req.url
    if u.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);calls.append(b)
        r={'ok':1,'reqs':[],'booths':[]} if b['op'].startswith('badm_') else {'ok':1,'booths':[],'prods':[]}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    if u.endswith('/rpc/app'):
        b=json.loads(req.post_data)
        if b.get('op')=='users':return route.fulfill(status=200,content_type='application/json',body=json.dumps([{'u':'ali','vip':0},{'u':'sara','vip':1}]))
        if b.get('op')=='staff_list':return route.fulfill(status=200,content_type='application/json',body=json.dumps([{'u':'boss','pm':['all']},{'u':'sara','pm':['p','o']}]))
    return route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else h(r,q))
        pg.goto('file:///home/claude/p/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='boss';S.pw='pw1';D.staff=[{u:'boss',pm:['all']},{u:'sara',pm:['p','o']}];UL=[{u:'ali',vip:0},{u:'sara',vip:1}];go({tab:4,pnl:1,at:'u',v:null})");pg.wait_for_timeout(900)
        r={'btns':pg.locator('[data-a=uadm]').count()==2}
        # ali: new admin, none ticked by default
        pg.locator('[data-a=uadm][data-v=ali]').click();pg.wait_for_timeout(300)
        r['default_none']=pg.locator('.pmx:checked').count()==0 and pg.locator('[data-a=uadmd]').count()==0
        pg.locator('.pmx[value=p]').check();pg.locator('.pmx[value=nt]').check()
        pg.click('[data-a=uadms]');pg.wait_for_timeout(500)
        c=[x for x in calls if x['op']=='badm_mkadm'][-1]
        r['mk_sent']=c['a']['u']=='ali' and sorted(c['a']['pm'])==['nt','p'] and c['u']=='boss'
        # sara: already admin, prefilled + remove button
        pg.locator('[data-a=uadm][data-v=sara]').click();pg.wait_for_timeout(300)
        r['prefilled']=pg.locator('.pmx:checked').count()==2 and pg.locator('[data-a=uadmd]').count()==1
        pg.click('[data-a=uadmd]');pg.wait_for_timeout(500)
        r['rm_sent']=any(x['op']=='badm_rmadm' and x['a']['u']=='sara' for x in calls)
        r['overflow']=pg.evaluate("document.documentElement.scrollWidth>innerWidth+1")
        # main admin can't be edited; non-main sees no button
        pg.evaluate("S.pm=['u']");pg.evaluate("render()");pg.wait_for_timeout(300)
        r['limited_no_btn']=pg.locator('[data-a=uadm]').count()==0
        print(w,r)
    print('ERRORS',errs);br.close()
