# تست 1.9.332: استودیو T2 چشم/قفل/نام/شبح/فقط‌همین/فاصله‌ی بیرون هر بخش (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
            ids=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(b=>b.dataset.b)")
            chk(t+'has blocks',len(ids)>=3)
            b0=ids[0];b1=ids[1]
            chk(t+'eye+lock icons',pg.locator('.hg .hbk .hh b[data-ey]').count()>=3 and pg.locator('.hg .hbk .hh b[data-lk]').count()>=3)
            # sheet controls
            pg.evaluate("(i)=>bsheet(i,'home')",b1);pg.wait_for_timeout(200)
            chk(t+'sheet inputs',pg.locator('#ov input[data-xs="mt"]').count()==1 and pg.locator('#ov input[data-xn]').count()==1 and pg.locator('#ov [data-xg]').count()>=5)
            fire(pg,'#ov [data-xs="mt"]',12);fire(pg,'#ov [data-xs="mb"]',20)
            fire(pg,'#ov [data-xn]','نام تستی من')
            pg.wait_for_timeout(300)
            chk(t+'margins saved',pg.evaluate("(i)=>{const s=D.cms.ST['home:'+i];return s&&s.mt==12&&s.mb==20}",b1))
            chk(t+'margin applied',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return e&&e.style.marginTop=='12px'&&e.style.marginBottom=='20px'}",b1))
            chk(t+'rename saved+shown',pg.evaluate("(i)=>D.cms.ST['home:'+i].nm=='نام تستی من'&&lnm('home',i)=='نام تستی من'&&document.querySelector('#ov h3').textContent.includes('نام تستی من')&&!!document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .xnm')",b1))
            # lock via handle: no drag/move controls
            pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh b[data-lk]').click()",b0);pg.wait_for_timeout(300)
            chk(t+'locked hides move',pg.evaluate("(i)=>{const h=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh');return D.cms.ST['home:'+i].lk==1&&!h.querySelector('[data-mv]')&&!h.querySelector('[data-hd]')&&h.querySelector('[data-lk]').textContent=='🔒'}",b0))
            pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh b[data-lk]').click()",b0);pg.wait_for_timeout(300)
            chk(t+'unlock restores move',pg.evaluate("(i)=>{const h=document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh');return !D.cms.ST['home:'+i].lk&&!!h.querySelector('[data-mv]')}",b0))
            # eye
            pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh b[data-ey]').click()",b0);pg.wait_for_timeout(300)
            chk(t+'eye hides',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return !!e&&e.classList.contains('hid')&&e.querySelector('[data-ey]').textContent=='🙈'}",b0))
            pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .hh b[data-ey]').click()",b0);pg.wait_for_timeout(300)
            chk(t+'eye shows',pg.evaluate("(i)=>!document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').classList.contains('hid')",b0))
            # ghost / solo
            pg.evaluate("(i)=>bsheet(i,'home')",b1);pg.wait_for_timeout(200)
            pg.evaluate("document.querySelector('#ov [data-xg^=\"gh:\"]').click()");pg.wait_for_timeout(200)
            chk(t+'ghost on',pg.evaluate("(i)=>document.querySelector('.hg').classList.contains('xgh')&&document.querySelectorAll('.hg .hbk.xgs').length==1&&document.querySelector('.hg .hbk.xgs').dataset.b==i",b1))
            chk(t+'ghost dims others',pg.evaluate("(()=>{const o=[...document.querySelectorAll('.hg .hbk:not(.xgs)')][0];return !o||getComputedStyle(o).opacity<0.5})()"))
            pg.evaluate("document.querySelector('#ov [data-xg^=\"so:\"]').click()");pg.wait_for_timeout(200)
            chk(t+'solo hides others',pg.evaluate("(()=>{const g=document.querySelector('.hg');if(!g.classList.contains('xso')||g.classList.contains('xgh'))return false;const o=[...document.querySelectorAll('.hg .hbk:not(.xgs)')][0];return !o||getComputedStyle(o).display=='none'})()"))
            pg.evaluate("document.querySelector('#ov [data-xg^=\"so:\"]').click()");pg.wait_for_timeout(200)
            chk(t+'solo off',pg.evaluate("!document.querySelector('.hg').classList.contains('xso')&&document.querySelectorAll('.hg .hbk.xgs').length==0"))
            # reset one
            pg.evaluate("(i)=>{stDel('home:'+i);cl();render()}",b1);pg.wait_for_timeout(300)
            chk(t+'reset clears',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return !D.cms.ST['home:'+i]&&e.style.marginTop==''&&!e.querySelector('.xnm')}",b1))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            if w==360 and not dark:
                pg.evaluate("(i)=>bsheet(i,'home')",b1);pg.wait_for_timeout(200)
                pg.evaluate("document.querySelector('#ov .sheet').scrollTop=240");pg.wait_for_timeout(200)
                pg.screenshot(path='/tmp/xs5_sheet.png')
                pg.evaluate("document.querySelector('[data-a=clo2]').click()");pg.wait_for_timeout(200)
                pg.screenshot(path='/tmp/xs5_edit.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
