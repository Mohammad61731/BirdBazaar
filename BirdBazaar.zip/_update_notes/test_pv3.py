# تست 1.9.265 P84: درخواست غرفه سه‌قدمی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':760},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("S.me='کاربر تست';S.role='user';window.__k=[];const o=window.kop;S.tab=1;S.v=null;render();btNav({v:'btq'})");pg.wait_for_timeout(400)
            chk(f'{w}/{dark}: step1 fields',pg.locator('.bqs i').count()==3 and pg.locator('#bqn').count()==1 and pg.locator('#bqs').count()==0)
            pg.locator('[data-a=bt_qn]').click();pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: blocked without name/phone',pg.evaluate("BQW.st")==1)
            pg.fill('#bqn','علی رضایی');pg.fill('#bqp','09121234567');pg.fill('#bqc','سراوان')
            pg.locator('[data-a=bt_qn]').click();pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: step2',pg.evaluate("BQW.st")==2 and pg.locator('#bqs').count()==1)
            pg.fill('#bqs','غرفه من');pg.fill('#bqa','ارزن و کتان')
            pg.locator('[data-a=bt_qb]').click();pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: back keeps values',pg.input_value('#bqn')=='علی رضایی' and pg.input_value('#bqc')=='سراوان')
            pg.locator('[data-a=bt_qn]').click();pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: step2 keeps values',pg.input_value('#bqs')=='غرفه من')
            pg.locator('[data-a=bt_qn]').click();pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: review',pg.evaluate("BQW.st")==3 and 'غرفه من' in pg.locator('.bqr').inner_text() and '09121234567' in pg.locator('.bqr').inner_text())
            chk(f'{w}/{dark}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360: pg.screenshot(path=f'/tmp/bq_{w}_{dark}.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
