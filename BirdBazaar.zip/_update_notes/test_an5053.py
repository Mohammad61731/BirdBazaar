# تست 1.9.304: AN50 تیک ذخیره‌ی موفق (toast) ، AN53 نبض نشانگر تازگی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.set_default_timeout(8000)
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                pg.evaluate("const b=document.createElement('button');b.id='tsv';b.className='btn';b.textContent='ذخیره';document.getElementById('scr').appendChild(b);0")
                # AN50: toast ذخیره شد بعد از کلیک
                pg.click('#tsv');pg.evaluate("toast('ذخیره شد.');0")
                k=pg.evaluate("(()=>{const b=document.getElementById('tsv');return {c:b.classList.contains('tk'),t:b.textContent,n:getComputedStyle(b).animationName}})()")
                chk(t+'AN50 tick on save toast',k['c'] and k['t'].startswith('✓'))
                if rm=='no-preference': chk(t+'AN50 ring anim',k['n']=='antk')
                pg.wait_for_timeout(1400)
                chk(t+'AN50 restored',pg.evaluate("(()=>{const b=document.getElementById('tsv');return !b.classList.contains('tk')&&b.textContent=='ذخیره'})()"))
                # نشد ← بدون تیک
                pg.click('#tsv');pg.evaluate("toast('ذخیره نشد.');0")
                chk(t+'AN50 no tick on failure',pg.evaluate("!document.getElementById('tsv').classList.contains('tk')"))
                # کلیک قدیمی ← بدون تیک
                pg.evaluate("window.__lt=0;toast('ذخیره شد.');0")
                chk(t+'AN50 no tick on stale click',pg.evaluate("!document.getElementById('tsv').classList.contains('tk')"))
                # AN53
                pg.evaluate("window.__fe={};SF.t['zz']=Date.now()-20*60000;window.__h1=frH('zz');SF.t['zz']=Date.now();window.__h2=frH('zz');window.__h3=frH('zz');0")
                h=pg.evaluate("[window.__h1,window.__h2,window.__h3]")
                chk(t+'AN53 first no pulse',h[0] is not None and 'frp' not in h[0] and '🔴' in h[0])
                chk(t+'AN53 change pulses',('frp' in h[1]) and '🟢' in h[1])
                chk(t+'AN53 same no pulse',h[2] is not None and 'frp' not in h[2])
                pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<div class=\"frs frp\" id=\"tfr\">x</div>');0")
                a=pg.evaluate("getComputedStyle(document.getElementById('tfr')).animationName")
                if rm=='no-preference': chk(t+'AN53 anim',a=='anfr')
                else: chk(t+'AN53 reduced none',a in ('none',''))
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
