# تست 1.9.330: استودیو T1-c متن/بنر/رنگ/حرکت (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render();window.SGT=2;sgSheet()");pg.wait_for_timeout(300)
            chk(t+'inputs',pg.locator('#ov input[data-sg]').count()>=13)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            fire(pg,'#ov [data-sg="x.bo"]',60);fire(pg,'#ov [data-sg="x.bh"]',150);fire(pg,'#ov [data-sg="x.bd"]',30)
            fire(pg,'#ov [data-sg="x.lh"]',180);fire(pg,'#ov [data-sg="x.tb"]','#aa3300')
            pg.evaluate("document.querySelector('#ov [data-sgc=\"x.nm:1\"]').click()");pg.wait_for_timeout(150)
            pg.evaluate("document.querySelector('#ov [data-sgc=\"i.io:1\"]').click()");pg.wait_for_timeout(150)
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'css banner',('opacity:0.6' in css) and ('150px' in css) and ('rgba(0,0,0,0.3)' in css))
            chk(t+'css text/color/motion/icons',('line-height:1.8' in css) and ('#aa3300' in css) and ('animation:none' in css) and ('.hqa .qa span{display:none}' in css))
            chk(t+'saved gx',pg.evaluate("D.cms.ST.gx.bh==150&&D.cms.ST.gx.nm==1&&D.cms.ST.gicon.io==1"))
            pg.evaluate("XF.xs=0;render()");pg.wait_for_timeout(150)
            chk(t+'off clears',pg.evaluate("document.getElementById('stg').textContent")=='')
            pg.evaluate("XF.xs=1;window.SGT=2;sgSheet();document.querySelector('#ov [data-sgc=\"reset:1\"]').click()");pg.wait_for_timeout(150)
            chk(t+'reset',pg.evaluate("!D.cms.ST.gx&&!D.cms.ST.gcard&&!D.cms.ST.gicon"))
            ctx.close()
    br.close()
print('ERRORS',errs)
