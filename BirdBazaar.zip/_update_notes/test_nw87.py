# تست 1.9.87 مرحله‌ی ۳: «🆕 آخرین ویژگی‌ها» (NEWF)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; reqs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                reqs.append(u)
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1000)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='';render()"); await pg.wait_for_timeout(300)
            chk(t+'APPV is a version', __import__('re').match(r'^1\.9\.\d+$', await pg.evaluate("APPV")) is not None)
            chk(t+'hub has new-features card', 'آخرین ویژگی‌ها' in await pg.evaluate("document.getElementById('sgg').innerText"))
            await pg.fill('#ssq','تغییرات اخیر'); await pg.wait_for_timeout(200)
            chk(t+'search finds it', await pg.evaluate("document.querySelectorAll('#sgg .sc').length")==1)
            await pg.fill('#ssq',''); await pg.wait_for_timeout(100)
            await pg.evaluate("go({sx:'nw'})"); await pg.wait_for_timeout(250)
            chk(t+'list renders all rows', await pg.evaluate("document.querySelectorAll('.nwi').length")==await pg.evaluate("NEWF.length"))
            chk(t+'current version badge', 'جدید' in await pg.evaluate("document.querySelector('.nwv').innerText"))
            chk(t+'no overflow', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk(t+'new-features code makes no server calls', not await pg.evaluate("/api\\(|op\\(|fetch\\(|sapi\\(/.test(nwSec.toString()+nwTo.toString())"))
            # میان‌بر به بخش پشتیبان
            await pg.evaluate("document.querySelector('.nwi button[data-a=setsx][data-v=bk]').click()"); await pg.wait_for_timeout(250)
            chk(t+'shortcut opens backup', await pg.evaluate("S.sx=='bk'"))
            await pg.evaluate("go({sx:'nw'})"); await pg.wait_for_timeout(200)
            # میان‌بر به آمار
            await pg.evaluate("document.querySelector('.nwi button[data-a=adm][data-v=st]').click()"); await pg.wait_for_timeout(250)
            chk(t+'shortcut opens stats', await pg.evaluate("S.at=='st'"))
            chk(t+'ab() stats -> hub', await pg.evaluate("(()=>{const r=ab();return r==1&&S.at=='set'&&!S.sx})()"))
            await pg.evaluate("go({sx:'nw'})"); await pg.wait_for_timeout(150)
            chk(t+'ab() list -> hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx&&S.pnl&&S.at=='set'})()"))
            # غیر مدیر اصلی: بخش نمی‌بیند
            await pg.evaluate("S.role='admin';S.pm=['set'];S.at='set';S.sx='';render()"); await pg.wait_for_timeout(250)
            chk(t+'non-owner does not see new-features', 'آخرین ویژگی‌ها' not in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'no errors %s'%errs, not errs)
            if w==360 and sch=='light':
                await pg.evaluate("S.pm=['all'];S.sx='nw';S.at='set';render()"); await pg.wait_for_timeout(250)
                await pg.screenshot(path='%s/shots/nw87_list.png'%ROOT)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
