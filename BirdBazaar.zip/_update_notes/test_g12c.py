# تست 1.9.430 G12-c: کد سفارش روی فاکتور و برچسب
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    pg.evaluate("BM={booth:{name:'تست'},prods:[]}")
    O="{id:7,name:'علی',phone:'0912',addr:'تهران',total:500,lines:[{n:'ارزن',q:2,u:'کیلو',pr:100,t:200}]}"
    chk('label has code',pg.evaluate("pnInvTxt(%s,'l').split('\\n')[0].includes('#۱٬۰۰۷')||pnInvTxt(%s,'l').split('\\n')[0].includes('#۱۰۰۷')"%(O,O)))
    chk('label has no prices',pg.evaluate("!pnInvTxt(%s,'l').includes('جمع')"%O))
    chk('invoice has code line',pg.evaluate("pnInvTxt(%s,'f').includes('کد سفارش: #')&&pnInvTxt(%s,'f').includes('جمع')"%(O,O)))
    chk('no id -> still safe',pg.evaluate("typeof pnInvTxt({name:'x'},'f')=='string'"))
    br.close()
print('ERRORS',errs)
