# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("D.cms.BN=[{k:'تبلیغات',t:'عنوان',x:'متن',bg:'#2563EB',bg2:'#7C3AED',tc:'#fff',m:'both',b:'خرید',lk:''},{k:'ک',t:'بدون دکمه',x:'',bg:'#111',bg2:'#222',tc:'#fff',m:'both'}];S.tab=0;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'button on first only',pg.evaluate("document.querySelectorAll('#scr .bnb').length==1&&document.querySelector('#scr .bnb').textContent.includes('خرید')"))
        chk(t+'xss',pg.evaluate("bnB({b:'<i>',m:'both'}).includes('&lt;i&gt;')&&bnB({b:'x',m:'img'})==''"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
print('ERRORS',errs)
