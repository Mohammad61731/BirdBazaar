# تست 1.9.436 D2-c3a: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=0;localStorage.removeItem('bp_rsv')")
        pg.evaluate("cpSave([{c:'1234',b:1,bn:'غ',ph:'0912',s:'n',t:Date.now(),h:6}])")
        chk(t+'off -> no friend button',pg.evaluate("!cpMyH().includes('dtfr')"))
        pg.evaluate("XF.dt=1")
        chk(t+'on -> friend button',pg.evaluate("cpMyH().includes('dtfr')"))
        pg.evaluate("bzAsk=(m,d,cb)=>cb('علی');0")
        RES[0]='{"err":"none"}'
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtfr';b.dataset.v='1234';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'err -> not saved',len(calls)==1 and pg.evaluate("!cpRsv()[0].f"))
        RES[0]='{"ok":1}'
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtfr';b.dataset.v='1234';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(700)
        chk(t+'ok -> cv_d sent + saved',len(calls)==2 and '"cv_d"' in calls[1] and pg.evaluate("cpRsv()[0].f=='علی'&&cpMyH().includes('علی')"))
        chk(t+'owner sees friend',pg.evaluate("cpOwnH({s:'new',id:5,t:new Date().toISOString(),pk:{h:6,c:'1234',f:'علی'}}).includes('علی')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
