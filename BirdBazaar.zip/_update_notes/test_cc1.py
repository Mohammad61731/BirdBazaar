# تست 1.9.396 G3: کلید cc حالت تماس غرفه‌دار
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        def cm(route):
            if 'cm_set' in (route.request.post_data or ''):
                return route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}')
            return route.fallback()
        pg.route('**/*',cm)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_ccb');XF.pn=1;XF.cc=0;CCQ={}")
        chk(t+'off: plain tel',pg.evaluate("ccBtn({id:5,phone:'0912'},'')")=='<a class="btn s" href="tel:0912">📞 تماس</a>')
        chk(t+'off: no phone empty',pg.evaluate("ccBtn({id:5,phone:''},'')")=='')
        chk(t+'off: owner box empty',pg.evaluate("ccOwnH(5)")=='')
        pg.evaluate("XF.cc=1;XF.pn=0");chk(t+'cc needs pn',pg.evaluate("ccOn()")==False)
        pg.evaluate("XF.pn=1;localStorage.setItem('bp_ccb',JSON.stringify({7:['b',Date.now()],8:['c',Date.now()],9:['a',Date.now()]}))")
        chk(t+'mode b sms',pg.evaluate("ccBtn({id:7,phone:'0912'},' o')").find('sms:0912')>0)
        chk(t+'mode c hidden',pg.evaluate("ccBtn({id:8,phone:'0912'},'')")=='')
        chk(t+'mode a tel',pg.evaluate("ccBtn({id:9,phone:'0912'},'')").find('tel:0912')>0)
        chk(t+'unknown: placeholder first',pg.evaluate("ccBtn({id:11,phone:'0912'},'')")=='<span data-cc="1"></span>')
        pg.wait_for_timeout(500)
        chk(t+'unknown then default a',pg.evaluate("ccLoc()[11]&&ccLoc()[11][0]")=='a')
        chk(t+'owner box 3 buttons',pg.evaluate("(ccOwnH(7).match(/data-a=\"ccs\"/g)||[]).length")==3)
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='ccs';b.dataset.v='c';b.dataset.b='9';document.body.appendChild(b);b.click();b.remove()})()");pg.wait_for_timeout(400)
        chk(t+'ccs saves mode',pg.evaluate("ccLoc()[9][0]")=='c')
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
