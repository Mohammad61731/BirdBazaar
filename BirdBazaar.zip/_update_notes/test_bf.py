# تست 1.9.126: ابزارهای غرفه (cfg.bf)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'تهران',bio:'',phone:''}];BT.prods=[{id:11,b:1,s:'on',d:{name:'دان',type:'plain',price:50000,emoji:'🌰',imgs:[],cat:'دان'}}];BT.ok=1;BT.t=Date.now();S.role=null;go({v:'bts',id:1})")
            pg.wait_for_timeout(300)
            chk(t+'follow button shown',pg.locator('[data-a=bt_fl]').count()==1)
            pg.click('[data-a=bt_fl]');pg.wait_for_timeout(250)
            chk(t+'followed state saved',pg.evaluate("JSON.parse(localStorage.getItem('bp_fb')).join()")=='1' and 'دنبال می' in pg.locator('[data-a=bt_fl]').inner_text())
            pg.evaluate("BT.prods.push({id:12,b:1,s:'on',d:{name:'جدید',type:'plain',price:10,emoji:'🌰',imgs:[],cat:'دان'}});BT.booths[0].n=2;go({tab:0,v:null})");pg.wait_for_timeout(300)
            txt=pg.evaluate("(document.querySelector('[data-b=fb]')||{textContent:''}).textContent")
            chk(t+'home follow row shows 1 new product ('+txt.strip()[:40]+')','غرفه یک' in txt and '۱' in txt and 'تازه' in txt)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            pg.evaluate("go({v:'bts',id:1})");pg.wait_for_timeout(250)
            pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(250)
            txt=pg.evaluate("(document.querySelector('[data-b=fb]')||{textContent:''}).textContent")
            chk(t+'opening booth clears new badge','تازه' not in txt)
            pg.evaluate("go({v:'bts',id:1})");pg.wait_for_timeout(250);pg.click('[data-a=bt_fl]');pg.wait_for_timeout(200)
            chk(t+'unfollow works and row hidden',pg.evaluate("JSON.parse(localStorage.getItem('bp_fb')).length")==0)
            # manager panel: guide + quick out
            pg.evaluate("BT.u='x';BM={booth:{id:1,name:'غرفه یک',views:3,bio:'',city:'',phone:''},prods:[{id:11,s:'on',d:{name:'دان',type:'plain',price:50000,emoji:'🌰',imgs:[]}}],days:[]};BOR=[];go({v:'btm',btt:'d'})");pg.wait_for_timeout(300)
            chk(t+'guide button in dashboard',pg.locator('[data-a=bt_gd]').count()==1)
            pg.click('[data-a=bt_gd]');pg.wait_for_timeout(250)
            chk(t+'guide sheet opens',pg.evaluate("document.getElementById('ov').classList.contains('on')")and 'راهنمای غرفه‌دار' in pg.evaluate("document.getElementById('ovc').textContent"))
            pg.evaluate("cl()");pg.evaluate("go({v:'btm',btt:'p'})");pg.wait_for_timeout(250)
            chk(t+'quick out button in product row',pg.locator('[data-a=bt_po]').count()==1 and 'ناموجود' in pg.locator('[data-a=bt_po]').inner_text())
            pg.evaluate("XF.bf=0;go({v:'bts',id:1})");pg.wait_for_timeout(250)
            chk(t+'bf=0 hides follow button',pg.locator('[data-a=bt_fl]').count()==0)
            pg.evaluate("go({v:'btm',btt:'p'})");pg.wait_for_timeout(250)
            chk(t+'bf=0 hides quick out',pg.locator('[data-a=bt_po]').count()==0)
            ctx.close()
    br.close()
print('ERRORS',errs)
