# تست 1.9.494: آزمایشگاه مدیر (labAct / labH)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(150)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def txt(pg): return pg.evaluate("document.getElementById('ovc').innerText")
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_lab');LAB={};S.role='admin';S.pm=['all'];S.pvu=0;XF.kd=0;XF.cg=0;XF.sto=0")
        chk(t+'off by default',pg.evaluate("!xf('kd')&&!xf('cg')"))
        clk(pg,'lab','o');chk(t+'demo box shown',('حالت دمو' in txt(pg)))
        clk(pg,'lab','dm');chk(t+'demo on',pg.evaluate("LAB.demo.on==1"))
        chk(t+'keys forced on',pg.evaluate("xf('kd')&&xf('cg')&&xf('cr')"))
        chk(t+'sto stays off',pg.evaluate("!xf('sto')"))
        chk(t+'bar shown',pg.evaluate("(labBar(),!!document.getElementById('labbar'))"))
        clk(pg,'lab','dk:cg');chk(t+'manual off',pg.evaluate("!xf('cg')&&xf('kd')"))
        clk(pg,'lab','dz');chk(t+'all off',pg.evaluate("!xf('kd')&&!xf('cr')"))
        clk(pg,'lab','da');chk(t+'all on',pg.evaluate("xf('kd')&&xf('cg')"))
        pg.evaluate("S.pm=[]");chk(t+'non-owner unaffected',pg.evaluate("!xf('kd')"));pg.evaluate("S.pm=['all']")
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        clk(pg,'lab','de');chk(t+'end clears',pg.evaluate("!LAB.demo&&!xf('kd')&&!document.getElementById('labbar')"))
        ctx.close()
    br.close()
print('ERRS',len(errs))
