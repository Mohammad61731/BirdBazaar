# تست 1.9.73: عکس سبک غرفه/پرنده (bpub2 / rpub2 / bimg / thD / محافظ lite / پرکردن th)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
TH='data:image/webp;base64,THUMB'
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
FULL='data:image/jpeg;base64,'+('A'*500)
async def main():
    ok=True
    def chk(name,cond):
        nonlocal ok; print(('PASS ' if cond else 'FAIL ')+name); ok&=bool(cond)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        st={'bpub2':0,'bpublic':0,'rpub2':0,'rpublic':0,'bimg':0,'sent':[],'has2':True}
        litep={'id':5,'b':1,'t':'2026-01-01','d':{'name':'ارزن','type':'plain','price':100,'imgs':[TH],'img':TH,'th':TH,'thk':str(len(FULL)),'lite':1}}
        fullp={'id':5,'b':1,'t':'2026-01-01','d':{'name':'ارزن','type':'plain','price':100,'imgs':[FULL],'th':TH,'thk':str(len(FULL))}}
        liteb={'id':7,'b':1,'bn':'غرفه','ph':'0912','city':'ش','k':'sale','t':'2026-01-01','d':{'name':'کاکتوس','price':900,'imgs':[TH],'img':TH,'th':TH,'thk':str(len(FULL)),'lite':1}}
        fullb={'id':7,'b':1,'bn':'غرفه','ph':'0912','city':'ش','k':'sale','t':'2026-01-01','d':{'name':'کاکتوس','price':900,'imgs':[FULL,FULL+'B'],'th':TH,'thk':str(len(FULL))}}
        booth={'id':1,'name':'غرفه','bio':'','logo':'','cover':'','city':'ش','phone':'0912','views':0,'n':1}
        base={'ok':1,'msgs':[],'rooms':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[],'products':[]}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if not u.startswith('http'): return await route.continue_()
            try: j=json.loads(bd); o=j.get('op')
            except Exception: j={}; o=None
            hd={'access-control-allow-origin':'*'}
            def ok_(body): return route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
            if u.endswith('/rpc/fapp'):
                if o=='psig': return await ok_({'ok':1,'s':'S1','b':'B1'})
                if o=='bpub2':
                    st['bpub2']+=1
                    return await ok_({'ok':1,'booths':[booth],'prods':[litep]}) if st['has2'] else await ok_({'err':'unknown'})
                if o=='rpub2':
                    st['rpub2']+=1
                    return await ok_({'ok':1,'birds':[liteb]}) if st['has2'] else await ok_({'err':'unknown'})
                if o=='bimg':
                    st['bimg']+=1
                    a=j.get('a',{})
                    return await ok_({'ok':1,'img':FULL,'imgs':(fullp if a.get('k')=='b' else fullb)['d']['imgs']})
                return await ok_({'ok':1})
            if u.endswith('/rpc/bapp'):
                if o=='bpublic': st['bpublic']+=1; return await ok_({'ok':1,'booths':[booth],'prods':[fullp]})
                if o=='bme': return await ok_({'ok':1,'booth':booth,'prods':[{'id':5,'d':{'name':'ارزن','type':'plain','price':100,'imgs':[PNG]},'s':'on'}]})
                if o=='bprod_set': st['sent'].append(('b',j)); return await ok_({'ok':1})
                return await ok_({'ok':1})
            if u.endswith('/rpc/rapp'):
                if o=='rpublic': st['rpublic']+=1; return await ok_({'ok':1,'birds':[fullb]})
                if o=='rme': return await ok_({'ok':1,'birds':[{'id':7,'k':'sale','s':'on','d':{'name':'کاکتوس','price':900,'imgs':[PNG]}}]})
                if o=='rset': st['sent'].append(('r',j)); return await ok_({'ok':1})
                return await ok_({'ok':1})
            return await ok_(base)
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2500)
        await pg.evaluate("localStorage.removeItem('bp_psigb');BT.ok=0;bpull()"); await pg.wait_for_timeout(1200)
        chk('guest: bpub2+rpub2 used (%d,%d)'%(st['bpub2'],st['rpub2']),st['bpub2']>=1 and st['rpub2']>=1)
        chk('guest: classic bpublic/rpublic not used (%d,%d)'%(st['bpublic'],st['rpublic']),st['bpublic']==0 and st['rpublic']==0)
        v=await pg.evaluate("[BT.prods[0].d.lite,BT.prods[0].d.imgs[0],BDL.list[0].d.lite]")
        chk('guest: booth product + bird are lite %s'%v[:1]+str(v[2]),v[0]==1 and v[1]==TH and v[2]==1)
        # صفحه‌ی محصول غرفه
        await pg.evaluate("go({v:'btp',id:5})"); await pg.wait_for_timeout(1200)
        r=await pg.evaluate("[!!BT.prods[0].d.lite,BT.prods[0].d.imgs[0].length]")
        chk('booth product open: full loaded %s'%r,r[0]==False and r[1]==len(FULL))
        # صفحه‌ی پرنده
        await pg.evaluate("go({v:'btbird',id:7})"); await pg.wait_for_timeout(1200)
        r=await pg.evaluate("[!!BDL.list[0].d.lite,BDL.list[0].d.imgs.length]")
        chk('bird open: full loaded %s'%r,r[0]==False and r[1]==2)
        chk('bimg called twice (%d)'%st['bimg'],st['bimg']==2)
        await pg.wait_for_timeout(300)
        c=await pg.evaluate("Promise.all([idbGet('IM:b:5'),idbGet('IM:r:7')]).then(x=>x.map(y=>y&&y.imgs.length))")
        chk('IDB cache saved %s'%c,c==[1,2])
        # دوباره سبک شد ← از کش بدون bimg
        await pg.evaluate("go({v:null});localStorage.removeItem('bp_psigb');BT.ok=0;bpull()"); await pg.wait_for_timeout(1000)
        n0=st['bimg']
        await pg.evaluate("go({v:'btp',id:5})"); await pg.wait_for_timeout(1000)
        r=await pg.evaluate("[!!BT.prods[0].d.lite,BT.prods[0].d.imgs[0].length]")
        chk('reopen booth product: from cache %s, no new bimg (%d->%d)'%(r,n0,st['bimg']),r[0]==False and st['bimg']==n0)
        # محافظ lite
        sent0=len(st['sent'])
        await pg.evaluate("go({v:null});localStorage.removeItem('bp_psigb');BT.ok=0;bpull()"); await pg.wait_for_timeout(1000)
        res=await pg.evaluate("Promise.all([bop('bprod_set',{id:5,d:BT.prods[0].d,s:'on'}),rop('rset',{id:7,d:BDL.list[0].d,k:'sale',s:'on'})]).then(x=>x.map(y=>y&&y.err))")
        chk('guard: lite d blocked %s'%res,res==['lite','lite'])
        chk('guard: nothing sent',len(st['sent'])==sent0)
        # th هنگام ذخیره
        await pg.evaluate("bop('bprod_set',{id:9,d:{name:'x',imgs:['%s']},s:'on'})"%PNG); await pg.wait_for_timeout(1200)
        d=st['sent'][-1][1]['a']['d']
        chk('save: th/thk added to booth product',bool(d.get('th')) and d.get('thk')==str(len(PNG)))
        # پرکردن th برای قدیمی‌ها (bme / rme)
        st['sent'].clear()
        await pg.evaluate("BT.u='o';BT.p='p';BM=null;btMan&&0;bop('bme').then(r=>{BM=r;thBack()});RB=null;rop('rme').then(r=>{RB=r.birds;thBack()})"); await pg.wait_for_timeout(2500)
        ks=sorted(k for k,_ in st['sent'])
        chk('backfill: sent b+r once %s'%ks,ks==['b','r'])
        okth=all(bool(j['a']['d'].get('th')) for _,j in st['sent'])
        chk('backfill: th present',okth)
        # فالبک: سرور bpub2 ندارد
        st['has2']=False; st['bpublic']=0; st['rpublic']=0
        await pg.evaluate("window.__nlb=0;window.__nlr=0;localStorage.removeItem('bp_psigb');BT.ok=0;bpull()"); await pg.wait_for_timeout(1200)
        chk('fallback: classic ops used (%d,%d)'%(st['bpublic'],st['rpublic']),st['bpublic']>=1 and st['rpublic']>=1)
        l=await pg.evaluate("!!BT.prods[0].d.lite")
        chk('fallback: full data',l==False)
        # ادمین: همیشه کامل
        st['has2']=True; b2=st['bpub2']
        await pg.evaluate("window.__nlb=0;window.__nlr=0;S.role='admin';localStorage.removeItem('bp_psigb');BT.ok=0;bpull()"); await pg.wait_for_timeout(1000)
        chk('admin: no bpub2 (%d->%d)'%(b2,st['bpub2']),st['bpub2']==b2)
        chk('no page errors %s'%errs[:2],not errs)
        await b.close()
    print('ALL OK' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
asyncio.run(main())
