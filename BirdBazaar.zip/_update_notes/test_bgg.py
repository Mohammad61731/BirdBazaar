# تست 1.9.109: بودجه‌ی دانلود برای همه‌ی کاربران
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            ctx=await b.new_context(viewport={'width':w,'height':760}); pg=await ctx.new_page(); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                if not route.request.url.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(800)
            t='%d '%w
            # کاربر عادی: بدون کلید → سطح ۰
            r=await pg.evaluate("(()=>{D.cms=D.cms||{};D.cms.BG=null;return [bgLv(),bgMul(),bgMB()]})()")
            chk(t+'off: lv0 mul1',r[0]==0 and r[1]==1)
            await pg.evaluate("D.cms.BG={on:1,mb:10,sl:5}")
            r=await pg.evaluate("[bgG()?1:0,bgMB()]"); chk(t+'on: mb=10',r==[1,10])
            r=await pg.evaluate("(()=>{ST.cur.b=5*1048576;return [bgLv(),bgMul()]})()"); chk(t+'50% lv0',r==[0,1])
            r=await pg.evaluate("(()=>{ST.cur.b=8.5*1048576;return [bgLv(),bgMul()]})()"); chk(t+'85% lv1 x1.5',r==[1,1.5])
            r=await pg.evaluate("(()=>{ST.cur.b=11*1048576;return [bgLv(),bgMul()]})()"); chk(t+'110% lv2 x5',r==[2,5])
            r=await pg.evaluate("sfMul()>=5"); chk(t+'sfMul uses it',r)
            await pg.evaluate("D.cms.BG={on:0,mb:10,sl:5}")
            r=await pg.evaluate("[bgLv(),bgMul()]"); chk(t+'switch off → normal',r==[0,1])
            # پنل مدیر
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='tl';render()")
            await pg.wait_for_timeout(300)
            html=await pg.evaluate("document.getElementById('scr').innerText")
            chk(t+'admin sees global box','برای همه‌ی کاربران' in html)
            ov=await pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"); chk(t+'no overflow',ov)
            chk(t+'no errors '+str(errs),not errs)
        await b.close()
    print('ALL OK' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
