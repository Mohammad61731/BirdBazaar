from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(900)
    R=lambda sel:pg.evaluate(f"(()=>{{const r=document.querySelector('{sel}').getBoundingClientRect();return [r.left,r.right,r.top,r.bottom]}})()")
    n=R('nav');print('1) 5 svg icons, no emoji:',pg.locator('nav button svg').count()==5,'| floating inset L/R:',round(n[0]),round(780 and 390-n[1]),'| gap bottom:',round(780-n[3]),'| radius:',pg.evaluate("getComputedStyle(document.querySelector('nav')).borderRadius"))
    pg.screenshot(path='../shots/u6_home.png')
    for i,t in enumerate((1,2,5,4,0)):
        pg.click(f'nav [data-v="{t}"]');pg.wait_for_timeout(450)
        on=pg.locator('nav button.on').count()==1 and pg.locator(f'nav button.on[data-v="{t}"]').count()==1
        print('2) tab',t,'active ok:',on,'| scrolled bottom -> last content above nav:',end=' ')
        r=pg.evaluate("""(()=>{const s=document.querySelector('#scr');s.scrollTop=s.scrollHeight;const k=[...s.children].filter(e=>e.getBoundingClientRect().height>0).pop().getBoundingClientRect().bottom;return [k,document.querySelector('nav').getBoundingClientRect().top]})()""")
        print(r[0]<=r[1]+1,round(r[0]),round(r[1]))
    pg.click('nav [data-v="1"]');pg.wait_for_timeout(400);pg.screenshot(path='../shots/u6_store.png')
    pg.click('nav [data-v="0"]');pg.wait_for_timeout(400);print('3) fab not over nav:',pg.evaluate("(()=>{const a=document.querySelector('#fab').getBoundingClientRect(),b=document.querySelector('nav').getBoundingClientRect();return a.bottom<=b.top})()"))
    # chat hides nav
    pg.evaluate("S.role='user';S.me='ali';go({v:'chat',id:0,fr:0})");pg.wait_for_timeout(400);print('4) chat hides nav:',not pg.locator('nav').is_visible())
    pg.evaluate("ab()");pg.wait_for_timeout(300);print('   back -> nav visible:',pg.locator('nav').is_visible())
    pg.evaluate("document.documentElement.setAttribute('data-theme','dark')");pg.wait_for_timeout(300);pg.screenshot(path='../shots/u6_dark.png')
    pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(300)
        tr=pg.evaluate("[...document.querySelectorAll('nav button span')].some(e=>e.scrollWidth>e.clientWidth)")
        print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'| label truncated:',tr)
    pg.set_viewport_size({'width':320,'height':780});pg.screenshot(path='../shots/u6_320.png')
    print('ERRORS',errs);br.close()
