# تست 1.9.501 DG1: صفحه‌ی پرداخت
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
BORD=[]
def hb(route,req):
    b=json.loads(req.post_data or '{}')
    if b.get('op')=='bord':
        BORD.append(b['a']);route.fulfill(status=200,content_type='application/json',body='{"ok":1,"id":1}')
    else:h2(route,req)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("BT.t=Date.now()+60000;BT.booths=[{id:1,name:'غرفه یک',phone:'1',city:'س'}];BT.prods=[%s];BC=[{p:11,m:'r',q:2}]"%json.dumps(PR(11,1,'الف',10)))
        pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(400)
        BORD.clear()
        pg.locator('[data-a=bt_pay]').first.dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'empty fields: toast, no sheet',pg.evaluate("!document.getElementById('bzpay')"))
        pg.fill('#bcn','علی');pg.fill('#bcp','09120000000');pg.fill('#bca','خیابان یک')
        pg.locator('[data-a=bt_pay]').first.dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'sheet open',pg.evaluate("!!document.getElementById('bzpay')"))
        chk(t+'no order yet',len(BORD)==0)
        chk(t+'no overflow',pg.evaluate("document.getElementById('bzpay').scrollWidth<=document.getElementById('bzpay').clientWidth+1"))
        chk(t+'has amount+tiles',pg.evaluate("document.querySelectorAll('#bzpay .bzpt').length==3&&!!document.querySelector('#bzpay .bzpn')"))
        if w==360 and sch=='light':pg.evaluate("document.querySelectorAll('.epg').forEach(e=>{if(!e.closest('#bzpay'))e.style.display='none'});var q=document.getElementById('spl');if(q)q.style.display='none'");pg.screenshot(path='/tmp/claude-0/p/dg1_360.png')
        pg.locator('[data-a=bt_px]').dispatch_event('click');pg.wait_for_timeout(150)
        chk(t+'back closes, cart still has fields',pg.evaluate("!document.getElementById('bzpay')&&document.getElementById('bcn').value=='علی'"))
        pg.locator('[data-a=bt_pay]').first.dispatch_event('click');pg.wait_for_timeout(200)
        pg.locator('[data-a=bt_pg]').dispatch_event('click');pg.wait_for_timeout(700)
        chk(t+'order sent once',len(BORD)==1)
        chk(t+'sheet closed after',pg.evaluate("!document.getElementById('bzpay')"))
        ctx.close()
    br.close()
print('ERRS',errs)
