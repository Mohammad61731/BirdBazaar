# تست 1.9.406 G4-a: کارت غرفه (کلید cd)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'off by default',pg.evaluate("XF.cd=0;cdOn()")==False and pg.evaluate("cdOwnH()")=='')
        pg.evaluate("XF.pn=1;XF.cd=1")
        on=pg.evaluate("pnOn()")
        if on:
            chk(t+'unverified message',pg.evaluate("CDQ={n:'',h:'',l:0};cdOwnH().includes('بعد از تأیید غرفه')")and pg.evaluate("!cdOwnH().includes('id=\"cdn\"')"))
            chk(t+'verified form',pg.evaluate("CDQ={n:'6037997112345678',h:'علی',l:1};const h=cdOwnH();h.includes('id=\"cdn\"')&&h.includes('6037 9971 1234 5678')&&h.includes('data-a=\"cds\"')"))
        else: print('SKIP pnOn false')
        chk(t+'mask',pg.evaluate("cdMask('6037997112345678')")=='6037 9971 1234 5678')
        ctx.close()
print('ERRORS',errs)
