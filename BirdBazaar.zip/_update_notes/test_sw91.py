# تست 1.9.91 مرحله‌ی ۷: «🎛 کلیدها»
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; ops=[]; SV={'dl':1,'lt':0,'md':1,'qb':1,'sto':0}
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                pd=route.request.post_data or ''
                import re
                m=re.search(r'"op":"(\w+)"',pd); op=m.group(1) if m else ''
                ops.append(op)
                body=dict(BODY)
                if op=='xset': dd=json.loads(pd); SV[dd['a']['k']]=dd['a']['v']; body={'ok':1,'f':dict(SV)}
                if op=='xget': body={'ok':1,'f':dict(SV)}
                if op=='sset': body={'ok':1,'off':1}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("localStorage.removeItem('bp_xf');S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='';render()"); await pg.wait_for_timeout(250)
            chk(t+'APPV 1.9.N', await pg.evaluate("/^1\\.9\\.\\d+$/.test(APPV)"))
            chk(t+'hub has keys card', 'کلیدها' in await pg.evaluate("document.getElementById('sgg').innerText"))
            await pg.fill('#ssq','سوییچ'); await pg.wait_for_timeout(200)
            chk(t+'search finds keys', await pg.evaluate("document.querySelectorAll('#sgg .sc').length")==1)
            await pg.fill('#ssq',''); await pg.wait_for_timeout(100)
            n0=len(ops)
            await pg.evaluate("go({sx:'sw'})"); await pg.wait_for_timeout(300)
            new=[o for o in ops[n0:] if o in ('xget','xset','sset','sget','sput')]
            chk(t+'opening makes no xf/stats request (%s)'%new, not new)
            chk(t+'4 boxes', await pg.evaluate("document.querySelectorAll('#scr .box').length")>=4)
            chk(t+'27 rows (5+5+1+16)', await pg.evaluate("document.querySelectorAll('#scr .rw.sw').length")==27)
            chk(t+'every row has Persian description', await pg.evaluate("[...document.querySelectorAll('#scr .rw.sw')].every(r=>(r.querySelector('.mu')||{}).innerText&&r.querySelector('.mu').innerText.length>8)"))
            tx=await pg.evaluate("document.getElementById('scr').innerText")
            chk(t+'scope labels', 'همه‌ی گوشی‌ها' in tx and 'فقط همین گوشی' in tx)
            chk(t+'no overflow', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            # قوانین
            before=await pg.evaluate("!!D.cfg.guestAds")
            await pg.evaluate("document.querySelector('#scr [data-a=cfgt][data-v=guestAds]').click()"); await pg.wait_for_timeout(200)
            chk(t+'cfg toggles', await pg.evaluate("!!D.cfg.guestAds")!=before)
            chk(t+'still on keys section', await pg.evaluate("S.sx=='sw'"))
            # ابزار محلی
            tb=await pg.evaluate("tlOn('cl')")
            await pg.evaluate("document.querySelector('#scr [data-a=tl_tog][data-v=cl]').click()"); await pg.wait_for_timeout(200)
            chk(t+'tool toggles locally', await pg.evaluate("tlOn('cl')")!=tb)
            await pg.evaluate("document.querySelector('#scr [data-a=tl_tog][data-v=cl]').click()"); await pg.wait_for_timeout(150)
            # xf
            n1=len(ops)
            await pg.evaluate("document.querySelector('#scr [data-a=xf_tog][data-v=dl]').click()"); await pg.wait_for_timeout(500)
            chk(t+'xf_tog sends one xset', ops[n1:].count('xset')==1)
            chk(t+'xf state updated in list', await pg.evaluate("xf('dl')===false&&[...document.querySelectorAll('#scr [data-a=xf_tog][data-v=dl]')][0].innerText.trim()=='خاموش'"))
            n2=len(ops)
            await pg.evaluate("document.querySelector('#scr [data-a=sw_xf]').click()"); await pg.wait_for_timeout(600)
            chk(t+'refresh sends one xget', ops[n2:].count('xget')==1)
            chk(t+'refresh re-renders keys section with server value', await pg.evaluate("S.sx=='sw'&&xf('lt')===false&&[...document.querySelectorAll('#scr [data-a=xf_tog][data-v=lt]')][0].innerText.trim()=='خاموش'"))
            # آمار
            chk(t+'stats row asks to open tab when unknown', await pg.evaluate("!document.querySelector('#scr [data-a=st_tog]')&&!!document.querySelector('#scr [data-a=adm][data-v=st]')"))
            await pg.evaluate("STV.d={off:0,byday:[]};render()"); await pg.wait_for_timeout(200)
            chk(t+'stats toggle appears when known', await pg.evaluate("!!document.querySelector('#scr [data-a=st_tog]')"))
            n3=len(ops)
            await pg.evaluate("document.querySelector('#scr [data-a=st_tog]').click()"); await pg.wait_for_timeout(500)
            chk(t+'st_tog sends one sset', ops[n3:].count('sset')==1)
            # میان‌بر آمار
            await pg.evaluate("STV.d=null;S.sx='sw';render()"); await pg.wait_for_timeout(150)
            await pg.evaluate("document.querySelector('#scr [data-a=adm][data-v=st]').click()"); await pg.wait_for_timeout(300)
            chk(t+'shortcut opens stats', await pg.evaluate("S.at=='st'"))
            await pg.evaluate("S.at='set';S.sx='sw';render()"); await pg.wait_for_timeout(150)
            chk(t+'ab() keys -> hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx&&S.at=='set'})()"))
            await pg.evaluate("S.pm=['set'];S.sx='';render()"); await pg.wait_for_timeout(150)
            chk(t+'non-owner cannot see keys', 'کلیدها' not in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'no errors %s'%errs, not errs)
            if w==360 and sch=='light':
                await pg.evaluate("S.pm=['all'];S.sx='sw';render()"); await pg.wait_for_timeout(250)
                await pg.screenshot(path='%s/shots/sw91.png'%ROOT)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
