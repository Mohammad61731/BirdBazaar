# تست 1.9.202: پک‌های آیکن (IC6)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.new('RGBA',(300,300),(200,98,42,255)).save('/home/claude/w/tmp/i6.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();icPick('nav.home')})()");pg.wait_for_timeout(300)
        pg.evaluate("icMan('nav.home')");pg.wait_for_timeout(200)
        pg.fill('#icgn','پرندگان|<b>');pg.click('[data-a=icgn]');pg.wait_for_timeout(300)
        chk(f'{w}: new pack active+sanitized',pg.evaluate("ICG")=='پرندگانb')
        with pg.expect_file_chooser() as fc: pg.click('[data-a=ica]')
        fc.value.set_files('/home/claude/w/tmp/i6.png');pg.wait_for_timeout(1000)
        chk(f'{w}: icon in pack',pg.evaluate("Object.values(ikLib).filter(e=>e.g=='پرندگانb').length")==1)
        pg.evaluate("ikLib.zz1={u:ikLib[Object.keys(ikLib)[0]].u,c:1}");pg.evaluate("icSv();ICG='';icPick('nav.home')");pg.wait_for_timeout(200)
        chk(f'{w}: chips shown',pg.locator('[data-a=icgp]').count()>=3)
        pg.click('[data-a=icgp][data-v$="|پرندگانb"]');pg.wait_for_timeout(200)
        chk(f'{w}: filter by pack',pg.locator('[data-a=ick] img.ic').count()==1)
        k=pg.evaluate("Object.keys(ikLib).find(k=>ikLib[k].g=='پرندگانb')")
        pg.evaluate(f"icSet('nav.home','{k}')");
        pg.evaluate("icMan('nav.home')");pg.click('[data-a=icgr]');pg.fill('#icgr','طوطی');pg.click('[data-a=icgs]');pg.wait_for_timeout(300)
        chk(f'{w}: renamed',pg.evaluate("Object.values(ikLib).some(e=>e.g=='طوطی')&&!Object.values(ikLib).some(e=>e.g=='پرندگانb')"))
        pg.evaluate(f"icOne('nav.home','{k}')");pg.click('[data-a=icmv]');pg.wait_for_timeout(300)
        chk(f'{w}: moved',pg.evaluate(f"ikLib['{k}'].g")=='عمومی')
        pg.evaluate(f"icOne('nav.home','{k}')");pg.click('[data-a=icdl]');pg.wait_for_timeout(300)
        chk(f'{w}: icon deleted',pg.evaluate(f"!ikLib['{k}']"))
        chk(f'{w}: selected survives (IKL)',pg.evaluate(f"!!ikGet('{k}')&&ikSel()['nav.home']=='{k}'"))
        pg.evaluate("window.confirm=()=>true;window.prompt=()=>'x'");pg.evaluate("icMan('nav.home')");pg.click('[data-a=icgd]');pg.wait_for_timeout(300)
        chk(f'{w}: pack deleted',pg.evaluate("Object.keys(icGs()).length")==0)
        chk(f'{w}: idb synced',pg.evaluate("idbGet('ICLIB').then(v=>!!v&&Object.keys(v).length==0)"))
    br.close()
print('ERRORS',errs)
