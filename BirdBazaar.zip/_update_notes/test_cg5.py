# تست 1.9.371 C3: خرید حضوری (کلید cp)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
G=[{'id':1,'lvl':1,'rm':0,'acc':'x','la':27.3,'ln':62.3,'hrs':{},'ad':''}]
def h2(route,req):
    b=json.loads(req.post_data or '{}');o=b.get('op','')
    if o in('bord','pk_cx','pk_got','pk_chk','cg_pub'):
        CALLS.append((o,b.get('a')))
        r={'ok':1}
        if o=='cg_pub':r={'ok':1,'g':G}
        if o=='pk_chk' and (b.get('a') or {}).get('c')!='4821':r={'err':'bad'}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    route.fallback()
def last(o): return next((c[1] for c in reversed(CALLS) if c[0]==o),None)
PR=lambda i,b,n:{'id':i,'b':b,'d':{'type':'plain','name':n,'emoji':'🐦','price':1000,'s':'on','imgs':[],'unit':'kg','disc':0}}
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();CALLS.clear();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',h2)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_rsv')")
        pg.evaluate("BT.t=Date.now()+60000;BT.booths=[{id:1,name:'غرفه یک',phone:'09120000001',city:'سراوان'},{id:9,name:'غرفه نه',phone:'09120000009'}];BT.prods=[%s,%s];BC=[{p:11,m:'r',q:2},{p:19,m:'r',q:1}];BCF={}"%(json.dumps(PR(11,1,'کالا یک'),ensure_ascii=False),json.dumps(PR(19,9,'کالا نه'),ensure_ascii=False)))
        pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(500)
        chk(t+'off: nothing',pg.evaluate("cpBx(1)===''&&cpMyH()===''&&cpMode(9)==='g'&&!document.querySelector('.cpb')"))
        pg.evaluate("XF.cg=1;cgSaveC({t:Date.now(),g:{1:%s}})"%json.dumps(G[0]))
        pg.evaluate("XF.cp=0;btRe()")
        chk(t+'cg on but cp off: still nothing',pg.evaluate("cpBx(1)===''&&cpMode(9)==='g'"))
        pg.evaluate("XF.cp=1;btRe()");pg.wait_for_timeout(300)
        chk(t+'two booth boxes',pg.evaluate("document.querySelectorAll('#scr .cpb [data-a=bt_cpm],#scr .cpb .cpo').length")==4)
        chk(t+'unverified: only-in-person tag, no remote chip',pg.evaluate("cpMode(9)=='h'&&cpMode(1)=='g'&&cpBx(9).includes('فقط حضوری')&&!cpBx(9).includes('برایم بفرستید')&&cpBx(1).includes('برایم بفرستید')"))
        chk(t+'unverified shows hours chips',pg.evaluate("cpBx(9).includes('bt_cph')&&!cpBx(1).includes('bt_cph')"))
        pg.locator('#bcn').fill('علی رضایی');pg.locator('#bcp').fill('۰۹۱۲۳۴۵۶۷۸۹')
        pg.locator('[data-a=bt_cpm][data-v="1:h"]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'typed fields survive re-render',pg.evaluate("document.getElementById('bcn').value=='علی رضایی'"))
        chk(t+'switch to in-person shows hours + note',pg.evaluate("cpMode(1)=='h'&&cpBx(1).includes('ببینم و بخرم')&&cpBx(1).includes('bt_cph')"))
        pg.locator('[data-a=bt_cph][data-v="1:24"]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'hours 24',pg.evaluate("cpHrs(1)==24"))
        pg.screenshot(path='/tmp/cg5_cart_%s.png'%w)
        chk(t+'no overflow cart',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        pg.locator('[data-a=bt_pay][data-v="1"]').dispatch_event('click');pg.wait_for_timeout(200);(pg.locator('[data-a=bt_pg]').dispatch_event('click') if pg.evaluate("!!document.getElementById('bzpay')") else 0);pg.wait_for_timeout(700)
        a=last('bord') or {}
        chk(t+'bord reserve payload',a.get('b')==1 and a.get('pk')==1 and a.get('rh')==24 and len(a.get('pc',''))==4 and a.get('pc','').isdigit() and a.get('addr')=='🏪 حضوری')
        chk(t+'invoice shows big code',pg.evaluate("S.v=='btinv'&&!!document.querySelector('.cpcd.big')&&document.querySelector('.cpcd.big').textContent==S.binv.rv.c"))
        chk(t+'address not saved as 🏪',pg.evaluate("(BCF.a||'')===''"))
        pg.screenshot(path='/tmp/cg5_inv_%s.png'%w)
        chk(t+'rsv saved locally',pg.evaluate("cpRsv().length==1&&cpRsv()[0].s=='n'&&cpRsv()[0].h==24&&cpRsv()[0].ph=='09123456789'"))
        # remote order for verified booth (existing behaviour kept)
        pg.evaluate("BC=[{p:11,m:'r',q:1}];S.v='btc';render()");pg.wait_for_timeout(300)
        pg.evaluate("CPM[1]='g'")
        pg.evaluate("btRe()")
        pg.locator('#bcn').fill('علی رضایی');pg.locator('#bcp').fill('۰۹۱۲۳۴۵۶۷۸۹');pg.locator('#bca').fill('سراوان خیابان اول')
        pg.locator('[data-a=bt_pay][data-v="1"]').dispatch_event('click');pg.wait_for_timeout(200);(pg.locator('[data-a=bt_pg]').dispatch_event('click') if pg.evaluate("!!document.getElementById('bzpay')") else 0);pg.wait_for_timeout(600)
        a=last('bord') or {}
        chk(t+'verified remote: pk 0, no reservation',a.get('pk')==0 and a.get('rh')==0 and a.get('pc')=='' and a.get('addr')=='سراوان خیابان اول')
        chk(t+'no new rsv for remote',pg.evaluate("cpRsv().length==1&&!S.binv.rv"))
        # unverified booth: forced in-person, default 6h
        pg.evaluate("BC=[{p:19,m:'r',q:1}];S.v='btc';render()");pg.wait_for_timeout(300)
        pg.locator('#bcn').fill('علی رضایی');pg.locator('#bcp').fill('۰۹۱۲۳۴۵۶۷۸۹')
        pg.locator('[data-a=bt_pay][data-v="9"]').dispatch_event('click');pg.wait_for_timeout(200);(pg.locator('[data-a=bt_pg]').dispatch_event('click') if pg.evaluate("!!document.getElementById('bzpay')") else 0);pg.wait_for_timeout(600)
        a=last('bord') or {}
        chk(t+'unverified forced reserve 6h',a.get('b')==9 and a.get('pk')==1 and a.get('rh')==6 and len(a.get('pc',''))==4)
        chk(t+'two rsv saved',pg.evaluate("cpRsv().length==2"))
        # my reservations card
        pg.evaluate("BC=[];S.v='btc';render()");pg.wait_for_timeout(300)
        chk(t+'my reservations (empty cart)',pg.evaluate("document.querySelectorAll('#scr .cpr').length")==2)
        pg.screenshot(path='/tmp/cg5_my_%s.png'%w)
        c1=pg.evaluate("cpRsv()[1].c");c0=pg.evaluate("cpRsv()[0].c")
        pg.locator('[data-a=bt_cpx][data-v="%s"]'%c1).dispatch_event('click');pg.wait_for_timeout(500)
        a=last('pk_cx') or {}
        chk(t+'cancel payload',a.get('c')==c1 and a.get('phone')=='09123456789')
        chk(t+'cancel marks local',pg.evaluate("cpRsv().find(x=>x.c=='%s').s=='x'"%c1))
        pg.locator('[data-a=bt_cpg][data-v="%s"]'%c0).dispatch_event('click');pg.wait_for_timeout(500)
        a=last('pk_got') or {}
        chk(t+'got payload',a.get('c')==c0)
        chk(t+'got marks local',pg.evaluate("cpRsv().find(x=>x.c=='%s').s=='g'"%c0))
        chk(t+'no buttons after done',pg.evaluate("document.querySelectorAll('#scr .cpr [data-a=bt_cpx]').length")==0)
        # owner side
        pg.evaluate("BT.u='ali';BT.p='1234'")
        o={'id':5,'name':'خریدار','phone':'0912','addr':'🏪 حضوری','lines':[],'total':2000,'s':'new','t':'2026-11-24T10:00:00+00:00','pk':{'h':6,'g':1}}
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tw\"></div>');document.getElementById('tw').innerHTML=cpOwnH(%s)"%json.dumps(o))
        chk(t+'owner box: input + buyer confirmed',pg.evaluate("!!document.getElementById('cpc5')&&document.getElementById('tw').textContent.includes('گرفتم')"))
        chk(t+'owner none for normal order',pg.evaluate("cpOwnH({id:6,s:'new',pk:null})===''"))
        pg.evaluate("BOR=[%s];document.getElementById('cpc5').value='1111'"%json.dumps(o))
        pg.evaluate("btAct('bt_cpk','5')");pg.wait_for_timeout(500)
        chk(t+'bad code rejected',(last('pk_chk') or {}).get('c')=='1111' and pg.evaluate("BOR[0].s=='new'"))
        pg.evaluate("document.getElementById('cpc5').value='4821'")
        pg.evaluate("btAct('bt_cpk','5')");pg.wait_for_timeout(500)
        chk(t+'good code closes order',(last('pk_chk') or {}).get('id')==5 and pg.evaluate("BOR[0].s=='done'&&BOR[0].pk.d==1"))
        pg.evaluate("document.getElementById('tw').innerHTML=cpOwnH(BOR[0])")
        chk(t+'owner box after: delivered, no input',pg.evaluate("document.getElementById('tw').textContent.includes('تحویل با کد')&&!document.getElementById('cpc5')"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
# ایستا
h=open('/home/claude/bb/www/index.html',encoding='utf8').read()
q=open('/home/claude/bb/ALL_SQL.sql',encoding='utf8').read()
chk('SQL has ops',all(k in q for k in ("op='pk_cx'","op='pk_got'","op='pk_chk'","add column if not exists pk jsonb","'cg'',''cp'")))
chk('SQL ends with DONE',q.rstrip().endswith("select 'ALL_SQL_DONE' as result;"))
chk('SQL C3 after C2',q.find('[1.9.371]')>q.find('[1.9.370]')>0)
chk('key registered',"cp:0}" in h and "['cp','🏪" in h and "cp:'خاموش" in h and "['1.9.371','🏪'" in h)
import re as _re
_v=_re.search(r"APPV='([\d.]+)'",h).group(1)
chk('three versions',("bp-v"+_v.replace('.','')) in open('/home/claude/bb/www/sw.js',encoding='utf8').read() and ('"'+_v+'"') in open('/home/claude/bb/package.json',encoding='utf8').read())
print('ERRORS',errs)
