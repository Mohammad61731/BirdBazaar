# تست 1.9.64: پشتیبان کامل رمزگذاری‌شده + راه‌اندازی سرور جدید
import asyncio, sys, json, os, tempfile
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            ctx=await b.new_context(viewport={'width':w,'height':700},accept_downloads=True); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            st={'state':{'ok':1,'empty':True,'armed':True},'imp':None,'exp':0,'impres':{'ok':1,'rows':{'users':2,'ads':3},'errs':[]}}
            SAMPLE={'ok':1,'v':1,'ddl':['create table if not exists public.t(id int)'],'data':{'users':[{'username':'ali','pass':'pw1'}],'ads':[{'id':1,'d':{}}]}}
            async def h(route):
                u=route.request.url; bd=route.request.post_data or ''
                if not u.startswith('http'): return await route.continue_()
                hd={'access-control-allow-origin':'*'}
                if u.endswith('/rpc/bkapp'):
                    q=json.loads(bd); o=q['op']
                    if o=='bkstate': body=st['state']
                    elif o=='bkexport': st['exp']+=1; body=SAMPLE
                    elif o=='bkimport': st['imp']=q; body=st['impres']
                    else: body={'err':'bad'}
                    return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[]}))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(3500)
            # --- رمزگذاری
            rt=await pg.evaluate("""async()=>{const j=await bkEnc('{"a":"سلام"}','secret1');const o=JSON.parse(j);let bad=false;try{await bkDec(j,'wrong!!')}catch(e){bad=true}return {ok:await bkDec(j,'secret1')=='{"a":"سلام"}',bad,plain:!j.includes('سلام'),big:await(async()=>{const t='x'.repeat(3000000);return (await bkDec(await bkEnc(t,'p12345'),'p12345')).length})()}}""")
            chk('%d enc/dec roundtrip'%w, rt['ok']); chk('%d wrong password fails'%w, rt['bad']); chk('%d file not plaintext'%w, rt['plain']); chk('%d 3MB roundtrip'%w, rt['big']==3000000)
            # --- دکمه‌ی راه‌اندازی برای مهمان
            await pg.evaluate("S.role='';S.me='';BKS={empty:1,armed:1};"); h1=await pg.evaluate("guestCard()"); chk('%d setup button shown (empty+armed)'%w,'bkr_open' in h1)
            await pg.evaluate("BKS={empty:0,armed:1}"); chk('%d hidden when not empty'%w,'bkr_open' not in await pg.evaluate("guestCard()"))
            await pg.evaluate("BKS={empty:1,armed:0}"); chk('%d hidden when not armed'%w,'bkr_open' not in await pg.evaluate("guestCard()"))
            # --- ساخت پشتیبان (ادمین)
            await pg.evaluate("S.role='admin';S.me='adm';S.pw='x';S.pm=['all'];S.pnl=1;S.at='x';render()"); await pg.wait_for_timeout(300)
            await pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tmpc\">'+bkfCard()+'</div>')")
            await pg.evaluate("document.querySelector('#bkf_pw').value='123'"); await pg.evaluate("bkFull()"); await pg.wait_for_timeout(400)
            chk('%d short pass refused'%w, st['exp']==0)
            await pg.evaluate("document.querySelector('#bkf_pw').value='mypass1'")
            async with pg.expect_download() as dl: await pg.evaluate("bkFull()")
            d=await dl.value; path=os.path.join(tempfile.gettempdir(),'t.bbk'); await d.save_as(path)
            txt=open(path,encoding='utf-8').read(); chk('%d download .bbk'%w, d.suggested_filename.endswith('.bbk') and 'ali' not in txt and 'pw1' not in txt)
            await pg.evaluate("document.getElementById('tmpc').remove()")
            # --- بازگردانی
            await pg.evaluate("S.role='';S.me='';S.pm=[];bkrOpen()"); await pg.wait_for_timeout(300)
            chk('%d no overflow sheet'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.set_input_files('#bkr_f',path); await pg.fill('#bkr_pw','WRONGPW'); await pg.fill('#bkr_k','KEY1'); await pg.evaluate("bkrGo()"); await pg.wait_for_timeout(1500)
            chk('%d wrong pw: no import'%w, st['imp'] is None)
            await pg.fill('#bkr_pw','mypass1'); await pg.evaluate("localStorage.setItem('bp_psig','x')")
            async with pg.expect_navigation(timeout=8000): await pg.evaluate("bkrGo()")
            await pg.wait_for_timeout(500)
            imp=st['imp']; chk('%d import called with ddl+data+key+url'%w, imp and imp['op']=='bkimport' and imp['a']['k']=='KEY1' and imp['a']['ddl']==SAMPLE['ddl'] and imp['a']['data']['users'][0]['pass']=='pw1' and imp['a']['url'].startswith('https://'))
            chk('%d caches cleared + reload'%w, await pg.evaluate("localStorage.getItem('bp_psig')")!='x')
            chk('%d no errors %s'%(w,errs), not errs)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
