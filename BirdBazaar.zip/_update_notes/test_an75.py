# تست 1.9.321: AN75 پارالاکس کاور غرفه (anPar)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("const sc=document.getElementById('scr');sc.style.overflowY='auto';sc.style.height='400px';sc.innerHTML='<div class=\"bcv\" id=\"tc\" style=\"background-image:linear-gradient(red,blue)\"></div><div class=\"bbc\"><div class=\"bcv\" id=\"tl\"></div></div><div style=\"height:2000px\"></div>';0")
            pg.evaluate("document.getElementById('scr').scrollTop=100")
            pg.wait_for_timeout(250)
            a=pg.evaluate("document.getElementById('tc').style.backgroundPositionY");b=pg.evaluate("document.getElementById('tl').style.backgroundPositionY")
            if rm=='no-preference': chk(t+'cover shifted 28px', '28px' in a)
            else: chk(t+'reduced: no shift', a=='')
            chk(t+'list card untouched', b=='')
            pg.evaluate("document.getElementById('scr').scrollTop=1000");pg.wait_for_timeout(250)
            a2=pg.evaluate("document.getElementById('tc').style.backgroundPositionY")
            if rm=='no-preference': chk(t+'shift clamped 45px', '45px' in a2)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
