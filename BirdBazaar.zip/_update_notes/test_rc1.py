# تست 1.9.460 A33: رسید فروش حضوری (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;BM={booth:{name:'غرفه‌ی تست'},prods:[]};BOR=[]")
        chk(t+'chip in panel',pg.evaluate("pnExp().includes('data-a=\"pnrc\"')"))
        chk(t+'receipt total',pg.evaluate("(()=>{const r=pnRcT('دانه|2|150000؛ قفس|1|900000');return r.includes('غرفه‌ی تست')&&r.includes(fa(1200000))&&r.split('•').length==3})()"))
        chk(t+'persian digits+newline',pg.evaluate("(()=>{const r=pnRcT('دانه|۳|۱۰۰۰\\nقفس|1|500');return r.includes(fa(3500))})()"))
        chk(t+'bad input empty',pg.evaluate("pnRcT('abc')==''&&pnRcT('x|0|5')==''&&pnRcT('')==''"))
        chk(t+'action asks',pg.evaluate("(()=>{let asked=0;const o=window.bzAsk;window.bzAsk=()=>{asked=1};document.body.insertAdjacentHTML('beforeend','<button id=tb data-a=pnrc></button>');document.getElementById('tb').click();window.bzAsk=o;document.getElementById('tb').remove();return asked==1})()"))
        ctx.close()
print('ERRORS',errs)
