# تست 1.9.379 C5f: دکمه‌ی «اول برای پیک‌های مورد علاقه» و ارسال x:1
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
def hb(route,req):
    b=json.loads(req.post_data or '{}')
    if b.get('op')=='cr_rdy':
        CALLS.append(b['a']);route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
    else:handle(route,req)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900);CALLS.clear()
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;BM={booth:{id:1}};cgVer=()=>1")
        h=pg.evaluate("crOwnH({id:7,s:'new'})")
        chk(t+'two buttons',h.count('bt_crr')==1 and h.count('bt_crx')==1 and 'مورد علاقه' in h)
        pg.evaluate("BOR=[{id:7,name:'م',phone:'1',s:'new',t:new Date().toISOString(),lines:[],total:1}];btAct('bt_crr','7')");pg.wait_for_timeout(300)
        pg.evaluate("btAct('bt_crx','7')");pg.wait_for_timeout(300)
        chk(t+'ops sent',CALLS==[{'id':7},{'id':7,'x':1}])
        fut=pg.evaluate("new Date(Date.now()+600000).toISOString()")
        h2=pg.evaluate("crOwnH({id:7,s:'new',cr:{s:'rdy',o:'1234',xu:'"+fut+"'}})")
        chk(t+'hint while window open','فقط برای پیک‌های مورد علاقه' in h2)
        h3=pg.evaluate("crOwnH({id:7,s:'new',cr:{s:'rdy',o:'1234',xu:'2000-01-01T00:00:00Z'}})")
        chk(t+'no hint after window','فقط برای پیک‌های مورد علاقه' not in h3)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
