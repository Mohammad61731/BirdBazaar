# تست مورد ۵: تیک‌های فرم محصول (اتمام موجودی / نمایش در ویترین) یک ردیف مرتب، بدون شکستن متن و سرریز
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
SHOT = len(sys.argv) > 2
HTML = '''<div id="tt" style="position:fixed;left:0;right:0;top:0;z-index:99999;box-sizing:border-box;padding:14px;display:flex;flex-direction:column;gap:10px;background:var(--bg,#fff)">
<label class="row tkr"><span>⛔ اتمام موجودی (کارت خاموش)</span><input type="checkbox" id="po"></label>
<label class="row tkr"><span>⛔ اتمام موجودی (کارت خاموش)</span><input type="checkbox" id="bfo" checked></label>
<label class="row tkr"><span>نمایش در ویترین</span><input type="checkbox" id="bfv" checked></label>
<label class="row"><b>🛒 فروش خرده</b><input type="checkbox" id="bfr" checked></label></div>'''
JS = """(h)=>{document.getElementById('tt')?.remove();document.body.insertAdjacentHTML('beforeend',h);
 const out=[];document.querySelectorAll('#tt label').forEach(l=>{const i=l.querySelector('input'),t=l.querySelector('span,b');
  const ir=i.getBoundingClientRect(),tr=t.getBoundingClientRect(),lr=l.getBoundingClientRect();
  out.push({cb:Math.round(ir.width),txtH:Math.round(tr.height),lbW:Math.round(lr.width),over:lr.right>innerWidth+1||lr.left<-1,
   sameRow:Math.abs((ir.top+ir.height/2)-(tr.top+tr.height/2))<14})});
 return {rows:out,hscroll:document.documentElement.scrollWidth>innerWidth}}"""
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for scheme in ('light','dark'):
                pg=await b.new_page(viewport={'width':w,'height':700},color_scheme=scheme)
                await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
                r=await pg.evaluate(JS,HTML)
                good=(not r['hscroll']) and all(x['cb']<=30 and x['txtH']<=44 and not x['over'] and x['sameRow'] for x in r['rows'])
                ok&=good
                print(w,scheme,'OK' if good else 'BAD',[(x['cb'],x['txtH']) for x in r['rows']])
                if SHOT and scheme=='light' and w==360:
                    await pg.locator('#tt').screenshot(path='/home/claude/shot_ticks_%s.png'%ROOT.split('/')[-1])
                await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
