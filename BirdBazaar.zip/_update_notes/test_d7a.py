# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;(BOR=[{id:1,s:'new',name:'a',phone:'1',t:new Date().toISOString(),lines:[],total:1},{id:2,s:'done',name:'b',phone:'2',t:new Date(Date.now()-864e5*0.01-86400000).toISOString(),lines:[],total:1},{id:3,s:'done',name:'c',phone:'3',t:new Date(Date.now()-864e5*5).toISOString(),lines:[],total:1}]);0")
        chk(t+'bar',pg.evaluate("pnDyBar().includes('امروز')&&pnDyBar().includes('(۱)')"))
        chk(t+'filter today',pg.evaluate("(PNDY='t',BOR.filter(pnDyF).length==1)"))
        chk(t+'filter old',pg.evaluate("(PNDY='o',BOR.filter(pnDyF).length==1&&BOR.filter(pnDyF)[0].id==3)"))
        chk(t+'all',pg.evaluate("(PNDY='',BOR.filter(pnDyF).length==3)"))
        chk(t+'off: no bar',pg.evaluate("(XF.pn=0,pnDyBar()==='')"))
        ctx.close()
print('ERRORS',errs)
