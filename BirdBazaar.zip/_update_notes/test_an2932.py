# تست 1.9.251 AN29 AN30 AN32
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.wait_for_timeout(3000)
        r=await pg.evaluate("""async()=>{const sc=document.getElementById('scr');sc.insertAdjacentHTML('beforeend',`<div id=msgs><div>a</div><div>b</div></div><div id=sres><div>1</div><div>2</div><div>3</div></div><button class='btn s o' data-a=bt_fl id=fl>f</button>`);await new Promise(r=>setTimeout(r,30));const m=document.getElementById('msgs');m.insertAdjacentHTML('beforeend','<div id=nm>c</div>');await new Promise(r=>setTimeout(r,40));const f=document.getElementById('fl');f.classList.add('anfl');const n=document.getElementById('nm'),s2=document.querySelector('#sres>div:nth-child(2)'),cs=getComputedStyle(s2);return [!!n&&n.classList.contains('anmg'),!!n&&getComputedStyle(n).animationName,!m.children[0].classList.contains('anmg'),cs.animationName,cs.animationDelay,getComputedStyle(f).animationName]}""")
        print(r)
        chk('new message animates',r[0] and r[1]=='anmg'); chk('old messages not animated',r[2])
        chk('results stagger',r[3]=='anrs' and r[4]=='0.03s'); chk('follow pop css',r[5]=='anpp')
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
