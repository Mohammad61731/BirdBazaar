# تست 1.9.400 H2-10/11: پنجره‌ی نرم به‌جای confirm/prompt بومی ؛ حالت خالی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.on('dialog',lambda d:(errs.append('NATIVE DIALOG'),d.dismiss()))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2300)
        pg.evaluate("""()=>{const b=document.createElement('button');b.id='tcf';b.textContent='x';b.style.cssText='position:fixed;top:60px;left:10px;z-index:5';b.addEventListener('click',()=>{if(!confirm('این محصول حذف شود؟'))return;window.__ok=(window.__ok||0)+1});document.body.appendChild(b);
        const q=document.createElement('button');q.id='tpr';q.textContent='y';q.style.cssText='position:fixed;top:60px;left:60px;z-index:5';q.addEventListener('click',()=>{const n=prompt('اسم قالب:','الف');if(n===null)return;window.__pv=n});document.body.appendChild(q)}""")
        pg.evaluate("document.querySelector('#tcf').click()");pg.wait_for_timeout(300)
        chk(t+'dialog shown, action blocked',pg.evaluate("!!document.querySelector('#bzdlg')&&!window.__ok"))
        chk(t+'danger style',pg.evaluate("!!document.querySelector('#bzdlg .bzdy.dg')"))
        chk(t+'dialog inside viewport',pg.evaluate("(()=>{const b=document.querySelector('#bzdlg .bzdc').getBoundingClientRect();return b.left>=0&&b.right<=innerWidth&&b.height>0})()"))
        pg.evaluate("document.querySelector('#bzdlg .bzdn').click()");pg.wait_for_timeout(100)
        chk(t+'cancel: closed, not run',pg.evaluate("!document.querySelector('#bzdlg')&&!window.__ok"))
        pg.evaluate("document.querySelector('#tcf').click()");pg.wait_for_timeout(300);pg.evaluate("document.querySelector('#bzdlg .bzdy').click()");pg.wait_for_timeout(100)
        chk(t+'confirm: runs once',pg.evaluate("window.__ok===1&&!document.querySelector('#bzdlg')"))
        pg.evaluate("document.querySelector('#tpr').click()");pg.wait_for_timeout(300)
        pg.fill('#bzdlg .bzdi','قالب من');pg.keyboard.press('Enter');pg.wait_for_timeout(150)
        chk(t+'prompt value returned',pg.evaluate("window.__pv==='قالب من'"))
        pg.evaluate("document.querySelector('#tpr').click()");pg.wait_for_timeout(300);pg.evaluate("document.querySelector('#bzdlg .bzdn').click()");pg.wait_for_timeout(100)
        chk(t+'prompt cancel keeps old',pg.evaluate("window.__pv==='قالب من'&&!document.querySelector('#bzdlg')"))
        chk(t+'empty helper',pg.evaluate("bzEmpty('💬','ت','ز').includes('bzem')"))
        pg.evaluate("S.role='';S.v='';S.tab=3;render()");pg.wait_for_timeout(400)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth-innerWidth<=0"))
        ctx.close()
    br.close()
print('ERRORS',errs)
