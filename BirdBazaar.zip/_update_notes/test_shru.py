# تست 1.9.77: shrU لوگو/کاور بزرگ را زیر سقف کوچک می‌کند؛ بزرگ‌نشده را دست نمی‌زند
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if route.request.url.startswith('http'):
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}')
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1800)
        r=await pg.evaluate("""(async()=>{const c=document.createElement('canvas');c.width=2400;c.height=1600;const x=c.getContext('2d');for(let i=0;i<4000;i++){x.fillStyle='rgb('+(Math.random()*255|0)+','+(Math.random()*255|0)+','+(Math.random()*255|0)+')';x.fillRect(Math.random()*2400,Math.random()*1600,40,40)}
        const big=c.toDataURL('image/jpeg',.95);const o=await shrU(big,900,230000);const small='data:image/png;base64,AAAA';const o2=await shrU(small,256,110000);const o3=await shrU(undefined,256,1);
        return {big:big.length,o:o.length,same:o2===small,und:o3===undefined}})()""")
        print(r); ok&= r['o']<=230000 and r['o']<r['big'] and r['same'] and r['und']
        print('errors',errs); ok&=not errs
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
