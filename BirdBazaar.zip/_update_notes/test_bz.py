# تست 1.9.279: استوری غرفه‌ها (P18) و ادامه‌ی بازدیدها (P19)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:1,views:5,logo:'',city:'تهران',bio:'',phone:''},{id:2,name:'غرفه‌ی دوم با اسم خیلی بلند',n:1,views:2,logo:'',city:'',bio:'',phone:''},{id:3,name:'خالی',n:0,views:0,logo:'',city:'',bio:'',phone:''}];BT.prods=[{id:11,b:1,s:'on',d:{name:'دان',type:'plain',price:50000,emoji:'🌰',imgs:[],cat:'دان'}},{id:12,b:2,s:'on',d:{name:'قفس',type:'plain',price:10,emoji:'🏠',imgs:[],cat:'قفس'}}];go({tab:0,v:null})")
            pg.wait_for_timeout(400)
            chk(t+'two booth rings (empty booth hidden)',pg.locator('.st.bzs').count()==2)
            chk(t+'both marked new',pg.locator('.st.bzs .stn').count()==2)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            if w==360 and not dark: pg.screenshot(path='/tmp/bz360.png')
            pg.locator('.st.bzs').first.click();pg.wait_for_timeout(300)
            chk(t+'tap opens booth page',pg.evaluate("S.v")=='bts')
            pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(300)
            chk(t+'seen ring loses new badge',pg.locator('.st.bzs .stn').count()==1 and pg.locator('.st.bzs.sn').count()==1)
            pg.evaluate("localStorage.setItem(RVK,JSON.stringify(['p'+D.products[0].id]));go({tab:0,v:null})");pg.wait_for_timeout(300)
            chk(t+'continue-visits title + clear link',pg.locator('[data-a=rvclr]').count()==1)
            pg.click('[data-a=rvclr]');pg.wait_for_timeout(300)
            chk(t+'clear removes the block',pg.locator('[data-a=rvclr]').count()==0 and pg.evaluate("rvGet().length")==0)
            ctx.close()
    br.close()
print('ERRORS',errs)
