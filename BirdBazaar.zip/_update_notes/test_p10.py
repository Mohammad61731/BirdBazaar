import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='adm';D.orders=[{id:1,cu:'a',ph:'1',ad:'x',tt:1000,st:'new'},{id:2,cu:'b',ph:'2',ad:'y',tt:500,st:'done'}];D.ads[0]&&(D.ads[0].st='pending');D.products[0].out=1;FM.reqn=3;go({tab:4,v:null,pnl:1,at:'x'})");pg.wait_for_timeout(500)
    t=pg.inner_text('.dsh')
    chk('بخش نیازمند اقدام',pg.locator('.dsr').count()==4)
    chk('شمارش سفارش جدید ۱',pg.locator('.dsr').nth(0).inner_text().strip().endswith('۱'))
    chk('ناموجود ۱',pg.locator('.dsr').nth(2).inner_text().strip().endswith('۱'))
    chk('درخواست انجمن ۳',pg.locator('.dsr').nth(3).inner_text().strip().endswith('۳'))
    pg.screenshot(path=P+'/shots/p10.png')
    pg.locator('.dsr').nth(2).click();pg.wait_for_timeout(300)
    chk('کلیک → تب محصولات',pg.evaluate("S.at")=='p')
    pg.evaluate("go({tab:4,v:null,pnl:1,at:'x'})");pg.wait_for_timeout(300)
    pg.locator('.dsr').nth(3).click();pg.wait_for_timeout(500)
    chk('کلیک → تب انجمن',pg.evaluate("S.tab")==5)
    pg.evaluate("go({tab:4,v:null,pnl:1,at:'x'})");pg.wait_for_timeout(300)
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
