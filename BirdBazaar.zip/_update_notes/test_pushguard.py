# تست محافظ کرش اعلان گوشی: اگر register() برنامه را ببندد، دفعه‌ی بعد دوباره صدایش نزن
import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb2'
ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1}))
def mock(build):
    return """window.__pn={L:{},calls:[]};window.Capacitor=window.Capacitor||{};Capacitor.Plugins=Capacitor.Plugins||{};
Capacitor.Plugins.App={getInfo:async()=>({build:'%s'})};
Capacitor.Plugins.PushNotifications={addListener:(e,f)=>{__pn.L[e]=f},requestPermissions:async()=>({receive:window.__deny?'denied':'granted'}),register:async()=>{__pn.calls.push('reg')}}"""%build
with sync_playwright() as p:
    br=p.chromium.launch()
    ctx=br.new_context(viewport={'width':360,'height':760})
    ctx.route('**/*',h)
    def run(build,pre=None,deny=False,wait=600,delay=80):
        pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(500)
        pg.evaluate(mock(build));pg.evaluate("window.__deny=%s;PUSH.d=%d"%('true' if deny else 'false',delay))
        if pre:pg.evaluate(pre)
        pg.evaluate("S.role='user';S.me='ali';S.pw='x';pushInit()");pg.wait_for_timeout(wait)
        r={'calls':pg.evaluate("__pn.calls.join()"),'st':pg.evaluate("localStorage.getItem('bp_pst')||''"),'tb':pg.evaluate("localStorage.getItem('bp_ptb')||''"),'errs':errs,'pg':pg}
        return r
    # 1) اولین بار: پرچم try گذاشته می‌شود، بعد از مکث register صدا زده می‌شود
    r=run('101',wait=400);chk('اولین بار: register صدا زده شد و پرچم try است',r['calls']=='reg' and r['st']=='try' and r['tb']=='101')
    # 2) شبیه‌سازی کرش: صفحه بسته می‌شود بدون رویداد registration؛ شروع بعدی با همان بیلد
    r['pg'].close()
    r=run('101');chk('بعد از کرش (همان بیلد): register صدا زده نمی‌شود، وضعیت bad',r['calls']=='' and r['st']=='bad')
    r['pg'].close()
    r=run('101');chk('شروع‌های بعدی هم bad می‌ماند و register نمی‌شود',r['calls']=='' and r['st']=='bad')
    r['pg'].close()
    # 3) بیلد جدید APK: یک امتحان دوباره
    r=run('102',wait=400);chk('بیلد جدید: دوباره امتحان می‌شود',r['calls']=='reg' and r['st']=='try' and r['tb']=='102')
    # 4) موفقیت: رویداد registration -> ok
    r['pg'].evaluate("__pn.L.registration({value:'T'.repeat(40)})");r['pg'].wait_for_timeout(150)
    chk('بعد از registration وضعیت ok می‌شود',r['pg'].evaluate("localStorage.getItem('bp_pst')")=='ok')
    r['pg'].close()
    # 5) ok: بدون مکث register می‌شود
    r=run('102',wait=100,delay=5000);chk('وضعیت ok: فوری register (بدون مکث)',r['calls']=='reg')
    r['pg'].close()
    # 6) رد مجوز: register نمی‌شود و پرچم عوض نمی‌شود
    ctx.clear_cookies()
    pg=ctx.new_page();pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(300);pg.evaluate("localStorage.clear()");pg.close()
    r=run('200',deny=True);chk('مجوز داده نشد: register نه، پرچم خالی',r['calls']=='' and r['st']=='');r['pg'].close()
    # 7) registrationError (بدون کرش): پرچم پاک می‌شود تا دوباره امتحان شود
    r=run('200',wait=400);r['pg'].evaluate("__pn.L.registrationError({error:'x'})");r['pg'].wait_for_timeout(100)
    chk('خطای معمولی ثبت: پرچم پاک می‌شود',r['pg'].evaluate("localStorage.getItem('bp_pst')||''")=='');r['pg'].close()
    # 8) خروج وسط مکث: پرچم try نماند
    pg=ctx.new_page();pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(300);pg.evaluate("localStorage.clear()");pg.close()
    pg=ctx.new_page();pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(500);pg.evaluate(mock('300'));pg.evaluate("PUSH.d=300;S.role='user';S.me='ali';S.pw='x';pushInit()");pg.wait_for_timeout(100);pg.evaluate("S.me=''");pg.wait_for_timeout(500)
    chk('خروج در مکث: register نه و پرچم پاک',pg.evaluate("__pn.calls.length")==0 and (pg.evaluate("localStorage.getItem('bp_pst')||''")==''));pg.close()
    # 9) بدون افزونه (مرورگر) بی‌خطا
    pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(500)
    pg.evaluate("S.me='ali';pushInit()");pg.wait_for_timeout(200);chk('بدون افزونه بی‌خطا',not errs)
    br.close()
print('PASS' if all(ok) else 'FAIL');sys.exit(0 if all(ok) else 1)
