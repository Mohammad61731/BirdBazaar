# تست 1.9.242 AN4 AN5
import asyncio, sys
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.route('**/*',lambda r:r.abort() if r.request.url.startswith('http') else r.continue_())
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1000)
        chk('first render no bounce',await pg.evaluate("!document.querySelector('#nav .bnc')"))
        await pg.evaluate("S.tab=1;render()"); await pg.wait_for_timeout(50)
        chk('tab change bounces',await pg.evaluate("!!document.querySelector('#nav button.on svg.bnc')"))
        await pg.evaluate("render()"); chk('same tab re-render no bounce',await pg.evaluate("!document.querySelector('#nav .bnc')"))
        await pg.evaluate("D.cart=[{id:1,q:1}];navFx()")
        await pg.evaluate("D.cart=[{id:1,q:1},{id:2,q:1}];document.querySelector('#nav').innerHTML+='';")
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
