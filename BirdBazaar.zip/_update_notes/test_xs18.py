# تست 1.9.345: استودیو S94 قالب‌های آماده ، S95 پشتیبان/وارد کردن طرح (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\\\"fw\\\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['all'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        pg.evaluate("stSet('home:prods','nm',0,0);D.cms.ST['home:prods'].nm='نام من'")
        clk(pg,'.edbar [data-pv="m"]')
        chk(t+'sheet parts',pg.locator('#ov [data-pv^="t:"]').count()==4 and pg.locator('#ov #pvi').count()==1)
        clk(pg,'#ov [data-pv="t:1"]');pg.wait_for_timeout(250)
        chk(t+'minimal',pg.evaluate("D.cms.ST['home:prods'].rd==14&&D.cms.ST['home:prods'].nm=='نام من'"))
        chk(t+'applied dom',pg.evaluate("(()=>{const e=stEl('home:prods');return !e||e.style.borderRadius=='14px'})()"))
        clk(pg,'.edbar [data-pv="m"]');clk(pg,'#ov [data-pv="t:3"]');pg.wait_for_timeout(250)
        chk(t+'occasion light only',pg.evaluate("D.cms.ST['home:prods'].md==1&&D.cms.ST['home:prods'].gd==1"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'.edbar [data-pv="m"]');clk(pg,'#ov [data-pv="t:0"]');pg.wait_for_timeout(250)
        chk(t+'default clears keeps name',pg.evaluate("Object.keys(D.cms.ST['home:prods']).join()=='nm'"))
        pg.evaluate("D.cms.ST['home:prods'].rd=9;window.BK=JSON.stringify({v:1,ST:D.cms.ST,LY:D.cms.LY||null,LY2:null})")
        pg.evaluate("D.cms.ST={};")
        clk(pg,'.edbar [data-pv="m"]')
        pg.evaluate("document.getElementById('pvi').value=window.BK");clk(pg,'#ov [data-pv="b:i"]');pg.wait_for_timeout(250)
        chk(t+'import ok',pg.evaluate("D.cms.ST['home:prods']&&D.cms.ST['home:prods'].rd==9"))
        clk(pg,'.edbar [data-pv="m"]')
        pg.evaluate("document.getElementById('pvi').value='{bad'");clk(pg,'#ov [data-pv="b:i"]')
        chk(t+'bad rejected',pg.evaluate("D.cms.ST['home:prods'].rd==9"))
        pg.evaluate("document.getElementById('pvi').value=JSON.stringify({v:1,ST:{'home:x<script>':{rd:5},'home:prods':{rd:'x'.repeat(30),zz:{a:1},bg:'#112233'}},LY:[{id:'<b>',w:'f'}]})");clk(pg,'#ov [data-pv="b:i"]');pg.wait_for_timeout(250)
        chk(t+'sanitized',pg.evaluate("!D.cms.ST['home:x<script>']&&D.cms.ST['home:prods'].bg=='#112233'&&D.cms.ST['home:prods'].zz===undefined&&D.cms.ST['home:prods'].rd===undefined&&!D.cms.LY"))
        pg.evaluate("lyAct(['ly','und','home','prods'])");pg.wait_for_timeout(250)
        chk(t+'undo import',pg.evaluate("D.cms.ST['home:prods']&&D.cms.ST['home:prods'].rd==9"))
        ctx.close()
    br.close()
print('ERRORS',errs)
