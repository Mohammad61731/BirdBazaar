# تست 1.9.287: LG7 کارت‌ها
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const c=document.querySelector('#scr .pc,#scr .bxc,#scr .ad');if(!c)return {n:0,ov:document.documentElement.scrollWidth<=innerWidth+1};const s=getComputedStyle(c),r=c.getBoundingClientRect();return {n:1,rad:parseFloat(s.borderTopLeftRadius),bf:s.backdropFilter,sh:s.boxShadow.split('rgb').length,w:r.width,ov:document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();go({tab:1,v:null})"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m' and r['n']:
                    chk(t+'card radius>=22',r['rad']>=22)
                    chk(t+'cards no blur',(r['bf'] or 'none')=='none')
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg7_%s.png'%('d' if dark else 'l'))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
