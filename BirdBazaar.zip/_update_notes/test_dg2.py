# تست 1.9.502 DG2: واریز کارت‌به‌کارت با عکس (کلید pi)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
import json
OPS=[]
def hb(route,req):
    b=json.loads(req.post_data or '{}');(b.get('op')!='bpublic') and OPS.append((b.get('op'),b.get('a')))
    route.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1,'im':'data:image/jpeg;base64,AAAA'}))
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch)
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+sch[0]+' '
        pg.evaluate("XF.pn=1;XF.cd=1;XF.cg=1;XF.pq=1;XF.pi=0")
        chk(t+'pi off: old textarea',pg.evaluate("(()=>{PQS={id:5,total:1000,card:{n:'6037997700000000',h:'x'},pay:{s:'wait'}};pqSheet();return !!document.getElementById('pqr')&&!document.querySelector('.bzdst')})()"))
        pg.evaluate("cl();XF.pi=1")
        chk(t+'pi on',pg.evaluate("piOn()"))
        pg.evaluate("S.binv={p:'09120000000',bid:1};PQS={id:5,total:1234500,card:{n:'6037997700001234',h:'علی رضایی'},pay:null};pqSheet()")
        chk(t+'steps+card+amount',pg.evaluate("document.querySelectorAll('.bzdst>div').length==3&&!!document.querySelector('.bzdc')&&!!document.querySelector('.bzda')&&document.querySelector('.bzdn').textContent=='6037 9977 0000 1234'"))
        chk(t+'step1 on, upload btn only primary',pg.evaluate("document.querySelector('.bzdst .on span').textContent=='واریز کن'&&document.querySelectorAll('.sheet .btn:not(.s)').length==1&&!!document.querySelector('[data-a=pipk]')"))
        chk(t+'later closes',pg.evaluate("!!document.querySelector('.bzdl[data-a=clo2]')"))
        pg.evaluate("""(async()=>{const c=document.createElement('canvas');c.width=1600;c.height=1200;const x=c.getContext('2d');for(let i=0;i<400;i++){x.fillStyle='hsl('+(i*7%360)+',70%,50%)';x.fillRect(Math.random()*1600,Math.random()*1200,120,90)}const b=await new Promise(r=>c.toBlob(r,'image/png'));piRead(new File([b],'a.png',{type:'image/png'}))})()""")
        pg.wait_for_timeout(900)
        L=pg.evaluate("PQS.im?PQS.im.length:0")
        chk(t+'image compressed <=44000 (%d)'%L,0<L<=56000)
        chk(t+'preview + send primary, step2',pg.evaluate("!!document.querySelector('.bzdim')&&!!document.querySelector('[data-a=pisd]')&&document.querySelector('.bzdst .on span').textContent=='عکسش را بفرست'"))
        if w==360 and sch=='light': pg.screenshot(path='/tmp/claude-0/p/dg2_360.png')
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth&&document.querySelector('.sheet').scrollWidth<=document.querySelector('.sheet').clientWidth+1"))
        pg.locator('[data-a=pisd]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'op pay_img sent once',len(OPS)==1 and OPS[0][0]=='pay_img' and OPS[0][1]['im'].startswith('data:image/') and OPS[0][1]['phone']=='09120000000')
        chk(t+'now sent state step3',pg.evaluate("document.querySelector('.bzdst .on span').textContent=='غرفه‌دار تأیید می‌کند'&&!document.querySelector('[data-a=pisd]')"))
        # owner side
        chk(t+'owner sees view btn only with hi',pg.evaluate("pqOwnH({id:7,s:'new',pay:{s:'sent',hi:1}}).includes('pqim')&&!pqOwnH({id:7,s:'new',pay:{s:'sent',rc:'x'}}).includes('pqim')"))
        pg.evaluate("BOR=[{id:7,s:'new',total:5000,pay:{s:'sent',hi:1}}]");OPS.clear()
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=tpq data-a=pqim data-v=7></button>')");pg.locator('#tpq').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'owner photo sheet',pg.evaluate("!!document.querySelector('.sheet .bzdim')&&!!document.querySelector('.sheet [data-a=pqok]')") and OPS[0][0]=='pay_imgget')
        pg.evaluate("document.getElementById('tpq').dispatch=0");OPS.clear();pg.locator('#tpq').dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'second open cached (no op)',len(OPS)==0)
        pg.evaluate("XF.pi=0")
        chk(t+'pi off hides owner btn',pg.evaluate("!pqOwnH({id:7,s:'new',pay:{s:'sent',hi:1}}).includes('pqim')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
