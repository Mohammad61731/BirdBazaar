# تست 1.9.110: پاکسازی در خلوت — فقط عکس‌های بیش از ۷ روز بی‌استفاده؛ آیتم باز و ضروری‌ها می‌مانند؛ کلید خاموش ← هیچ
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('icOn default on', await pg.evaluate("icOn()")==True)
        chk('tlOn ic', await pg.evaluate("tlOn('ic')")==True)
        # ۴ عکس کوچک: دو تا قدیمی (۱۰ روز) ، یکی تازه ، یکی قدیمی ولی باز
        await pg.evaluate("""(async()=>{await idbSet('D',{products:[{id:1}],t:1});for(let i=1;i<=4;i++)await idbSet('IM:p:'+i,{thk:'1',img:'x'.repeat(1000),imgs:[]});const ix=await cmLoad();const now=Date.now(),old=now-10*864e5;ix.e['IM:p:1']=[1000,old];ix.e['IM:p:2']=[1000,old];ix.e['IM:p:3']=[1000,now];ix.e['IM:p:4']=[1000,old];S.v='prod';S.id=4;CM.sc=1})()""")
        await pg.evaluate("cmRun(0,1)")
        left=await pg.evaluate("idbOpen().then(db=>new Promise(r=>{const o=[];const q=db.transaction('kv').objectStore('kv').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return r(o);o.push(c.key);c.continue()}}))")
        chk('old unused p:1,p:2 removed', 'IM:p:1' not in left and 'IM:p:2' not in left)
        chk('recent p:3 kept', 'IM:p:3' in left)
        chk('open item p:4 kept', 'IM:p:4' in left)
        chk('essential D kept', 'D' in left)
        chk('counter ic=2', await pg.evaluate("CM.idx.st.ic")==2)
        # بدون پرچم idle ← هیچ پاک نمی‌شود
        await pg.evaluate("""(async()=>{await idbSet('IM:p:5',{thk:'1',img:'x',imgs:[]});const ix=await cmLoad();ix.e['IM:p:5']=[1,Date.now()-10*864e5];await cmRun(0,0)})()""")
        left=await pg.evaluate("idbOpen().then(db=>new Promise(r=>{const o=[];const q=db.transaction('kv').objectStore('kv').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return r(o);o.push(c.key);c.continue()}}))")
        chk('normal run (no idle) keeps old under budget', 'IM:p:5' in left)
        # کلید خاموش
        await pg.evaluate("tlSet('ic',0)")
        chk('tlOn ic off', await pg.evaluate("tlOn('ic')")==False)
        await pg.evaluate("cmRun(0,1)")
        left=await pg.evaluate("idbOpen().then(db=>new Promise(r=>{const o=[];const q=db.transaction('kv').objectStore('kv').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return r(o);o.push(c.key);c.continue()}}))")
        chk('off: nothing removed', 'IM:p:5' in left)
        await pg.evaluate("tlSet('ic',1)")
        chk('tlSec has row', 'پاکسازی در خلوت' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
