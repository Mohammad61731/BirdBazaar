# تست 1.9.256: خط زمانی سفارش (P61/P62)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':700},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        h=pg.evaluate("moStep('new','1405/08/29 10:30')"); d=pg.evaluate("moStep('done','')"); x=pg.evaluate("moStep('x','')")
        chk(f'{w}: new has 3 steps and 2 on',h.count('class="tli')==3 and h.count(' on')==2)
        chk(f'{w}: date shown','1405/08/29 10:30' in h)
        chk(f'{w}: done all on',d.count(' on')==3)
        chk(f'{w}: cancelled text','لغو' in x)
        pg.evaluate("document.getElementById('scr').innerHTML=moStep('new','1405/08/29')");pg.wait_for_timeout(100)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        chk(f'{w}: connector drawn',pg.evaluate("getComputedStyle(document.querySelector('.tli'),'::before').height")=='2px')
    br.close()
print('ERRORS',errs)
