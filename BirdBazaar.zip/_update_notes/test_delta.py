# تست 1.9.71: دانلود فقط تغییرات (pidx/pget) + بازگشت به دانلود کامل
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
DD={k:{'m':1,'x':1,'l':1,'c':1} for k in ['s','m','l','xl','b','xs','g']}
def prod(i,n): return {'id':i,'name':n,'price':1000+i,'cat':'x','dose':DD,'img':'','imgs':[]}
async def main():
    ok=True
    def chk(name,cond):
        nonlocal ok; print(('PASS ' if cond else 'FAIL ')+name); ok&=bool(cond)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        st={'seal':'S1','pub2':0,'pidx':0,'pget':0,'ids':None,'has':True,'prods':[prod(1,'a'),prod(2,'b'),prod(3,'c'),prod(4,'d'),prod(5,'e'),prod(6,'f'),prod(7,'g'),prod(8,'h'),prod(9,'i'),prod(10,'j'),prod(11,'k'),prod(12,'l'),prod(13,'m'),prod(14,'n'),prod(15,'o'),prod(16,'p'),prod(17,'q'),prod(18,'r'),prod(19,'s'),prod(20,'t')],'gd':[]}
        base={'ok':1,'msgs':[],'rooms':[],'stories':[],'ads':[],'guides':[],'cats':[],'banners':[]}
        def hs(o): return str(hash(json.dumps(o,sort_keys=True,ensure_ascii=False)))
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if not u.startswith('http'): return await route.continue_()
            try: j=json.loads(bd); o=j.get('op')
            except Exception: j={}; o=None
            hd={'access-control-allow-origin':'*'}
            def ok_(body): return route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
            if u.endswith('/rpc/fapp'):
                if o=='psig': return await ok_({'ok':1,'s':st['seal'],'b':'B1'})
                if o=='public2':
                    st['pub2']+=1; return await ok_(dict(base,products=st['prods'],guides=st['gd']))
                if o=='pidx':
                    st['pidx']+=1
                    if not st['has']: return await ok_({'ok':1})
                    return await ok_({'ok':1,'p':[[str(x['id']),hs(x)] for x in st['prods']],'a':[],'s':[],'x':hs(st['gd'])})
                if o=='pget':
                    st['pget']+=1; st['ids']=j['a']
                    ids=set(map(str,j['a']['p']))
                    r={'ok':1,'products':[x for x in st['prods'] if str(x['id']) in ids],'ads':[],'stories':[],'rest':({'guides':st['gd']} if j['a'].get('rest') else None)}
                    return await ok_(r)
                return await ok_({'ok':1})
            if u.endswith('/rpc/bapp'): return await ok_({'ok':1,'booths':[],'prods':[]})
            return await ok_(dict(base,products=st['prods'],guides=st['gd']))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2500)
        chk('first load: full public2 (%d)'%st['pub2'],st['pub2']>=1)
        chk('first load: no pget',st['pget']==0)
        chk('index stored',await pg.evaluate("!!localStorage.getItem('bp_pidx')"))
        # تغییر یک محصول
        st['prods'][2]=prod(3,'c-NEW'); st['seal']='S2'
        p2=st['pub2']
        await pg.evaluate("pull()"); await pg.wait_for_timeout(1000)
        chk('change 1: pget used (%d)'%st['pget'],st['pget']==1)
        chk('change 1: only changed id asked %s'%st['ids'],st['ids'] and st['ids']['p']==['3'])
        chk('change 1: no full download',st['pub2']==p2)
        n=await pg.evaluate("D.products.map(p=>p.name).join(',')")
        chk('change 1: merged + order kept',n.startswith('a,b,c-NEW,d') and n.count(',')==19)
        # حذف + افزودن
        st['prods']=[x for x in st['prods'] if x['id']!=5]+[prod(21,'new')]; st['seal']='S3'
        await pg.evaluate("pull()"); await pg.wait_for_timeout(1000)
        n=await pg.evaluate("D.products.map(p=>p.id).join(',')")
        chk('delete+add applied %s'%n,'5' not in n.split(',') and n.endswith('21') and len(n.split(','))==20)
        chk('delete+add: still no full download',st['pub2']==p2)
        # تغییر guides ← rest
        st['gd']=[{'id':1,'t':'x'}]; st['seal']='S4'
        await pg.evaluate("pull()"); await pg.wait_for_timeout(1000)
        chk('guides changed: rest fetched',await pg.evaluate("D.guides.length")==1)
        # تغییر زیاد ← دانلود کامل
        st['prods']=[prod(i+100,'z%d'%i) for i in range(20)]; st['seal']='S5'
        await pg.evaluate("pull()"); await pg.wait_for_timeout(1000)
        chk('mass change: full download (%d)'%st['pub2'],st['pub2']==p2+1)
        # ادمین: دلتا ندارد
        st['seal']='S6'; q=st['pidx']
        await pg.evaluate("S.role='admin';pull()"); await pg.wait_for_timeout(900)
        chk('admin: pidx not used',st['pidx']==q)
        await pg.evaluate("S.role=null")
        # سرور pidx ندارد
        st['has']=False; st['seal']='S7'; st['prods'][0]=prod(100,'zz')
        await pg.evaluate("window.__nodelta=0;localStorage.removeItem('bp_pidx');pull()"); await pg.wait_for_timeout(1000)
        chk('no pidx on server: falls back to full',await pg.evaluate("D.products[0].name")=='zz')
        chk('no pidx: delta disabled',await pg.evaluate("window.__nodelta")==1)
        print('errors',errs); ok&=not errs
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
