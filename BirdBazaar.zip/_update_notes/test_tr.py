# تست 1.9.132: کد رهگیری tr
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
calls=[]
def fapp(route,req):
    b=json.loads(req.post_data);o=b['op'];r={'err':'x'}
    if o=='myorders':r={'ok':1,'l':[{'id':7,'dt':'d','tt':1000,'st':'new','it':[{'n':'a','q':1}]}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
def tapp(route,req):
    b=json.loads(req.post_data);calls.append(b['op'])
    r={'ok':1,'l':[{'id':7,'c':'RG123','n':'پست'}]} if b['op']=='tmine' else {'ok':1}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.route('**/rpc/fapp',fapp);pg.route('**/rpc/tapp',tapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t='%d%s '%(w,'d' if dark else 'l');calls.clear()
            pg.evaluate("S.me='u1';S.pw='p';XF.tr=0;moOpen()");pg.wait_for_timeout(500)
            chk(t+'off: no tapp call, no code',not calls and 'RG123' not in pg.inner_text('#scr'))
            pg.evaluate("XF.tr=1;moOpen()");pg.wait_for_timeout(700)
            chk(t+'on: code shown','RG123' in pg.inner_text('#scr') and 'tmine' in calls)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            calls.clear();pg.evaluate("S.pm=['all'];S.role='admin';var b=document.createElement('button');b.dataset.a='trs';b.dataset.v='7';document.body.appendChild(b);b.click()");pg.wait_for_timeout(300)
            chk(t+'sheet opens',pg.evaluate("!!document.querySelector('#trc')"))
            pg.fill('#trc','ZZ9');pg.evaluate("document.querySelector('[data-a=trgo]').click()");pg.wait_for_timeout(500)
            chk(t+'save sends tset','tset' in calls)
            chk(t+'sheet closed',pg.evaluate("!document.querySelector('#trc')"))
            ctx.close()
print('ERRORS',errs)
