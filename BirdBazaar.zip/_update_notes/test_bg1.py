# test_bg1: bgwOne سفید می‌کند و axGone بعد از ۳ روز پنهان می‌کند. اجرا: python3 test_bg1.py <bb-dir> .
import sys
from playwright.sync_api import sync_playwright
s=open((sys.argv[1] if len(sys.argv)>1 else '..')+'/www/index.html',encoding='utf-8').read()
f1=s[s.index('function bgwOne'):s.index('async function bgwAll')]
f2=s[s.index('var SDK='):s.index('function axPull(){')]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.goto('about:blank')
    pg.add_script_tag(content="window.WQ={upl:.8};window.encImg=function(c,q){return c.toDataURL('image/webp',q)};"+f1)
    r=pg.evaluate("""async()=>{const mk=f=>{const c=document.createElement('canvas');c.width=300;c.height=200;f(c.getContext('2d'));return c.toDataURL('image/png')};
    const a=await bgwOne(mk(x=>{x.fillStyle='#d8c9a0';x.fillRect(0,0,300,200);x.fillStyle='#c0392b';x.beginPath();x.arc(150,100,60,0,7);x.fill()}));
    const u=await bgwOne(mk(x=>{x.fillStyle='#c0392b';x.fillRect(0,0,300,200)}));return [!!a,u===null]}""")
    print('bg plain/uniform-skip',r); assert r==[True,True]
    g=pg.evaluate("(function(){var _m={};var localStorage={getItem:function(k){return _m[k]||null},setItem:function(k,v){_m[k]=v}};var AX={1:{s:true},2:{s:true},3:{s:false}};var S={me:'u9'};"+f2+"var n=Date.now();localStorage.setItem('bz_sd3',JSON.stringify({1:n-4*864e5,2:n-864e5}));return [axGone({id:1,own:'x'}),axGone({id:1,own:'u9'}),axGone({id:2,own:'x'}),axGone({id:3,own:'x'})]})()")
    print('sold gone',g); assert g==[True,False,False,False]
    b.close()
print('PASS')
