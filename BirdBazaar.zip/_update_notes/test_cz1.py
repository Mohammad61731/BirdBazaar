# تست 1.9.387 D1/146+135+133: cb cq cu
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.cz=0;XF.ot=0;D.products.forEach(p=>p.out=0);D.cart=[{id:D.products[0].id,q:1},{id:D.products[1].id,q:1}];S.tab=3;S.v=0;render()")
        sw="""(dx)=>{const c=[...document.querySelectorAll('#scr .card')].find(x=>x.querySelector('[data-a=cd]'));const o=(t,x)=>c.dispatchEvent(new PointerEvent(t,{clientX:x,clientY:100,bubbles:true}));o('pointerdown',300);o('pointerup',300+dx)}"""
        pg.evaluate("("+sw+")(-200)");chk(t+'cz off: swipe ignored',pg.evaluate("D.cart.length")==2)
        pg.evaluate("XF.cz=1");pg.evaluate("("+sw+")(30)");chk(t+'cz short swipe ignored',pg.evaluate("D.cart.length")==2)
        pg.evaluate("("+sw+")(-200)");pg.wait_for_timeout(700)
        chk(t+'cz swipe removes',pg.evaluate("D.cart.length")==1)
        chk(t+'cz undo bar shown',pg.evaluate("!!document.querySelector('#scr [data-a=cu]')"))
        pg.evaluate("document.querySelector('#scr [data-a=cu]').click()")
        chk(t+'cz undo restores',pg.evaluate("D.cart.length")==2)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
