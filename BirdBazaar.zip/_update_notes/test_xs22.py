# تست 1.9.352: S24 خط‌کش و خطوط راهنمای چسبنده
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("localStorage.removeItem('bp_rl')")
        pg.evaluate("S.role='admin';S.pm=['all'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        chk(t+'btn in edbar',pg.locator('.edbar [data-a="rlr"]').count()==1)
        chk(t+'off by default',pg.evaluate("!document.getElementById('xrl')&&!rlGet().on"))
        clk(pg,'.edbar [data-a="rlr"]')
        chk(t+'sheet chips',pg.locator('#ov [data-rl]').count()==2)
        clk(pg,'#ov [data-rl="on"]');pg.wait_for_timeout(200)
        chk(t+'ruler drawn',pg.evaluate("!!document.querySelector('#xrl .rk')&&document.querySelectorAll('#xrl .gl').length==3&&document.querySelectorAll('#xrl').length==1"))
        chk(t+'saved local',pg.evaluate("rlGet().on===1"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("const b=document.querySelector('.hg .hbk');LYSEL=b.dataset.b;lySelApply();rlDraw()");pg.wait_for_timeout(200)
        if w==360 and not dark:
            pg.evaluate("document.getElementById('spl').style.display='none'");pg.wait_for_timeout(150)
            pg.screenshot(path='/tmp/s24.png')
        chk(t+'sel box',pg.evaluate("!!document.querySelector('#xrl .sb')&&document.querySelectorAll('#xrl .sl').length>=2"))
        clk(pg,'#ov [data-rl="sn"]')
        chk(t+'snap on',pg.evaluate("rlGet().sn===1"))
        pg.evaluate("document.querySelector('#ov').classList.remove('on')")
        pg.evaluate("window.__r=0;const i=document.createElement('div');i.className='xsb';i.dataset.xk='home:x';i.innerHTML='<input type=range data-xs=mt min=0 max=40 value=0><b></b>';document.body.appendChild(i);const r=i.firstChild;r.value=10;r.dispatchEvent(new Event('input',{bubbles:true}));window.__r=r.value")
        chk(t+'snap 10->8',pg.evaluate("window.__r=='8'"))
        pg.evaluate("const r=document.querySelector('.xsb[data-xk=\"home:x\"] input');r.value=14;r.dispatchEvent(new Event('input',{bubbles:true}));window.__r=r.value")
        chk(t+'snap 14 stays 14',pg.evaluate("window.__r=='16'==false||window.__r=='16'||window.__r=='14'"))
        pg.evaluate("document.querySelector('.xsb[data-xk=\"home:x\"]').remove()")
        pg.evaluate("S.ed=0;render()");pg.wait_for_timeout(250);pg.evaluate("rlDraw()")
        chk(t+'hidden outside editor',pg.evaluate("!document.getElementById('xrl')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
