# تست 1.9.387 D1/146+135+133: cb cq cu
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.cn=0;const p=D.products[0];p.out=0;D.cart=[{id:p.id,q:1,s:1}]")
        chk(t+'cn off: no bar',pg.evaluate("cnBar()")=='' and 'cnb' not in pg.evaluate("cartV0()"))
        pg.evaluate("XF.cn=1");chk(t+'cn on: price changed bar','cnb' in pg.evaluate("cartV0()"))
        pg.evaluate("D.products[0].out=1");chk(t+'cn out of stock',' ناموجود' in pg.evaluate("cnBar()"))
        pg.evaluate("D.products[0].out=0;D.cart[0].s=unit(getP(D.cart[0].id),0,0,1)");chk(t+'cn same price: no bar',pg.evaluate("cnBar()")=='')
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
