# تست 1.9.322: AN76 رشد میله‌های نمودار (anCh)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("const o=Element.prototype.animate;window.__an=0;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};const sc=document.getElementById('scr');sc.innerHTML='<div style=\"display:flex;height:60px\"><i style=\"flex:1;border-radius:3px 3px 0 0;background:red;height:50%\"></i><i style=\"flex:1;border-radius:3px 3px 0 0;background:red;height:80%\"></i></div><div style=\"height:7px\"><i style=\"display:block;height:100%;width:40%;background:red\"></i></div>';0")
            pg.evaluate("window.__an=0;window.__anChS='';anCh(document.getElementById('scr'),false)")
            n=pg.evaluate("window.__an")
            if rm=='no-preference':
                chk(t+'3 chart anims', n==3)
                pg.evaluate("window.__an=0;anCh(document.getElementById('scr'),false)")
                chk(t+'same data no replay', pg.evaluate("window.__an")==0)
                pg.evaluate("window.__an=0;anCh(document.getElementById('scr'),true)")
                chk(t+'new view replays', pg.evaluate("window.__an")==3)
            else: chk(t+'reduced: no anim', n==0)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
