# تست 1.9.66: نسخه‌ی سبک عکس‌ها (public2 / pimg / th+thk / محافظ lite / کش IDB)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
TH='data:image/webp;base64,THUMB'
DD={k:{'m':1,'x':1,'l':1,'c':1} for k in ['s','m','l','xl','b','xs','g']}
FULL='data:image/jpeg;base64,'+('A'*500)
async def main():
    ok=True
    def chk(name,cond):
        nonlocal ok; print(('PASS ' if cond else 'FAIL ')+name); ok&=bool(cond)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        st={'pub':0,'pub2':0,'pimg':0,'pset':0,'seal':'S1','has2':True}
        lite={'id':9,'name':'محصول','price':1000,'cat':'x','dose':DD,'img':TH,'imgs':[TH],'th':TH,'thk':str(len(FULL)),'lite':1}
        full={'id':9,'name':'محصول','price':1000,'cat':'x','dose':DD,'img':FULL,'imgs':[FULL,FULL+'B'],'th':TH,'thk':str(len(FULL))}
        base={'ok':1,'msgs':[],'rooms':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if not u.startswith('http'): return await route.continue_()
            try: o=json.loads(bd).get('op')
            except Exception: o=None
            hd={'access-control-allow-origin':'*'}
            def ok_(body): return route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
            if u.endswith('/rpc/fapp'):
                if o=='psig': return await ok_({'ok':1,'s':st['seal'],'b':'B1'})
                if o=='public2':
                    st['pub2']+=1
                    if not st['has2']: return await ok_({'err':'unknown'})
                    return await ok_(dict(base,products=[lite]))
                if o=='pimg':
                    st['pimg']+=1; return await ok_({'ok':1,'img':FULL,'imgs':full['imgs']})
                return await ok_({'ok':1})
            if u.endswith('/rpc/app') and o=='public':
                st['pub']+=1; return await ok_(dict(base,products=[full]))
            if o=='products_set': st['pset']+=1
            if u.endswith('/rpc/bapp'): return await ok_({'ok':1,'booths':[],'prods':[]})
            return await ok_(dict(base,products=[full]))
        await pg.route('**/*',h)
        url='file://%s/www/index.html'%ROOT
        await pg.goto(url); await pg.wait_for_timeout(2500)
        # 1) مهمان: نسخه‌ی سبک
        chk('guest: public2 used (%d)'%st['pub2'],st['pub2']>=1)
        chk('guest: classic public not used (%d)'%st['pub'],st['pub']==0)
        v=await pg.evaluate("[D.products[0].lite,D.products[0].imgs[0]]")
        chk('guest: card has thumb only %s'%v[1][:20],v[0]==1 and v[1]==TH)
        # 2) باز کردن محصول ← عکس کامل
        await pg.evaluate("go({v:'prod',id:9})"); await pg.wait_for_timeout(1200)
        r=await pg.evaluate("[!!D.products[0].lite,D.products[0].imgs.length]")
        chk('open product: full images loaded %s'%r,r[0]==False and r[1]==2)
        chk('open product: pimg once (%d)'%st['pimg'],st['pimg']==1)
        await pg.wait_for_timeout(300)
        c=await pg.evaluate("idbGet('IM:p:9').then(x=>x&&x.imgs.length)")
        chk('IDB image cache saved (%s)'%c,c==2)
        # 3) مهر عوض شد ← دوباره سبک، باز کردن دوباره ← از کش، بدون pimg
        await pg.evaluate("go({v:null})"); st['seal']='S2'
        await pg.evaluate("localStorage.removeItem('bp_psig');pull()"); await pg.wait_for_timeout(900)
        l=await pg.evaluate("D.products[0].lite")
        chk('after refresh: lite again',l==1)
        n0=st['pimg']
        await pg.evaluate("go({v:'prod',id:9})"); await pg.wait_for_timeout(1000)
        r=await pg.evaluate("[!!D.products[0].lite,D.products[0].imgs.length]")
        chk('reopen: full from cache %s'%r,r[0]==False and r[1]==2)
        chk('reopen: no new pimg (%d->%d)'%(n0,st['pimg']),st['pimg']==n0)
        # 4) محافظ: آیتم سبک هرگز به سرور نرود
        await pg.evaluate("go({v:null})")
        await pg.evaluate("localStorage.removeItem('bp_psig');st=0;pull()"); await pg.wait_for_timeout(800)
        res=await pg.evaluate("op('products_set',{rows:D.products}).then(x=>x===undefined)")
        chk('guard: lite rows blocked',res is True)
        chk('guard: nothing sent (%d)'%st['pset'],st['pset']==0)
        # 5) ادمین: نسخه‌ی کامل از public قدیمی
        p2=st['pub2']
        await pg.evaluate("S.role='admin';localStorage.removeItem('bp_psig');pull()"); await pg.wait_for_timeout(900)
        chk('admin: classic public (%d)'%st['pub'],st['pub']>=1 and st['pub2']==p2)
        l=await pg.evaluate("!!D.products[0].lite")
        chk('admin: full data, no lite',l==False)
        # 6) تابع public2 روی سرور نیست ← رفتار قبلی
        st['has2']=False
        await pg.evaluate("S.role=null;window.__nolite=0;localStorage.removeItem('bp_psig');pub=0;pull()"); await pg.wait_for_timeout(900)
        pb=st['pub']
        await pg.evaluate("localStorage.removeItem('bp_psig');pull()"); await pg.wait_for_timeout(700)
        chk('no public2 on server: fallback works (%d->%d)'%(pb,st['pub']),st['pub']>pb)
        # 7) ساخت عکس کوچک در ابزار ادمین
        await pg.evaluate("S.role='admin'")
        await pg.evaluate("""(()=>{const c=document.createElement('canvas');c.width=900;c.height=700;const x=c.getContext('2d');for(let i=0;i<400;i++){x.fillStyle='hsl('+(i*7%360)+',70%,50%)';x.fillRect(Math.random()*900,Math.random()*700,120,90)}
          D.products=[{id:1,name:'t',price:5,cat:'x',imgs:[c.toDataURL('image/png')]}];D.stories=[];D.ads=[]})()""")
        r=await pg.evaluate("imgShrink(true).then(x=>({thn:x.thn,th:D.products[0].th&&D.products[0].th.slice(0,10),ok:D.products[0].thk===String(D.products[0].imgs[0].length),len:D.products[0].th?D.products[0].th.length:0}))")
        chk('thumb built %s'%r,r['thn']==1 and (r['th'] or '').startswith('data:image') and r['ok'] and 0<r['len']<30000)
        r=await pg.evaluate("imgShrink(true).then(x=>x.thn)")
        chk('thumb not rebuilt when current',r==0)
        chk('no page errors %s'%errs,not errs)
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
