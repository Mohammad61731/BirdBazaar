# تست 1.9.114: شبیه‌ساز گوشی ضعیف — پیش‌فرض خاموش ؛ روشن ← slow و low ؛ خاموش ← برگشت
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.add_init_script("Object.defineProperty(navigator,'deviceMemory',{get:()=>8})")
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default off', await pg.evaluate("tlOn('ws')")==False)
        chk('real profile high', await pg.evaluate("cmProf().t")=='high')
        await pg.evaluate("tlSet('ws',1)")
        chk('on: net slow', await pg.evaluate("sfNet()")=='slow')
        chk('on: profile low/40MB/6', await pg.evaluate("(()=>{const p=cmProf();return [p.t,p.mb,p.fc]})()")==['low',40,6])
        chk('on: sfMul >=3', await pg.evaluate("sfMul()")>=3)
        chk('on: warning shown', 'شبیه‌ساز روشن است' in await pg.evaluate("tlSec()"))
        await pg.evaluate("tlSet('ws',0)")
        chk('off: profile back to high', await pg.evaluate("cmProf().t")=='high')
        chk('off: no warning', 'شبیه‌ساز روشن است' not in await pg.evaluate("tlSec()"))
        chk('tlSec has row', 'شبیه‌ساز گوشی ضعیف' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
