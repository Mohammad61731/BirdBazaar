# تست 1.9.129: مراحل سفارش ot (سبد برگرداندن + سفارش مجدد)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fapp(route,req):
    b=json.loads(req.post_data);o=b['op']
    r={'err':'x'}
    if o=='myorders':r={'ok':1,'l':[{'id':1,'st':'new','it':[{'id':1,'n':'الف','q':1}],'tt':1000,'dt':'x'},{'id':2,'st':'done','it':[{'n':'ب','q':2}],'tt':2000,'dt':'x'},{'id':3,'st':'x','it':[],'tt':0,'dt':'x'}]}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.route('**/rpc/fapp',fapp);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            for on in (1,0):
                pg.evaluate("XF.ot=%d;D.products.length||D.products.push({id:1,name:'الف',d:'',out:0,price:1000,pr:1000});D.cart=[{id:D.products[0].id,w:0,v:0,q:1}];S.me='u1';go({tab:3,v:null})"%on);pg.wait_for_timeout(200)
                pg.evaluate("document.querySelector('[data-a=cd]').click()");pg.wait_for_timeout(200)
                chk(t+'undo bar on=%d'%on,pg.locator('[data-a=cu]').count()==on)
                if on:
                    pg.evaluate("document.querySelector('[data-a=cu]').click()");pg.wait_for_timeout(200)
                    chk(t+'restored',pg.evaluate("D.cart.length")==1)
                pg.evaluate("moOpen()");pg.wait_for_timeout(500)
                chk(t+'steps on=%d'%on,(pg.locator('#scr .card >> text=در بررسی غرفه').count()>0)==bool(on))
                chk(t+'reorder btn on=%d'%on,pg.locator('[data-a=mo_re]').count()==(1 if on else 0))
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1 && document.querySelector('#scr').scrollWidth<=innerWidth+1"))
            ctx.close()
    br.close()
print('ERRORS',errs)
