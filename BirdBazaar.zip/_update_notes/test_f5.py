import json,datetime,os
from PIL import Image
from playwright.sync_api import sync_playwright
os.makedirs('/tmp/f5',exist_ok=True)
Image.new('RGB',(1600,1200),(200,60,60)).save('/tmp/f5/big.png')
open('/tmp/f5/clip.mp4','wb').write(b'\x00\x00\x00\x18ftypmp42'+b'0'*2000)
open('/tmp/f5/doc.txt','w').write('hello')
open('/tmp/f5/huge.bin','wb').write(b'0'*3100000)
errs=[];calls=[]
ST={'perm':{'txt':False,'img':True,'vid':False,'fil':False,'muted':False,'blocked':False},'nid':10}
MS=[{'id':1,'u':'sara','k':'text','b':'سلام به همه','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:00:00Z','r':{}},{'id':2,'u':'reza','k':'text','b':'این پیام دوم است','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:05:00Z','r':{}}]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);calls.append(b);o=b['op'];a=b['a'];r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':False,'perm':ST['perm'],'avatar':''}
        if o=='fpull':
            rows=[m for m in MS if m['id']>a.get('after',0)]
            r={'ok':1,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜'}],'msgs':rows if a.get('room')==7 else [],'av':{},'pins':[],'reqn':0}
        if o=='fsend':
            ST['nid']+=1;MS.append({'id':ST['nid'],'u':b['u'],'k':a['k'],'b':a.get('b',''),'md':a.get('md'),'rt':a.get('rt'),'pin':False,'t':'2026-11-13T09:00:00Z','r':{}});r={'ok':1,'id':ST['nid']}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def sends():return [c for c in calls if c['op']=='fsend']
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(900)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(800)
    print('1) image-only user: bar shown:',pg.locator('.cin').count()==1,'| input disabled:',pg.locator('#ci').is_disabled(),'| send btn hidden:',pg.locator('.cin .snd').count()==0)
    pg.click('[data-a=fatts]');pg.wait_for_timeout(300)
    t=pg.locator('[data-a=fatt]').all_inner_texts();print('   sheet buttons:',[x.replace('\n',' ') for x in t])
    pg.click('[data-a=fatt][data-v=vid]');pg.wait_for_timeout(300);print('   video blocked (no send):',len(sends())==0)
    pg.click('[data-a=fatts]') if pg.locator('[data-a=fatt]').count()==0 else None
    with pg.expect_file_chooser() as fc:pg.click('[data-a=fatt][data-v=img]')
    fc.value.set_files('/tmp/f5/big.png');pg.wait_for_timeout(1500)
    s=sends();print('   image sent:',len(s)==1 and s[0]['a']['k']=='img','| jpeg:',s[0]['a']['md'][:20] if s else None,'| chars:',len(s[0]['a']['md']) if s else None)
    dims=pg.evaluate("new Promise(r=>{const i=new Image();i.onload=()=>r([i.width,i.height]);i.src=calls_md})") if False else None
    print('   image bubble shown:',pg.locator('.fmb img').count()==1)
    pg.click('.fmb img');pg.wait_for_timeout(400);print('   tap image opens zoom viewer:',pg.locator('#zv').count()==1);pg.evaluate("document.getElementById('zv')&&document.getElementById('zv').remove()")
    pg.screenshot(path='../shots/f5_img.png')
    # all permissions
    ST['perm'].update(txt=True,vid=True,fil=True);pg.evaluate("FM.perm.txt=FM.perm.vid=FM.perm.fil=true;fOpen(7)");pg.wait_for_timeout(900)
    print('2) full perms: input enabled:',pg.locator('#ci').is_enabled(),'| send btn:',pg.locator('.cin .snd').count()==1)
    pg.click('[data-a=fatts]');pg.wait_for_timeout(250)
    with pg.expect_file_chooser() as fc:pg.click('[data-a=fatt][data-v=vid]')
    fc.value.set_files('/tmp/f5/clip.mp4');pg.wait_for_timeout(800)
    pg.click('[data-a=fatts]');pg.wait_for_timeout(250)
    with pg.expect_file_chooser() as fc:pg.click('[data-a=fatt][data-v=file]')
    fc.value.set_files('/tmp/f5/doc.txt');pg.wait_for_timeout(800)
    s=sends();print('   video sent:',s[-2]['a']['k']=='vid','| file sent:',s[-1]['a']['k']=='file','| file name as body:',s[-1]['a']['b'],'| video tag:',pg.locator('.fmb video').count(),'| file chip:',pg.locator('.fmf').count())
    n0=len(sends());pg.click('[data-a=fatts]');pg.wait_for_timeout(250)
    with pg.expect_file_chooser() as fc:pg.click('[data-a=fatt][data-v=file]')
    fc.value.set_files('/tmp/f5/huge.bin');pg.wait_for_timeout(800);print('   >3MB rejected (no send):',len(sends())==n0)
    with pg.expect_download() as d:pg.click('.fmf')
    print('   file download works:',d.value.suggested_filename)
    # reply
    pg.click('.fmr.in >> nth=1',position={'x':20,'y':10});pg.wait_for_timeout(300);print('3) message sheet opens:',pg.locator('#ov.on [data-a=frep]').count()==1,'| copy btn:',pg.locator('[data-a=fcopy]').count()==1)
    pg.click('[data-a=frep]');pg.wait_for_timeout(300);print('   reply strip:',pg.locator('#frp').is_visible(),'|',pg.locator('#frp').inner_text()[:40])
    pg.fill('#ci','موافقم');pg.press('#ci','Enter');pg.wait_for_timeout(900)
    s=sends();print('   text sent with rt:',s[-1]['a'].get('rt'),'| strip cleared:',not pg.locator('#frp').is_visible(),'| quote in bubble:',pg.locator('.fmq').count()>=1)
    pg.screenshot(path='../shots/f5_reply.png')
    pg.click('.fmr.in >> nth=0',position={'x':20,'y':10});pg.wait_for_timeout(250);pg.click('[data-a=frep]');pg.wait_for_timeout(200);pg.click('[data-a=frepx]');print('   cancel reply:',not pg.locator('#frp').is_visible())
    # back button closes sheet / leaves chat
    pg.click('[data-a=fatts]');pg.wait_for_timeout(200);print('4) back closes sheet first:',pg.evaluate("ab()===1&&!ov.classList.contains('on')&&S.v==='chat'"),'| then leaves chat:',pg.evaluate("ab()===1&&S.v===null"))
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("fOpen(7)");pg.wait_for_timeout(500);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
