# استفاده: python3 switch_server.py https://NEWREF.supabase.co sb_publishable_XXXX
# فقط SB و KEY در www/index.html و آدرس push در ALL_SQL.sql را عوض می‌کند (کلید Publishable؛ هیچ رمزی نیست).
import sys,re
url,key=sys.argv[1].rstrip('/'),sys.argv[2]
assert re.fullmatch(r'https://[a-z0-9]+\.supabase\.co',url),'آدرس باید مثل https://xxxx.supabase.co باشد'
assert key.startswith('sb_publishable_'),'فقط کلید Publishable (sb_publishable_...) مجاز است'
for p,f in (('www/index.html',lambda s:re.sub(r"const SB='https://[a-z0-9]+\.supabase\.co/rest/v1/rpc/app',KEY='[^']+'","const SB='"+url+"/rest/v1/rpc/app',KEY='"+key+"'",s,count=1)),
            ('ALL_SQL.sql',lambda s:re.sub(r"https://[a-z0-9]+\.supabase\.co/functions/v1/push","'"[:0]+url+"/functions/v1/push",s))):
    s=open(p,encoding='utf-8').read(); n=f(s); assert n!=s or url in s,p; open(p,'w',encoding='utf-8').write(n); print('ok',p)
