# تست 1.9.183: نام فارسی برند + فونت + انیمیشن
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("localStorage.setItem('bp_tls', JSON.stringify({fw:0}))");pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2500)
        txt=pg.evaluate("document.querySelector('#top .bnm')?document.querySelector('#top .bnm').textContent:''")
        chk(f'{w}: header persian name',txt=='پی‌تآب کالا')
        chk(f'{w}: font loaded',pg.evaluate("document.fonts.check('20px PitabType')"))
        chk(f'{w}: title persian',pg.title()=='پی‌تآب کالا')
        chk(f'{w}: no horizontal overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360:
            chk('logo layers present',pg.locator('#scr .wl .lbx .la').count()==1 and pg.locator('#scr .wl .lbx .lb').count()==1)
            an=pg.evaluate("(()=>{const a=document.querySelector('#scr .wl .la'),b=document.querySelector('#scr .wl .lb');return a&&b?[getComputedStyle(a).animationName,getComputedStyle(b).animationName,getComputedStyle(a).backgroundImage.slice(0,22)]:[]})()")
            chk('cart layer first then rest, transform-only keyframes',len(an)==3 and an[0]=='lgA' and an[1]=='lgB' and an[2].startswith('url("data:image/webp'))
            pg.wait_for_timeout(2500);pg.screenshot(path='/home/claude/_update_notes/br360.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
