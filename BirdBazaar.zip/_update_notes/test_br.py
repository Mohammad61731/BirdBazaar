# تست 1.9.183: نام فارسی برند + فونت + انیمیشن
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("localStorage.setItem('bp_tls', JSON.stringify({fw:0}))");pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2500)
        txt=pg.evaluate("document.querySelector('#top .bnm')?document.querySelector('#top .bnm').textContent:(document.querySelector('#top .ni')?document.querySelector('#top .ni').alt:'')")
        chk(f'{w}: header has no name text (logo only)',not txt)
        chk(f'{w}: title persian',pg.title()=='پی‌تآب بازار')
        chk(f'{w}: no horizontal overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360:
            chk('logo block present (wl)',pg.locator('#scr .wl').count()>=1)
            kf=pg.evaluate("(()=>{const r={};for(const sh of document.styleSheets){let rs;try{rs=sh.cssRules}catch(e){continue}for(const x of rs){if(x.type===7&&(x.name==='lgA'||x.name==='lgB')){let ok=1;for(const k of x.cssRules){for(const p of k.style){if(p!=='opacity'&&p!=='transform')ok=0}}r[x.name]=ok}}}return r})()")
            chk('lgA/lgB keyframes exist, opacity/transform only',kf.get('lgA')==1 and kf.get('lgB')==1)
            pg.wait_for_timeout(2500);pg.screenshot(path='/home/claude/_update_notes/br360.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
