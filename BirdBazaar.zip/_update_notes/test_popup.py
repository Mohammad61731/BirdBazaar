# تست مورد ۱۱+۱۲: پاپ‌آپ مدیریت (دکمه‌ی خواندم) و پنجره‌ی شناور ۳ ثانیه‌ای؛ عرض ۳۲۰/۳۶۰/۴۱۲ روشن/تاریک
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
SHOT = len(sys.argv) > 2
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for scheme in ('light','dark'):
                pg=await b.new_page(viewport={'width':w,'height':700},color_scheme=scheme)
                errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
                await pg.evaluate("()=>{S.me='ali'}")
                # شناور: اولین poll با n=0 چیزی نشان ندهد، بعد افزایش نشان بدهد
                await pg.evaluate("()=>{bpNote('c',{n:0})}")
                a=await pg.evaluate("!!document.getElementById('bpn')")
                await pg.evaluate("()=>{bpNote('c',{n:1})}")
                bx=await pg.evaluate("()=>{const e=document.getElementById('bpn');if(!e)return null;const r=e.getBoundingClientRect();return [r.left>=0,r.right<=innerWidth,e.className]}")
                if SHOT and w==320 and scheme=='light': await pg.screenshot(path='/home/claude/shot_float.png')
                await pg.wait_for_timeout(3300)
                gone=await pg.evaluate("!document.getElementById('bpn')")
                # باز کردن پیام از شناور (گفتگو)
                await pg.evaluate("()=>{bpNote('c',{n:2})}")
                await pg.click('#bpn [data-a=bpo]'); await pg.wait_for_timeout(200)
                gone2=await pg.evaluate("!document.getElementById('bpn')")
                # پاپ‌آپ
                await pg.evaluate("()=>{S.v=null;bpNote('m',{n:1,pop:{id:7,f:'admin',b:'سلام! '.repeat(60)}})}")
                pp=await pg.evaluate("()=>{const e=document.querySelector('#bpp .bpc');if(!e)return null;const r=e.getBoundingClientRect();return [r.left>=0,r.right<=innerWidth,r.bottom<=innerHeight,document.documentElement.scrollWidth<=innerWidth]}")
                if SHOT and w==320 and scheme=='dark': await pg.screenshot(path='/home/claude/shot_pop.png')
                # همان پیام دوباره نشان داده نشود پس از بستن
                await pg.click('#bpp [data-a=bpr]'); await pg.wait_for_timeout(200)
                closed=await pg.evaluate("!document.getElementById('bpp')")
                await pg.evaluate("()=>{bpNote('m',{n:1,pop:{id:7,f:'admin',b:'x'}})}")
                again=await pg.evaluate("!document.getElementById('bpp')")
                good=(not a) and bx and all(bx[:2]) and 'gr' in bx[2] and gone and gone2 and pp and all(pp) and closed and again and not errs
                ok&=bool(good); print(w,scheme,'OK' if good else 'BAD',a,bx,gone,gone2,pp,closed,again,errs[:1])
                await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
