# تست 1.9.436 D3-b: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.route('**/rpc/bapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=1;BT.booths=[{id:1,name:'غ',phone:'0912 000 1111'}];localStorage.removeItem('bp_cdo');dtCdAdd({bid:1,bn:'غ',p:'0935',t:Date.now()-40*60000})")
        chk(t+'old order -> sms chips',pg.evaluate("dtCdH().includes('sms:09120001111')&&dtCdH().includes('پیک نیامد')"))
        pg.evaluate("localStorage.removeItem('bp_cdo');dtCdAdd({bid:1,bn:'غ',p:'0935',t:Date.now()-5*60000})")
        chk(t+'fresh order -> no chips',pg.evaluate("!dtCdH().includes('پیک نیامد')"))
        pg.evaluate("XF.dt=0")
        chk(t+'off -> nothing',pg.evaluate("dtCdH()===''"))
        pg.evaluate("XF.dt=1;localStorage.removeItem('bp_cdo');dtCdAdd({bid:1,bn:'غ',p:'0935',t:Date.now()-40*60000});BC=[];D.cart=[];S.tab=3;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
