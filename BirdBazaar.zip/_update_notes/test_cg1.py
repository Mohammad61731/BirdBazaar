# تست 1.9.367 C0: زیرساخت لوکیشن/تأیید غرفه (کلید cg)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
G=[{'id':1,'lvl':1,'rm':1,'acc':'x','la':25.3,'ln':61.6,'hrs':{'o':'09:00','c':'21:00'},'ad':'خیابان اصلی'},{'id':2,'lvl':0,'rm':0,'acc':'n','la':25.3,'ln':61.6,'hrs':{},'ad':''}]
def h2(route,req):
    b=json.loads(req.post_data or '{}');o=b.get('op','')
    if o in('cg_pub','cg_set','cg_get'):
        CALLS.append((o,b.get('a')))
        r={'ok':1,'g':G} if o=='cg_pub' else {'ok':1,'geo':{},'lvl':1}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    route.fallback()
with sync_playwright() as p:
    br=p.chromium.launch()
    ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR')
    pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.route('**/*',handle);pg.route('**/rpc/bapp',h2)
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    chk('APPV 1.9.367',pg.evaluate("APPV").startswith('1.9.'))
    chk('XD.cg default 0',pg.evaluate("XD.cg")==0)
    chk('XL has cg',pg.evaluate("XL.some(x=>x[0]=='cg')"))
    chk('XLD has cg',pg.evaluate("typeof XLD.cg=='string'"))
    chk('xf(cg) off by default',pg.evaluate("xf('cg')")==False)
    chk('cgPub off -> {} no call',pg.evaluate("cgPub().then(x=>Object.keys(x).length)")==0 and len(CALLS)==0)
    chk('cgSave off -> null',pg.evaluate("cgSave({lat:1,lng:1})")is None and len(CALLS)==0)
    pg.evaluate("XF.cg=1")
    chk('xf(cg) on',pg.evaluate("xf('cg')")==True)
    chk('cgPub fetch ok',pg.evaluate("cgPub(true).then(x=>Object.keys(x).length)")==2 and len(CALLS)==1)
    chk('cgPub cached no 2nd call',pg.evaluate("cgPub().then(x=>Object.keys(x).length)")==2 and len(CALLS)==1)
    chk('cgG(1).lvl',pg.evaluate("cgG(1).lvl")==1)
    chk('cgMode(1) rm',pg.evaluate("cgMode(1).rm")==1 and pg.evaluate("cgMode(2).here")==1 and pg.evaluate("cgMode(99).lvl")==0)
    d=pg.evaluate("cgDist(35.6892,51.389,36.2605,59.6168)")
    chk('cgDist Tehran-Mashhad %s'%d,730<d<750 and pg.evaluate("cgDist(1,1,1,1)")==0)
    chk('cgEta',pg.evaluate("cgEta(5).w")==60 and pg.evaluate("cgEta(25).m")==60)
    chk('cgFuzz',pg.evaluate("cgFuzz(25.34567)")==25.35)
    chk('cgOpen day',pg.evaluate("cgOpen({o:'09:00',c:'21:00',off:[5]},new Date(2026,10,21,10,0))")==1)
    chk('cgOpen night closed',pg.evaluate("cgOpen({o:'09:00',c:'21:00',off:[5]},new Date(2026,10,21,22,0))")==0)
    chk('cgOpen off day',pg.evaluate("cgOpen({o:'09:00',c:'21:00',off:[5]},new Date(2026,10,20,10,0))")==0)
    chk('cgOpen overnight',pg.evaluate("cgOpen({o:'20:00',c:'02:00'},new Date(2026,10,21,1,0))")==1)
    chk('cgOpen unknown',pg.evaluate("cgOpen({})")==-1 and pg.evaluate("cgOpen(null)")==-1)
    n=len(CALLS)
    r=pg.evaluate("cgSave({lat:'۲۵.۳۰۱',lng:'61.6',acc:'n',rm:1,ad:'x'.repeat(300),hrs:{o:'09:00',c:'21:00'}}).then(r=>r&&r.ok)")
    a=CALLS[-1][1] if len(CALLS)>n else {}
    chk('cgSave sent',r==1 and a.get('lat')==25.301 and a.get('acc')=='n' and a.get('rm')==1 and len(a.get('ad',''))==160)
    chk('cgSave bad lat -> null',pg.evaluate("cgNum('abc',90)")is None and pg.evaluate("cgNum('95',90)")is None)
    chk('cache stale after save',pg.evaluate("cgCache().t")==0)
    chk('cgMine',pg.evaluate("cgMine().then(x=>x&&x.lvl)")==1)
    chk('no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
    br.close()
print('ERRORS',errs)
