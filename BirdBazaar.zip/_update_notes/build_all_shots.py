import html,base64,re,json
from playwright.sync_api import sync_playwright
src=open('/tmp/bb/www/index.html',encoding='utf8').read()
MOCK=r"""<script>(function(){
const B=[{id:7,name:'غرفه ارزن',phone:'09120001122',city:'سراوان',n:2,views:48,bio:'دان و ارزن مرغوب'},{id:8,name:'غرفه کتان',phone:'09123334455',city:'تهران',n:1,views:20,bio:''}];
const P=[{id:11,b:7,d:{type:'plain',name:'ارزن سفید ممتاز',emoji:'🌾',cat:'دان',price:50000,imgs:[],wh:{on:0},rt:{on:0}}},{id:12,b:7,d:{type:'plain',name:'کتان فرادما',emoji:'🌱',cat:'دان',price:80000,imgs:[],wh:{on:0},rt:{on:0}}},{id:13,b:8,d:{type:'plain',name:'کتان درجه یک',emoji:'🌱',cat:'دان',price:70000,imgs:[],wh:{on:0},rt:{on:0}}}];
const DB=[{id:1,b:7,cu:'ali',s:'u',body:'سلام، ارزن سفید دارید؟',k:'t'},{id:2,b:7,cu:'ali',s:'b',body:'سلام، بله موجود است 🌾',k:'t'},{id:3,b:7,cu:'ali',s:'b',body:'ارزن سفید ممتاز',k:'p',x:{id:11}},{id:4,b:7,cu:'ali',s:'u',body:'عالی، ۱۰ عدد می‌خوام',k:'t'},{id:5,b:8,cu:'ali',s:'b',body:'کتان تازه رسید',k:'t'},{id:6,b:7,cu:'reza',s:'u',body:'ارسال به مشهد دارید؟',k:'t'}];
const SEEN={};const OWN={7:'bob',8:'sara'};
const ok=o=>Promise.resolve(new Response(JSON.stringify(o),{status:200,headers:{'Content-Type':'application/json'}}));
function capp(d){const op=d.op,u=d.u,a=d.a||{};
 if(op=='ccount'){let n=0;DB.forEach(m=>{if(m.cu==u&&m.s=='b'&&m.id>(SEEN[m.b+'|'+m.cu+'|u']||0))n++;if(OWN[m.b]==u&&m.s=='u'&&m.id>(SEEN[m.b+'|'+m.cu+'|b']||0))n++});return{ok:1,n}}
 if(op=='clist'){const k={};DB.forEach(m=>{if(m.cu==u||OWN[m.b]==u)k[m.b+'|'+m.cu]=m});const l=Object.keys(k).map(key=>{const m=k[key],r=m.cu==u?'u':'b';const un=DB.filter(q=>q.b==m.b&&q.cu==m.cu&&q.s!=r&&q.id>(SEEN[m.b+'|'+m.cu+'|'+r]||0)).length;return{b:m.b,cu:m.cu,lid:m.id,r,lb:m.body,lk:m.k,ls:m.s,lt:new Date().toISOString(),un}}).sort((x,y)=>y.lid-x.lid);return{ok:1,l}}
 if(op=='cmsgs'||op=='csend'){let s,cu;if(OWN[a.b]==u){s='b';cu=a.cu;if(cu==u)return{err:'self'}}else{s='u';cu=u}
  if(op=='cmsgs'){const all=DB.filter(m=>m.b==a.b&&m.cu==cu);if(all.length)SEEN[a.b+'|'+cu+'|'+s]=Math.max(...all.map(m=>m.id));const ps=SEEN[a.b+'|'+cu+'|'+(s=='u'?'b':'u')]||0;return{ok:1,ps,m:all.filter(m=>m.id>(a.after||0)).map(m=>({id:m.id,s:m.s,b:m.body,k:m.k,x:m.x,t:new Date().toISOString()}))}}
  DB.push({id:DB.length+1,b:+a.b,cu,s,body:a.body,k:a.k||'t',x:a.x});return{ok:1,id:DB.length}}
 return{err:'unknown'}}
window.fetch=function(url,o){try{const d=JSON.parse((o&&o.body)||'{}');if(/rpc\/capp/.test(url))return ok(capp(d));if(/rpc\/bapp/.test(url)){if(d.op=='bpublic')return ok({ok:1,booths:B,prods:P});if(d.op=='bme'||d.op=='blogin')return ok({ok:1,booth:Object.assign({},B[0],{status:'active',logo:'',cover:''}),prods:P.filter(p=>p.b==7).map(p=>({id:p.id,d:p.d,s:'on',t:new Date().toISOString()})),days:[0,1,2,3,4,5,6].map(i=>({day:new Date(Date.now()-(6-i)*864e5).toISOString().slice(0,10),n:[3,5,2,8,6,9,12][i]}))});if(d.op=='bords')return ok({ok:1,orders:[{id:2,name:'علی رضایی',phone:'09121112233',addr:'سراوان، خیابان امام',lines:[{n:'ارزن سفید ممتاز',q:10,u:'عدد',pr:50000,t:500000,m:'r'}],total:500000,s:'new',t:new Date().toISOString()},{id:1,name:'رضا احمدی',phone:'09124445566',addr:'مشهد',lines:[{n:'کتان فرادما',q:5,u:'عدد',pr:80000,t:400000,m:'r'}],total:400000,s:'done',t:new Date(Date.now()-864e5).toISOString()}]});return ok({ok:1})}
if(/rpc\/mapp/.test(url)){if(d.op=='mcount')return ok({ok:1,n:2,adm:0,main:0,booth:1});if(d.op=='minbox')return ok({ok:1,in:[{id:1,f:'مدیریت',g:'all',t:new Date().toISOString(),b:'سلام دوستان؛ ویترین جدید با غرفه‌های تازه فعال شد 🌿',r:0},{id:2,f:'مدیریت',g:'booth',t:new Date(Date.now()-864e5).toISOString(),b:'غرفه‌داران عزیز، لطفاً قیمت محصولات را به‌روز کنید.',r:1}],sent:[],adm:0,main:0,booth:1});return ok({ok:1})}}catch(e){}return Promise.reject(new Error('demo'))};
})();</script>"""
app=src.replace('<head>','<head>'+MOCK,1)
assert MOCK in app
open('demo_app.html','w',encoding='utf8').write(app)

SEED="S.me='%s';S.pw='1';S.role='user';BT.ok=1;BT.t=Date.now()+1e9;"
shots=[]
def sh(pg,name,who,js,wait=700,full=False):
    try:
        pg.evaluate(SEED%who+js)
    except Exception as e:print('ERR',name,str(e)[:120])
    pg.wait_for_timeout(wait);pg.screenshot(path='shots/a_%s.png'%name);shots.append(name)
with sync_playwright() as p:
    br=p.chromium.launch()
    ctx=br.new_context(viewport={'width':360,'height':740},locale='fa-IR');pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    pg.goto('file:///tmp/bb/_update_notes/demo_app.html');pg.wait_for_timeout(1500)
    pg.evaluate("bpull()");pg.wait_for_timeout(400)
    sh(pg,'home','ali',"go({tab:0,v:null,ed:0})")
    sh(pg,'store','ali',"go({tab:1,v:null,sub:0})")
    sh(pg,'store_booths','ali',"go({tab:1,v:null,sub:2})")
    sh(pg,'booth','ali',"btNav({v:'bts',id:7})")
    sh(pg,'product','ali',"btNav({v:'btp',id:11})")
    sh(pg,'invoice','ali',"S.binv={bn:'غرفه ارزن',dt:'۱۴۰۵/۸/۲۳',n:'علی رضایی',p:'09121112233',a:'سراوان، خیابان امام',lines:[{n:'ارزن سفید ممتاز',q:10,u:'عدد',pr:50000,t:500000,m:'r'}],total:500000,bp:'09120001122'};btNav({v:'btinv'})")
    sh(pg,'ads','ali',"go({tab:2,v:null})")
    sh(pg,'forum','ali',"go({tab:3,v:null})",1200)
    sh(pg,'profile','ali',"go({tab:4,v:null})")
    sh(pg,'chats','ali',"cListOpen()",900)
    sh(pg,'chat','ali',"cOpen(7,'ali','u')",900)
    pg.click('button[data-a=ct_pp]');pg.wait_for_timeout(400);pg.screenshot(path='shots/a_pick.png');shots.append('pick');pg.evaluate("cl()")
    sh(pg,'inbox','ali',"msOpen()",900)
    sh(pg,'owner','bob',"BT.u='bob';BT.p='1';BM=null;S.btt='d';btNav({v:'btm'})",900)
    sh(pg,'owner_orders','bob',"S.btt='o';BOR=null;btRe()",900)
    sh(pg,'admin_edit','admin',"S.role='admin';S.pm=['all'];S.at=tabsOf()[0];go({tab:0,v:null,ed:1})",900)
    sh(pg,'theme','admin',"S.role='admin';S.pm=['all'];go({tab:0,v:null,ed:0});thSheet()",600)
    pg.evaluate("cl();thSet(thKey(),{m:'g',c:'b'});");pg.wait_for_timeout(600);pg.screenshot(path='shots/a_glass.png');shots.append('glass')
    pg.evaluate("thSet(thKey(),{m:'n'})")
    print('errs',errs);br.close()
print(shots)
