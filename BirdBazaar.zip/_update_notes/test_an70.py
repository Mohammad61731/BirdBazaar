# تست 1.9.318: AN70 حرکت نرم مرتب‌سازی (anShift / anMv)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("window.__an=0;const o=Element.prototype.animate;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};0")
            pg.evaluate("const g=document.createElement('div');g.id='tg';g.style.cssText='position:fixed;top:60px;left:0;width:200px;z-index:9';g.innerHTML=[1,2,3].map(i=>'<div class=\"rw\" style=\"height:40px\"><button data-a=\"tmv\">'+i+'</button></div>').join('');document.body.appendChild(g)")
            pg.evaluate("window.__an=0;anShift(document.getElementById('tg'),()=>{const g=document.getElementById('tg');g.insertBefore(g.children[2],g.children[0])})")
            n=pg.evaluate("window.__an");order=pg.evaluate("[...document.querySelectorAll('#tg button')].map(b=>b.textContent).join('')")
            chk(t+'anShift order changed',order=='312')
            if rm=='no-preference': chk(t+'anShift animates moved rows',n>=2)
            else: chk(t+'reduced: anShift no anim',n==0)
            pg.evaluate("window.__an=0;anMv(anRows('tmv','.rw'),0,1,()=>{const g=document.getElementById('tg');g.insertBefore(g.children[1],g.children[0])})")
            n2=pg.evaluate("window.__an");order=pg.evaluate("[...document.querySelectorAll('#tg button')].map(b=>b.textContent).join('')")
            chk(t+'anMv order changed',order=='132')
            if rm=='no-preference': chk(t+'anMv animates 2 rows',n2==2)
            else: chk(t+'reduced: anMv no anim',n2==0)
            pg.evaluate("D.cms.BN=[{t:'a',k:'x'},{t:'b',k:'y'}];S.v=null;S.tab=0")
            r=pg.evaluate("(()=>{try{mvb('0:1');return D.cms.BN.map(x=>x.t).join('')}catch(e){return 'ERR '+e}})()")
            chk(t+'mvb swaps banners',r=='ba')
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
