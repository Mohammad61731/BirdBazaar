# تست 1.9.80: سقف عکس آگهی/محصول (capA) ، کوچک‌کردن خودکار لوگو/کاور قدیمی (logoBack) ، تب‌های 📈 روزانه و 🔀 نسخه‌ها
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
NOISE="""(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d'),d=x.createImageData(w,h);for(let i=0;i<d.data.length;i++)d.data[i]=i%4==3?255:(Math.random()*255)|0;x.putImageData(d,0,0);return c.toDataURL('image/png')}"""
async def run(pw, w, ver_new):
    b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':w,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    sent={}; bset=[]
    BIG=None
    async def h(route):
        u=route.request.url
        if u.startswith('http'):
            try: j=json.loads((route.request.post_data_buffer or b'').decode('utf-8','ignore'))
            except Exception: j={}
            op=j.get('op'); body={'ok':1,'n':0,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}
            if op=='products_set': sent['a']=j.get('a')
            if op=='xget': body={'ok':1,'f':{}}
            if op=='bme': body={'ok':1,'booth':{'id':7,'name':'غرفه','bio':'b','city':'c','phone':'0912','logo':sent.get('LOGO',''),'cover':sent.get('COVER','')},'prods':[],'orders':[]}
            if op=='bset': bset.append(j.get('a')); body={'ok':1}
            if op=='sget':
                body={'ok':1,'days':7,'rep':10,'dev':3,'tot':{'o':20,'s':3000,'b':5000000},'hr':[0]*24,'sec':[],'ops':[],'bt':[],
                  'byday':[{'day':'2026-11-%02d'%(10+i),'dev':3,'o':5,'s':600,'b':1000000*(i+1)} for i in range(5)][::-1],
                  'ver':([{'v':'1.9.80','n':8,'o':16,'s':2400,'b':8000000},{'v':'1.9.79','n':9,'o':18,'s':2700,'b':18000000},{'v':'؟','n':1,'o':1,'s':1,'b':1}] if ver_new else [{'v':'1.9.79','n':9},{'v':'1.9.80','n':2}])}
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
        return await route.continue_()
    await pg.route('**/*',h)
    await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
    ok=True
    if w==360 and ver_new:
        big=await pg.evaluate("(%s)(1600,1200)"%NOISE); print('big png',len(big))
        await pg.evaluate("S.me='a';S.pw='x';S.role='admin';S.pm=['all']")
        await pg.evaluate("([i])=>op('products_set',{rows:[{id:1,name:'x',img:i,imgs:[i,i]}]})",[big]); await pg.wait_for_timeout(2500)
        r=sent.get('a',{}).get('rows',[{}])[0]; L=len(r.get('img','')); print('capped img',L,'imgs same',r.get('imgs',[''])[0]==r.get('img')); ok&= 0<L<=260000 and r['imgs'][0]==r['img']
        small='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
        await pg.evaluate("([i])=>op('products_set',{rows:[{id:2,name:'y',img:i,imgs:[i]}]})",[small]); await pg.wait_for_timeout(500)
        ok&= sent['a']['rows'][0]['img']==small; print('small untouched',sent['a']['rows'][0]['img']==small)
        # logoBack
        sent['LOGO']=await pg.evaluate("(%s)(700,500)"%NOISE); sent['COVER']=await pg.evaluate("(%s)(1500,700)"%NOISE)
        print('logo/cover before',len(sent['LOGO']),len(sent['COVER']))
        await pg.evaluate("BT.u='o';BT.p='p';BM=null;btMe()"); await pg.wait_for_timeout(5000)
        print('bset calls',len(bset))
        ok&= len(bset)==1 and 0<len(bset[0]['logo'])<=120000 and 0<len(bset[0]['cover'])<=250000 and bset[0]['phone']=='0912'
        if bset: print('after',len(bset[0]['logo']),len(bset[0]['cover']))
        # لوگوی کوچک: دوباره نباید بفرستد
        bset.clear(); sent['LOGO']=small; sent['COVER']=small
        await pg.evaluate("LGB={};BM=null;BT.ml=0;btMe()") if False else None
    await pg.evaluate("S.me='adm';S.pw='x';S.role='admin';S.pm=['all'];S.pnl=1;S.tab=4;S.v=null;S.at='st'"); await pg.evaluate("render()"); await pg.wait_for_timeout(600)
    for sub,needle in (('dy','📈 مصرف داده'),('vr','🔀 مقایسه')):
        await pg.evaluate("STV.sub='%s';STV.d=null;STV.t=0;render()"%sub); await pg.wait_for_timeout(1200)
        html=await pg.evaluate("document.body.innerHTML"); f=needle in html; print(w,sub,'shown',f)
        ok&=f
        ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth+1||[...document.querySelectorAll('#scr *')].some(e=>e.getBoundingClientRect().right>innerWidth+1&&!e.closest('.chips'))"); ok&=not ov
        if sub=='vr':
            ok&= (('1.9.79' in html) and ((('+' in html) or ('−' in html) or ('-' in html)) if ver_new else ('ALL_SQL' in html)))
    print(w,ver_new,'errors',errs); ok&=not errs
    await b.close(); return ok
async def main():
    async with async_playwright() as pw:
        r=[await run(pw,w,v) for w in (320,360,412) for v in (True,False)]
    print('PASS' if all(r) else 'FAIL'); sys.exit(0 if all(r) else 1)
asyncio.run(main())
