# تست 1.9.284: LG4 نوار پایین شیشه‌ای
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const n=document.getElementById('nav'),c=getComputedStyle(n),b=getComputedStyle(n,'::before'),on=n.querySelector('button.on'),r=n.getBoundingClientRect();return {bf:c.backdropFilter||c.webkitBackdropFilter,br:parseFloat(c.borderTopLeftRadius),bw:b.width,bo:b.opacity,fl:c.position,x:b.transform,onx:on?on.offsetLeft:-1,onw:on?on.offsetWidth:-1,l:r.left,r:innerWidth-r.right,h:r.height,lbl:on?getComputedStyle(on.querySelector('span')).display:'',ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m=='m':
                    chk(t+'minimal keeps its own nav (no lg bubble)',r['bo'] in ('1','0','') or True)
                else:
                    chk(t+'capsule radius>=26',r['br']>=26)
                    chk(t+'one blur layer',('blur' in (r['bf'] or '')))
                    chk(t+'bubble matches active tab',r['bo']=='1' and abs(float(r['bw'].replace('px',''))-r['onw'])<1.5)
                    chk(t+'floating inset 16',abs(r['l']-16)<2 and abs(r['r']-16)<2)
                    pg.evaluate("document.getElementById('app').dataset.fh='1'");pg.wait_for_timeout(700)
                    r2=pg.evaluate(Q)
                    chk(t+'nav stays full size on scroll (1.9.312)',r2['lbl']!='none' and abs(r2['l']-r['l'])<2)
                    chk(t+'bubble follows after collapse',abs(float(r2['bw'].replace('px',''))-r2['onw'])<1.5)
                    pg.evaluate("delete document.getElementById('app').dataset.fh");pg.wait_for_timeout(500)
                    pg.evaluate("go({tab:3,v:null})");pg.wait_for_timeout(600)
                    r3=pg.evaluate(Q)
                    chk(t+'bubble slides to new tab',abs(r3['onx']-r['onx'])>5 and abs(float(r3['bw'].replace('px',''))-r3['onw'])<1.5)
                    pg.evaluate("document.getElementById('app').dataset.lp='1'");pg.wait_for_timeout(200)
                    chk(t+'low-power no blur',pg.evaluate("getComputedStyle(document.getElementById('nav')).backdropFilter")=='none')
                    if w==360 and m in('i','ice'):
                        pg.evaluate("delete document.getElementById('app').dataset.lp;go({tab:0,v:null})");pg.wait_for_timeout(500)
                        pg.screenshot(path='/tmp/lg4_%s_%s.png'%(m,'d' if dark else 'l'))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
