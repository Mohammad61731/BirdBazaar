import sys,re
from playwright.sync_api import sync_playwright
root=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
E=[]
s=open(root+'/www/index.html',encoding='utf8').read()
for k in ('class="spj"','class="spk"','spOut(sp)','greetT','gOk','1.9.232 PX7'):
    if k not in s: E.append('FAIL missing '+k)
if "APPV='1.9.232'" not in s: E.append('FAIL APPV')
if 'bp-v19232' not in open(root+'/www/sw.js').read(): E.append('FAIL sw')
with sync_playwright() as p:
    b=p.chromium.launch()
    for w in (320,360,412):
        pg=b.new_page(viewport={'width':w,'height':700});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)))
        pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith('file:') else r.abort())
        pg.add_init_script("window.fetch=()=>new Promise(()=>{})")
        pg.goto('file://'+root+'/www/index.html');pg.wait_for_timeout(800)
        if not pg.evaluate("!!document.querySelector('#spl .spj')&&!!document.querySelector('#spl .spk')"):E.append('FAIL spl '+str(w))
        if not pg.evaluate("document.documentElement.scrollWidth<=innerWidth"):E.append('FAIL overflow '+str(w))
        if not pg.evaluate("/(صبح|روز|عصر|شب) بخیر/.test(greetT())"):E.append('FAIL greet '+str(w))
        if er:E.append('FAIL err '+str(er))
    b.close()
print('ERRORS',E)
