# تست 1.9.124: اکسپلور (cfg.ex)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            D0="dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}"
            pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'تهران'}];BT.prods=[{id:11,b:1,s:'on',d:{name:'دان ارزان',type:'plain',price:50000,emoji:'🌰',imgs:[],cat:'دان'}},{id:12,b:1,s:'on',d:{name:'دان گران',type:'plain',price:900000,emoji:'🌰',imgs:[],cat:'دان'}}];BT.ok=1;BT.t=Date.now();D.products=[{id:901,name:'ویتامین',cat:'مکمل',price:200000,img:'',vol:{},%s},{id:902,name:'مکمل',cat:'مکمل',price:70000,img:'',vol:{},%s}];S.role=null;go({tab:1,v:null,sv:'a',prf:0})"%(D0,D0))
            pg.wait_for_timeout(400)
            chk(t+'nav has 5 buttons',pg.locator('#nav button').count()==5)
            chk(t+'explore tab highlighted',pg.evaluate("document.querySelector('#nav button.on span').textContent")=='اکسپلور')
            chk(t+'3 segment tabs',pg.locator('#scr .seg button').count()==3)
            n0=pg.evaluate("document.querySelectorAll('#pgrid .pc,#pgrid .bxc').length")
            pg.click('[data-a=prf][data-v="1"]');pg.wait_for_timeout(250)
            n1=pg.evaluate("[...document.querySelectorAll('#pgrid .pc,#pgrid .bxc')].map(e=>e.textContent).join('|')")
            chk(t+'price <100k keeps only cheap (%s)'%n1,('ارزان' in n1 or 'مکمل' in n1) and 'گران' not in n1 and 'ویتامین' not in n1)
            pg.click('[data-a=prf][data-v="3"]');pg.wait_for_timeout(250)
            n3=pg.evaluate("[...document.querySelectorAll('#pgrid .pc,#pgrid .bxc')].map(e=>e.textContent).join('|')")
            chk(t+'price >500k keeps only expensive',('دان گران' in n3) and 'ویتامین' not in n3)
            pg.click('[data-a=prf][data-v="0"]');pg.wait_for_timeout(250)
            chk(t+'reset shows all',pg.evaluate("document.querySelectorAll('#pgrid .pc,#pgrid .bxc').length")==n0)
            pg.click('#scr .seg button:nth-child(1)');pg.wait_for_timeout(300)
            chk(t+'booths tab',pg.evaluate("S.tab==1&&S.sv=='b'")and pg.locator('#scr .seg button.on').inner_text().find('غرفه')>=0)
            pg.click('#scr .seg button:nth-child(3)');pg.wait_for_timeout(300)
            chk(t+'ads tab keeps explore highlighted + seg',pg.evaluate("S.tab==2")and pg.locator('#scr .seg button.on').inner_text().find('آگهی')>=0 and pg.evaluate("document.querySelector('#nav button.on span').textContent")=='اکسپلور')
            pg.click('#scr .seg button:nth-child(2)');pg.wait_for_timeout(300)
            chk(t+'products tab from ads',pg.evaluate("S.tab==1&&S.sv=='a'"))
            chk(t+'no horizontal overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            if w==360 and not dark: pg.screenshot(path='../shots/ex360.png')
            pg.evaluate("D.cfg.ex=0;go({tab:1,v:null,sv:'a',prf:2})");pg.wait_for_timeout(250)
            chk(t+'ex=0 old nav (6) and old seg, no price chips, no filter',pg.locator('#nav button').count()==6 and pg.locator('[data-a=bt_sv]').count()==3 and pg.locator('[data-a=prf]').count()==0 and pg.evaluate("document.querySelectorAll('#pgrid .pc').length")==2)
            ctx.close()
    br.close()
print('ERRORS',errs)
