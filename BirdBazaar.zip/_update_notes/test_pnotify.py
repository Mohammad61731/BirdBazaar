# تست مورد ۱۵: اعلان آزاد ادمین (فقط اعلان گوشی؛ pnapp)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            calls=[]; msend=[]; st={'mode':'ok'}
            async def h(route):
                u=route.request.url; bd=route.request.post_data or ''
                if not u.startswith('http'): return await route.continue_()
                hd={'access-control-allow-origin':'*'}
                if u.endswith('/rpc/pnapp'):
                    calls.append(json.loads(bd))
                    if st['mode']=='404': return await route.fulfill(status=404,headers=hd,body='{}')
                    body={'err':'nouser'} if st['mode']=='nouser' else {'ok':1,'n':5,'reg':3 if st['mode']=='ok' else 0}
                    return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
                if u.endswith('/rpc/mapp') and '"msend"' in bd: msend.append(bd)
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'in':[],'sent':[]}))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            await pg.evaluate("S.me='adm';S.pw='x';MS.main=1;MS.adm=1;msWrite()"); await pg.wait_for_timeout(300)
            vis=lambda i: pg.evaluate("(i)=>getComputedStyle(document.getElementById(i)).display",i)
            chk('%d title hidden by default'%w, await vis('ms_tl')=='none')
            await pg.select_option('#ms_k','nt'); chk('%d title shown for nt'%w, await vis('ms_tl')!='none')
            chk('%d maxlength 120'%w, await pg.evaluate("document.getElementById('ms_b').maxLength")==120)
            chk('%d no overflow'%w, not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.select_option('#ms_to','g:all'); await pg.fill('#ms_t','تخفیف'); await pg.fill('#ms_b','متن آزمون')
            await pg.click('[data-a=ms_s]'); await pg.wait_for_timeout(500)
            chk('%d pnapp called, group all'%w, len(calls)==1 and calls[0]['op']=='pnotify' and calls[0]['a'].get('g')=='all' and calls[0]['a']['title']=='تخفیف' and calls[0]['a']['b']=='متن آزمون')
            chk('%d no inbox message created'%w, not msend)
            # یک کاربر
            await pg.evaluate("msWrite()"); await pg.wait_for_timeout(200)
            await pg.select_option('#ms_k','nt'); await pg.select_option('#ms_to','u'); await pg.fill('#ms_u','ali'); await pg.fill('#ms_b','سلام'); st['mode']='nouser'
            await pg.click('[data-a=ms_s]'); await pg.wait_for_timeout(400)
            chk('%d single user sent to=ali'%w, len(calls)==2 and calls[1]['a'].get('to')=='ali' and 'g' not in calls[1]['a'])
            t=await pg.evaluate("document.body.innerText"); chk('%d nouser toast'%w,'چنین کاربری' in t)
            # مسیر عادی پیام هنوز کار می‌کند
            await pg.evaluate("msWrite()"); await pg.wait_for_timeout(200)
            await pg.select_option('#ms_to','g:booth'); await pg.fill('#ms_b','پیام عادی'); await pg.click('[data-a=ms_s]'); await pg.wait_for_timeout(400)
            chk('%d normal msend still works'%w, len(msend)==1 and len(calls)==2)
            chk('%d no errors %s'%(w,errs), not errs)
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
