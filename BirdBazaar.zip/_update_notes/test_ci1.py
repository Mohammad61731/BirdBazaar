# تست 1.9.386 D1/140+141: کلید ci ، قالب و کد سبد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_cvt');XF.ci=0;D.cart=[{id:(D.products[0]||{id:1}).id,q:2}]")
        chk(t+'off: no box',pg.evaluate("ciBox()")=='' and 'cvs' not in pg.evaluate("cartV0()"))
        pg.evaluate("XF.ci=1");h=pg.evaluate("cartV0()");chk(t+'on: buttons in cart','cvs' in h and 'cvc' in h)
        pg.on('dialog',lambda d:d.accept('خرید ماهانه'))
        clk(pg,'cvs','');chk(t+'template saved',pg.evaluate("ciTpl().length")==1)
        pg.evaluate("D.cart=[]");chk(t+'empty cart shows template','cvr' in pg.evaluate("cartV0()"))
        clk(pg,'cvr','0');chk(t+'restore adds item',pg.evaluate("D.cart.length")>=1)
        pg.evaluate("window.__c=ciCode()");chk(t+'code roundtrip',pg.evaluate("JSON.stringify(ciDec(__c))==JSON.stringify(ciLines())"))
        chk(t+'bad code rejected',pg.evaluate("ciDec('xx')===null"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
