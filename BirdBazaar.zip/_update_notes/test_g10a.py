# تست 1.9.427 G10-a: همسایه/نشانه/ساعت ترجیحی در سبد غرفه (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0;localStorage.removeItem('bp_dlv')")
        chk(t+'off -> nothing',pg.evaluate("pnDlTxt('g')===''&&pnDlH(1)===''"))
        pg.evaluate("XF.pn=1")
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(200)
        click('pnnb')
        chk(t+'neighbor on',pg.evaluate("pnDl().n==1&&pnDlTxt('g').includes('همسایه')&&pnDlTxt('h')===''"))
        click('pnnb')
        chk(t+'neighbor off',pg.evaluate("!pnDl().n&&pnDlTxt('g')===''"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('نزدیک مسجد <b> پلاک ۱۲'))");click('pnlm')
        chk(t+'landmark sanitized',pg.evaluate("pnDl().l=='نزدیک مسجد b پلاک ۱۲'&&pnDlTxt('g').includes('📍 نزدیک مسجد')"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('۱۸-۲۰'))");click('pnwt')
        chk(t+'preferred time (Persian digits)',pg.evaluate("pnDl().w.f==18&&pnDl().w.t==20&&pnDlTxt('g').includes('ترجیحاً')"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb('abc'))");click('pnwt')
        chk(t+'bad time keeps old',pg.evaluate("pnDl().w.f==18"))
        pg.evaluate("void(window.bzAsk=(m,d,cb)=>cb(''))");click('pnwt');click('pnlm')
        chk(t+'empty clears both',pg.evaluate("!pnDl().w&&!pnDl().l"))
        pg.evaluate("localStorage.setItem('bp_dlv',JSON.stringify({w:{f:5,t:5},l:'<x>'}))")
        chk(t+'bad stored ignored',pg.evaluate("!pnDl().w&&pnDl().l=='x'"))
        pg.evaluate("localStorage.setItem('bp_dlv','{bad')")
        chk(t+'broken storage safe',pg.evaluate("pnDl().d===0&&pnDlTxt('g')===''"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div class=wrap>'+pnDlH(1)+'</div>'")
        chk(t+'chips no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
