# تست 1.9.419 G7-a: فیلتر سفارش‌های من (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0;MO.l=[{id:1,st:'new',it:[{n:'a',q:1}],tt:10},{id:2,st:'done',it:[],tt:5},{id:3,st:'x',it:[],tt:1}]")
        chk(t+'off -> empty bar, no filter',pg.evaluate("pnMoBar()===''&&pnMoF({st:'x'})===true"))
        pg.evaluate("XF.pn=1;PNMF=''")
        chk(t+'4 chips',pg.evaluate("(pnMoBar().match(/<button/g)||[]).length==4"))
        def click(v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pnmf';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%v);pg.wait_for_timeout(200)
        click('done')
        chk(t+'filter done',pg.evaluate("PNMF==='done'&&pnMoF({st:'done'})&&!pnMoF({st:'new'})&&pnMoF({st:'done'})"))
        chk(t+'render keeps only done',pg.evaluate("(()=>{const h=moV();return h.includes('#۱٬۰۰۲')&&!h.includes('#۱٬۰۰۱')&&!h.includes('#۱٬۰۰۳')})()"))
        click('zzz')
        chk(t+'bad value -> all',pg.evaluate("PNMF===''&&moV().includes('#۱٬۰۰۱')&&moV().includes('#۱٬۰۰۳')"))
        pg.evaluate("MO.l=[{id:1,st:'new',it:[],tt:1}];PNMF='x'")
        chk(t+'empty category note',pg.evaluate("pnMoBar().includes('سفارشی در این دسته نیست')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
