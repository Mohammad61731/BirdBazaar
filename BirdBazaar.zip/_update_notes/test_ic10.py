# تست 1.9.216: انتخاب گروهی آیکن (IC10)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.effect_mandelbrot((400,400),(-2,-1.5,1,1.5),30).convert('RGBA').save('/home/claude/w/tmp/i10.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        for i in range(4):
            pg.evaluate("icPick('nav.home')");pg.wait_for_timeout(200)
            with pg.expect_file_chooser() as fc: pg.click('[data-a=ica]')
            fc.value.set_files('/home/claude/w/tmp/i10.png');pg.wait_for_timeout(700)
        ks=pg.evaluate("Object.keys(ikLib)");chk(f'{w}: 4 icons',len(ks)==4)
        pg.evaluate("icSheet()");pg.wait_for_timeout(300)
        chk(f'{w}: group headers',pg.locator('[data-a=icpg]').count()==5 and pg.locator('[data-a=icrg]').count()==5)
        pg.click('[data-a=icpg][data-v="دسترسی سریع خانه"]');pg.wait_for_timeout(500)
        chk(f'{w}: pack list',pg.locator('[data-a=icpk]').count()>=1)
        pg.click('[data-a=icpk]');pg.wait_for_timeout(500)
        s=pg.evaluate("ikSel()")
        chk(f'{w}: 4 qa slots set in order',all(s.get(x)==k for x,k in zip(['qa.disc','qa.ads','qa.booth','qa.birds'],ks)) and 'nav.home' not in s and 'fav.on' not in s)
        pg.evaluate("icSheet()");pg.click('[data-a=icrg][data-v="دسترسی سریع خانه"]');pg.wait_for_timeout(500)
        s=pg.evaluate("ikSel()")
        chk(f'{w}: group reset',not any(k.startswith('qa.') for k in s))
    br.close()
print('ERRORS',errs)
