# تست 1.9.394 G1: کلید pn (پنل جدید ، کیت ساده)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.pn=0;localStorage.removeItem('bp_pb')")
        chk(t+'off: pnOn false',pg.evaluate("pnOn()")==False)
        chk(t+'off: section muted',pg.evaluate("pnSec().includes('خاموش')"))
        clk(pg,'pnb');chk(t+'off: pnb does nothing',pg.evaluate("localStorage.getItem('bp_pb')")is None)
        pg.evaluate("XF.pn=1")
        chk(t+'on: kit html',pg.evaluate("(()=>{const s=pnSec();return s.includes('pnkT')&&s.includes('pnkS')&&s.includes('pnkW')&&s.includes('pnkM')&&s.includes('pnkC')&&s.includes('pnkR')})()"))
        clk(pg,'pnb');chk(t+'big on',pg.evaluate("document.documentElement.dataset.pb")=='1')
        clk(pg,'pnb');chk(t+'big off',pg.evaluate("document.documentElement.dataset.pb")=='0')
        clk(pg,'pnd','1');clk(pg,'pnd','1');chk(t+'step 2',pg.evaluate("S.pnd")==2)
        for i in range(8): clk(pg,'pnd','1')
        chk(t+'step capped 4',pg.evaluate("S.pnd")==4)
        for i in range(8): clk(pg,'pnd','-1')
        chk(t+'step floor 0',pg.evaluate("S.pnd")==0)
        clk(pg,'pnr');chk(t+'refresh stamps',pg.evaluate("!!S.pnt"))
        pg.evaluate("S.sx='pn';S.tab=4;render();document.getElementById('scr').insertAdjacentHTML('afterbegin',pnSec())");pg.wait_for_timeout(250)
        chk(t+'settings page shows kit',pg.evaluate("document.querySelectorAll('#scr .pnkT').length")>=2)
        chk(t+'steps 5',pg.evaluate("document.querySelectorAll('#scr .pnkp').length")==5)
        chk(t+'tile >=44px',pg.evaluate("[...document.querySelectorAll('#scr .pnkT')].every(e=>e.getBoundingClientRect().height>=44)"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        clk(pg,'pnb');pg.wait_for_timeout(200)
        chk(t+'big: no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        if w==360 and sch=='light':
            pg.screenshot(path='/tmp/pn_360.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
