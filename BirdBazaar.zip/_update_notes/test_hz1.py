# تست 1.9.471: «حاضرم» غرفه‌دار (کلید hz)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=1;XF.hz=0")
        pg.evaluate("cgSaveC({t:Date.now(),g:{7:{id:7,hrs:{o:'00:00',c:'00:01'}}}})")
        chk(f'{w}: closed without hz',pg.evaluate("dtClosed(7)===true"))
        chk(f'{w}: off -> btn empty',pg.evaluate("hzBtn({})===''"))
        pg.evaluate("XF.hz=1")
        chk(f'{w}: on -> 3 buttons',pg.evaluate("(hzBtn({}).match(/data-cg=\"hz\"/g)||[]).length===3"))
        chk(f'{w}: active -> cancel btn',pg.evaluate("(hzBtn({pr:Date.now()+36e5}).match(/data-cg=\"hz\"/g)||[]).length===4"))
        chk(f'{w}: dtWhen shows present',pg.evaluate("dtWhen({pr:Date.now()+36e5}).includes('حاضر')"))
        chk(f'{w}: expired not present',pg.evaluate("!dtWhen({o:'08:00',c:'20:00',pr:Date.now()-1}).includes('الان حاضر')"))
        pg.evaluate("cgSaveC({t:Date.now(),g:{7:{id:7,hrs:{o:'00:00',c:'00:01',pr:Date.now()+36e5}}}})")
        chk(f'{w}: present overrides closed',pg.evaluate("dtClosed(7)===false"))
        pg.evaluate("XF.hz=0")
        chk(f'{w}: key off -> closed again',pg.evaluate("dtClosed(7)===true"))
        pg.evaluate("XF.hz=1;document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+hzBtn({})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    br.close()
print('ERRORS',errs)
