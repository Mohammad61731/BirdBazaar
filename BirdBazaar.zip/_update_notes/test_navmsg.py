# تست مورد ۹-الف: نوار پایین ۶ دکمه (سبد) + دکمه‌ی 📨 بالا + منوی ☰ بدون پیام/گفتگو
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
SHOT = len(sys.argv) > 2
JS = """()=>{const n=[...document.querySelectorAll('#nav button')];const nr=document.getElementById('nav').getBoundingClientRect();
 const top=[...document.querySelectorAll('#top .ib')].map(b=>b.getAttribute('aria-label'));
 return {n:n.length,labels:n.map(b=>b.textContent.trim()),
  clip:n.some(b=>b.scrollWidth>b.clientWidth+1||b.getBoundingClientRect().right>nr.right+1||b.getBoundingClientRect().left<nr.left-1),
  minw:Math.round(Math.min(...n.map(b=>b.getBoundingClientRect().width))),top,
  hscroll:document.documentElement.scrollWidth>innerWidth}}"""
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for scheme in ('light','dark'):
                pg=await b.new_page(viewport={'width':w,'height':700},color_scheme=scheme)
                errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(600)
                r=await pg.evaluate(JS)
                good=r['n']==6 and 'سبد' in r['labels'][4] and not r['clip'] and not r['hscroll'] and r['minw']>=44 \
                  and 'پیام‌ها و گفتگوها' in r['top'] and 'سبد خرید' not in r['top'] and not errs
                # دکمه‌ی سبد در نوار پایین کار کند
                await pg.click('#nav button[data-v="3"]'); await pg.wait_for_timeout(200)
                on=await pg.evaluate("document.querySelector('#nav button[data-v=\"3\"]').classList.contains('on')")
                # منوی ☰ دیگر پیام/گفتگو ندارد
                await pg.click('#top [data-a=dr]'); await pg.wait_for_timeout(200)
                drw=await pg.evaluate("document.querySelector('.drw')?.innerHTML||''")
                good&=on and 'data-a="minb"' not in drw and 'data-a="cht"' not in drw
                await pg.evaluate("document.getElementById('ov')?.classList.remove('on')")
                # دکمه‌ی 📨 بدون ورود: خطا ندهد
                await pg.click('#top [data-a=msgh]'); await pg.wait_for_timeout(200)
                ok&=good
                print(w,scheme,'OK' if good else 'BAD',r['n'],r['minw'],r['clip'],errs[:1])
                if SHOT and scheme=='light' and w==320:
                    await pg.evaluate("document.getElementById('ov')?.classList.remove('on')")
                    await pg.screenshot(path='/home/claude/shot_nav320.png')
                await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
