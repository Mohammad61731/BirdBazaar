# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=1;S.me='u1';localStorage.removeItem('bp_dup');BT.prods=[{id:1,b:1,s:'on',d:{name:'قفس',type:'plain',price:1000,emoji:'🪺'}}];BT.booths=[{id:1,name:'غرفه',phone:'0912',city:'س'}];BC=[{p:1,m:'r',q:2}];BCF={n:'علی',p:'09121234567',a:'سراوان خیابان'};CPM[1]='h';S.tab=3;S.v=null;S.cs='bt';SCT='c';XF.sc=1;render()");pg.wait_for_timeout(400)
        chk(t+'see-first note',pg.evaluate("!!document.querySelector('#scr .dtsf')&&document.querySelector('#scr .dtsf').textContent.includes('اول ببین')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("dtDupS(1)");
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='bt_co';b.dataset.v='1';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(400)
        chk(t+'dup asks',pg.evaluate("document.body.innerText.includes('چند دقیقه پیش فرستادی')"))
        pg.evaluate("XF.dt=0;render()");pg.wait_for_timeout(300)
        chk(t+'off: no note',pg.evaluate("!document.querySelector('#scr .dtsf')"))
        ctx.close()
print('ERRORS',errs)
