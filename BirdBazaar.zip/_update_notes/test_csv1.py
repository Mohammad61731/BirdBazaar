# تست 1.9.461 120: خروجی CSV سفارش‌ها (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;BM={booth:{name:'غ'},prods:[]};BOR=[{id:5,t:Date.now(),name:'علی \"x\"',phone:'09121234567',s:'done',total:250000,lines:[{n:'دانه',q:2},{n:'قفس',q:1}]},{id:6,t:Date.now(),name:'سارا',phone:'0935',s:'new',total:1000,lines:[]}]")
        chk(t+'chip in panel',pg.evaluate("pnExp().includes('data-v=\"c\"')"))
        chk(t+'csv rows',pg.evaluate("(()=>{const c=pnExT('c').split('\\n');return c.length==3&&c[0].split(',').length==7})()"))
        chk(t+'csv content',pg.evaluate("(()=>{const c=pnExT('c');return c.includes('انجام‌شده')&&c.includes('250000')&&c.includes('\"علی \"\"x\"\"\"')&&c.includes('دانه ×2')})()"))
        chk(t+'empty orders header only',pg.evaluate("(BOR=[],pnExT('c').split('\\n').length==1)"))
        chk(t+'old exports still work',pg.evaluate("pnExT('d').includes('خلاصه')"))
        ctx.close()
print('ERRORS',errs)
