# تست 1.9.112: تأخیر تصادفی — بین ۱ تا ۱٫۲۵ ؛ هر بار عدد تازه ؛ خاموش = ۱ ؛ وابسته به sf
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default on', await pg.evaluate("jtOn()&&tlOn('jt')")==True)
        v=await pg.evaluate("(()=>{const a=[];for(let i=0;i<200;i++){jtRoll();a.push(jtMul())}return [Math.min(...a),Math.max(...a),new Set(a).size]})()")
        chk('range 1..1.25 (%s)'%v, v[0]>=1 and v[1]<=1.25 and v[2]>50)
        await pg.evaluate("tlSet('jt',0)")
        chk('off: multiplier 1', await pg.evaluate("jtMul()")==1)
        await pg.evaluate("tlSet('jt',1);tlSet('sf',0)")
        chk('sf off: multiplier 1', await pg.evaluate("jtMul()")==1)
        await pg.evaluate("tlSet('sf',1)")
        chk('tlSec has row', 'هم‌گام‌سازی با تأخیر تصادفی' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
