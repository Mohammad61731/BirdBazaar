from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':360,'height':780},locale='fa-IR',has_touch=True).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];S.pnl=1;go({tab:4,v:null,at:'p'})");pg.wait_for_timeout(600)
    btns=pg.locator('#scr .chips button');n=btns.count();print('tabs:',n,'| scrollable:',pg.evaluate("(()=>{const e=document.querySelector('#scr .chips');return e.scrollWidth>e.clientWidth})()"))
    seen=[]
    for i in range(n):
        pg.evaluate(f"(()=>{{const b=document.querySelectorAll('#scr .chips button')[{i}];b.scrollIntoView({{inline:'center'}})}})()");pg.wait_for_timeout(120)
        before=pg.evaluate("document.querySelector('#scr .chips').scrollLeft")
        btns.nth(i).click();pg.wait_for_timeout(400)
        after=pg.evaluate("document.querySelector('#scr .chips').scrollLeft")
        vis=pg.evaluate("(()=>{const e=document.querySelector('#scr .chips'),a=e.querySelector('.on');if(!a)return null;const r=e.getBoundingClientRect(),q=a.getBoundingClientRect();return q.left>=r.left-1&&q.right<=r.right+1})()")
        seen.append((i,round(before),round(after),vis))
    print(seen);print('all active visible & scroll kept:',all(v for *_,v in seen) and all(abs(b-a)<=40 for _,b,a,_v in seen))
    print('ERRORS',errs);br.close()
