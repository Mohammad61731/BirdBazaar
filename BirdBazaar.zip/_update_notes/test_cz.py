# تست 1.9.111: سنجش فشرده‌سازی — پیش‌فرض خاموش ، بدون درخواست ، پیام‌های درست
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        reqs=[]
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            reqs.append(route.request.url)
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default off', await pg.evaluate("tlOn('cz')")==False)
        chk('off: empty html', await pg.evaluate("tlCz()")=='')
        await pg.evaluate("tlSet('cz',1)")
        n0=len(reqs)
        h1=await pg.evaluate("tlCz()")
        chk('on: shows a message', len(h1)>20)
        chk('no new request', len(reqs)==n0)
        chk('czRead object', await pg.evaluate("czRead()!==null"))
        chk('tlSec has row', 'سنجش فشرده‌سازی' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
