# تست 1.9.372 C4: سبد (خلاصه ، مجموع جدا ، یادآوری انتخاب)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
G=[{'id':1,'lvl':1,'rm':0,'acc':'x','la':27.3,'ln':62.3,'hrs':{},'ad':''}]
def h2(route,req):
    b=json.loads(req.post_data or '{}')
    route.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1,'g':G})) if b.get('op')=='cg_pub' else route.fallback()
PR=lambda i,b,n,disc:{'id':i,'b':b,'d':{'type':'plain','name':n,'emoji':'🐦','price':1000,'s':'on','imgs':[],'unit':'kg','disc':disc}}
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',h2)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_cpl')")
        pg.evaluate("BT.t=Date.now()+60000;BT.booths=[{id:1,name:'غرفه یک',phone:'1',city:'س'},{id:9,name:'غرفه نه',phone:'2'}];BT.prods=[%s,%s];BC=[{p:11,m:'r',q:2},{p:19,m:'r',q:1}];BCF={}"%(json.dumps(PR(11,1,'الف',10),ensure_ascii=False),json.dumps(PR(19,9,'ب',0),ensure_ascii=False)))
        pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(400)
        chk(t+'off: none',pg.evaluate("!document.querySelector('.cpb')"))
        pg.evaluate("XF.cg=1;XF.cp=1;cgSaveC({t:Date.now(),g:{1:%s}});btRe()"%json.dumps(G[0]));pg.wait_for_timeout(300)
        chk(t+'summary 1 in-person 1 remote',pg.evaluate("cpAllH({1:[],9:[]})").count('1')>=0 and pg.evaluate("document.getElementById('scr').innerText.includes('تفکیک سبد')"))
        chk(t+'summary counts',pg.evaluate("(()=>{const e=[...document.querySelectorAll('#scr .card')].find(c=>c.innerText.includes('تفکیک سبد'));const r=e.querySelectorAll('.row b');return r[0].innerText.includes('۱')&&r[1].innerText.includes('۱')})()"))
        chk(t+'sum rows booth1: goods + discount',pg.evaluate("(()=>{const s=cpSumH(BC.map(btCLine).filter(q=>q.p.b==1),1);return s.includes('تخفیف')&&/۲[٬,]?۰۰۰/.test(s)&&s.includes('۲۰۰')})()"))
        chk(t+'no discount row when none',pg.evaluate("!cpSumH(BC.map(btCLine).filter(q=>q.p.b==9),9).includes('تخفیف')"))
        chk(t+'shipping text per mode',pg.evaluate("cpSumH(BC.map(btCLine).filter(q=>q.p.b==9),9).includes('ندارد')&&cpSumH(BC.map(btCLine).filter(q=>q.p.b==1),1).includes('توافق')"))
        pg.locator('[data-a=bt_cpm][data-v="1:h"]').dispatch_event('click');pg.wait_for_timeout(200)
        pg.locator('[data-a=bt_cph][data-v="1:2"]').dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'last choice saved',pg.evaluate("JSON.parse(localStorage.getItem('bp_cpl'))[1].m=='h'&&JSON.parse(localStorage.getItem('bp_cpl'))[1].h==2"))
        pg.evaluate("CPM={};CPH={}")
        chk(t+'restored after reload state',pg.evaluate("cpMode(1)=='h'&&cpHrs(1)==2&&cpHrs(9)==6"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
