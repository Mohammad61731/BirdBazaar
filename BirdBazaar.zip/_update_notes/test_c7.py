# تست 1.9.405 C7: پنجره‌ی استودیو دو صفحه با سرتیتر ثابت
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render();window.SGT=0;sgSheet()");pg.wait_for_timeout(300)
            h1=pg.evaluate("document.querySelector('#ov .sheet').scrollHeight")
            chk(t+'p1 has card+banner, no text/nav',pg.locator('#ov [data-sg="x.bo"]').count()==1 and pg.locator('#ov [data-sg="x.ts"]').count()==0)
            chk(t+'header+footer present',pg.locator('#ov .sgh').count()==1 and pg.locator('#ov .sgf').count()==1)
            if w==360 and not dark: pg.screenshot(path='/tmp/c7_p1.png')
            pg.evaluate("document.querySelector('#ov [data-sgt=\"1\"]').click()");pg.wait_for_timeout(200)
            h2=pg.evaluate("document.querySelector('#ov .sheet').scrollHeight")
            chk(t+'p2 has text+nav+anim, no card',pg.locator('#ov [data-sg="x.ts"]').count()==1 and pg.locator('#ov [data-sg="x.nz"]').count()==1 and pg.locator('#ov [data-sg="x.bo"]').count()==0)
            chk(t+'each page shorter than 3 screens',h1<780*3.3 and h2<780*3.3)
            chk(t+'no horizontal overflow',pg.evaluate("(()=>{const s=document.querySelector('#ov .sheet');return s.scrollWidth<=s.clientWidth+1})()"))
            if w==360 and not dark: pg.screenshot(path='/tmp/c7_p2.png')
            pg.evaluate("document.querySelector('#ov [data-sgc=\"x.nm:1\"]').click()");pg.wait_for_timeout(150)
            chk(t+'stays on p2 after change',pg.locator('#ov [data-sg="x.nz"]').count()==1)
            print(t,h1,h2)
            ctx.close()
print('ERRORS',errs)
