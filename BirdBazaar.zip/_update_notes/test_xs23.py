# تست 1.9.352: S97-99 استودیو روی صفحه‌های غرفه/سبد/پروفایل
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['all'];S.ed=0;XF.xs=1;D.cms.ST={}")
        for tab,key in ((3,'cart'),(4,'acct')):
            pg.evaluate("(a)=>{S.v=null;S.tab=a;render()}",tab);pg.wait_for_timeout(300)
            chk(t+key+' wrapper',pg.evaluate("(k)=>{const w=document.querySelector('.pgs');return !!w&&w.dataset.p==k&&getComputedStyle(w).display=='contents'}",key))
            chk(t+key+' marked',pg.evaluate("document.querySelectorAll('.pgs>[data-sb]').length>=1"))
            chk(t+key+' btn',pg.locator('.pgsb [data-pgs]').count()==1)
            clk(pg,'.pgsb [data-pgs]');pg.wait_for_timeout(250)
            chk(t+key+' edit on',pg.evaluate("document.querySelector('.pgs').classList.contains('pse')"))
            pg.evaluate("document.querySelector('.pgs>[data-sb=s0]').click()");pg.wait_for_timeout(250)
            chk(t+key+' sheet',pg.evaluate("!!document.querySelector('#ov .xsb')&&document.querySelector('#ov .xsb').dataset.xk.endsWith(':s0')"))
            pg.evaluate("const r=document.querySelector('#ov [data-xs=o]');r.value=50;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))");pg.wait_for_timeout(150)
            chk(t+key+' applied',pg.evaluate("(k)=>D.cms.ST[k+':s0']&&D.cms.ST[k+':s0'].o==50&&document.querySelector('.pgs>[data-sb=s0]').style.opacity=='0.5'",key))
            chk(t+key+' ruler',pg.evaluate("document.querySelector('.pgsb [data-a=rlr]')!==null"))
            pg.evaluate("document.querySelector('#ov [data-a=xsr]').click()");pg.wait_for_timeout(200)
            chk(t+key+' reset',pg.evaluate("(k)=>!D.cms.ST[k+':s0']&&document.querySelector('.pgs>[data-sb=s0]').style.opacity==''",key))
            pg.evaluate("cl();PGSE={};render()");pg.wait_for_timeout(150)
            chk(t+key+' no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("D.cms.ST={'acct:s0':{o:60}};S.role=null;S.pm=[];S.tab=4;render()");pg.wait_for_timeout(300)
        chk(t+'visitor sees style',pg.evaluate("(()=>{const e=document.querySelector('.pgs>[data-sb=s0]');return !!e&&e.style.opacity=='0.6'&&!document.querySelector('.pgsb')})()"))
        pg.evaluate("D.cms.ST={};S.tab=0;render()");pg.wait_for_timeout(200)
        chk(t+'home untouched',pg.evaluate("!document.querySelector('.pgs')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
