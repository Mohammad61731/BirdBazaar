# تست مورد ۱۴ (مرحله ۳): lazy/async روی عکس‌ها و content-visibility کارت‌های شبکه
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            await pg.route('**/*',lambda r: r.abort() if r.request.url.startswith('http') else r.continue_())
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(800)
            r=await pg.evaluate("""()=>{const s=document.documentElement.outerHTML;
              const css=[...document.styleSheets].some(x=>(()=>{try{return [...x.cssRules]}catch(e){return []}})().some(r=>/grid\s*\.pc/.test(r.selectorText||'')&&r.style.contentVisibility=='auto'));
              D.products=[1,2,3,4,5,6].map(i=>({id:i,n:'محصول '+i,p:1000*i,cat:'x',imgs:[]}));S.tab=1;S.v=null;render();
              const pcs=document.querySelectorAll('.grid .pc').length;
              const lz=[...document.querySelectorAll('img')].every(i=>i.id=='zi'||i.id=='cri'||i.loading=='lazy'||!i.closest('#scr'));
              return {css,pcs,lz,ov:document.documentElement.scrollWidth>innerWidth}}""")
            print(w,r,errs); ok&=r['css'] and not r['ov'] and not errs
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
