# فونت «پی‌تآب» — طراحی اصیل؛ فقط الهام از حس کلی (ضخیم و گرد + برش‌های مورب)، بدون کپی‌کردن هیچ فونتی
import math
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
T=120
def area(p): return sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))/2
def rect(x0,y0,x1,y1): return [(x0,y0),(x0,y1),(x1,y1),(x1,y0)]
def stem(x0,x1,y0,yt,c=55,d=75,r=42):
    p=[(x0,y0),(x0,yt-d),(x0+c,yt)]
    cx,cy=x1-r,yt-r
    for a in (90,67.5,45,22.5,0):
        p.append((round(cx+r*math.cos(math.radians(a))),round(cy+r*math.sin(math.radians(a)))))
    p.append((x1,y0)); return p
def stemdown(x0,x1,yb,y1,c=55,d=75):
    return [(x0,yb+d),(x0,y1),(x1,y1),(x1,yb),(x0+c,yb)]
def dot(cx,cy,r=62): return [(cx,cy+r),(cx+r,cy),(cx,cy-r),(cx-r,cy)]
def par(pts): return pts
G={}  # name -> (width, [polys])
def add(name,w,polys): G[name]=(w,polys)
def dots(kind,cx,top=False):
    if kind=='b': return [dot(cx,-165)]
    if kind=='p': return [dot(cx-72,-120,56),dot(cx+72,-120,56),dot(cx,-262,56)]
    if kind=='t': return [dot(cx-66,430,56),dot(cx+66,430,56)]
    if kind=='y': return [dot(cx-62,-170,52),dot(cx+62,-170,52)]
    return []
def bowl(form,kind,isy=False):
    if form=='init': W=300; P=[rect(0,0,W,T),stem(W-125,W,0,300)]; cx=140
    elif form=='medi': W=300; P=[rect(0,0,W,T),stem(W//2-62,W//2+62,0,255)]; cx=150
    elif form=='fina':
        W=380; P=[rect(40,0,W,T)]
        P.append(stemdown(40,160,-150,T) if isy else stem(40,160,0,230)); cx=270
    else:
        W=420; P=[rect(40,0,380,T),stem(260,380,0,300)]
        P.append(stemdown(40,160,-150,T) if isy else stem(40,160,0,230)); cx=270
    P+=dots(kind,cx); return W,P
for nm,k,isy in (('uni0628','b',0),('uni067E','p',0),('uni062A','t',0),('uni06CC','y',1)):
    for f in ('isol','init','medi','fina'):
        W,P=bowl(f,k,isy); add(nm if f=='isol' else nm+'.'+f,W,P)
def kaf(form):
    if form in('init','medi'): W=360; P=[rect(0,0,W,T)]; sx=W
    elif form=='fina': W=360; P=[rect(40,0,W,T)]; sx=W
    else: W=400; P=[rect(40,0,W,T)]; sx=W
    P+= [stem(sx-125,sx,0,470),[(sx-125,290),(sx-345,385),(sx-345,495),(sx-125,400)]]
    return W,P
def lam(form):
    if form in('init','medi'): W=320; P=[rect(0,0,W,T)]
    elif form=='fina': W=320; P=[rect(40,0,W,T)]
    else: W=360; P=[rect(40,0,W,T),stem(40,160,0,200)]
    P.append(stem(W-125,W,0,610)); return W,P
for nm,fn in (('uni06A9',kaf),('uni0644',lam)):
    for f in ('isol','init','medi','fina'):
        W,P=fn(f); add(nm if f=='isol' else nm+'.'+f,W,P)
def alef(form,madda):
    if form=='isol': W=190; P=[stem(35,155,0,570)]; x0,x1=35,155
    else: W=190; P=[stem(70,190,0,570)]; x0,x1=70,190
    if madda: P.append([(x0-25,650),(x0+35,745),(x1+45,745),(x1-15,650)])
    return W,P
for nm,m in (('uni0627',0),('uni0622',1)):
    for f in ('isol','fina'):
        W,P=alef(f,m); add(nm if f=='isol' else nm+'.'+f,W,P)
add('space',220,[]); add('uni200C',0,[]); add('.notdef',500,[rect(60,0,440,700),rect(120,60,380,640)[::-1]])
order=['.notdef']+[k for k in G if k!='.notdef']
glyphs={};metrics={}
for n in order:
    W,P=G[n]; pen=TTGlyphPen(None); xs=[]
    for poly in P:
        if n=='.notdef' and poly is P[-1]:
            pts=poly
        else:
            pts=poly if area(poly)<0 else poly[::-1]
        pen.moveTo(pts[0]); [pen.lineTo(q) for q in pts[1:]]; pen.closePath(); xs+= [q[0] for q in poly]
    glyphs[n]=pen.glyph(); metrics[n]=(W,min(xs) if xs else 0)
cmap={0x20:'space',0x200C:'uni200C'}
for n in order:
    if n.startswith('uni') and '.' not in n and n!='uni200C': cmap[int(n[3:],16)]=n
fb=FontBuilder(1000,isTTF=True)
fb.setupGlyphOrder(order); fb.setupCharacterMap(cmap); fb.setupGlyf(glyphs); fb.setupHorizontalMetrics(metrics)
fb.setupHorizontalHeader(ascent=800,descent=-360)
fb.setupNameTable({'familyName':'PitabType','styleName':'Regular','uniqueFontIdentifier':'PitabType-1.0','fullName':'PitabType Regular','version':'Version 1.000','psName':'PitabType-Regular','copyright':'Original design for Pitab Kala app','licenseDescription':'Original artwork created for the Pitab Kala app owner. Free to use in the app.'})
fb.setupOS2(sTypoAscender=800,sTypoDescender=-360,sTypoLineGap=0,usWinAscent=800,usWinDescent=360,achVendID='PTAB',fsType=0)
fb.setupPost()
dual=['uni0628','uni067E','uni062A','uni06CC','uni06A9','uni0644']; right=['uni0627','uni0622']
J=lambda L,s:' '.join(x+s for x in L)
fea=f"""languagesystem DFLT dflt;
languagesystem arab dflt;
feature init {{ sub [{' '.join(dual)}] by [{J(dual,'.init')}]; }} init;
feature medi {{ sub [{' '.join(dual)}] by [{J(dual,'.medi')}]; }} medi;
feature fina {{ sub [{' '.join(dual+right)}] by [{J(dual+right,'.fina')}]; }} fina;
"""
addOpenTypeFeaturesFromString(fb.font,fea)
fb.save('PitabType.ttf')
from fontTools.ttLib import TTFont
f=TTFont('PitabType.ttf'); f.flavor='woff'; f.save('PitabType.woff')
import os;print(os.path.getsize('PitabType.ttf'),os.path.getsize('PitabType.woff'),len(order),'glyphs')
