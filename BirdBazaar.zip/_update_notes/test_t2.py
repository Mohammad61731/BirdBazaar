# U10-T2: نوارهای نئون
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
import io
errs=[];R={}
NEW='file:///home/claude/bb/www/index.html';OLD='file:///tmp/orig/www/index.html'
def mk(br,url,w=390,cs='light'):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=cs,reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto(url);pg.wait_for_timeout(900);return pg
sh=lambda pg:Image.open(io.BytesIO(pg.screenshot()))
with sync_playwright() as p:
    br=p.chromium.launch()
    a=mk(br,NEW);b=mk(br,OLD)
    R['normal_pixel_same']=ImageChops.difference(sh(a).convert('RGB'),sh(b).convert('RGB')).getbbox() is None
    a.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];thSet('home',{m:'g',c:'purple'})");a.wait_for_timeout(300)
    R['top_shadow_g']='rgba(185, 131, 255' in a.evaluate("getComputedStyle(document.querySelector('#app>#top')).boxShadow")
    R['nav_border_g']='185, 131, 255' in a.evaluate("getComputedStyle(document.querySelector('#nav')).borderTopColor")
    a.screenshot(path='shots/t2_glass_purple.png')
    a.evaluate("thSet('home',{m:'p',c:'orange'})");a.wait_for_timeout(300)
    R['top_shadow_p']='255, 159, 67' in a.evaluate("getComputedStyle(document.querySelector('#app>#top')).boxShadow")
    a.screenshot(path='shots/t2_p_orange.png')
    a.evaluate("thLP(1);thApply()");a.wait_for_timeout(200)
    R['lp_no_blur']=a.evaluate("getComputedStyle(document.querySelector('#app>#nav')).backdropFilter")=='none'
    a.evaluate("thLP(0);thReset();thApply()");a.wait_for_timeout(200)
    R['reset_back']=a.evaluate("document.querySelector('#app').dataset.tm")=='n'
    for w in (320,360,412):
        for cs in ('light','dark'):
            q=mk(br,NEW,w,cs);q.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];thSet('home',{m:'g',c:'green'})");q.wait_for_timeout(250)
            R[f'noover_{w}_{cs}']=q.evaluate("document.documentElement.scrollWidth<=innerWidth")
            if w==360:q.screenshot(path=f'shots/t2_{cs}.png')
    br.close()
for k,v in R.items():print(('OK  ' if v else 'FAIL'),k)
print('errors:',errs);print('ALL PASS' if all(R.values()) and not errs else 'SOME FAIL')
