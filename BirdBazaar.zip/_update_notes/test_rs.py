# تست 1.9.113: دانلود قابل‌ادامه — ۳ تلاش با فاصله‌ی ۸/۳۰/۹۰ ؛ خاموش = هیچ ؛ online شمارنده را صفر می‌کند
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default on', await pg.evaluate("rsOn()&&tlOn('rs')")==True)
        d=await pg.evaluate("""(()=>{const t=[],o=window.setTimeout;window.setTimeout=(f,ms)=>{t.push(ms);return 0};for(let i=0;i<5;i++)rsFail('p:9',()=>{});window.setTimeout=o;return t})()""")
        chk('delays 8/30/90 then stop (%s)'%d, d==[8000,30000,90000])
        d=await pg.evaluate("""(()=>{const t=[],o=window.setTimeout;window.setTimeout=(f,ms)=>{t.push(ms);return 0};window.dispatchEvent(new Event('online'));RS.n={};rsFail('p:9',()=>{});window.setTimeout=o;return t.filter(x=>x==8000).length})()""")
        chk('online resets counter', d==1)
        await pg.evaluate("tlSet('rs',0)")
        d=await pg.evaluate("""(()=>{RS.n={};const t=[],o=window.setTimeout;window.setTimeout=(f,ms)=>{t.push(ms);return 0};rsFail('p:7',()=>{});window.setTimeout=o;return t.length})()""")
        chk('off: no retry', d==0)
        await pg.evaluate("tlSet('rs',1)")
        chk('tlSec has row', 'دانلود قابل‌ادامه‌ی عکس' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
