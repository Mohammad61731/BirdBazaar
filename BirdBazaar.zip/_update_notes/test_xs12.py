# تست 1.9.339: استودیو T2-g ویرایش مستقیم متن با لمس (D.cms.ST.gtx ؛ کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=0;XF.xs=1;render()");pg.wait_for_timeout(300)
        pg.evaluate("sgSheet()");pg.wait_for_timeout(250)
        chk(t+'toggle button',pg.locator('#ov [data-xtx="on"]').count()==1)
        clk(pg,'#ov [data-xtx="on"]')
        chk(t+'mode on + bar',pg.evaluate("!!window.XTX&&!!document.getElementById('xtxb')"))
        tab0=pg.evaluate("S.tab")
        # edit hero title
        orig=pg.evaluate("document.querySelector('.hero h2').textContent.trim()")
        pg.evaluate("document.querySelector('.hero h2').click()");pg.wait_for_timeout(250)
        chk(t+'sheet opened',pg.locator('#ov #xtxi').count()==1)
        pg.evaluate("()=>{const i=document.querySelector('#xtxi');i.value='سلام <b>دوست</b>'}")
        clk(pg,'#ov [data-xtx="save"]')
        chk(t+'saved sanitized',pg.evaluate("(o)=>{const v=D.cms.ST.gtx[o];return v=='سلام bدوست/b'||v=='سلام bدوستb'||(!/[<>]/.test(v)&&v.startsWith('سلام'))}",orig))
        chk(t+'hero updated',pg.evaluate("document.querySelector('.hero h2').textContent.startsWith('سلام')"))
        chk(t+'no nav on click',pg.evaluate("S.tab")==tab0)
        # nav label
        nl=pg.evaluate("document.querySelector('#nav button span').textContent.trim()")
        pg.evaluate("document.querySelector('#nav button span').click()");pg.wait_for_timeout(250)
        pg.evaluate("()=>{document.querySelector('#xtxi').value='اصلی'}")
        clk(pg,'#ov [data-xtx="save"]')
        chk(t+'nav updated',pg.evaluate("document.querySelector('#nav button span').textContent.trim()=='اصلی'"))
        # persists after render
        pg.evaluate("render()");pg.wait_for_timeout(400)
        chk(t+'persist after render',pg.evaluate("document.querySelector('.hero h2').textContent.startsWith('سلام')&&document.querySelector('#nav button span').textContent.trim()=='اصلی'"))
        # product card protected
        has=pg.evaluate("!!document.querySelector('#scr .pc h4')")
        if has:
            pg.evaluate("document.querySelector('#scr .pc h4').click()");pg.wait_for_timeout(250)
            chk(t+'card text protected',pg.locator('#ov #xtxi').count()==0)
        # list + delete
        pg.evaluate("window.XTX=0;txBar();sgSheet()");pg.wait_for_timeout(250)
        chk(t+'list shows 2',pg.locator('#ov [data-xtx^="del:"]').count()==2)
        clk(pg,'#ov [data-xtx="del:0"]')
        chk(t+'del restores',pg.evaluate("Object.keys(D.cms.ST.gtx).length==1"))
        clk(pg,'#ov [data-xtx="all"]')
        chk(t+'all restores',pg.evaluate("Object.keys(D.cms.ST.gtx).length==0&&!document.querySelector('.hero h2').textContent.startsWith('سلام')&&document.querySelector('#nav button span').textContent.trim()!='اصلی'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        # exit bar
        pg.evaluate("window.XTX=1;txBar()");clk(pg,'#xtxb')
        chk(t+'bar exits',pg.evaluate("!window.XTX&&!document.getElementById('xtxb')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
