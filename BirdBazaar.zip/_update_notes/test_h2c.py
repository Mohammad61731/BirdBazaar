# تست 1.9.401 H2 C4 C5 C6: پنجره‌ی لوگو ، برچسب بنر ، تب‌های پنل مدیریت
import re;APPV_EXP=re.search(r"APPV='([^']+)'",open('/home/claude/bb/www/index.html',encoding='utf-8').read()).group(1)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.add_init_script("localStorage.setItem('bp_tls', JSON.stringify({fw:0}))")
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2300)
        chk(t+'APPV',pg.evaluate("APPV")==APPV_EXP)
        pg.evaluate("S.role='admin';S.me='admin';S.pw='x';S.pm=['all'];S.pvu=0;S.tab=4;S.v='';S.at='set';render()");pg.wait_for_timeout(400)
        pg.evaluate("lgSheet()");pg.wait_for_timeout(400)
        r=pg.evaluate("""()=>{const sh=document.querySelector('#ovc .sheet,#ov .sheet')||document.querySelector('#ovc');const b=[...sh.querySelectorAll('[data-a=lgea],[data-a=lgp]')].map(e=>e.getBoundingClientRect());const h=[...sh.querySelectorAll('b')].map(e=>e.getBoundingClientRect());
          let ov=false;b.forEach(x=>h.forEach(y=>{if(x.left<y.right-1&&x.right>y.left+1&&x.top<y.bottom-1&&x.bottom>y.top+1)ov=true}));return {n:b.length,ov,wide:b.every(x=>x.width>innerWidth*.6)}}""")
        chk(t+'logo buttons dont overlap headings',r['n']==2 and not r['ov'])
        chk(t+'logo buttons full width',r['wide'])
        pg.evaluate("clo2&&clo2()") if False else pg.evaluate("document.querySelector('[data-a=clo2]')&&document.querySelector('[data-a=clo2]').click()");pg.wait_for_timeout(300)
        chk(t+'schB expired/start/until',pg.evaluate("(()=>{const a=schB({fr:'2020-01-01',to:'2020-02-01'}),b=schB({fr:'2999-01-01'}),c=schB({to:'2999-01-01'});return /منقضی/.test(a)&&/ex/.test(a)&&/شروع/.test(b)&&/تا/.test(c)&&schB({})===''&&!/absolute/.test(schB({to:'2999-01-01'},1))})()"))
        pg.evaluate("document.querySelector('[data-a=pnl]').click()");pg.wait_for_timeout(500)
        chk(t+'panel title has gap under header',pg.evaluate("(()=>{const h=document.querySelector('.admh').getBoundingClientRect(),hd=document.querySelector('header,.top,#top');return h.top>=60})()"))
        chk(t+'active tab visible in strip',pg.evaluate("(()=>{const o=document.querySelector('.chips.admt .chip.on').getBoundingClientRect();return o.left>=0&&o.right<=innerWidth})()"))
        pg.evaluate("document.querySelector('[data-a=adm][data-v=br]').click()");pg.wait_for_timeout(500)
        chk(t+'tab switch keeps active visible',pg.evaluate("(()=>{const o=document.querySelector('.chips.admt .chip.on').getBoundingClientRect();return o.left>=0&&o.right<=innerWidth})()"))
        chk(t+'banner rows buttons >=40',pg.evaluate("[...document.querySelectorAll('#scr .rw .tg')].every(b=>b.getBoundingClientRect().height>=40)"))
        chk(t+'panel no overflow',pg.evaluate("document.documentElement.scrollWidth-innerWidth<=0"))
        ctx.close()
    br.close()
print('ERRORS',errs)
