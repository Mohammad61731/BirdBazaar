# تست 1.9.79: 🧪 آزمایشی — کلیدها، آپلود Storage با بازگشت به base64، پنل
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
PX='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
async def run(pw, mode):
    b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':700})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    calls=[]; up=[]; sent={}
    flags={'sto':1} if mode in('on','fail') else {}
    async def h(route):
        u=route.request.url; bd=(route.request.post_data_buffer or b'').decode('utf-8','ignore')
        if '/storage/v1/object/' in u:
            up.append(u)
            if mode=='fail': return await route.fulfill(status=400,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"error":"x"}')
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"Key":"ok"}')
        if u.startswith('http'):
            try: j=json.loads(bd)
            except Exception: j={}
            op=j.get('op'); calls.append(op)
            if op=='products_set': sent['a']=j.get('a')
            if op=='xget': body={'ok':1,'f':flags}
            elif op=='xset': body={'ok':1,'f':{'sto':1}}
            else: body={'ok':1,'n':0,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*','access-control-expose-headers':'*'},body=json.dumps(body))
        return await route.continue_()
    await pg.route('**/*',h)
    await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(3500)
    ok=True
    st=await pg.evaluate("[xf('sto'),xf('dl'),xf('lt'),xf('md'),xf('qb')]"); print(mode,'flags',st)
    ok&= st[0]==(mode in('on','fail')) and all(st[1:])
    await pg.evaluate("S.me='a';S.pw='x';S.role='admin';S.pm=['all']")
    await pg.evaluate("op('products_set',{rows:[{id:1,name:'x',img:%r,imgs:[%r,%r]}]})"%(PX,PX,PX)); await pg.wait_for_timeout(1200)
    r=sent.get('a',{}).get('rows',[{}])[0]
    imgs=r.get('imgs') or []
    print(mode,'uploads',len(up),'img0',str(imgs[0])[:40] if imgs else None)
    if mode=='on': ok&= len(up)==1 and str(r.get('img','')).startswith('http') and all(str(x).startswith('http') for x in imgs) and r.get('thk')==str(len(r['img']))
    if mode=='fail': ok&= len(up)>=1 and str(r.get('img','')).startswith('data:image')
    if mode=='off': ok&= len(up)==0 and str(r.get('img','')).startswith('data:image')
    if mode=='on':
        await pg.evaluate("S.pnl=1;S.at='xf';render()"); await pg.wait_for_timeout(600)
        html=await pg.evaluate("document.body.innerHTML"); has='data-a="xf_tog"' in html and 'آزمایش Storage' in html; print('panel',has); ok&=has
        await pg.evaluate("xf_dummy=0") if False else None
        await pg.evaluate("XF.dl=0"); n=await pg.evaluate("deltaGet()"); ok&= n is None
    print(mode,'errors',errs); ok&=not errs
    await b.close(); return ok
async def main():
    async with async_playwright() as pw:
        r=[await run(pw,m) for m in ('off','on','fail')]
    print('PASS' if all(r) else 'FAIL'); sys.exit(0 if all(r) else 1)
asyncio.run(main())
