# تست 1.9.90 مرحله‌ی ۶: «🧰 ابزارها» دسته‌ی ۳ (bv ، pt ، cl ، lg)
import asyncio, sys, json, os
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
GOOD=json.dumps({'app':'birdbazaar','ver':1,'t':'2099-01-01T00:00:00.000Z','data':{'products':[{'id':1,'name':'a'},{'id':2,'name':'b'}],'ads':[{'id':1,'title':'t'}],'stories':[],'guides':[],'cms':{}}})
DUP=json.dumps({'app':'birdbazaar','ver':1,'t':'2020-01-01T00:00:00.000Z','data':{'products':[{'id':1},{'id':1}],'ads':[],'cms':{}}})
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    open('/tmp/bv_good.json','w').write(GOOD); open('/tmp/bv_dup.json','w').write(DUP); open('/tmp/bv_bad.json','w').write('{nope')
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                await asyncio.sleep(0.05)
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='tl';render()"); await pg.wait_for_timeout(250)
            chk(t+'APPV 1.9.9x', await pg.evaluate("/^1\\.9\\.(9\\d)$/.test(APPV)"))
            chk(t+'13 tools, 4 new off', await pg.evaluate("TLK.length==13&&['bv','pt','cl','lg'].every(k=>!tlOn(k))"))
            chk(t+'off: fetch untouched', await pg.evaluate("!PTW&&window.fetch.toString().indexOf('PTON')<0"))
            chk(t+'off: no forms', await pg.evaluate("!document.querySelector('[data-a=bv_chk],[data-a=cl_t],[data-a=lg_clr],[data-a=pt_clr]')"))
            for k in ('bv','pt','cl','lg'):
                await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=%s]').click()"%k); await pg.wait_for_timeout(120)
            chk(t+'4 on', await pg.evaluate("['bv','pt','cl','lg'].every(k=>tlOn(k))"))
            chk(t+'no overflow', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            # --- bv: یادآوری
            await pg.evaluate("window.__bvr=0;localStorage.removeItem('bp_lbk');S.me='adm';bvRemind()"); await pg.wait_for_timeout(150)
            chk(t+'bv reminder when never', await pg.evaluate("window.__bvr===1"))
            await pg.evaluate("window.__bvr=0;localStorage.setItem('bp_lbk',String(Date.now()-3*864e5));bvRemind()")
            chk(t+'bv quiet when <7d', await pg.evaluate("window.__bvr===0"))
            await pg.evaluate("localStorage.setItem('bp_lbk',String(Date.now()-9*864e5));bvRemind()")
            chk(t+'bv reminder when >7d', await pg.evaluate("window.__bvr===1"))
            await pg.evaluate("S.role='user';S.pm=[];window.__bvr=0;bvRemind()")
            chk(t+'bv silent for non-owner', await pg.evaluate("window.__bvr===0"))
            await pg.evaluate("S.role='admin';S.pm=['all'];localStorage.removeItem('bp_lbk');bvMark()")
            chk(t+'bvMark records', await pg.evaluate("bvRd()>0"))
            # --- bv: فایل
            await pg.evaluate("render()"); await pg.wait_for_timeout(150)
            for f,exp in (('/tmp/bv_good.json','محصول'),('/tmp/bv_dup.json','تکراری'),('/tmp/bv_bad.json','JSON درست نیست')):
                async with pg.expect_file_chooser() as fc:
                    await pg.evaluate("document.querySelector('[data-a=bv_chk]').click()")
                (await fc.value).set_files(f) if False else await (await fc.value).set_files(f)
                await pg.wait_for_timeout(400)
                chk(t+'bv scan '+os.path.basename(f), exp in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'bv scan does not change D', await pg.evaluate("D.products.length>=0&&!(D.products||[]).some(x=>x&&x.name=='a'&&x.id===1&&x.price===undefined)"))
            # --- pt: زمان‌سنجی
            await pg.evaluate("ptSync()")
            chk(t+'pt wrapper installed', await pg.evaluate("!!PTW&&window.fetch===PTW"))
            await pg.evaluate("localStorage.removeItem('bp_ptm')")
            await pg.evaluate("(async()=>{for(let i=0;i<3;i++)await fetch('https://example.test/rest/v1/rpc/app',{method:'POST',body:JSON.stringify({op:'zzop'})}).catch(()=>0)})()"); await pg.wait_for_timeout(700)
            r=await pg.evaluate("JSON.parse(localStorage.getItem('bp_ptm')||'{}')")
            chk(t+'pt recorded op zzop x3 (%s)'%r.get('zzop'), r.get('zzop',{}).get('n')==3 and r['zzop']['s']>=0)
            await pg.evaluate("render()"); await pg.wait_for_timeout(150)
            chk(t+'pt shows op', 'zzop' in await pg.evaluate("document.getElementById('scr').innerText"))
            # --- cl
            await pg.evaluate("document.querySelectorAll('[data-a=cl_t]')[0].click()"); await pg.wait_for_timeout(150)
            chk(t+'cl tick persists', await pg.evaluate("clRd()[0]===1"))
            await pg.evaluate("document.querySelectorAll('[data-a=cl_t]')[0].click()"); await pg.wait_for_timeout(100)
            chk(t+'cl untick', await pg.evaluate("!clRd()[0]"))
            await pg.evaluate("document.querySelectorAll('[data-a=cl_t]')[1].click()"); await pg.wait_for_timeout(100)
            await pg.evaluate("document.querySelector('[data-a=cl_r]').click()"); await pg.wait_for_timeout(100)
            chk(t+'cl reset', await pg.evaluate("Object.keys(clRd()).length==0"))
            # --- lg
            await pg.evaluate("localStorage.removeItem('bp_lgl');lgPush('ali',1);lgPush('bob',0)"); await pg.evaluate("render()"); await pg.wait_for_timeout(150)
            tx=await pg.evaluate("document.getElementById('scr').innerText")
            chk(t+'lg lists entries', 'ali' in tx and 'bob' in tx and 'ورود ناموفق' in tx)
            chk(t+'lg stores no password', 'pw' not in await pg.evaluate("localStorage.getItem('bp_lgl')"))
            await pg.evaluate("for(let i=0;i<40;i++)lgPush('u'+i,1)")
            chk(t+'lg capped 30', await pg.evaluate("lgRd().length==30"))
            # ورود واقعی از doLogin (سرور ساختگی: login ← نقش user برای ادمین = ناموفق)
            await pg.evaluate("localStorage.removeItem('bp_lgl')")
            await pg.evaluate("doLogin('zed','pw1',true)"); await pg.wait_for_timeout(600)
            chk(t+'doLogin failed admin logged', await pg.evaluate("lgRd().some(x=>x.u=='zed'&&x.ok===0)")) 
            await pg.evaluate("doLogin('zed2','pw2',false)"); await pg.wait_for_timeout(400)
            chk(t+'non-admin login not logged', await pg.evaluate("!lgRd().some(x=>x.u=='zed2')"))
            # --- خاموش = پاک
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='tl';S.v='';render()"); await pg.wait_for_timeout(250)
            for k in ('bv','pt','cl','lg'):
                await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=%s]').click()"%k); await pg.wait_for_timeout(120)
            chk(t+'off clears data', await pg.evaluate("['bp_lbk','bp_ptm','bp_cl','bp_lgl'].every(k=>localStorage.getItem(k)===null)"))
            chk(t+'pt wrapper removed', await pg.evaluate("!PTW&&window.fetch.toString().indexOf('PTON')<0"))
            await pg.evaluate("lgPush('q',1);bvMark()")
            chk(t+'off: lgPush/bvMark do nothing', await pg.evaluate("lgRd().length==0&&bvRd()==0"))
            chk(t+'ab() tools -> hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx&&S.at=='set'})()"))
            chk(t+'no errors %s'%errs, not errs)
            if w==360 and sch=='light':
                await pg.evaluate("for(const k of ['bv','pt','cl','lg'])tlSet(k,1);ptSync();lgPush('ali',1);S.pm=['all'];S.sx='tl';render()"); await pg.wait_for_timeout(250)
                await pg.evaluate("document.getElementById('scr').scrollTo(0,99999)"); await pg.wait_for_timeout(100)
                await pg.screenshot(path='%s/shots/tl90.png'%ROOT)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
