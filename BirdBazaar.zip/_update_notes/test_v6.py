from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',has_touch=True).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(700)
        pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];D.cfg.guestAds=1;D.ads.forEach(a=>{a.st='ok'});if(D.ads[0]){D.ads[0].own='ali';D.ads[0].city='تهران'}go({tab:2,sub:0,v:null})");pg.wait_for_timeout(600)
        c=pg.locator('#scr .ad');n=c.count()
        has_call=pg.locator('#scr .ad button[data-a=acall],#scr .ad button[data-a=amsg]').count()
        ov=pg.evaluate("document.documentElement.scrollWidth>innerWidth")
        print(w,'cards',n,'callbtns',has_call,'overflow',ov)
        if w==360:pg.screenshot(path='shots/v6_list.png')
        c.first.click();pg.wait_for_timeout(500)
        print(' detail:',pg.evaluate("S.v"),'call btn',pg.locator('#scr button[data-a=acall]').count(),'owner box',pg.locator('#scr .ao').count())
        if w==360:pg.screenshot(path='shots/v6_detail.png')
        pg.evaluate("go({v:null})")
    print('ERRORS',errs);br.close()
