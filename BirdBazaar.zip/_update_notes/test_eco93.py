# تست 1.9.93: حالت صرفه‌جویی کاربران
import asyncio, sys, json, re
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/src'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; xs=[]; st={'dl':1,'lt':1,'md':1,'qb':1,'sto':0}
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
                d=json.loads(route.request.post_data or '{}'); op=d.get('op','')
                body=BODY
                if op=='xset': xs.append(d['a']); st[d['a']['k']]=d['a']['v']; body={'ok':1,'f':dict(st)}
                if op=='xget': body={'ok':1,'f':dict(st)}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='sw';render()"); await pg.wait_for_timeout(300)
            chk(t+'APPV 1.9.93', await pg.evaluate("/^1\\.9\\.9\\d$/.test(APPV)"))
            chk(t+'eco box shown', 'حالت صرفه‌جویی کاربران' in await pg.evaluate("document.body.innerText"))
            await pg.click('[data-a=eco_all][data-v="0"]'); await pg.wait_for_timeout(900)
            chk(t+'revert sends 4 xset off', sorted(x['k'] for x in xs)==['dl','lt','md','qb'] and all(x['v']==0 for x in xs))
            chk(t+'state now all off', await pg.evaluate("ECO.every(k=>!xf(k))"))
            n=len(xs); await pg.click('[data-a=eco_all][data-v="1"]'); await pg.wait_for_timeout(900)
            chk(t+'enable sends 4 xset on', len(xs)-n==4 and await pg.evaluate("ECO.every(k=>xf(k))"))
            n=len(xs); await pg.click('[data-a=eco_all][data-v="1"]'); await pg.wait_for_timeout(500)
            chk(t+'no requests when already on', len(xs)==n)
            chk(t+'sto untouched', 'sto' not in [x['k'] for x in xs])
            chk(t+'no overflow', await pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            chk(t+'no js errors', not errs)
            await ctx.close()
        await b.close()
    print('ALL OK' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
asyncio.run(main())
