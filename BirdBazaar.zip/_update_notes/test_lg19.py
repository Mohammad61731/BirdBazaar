# تست 1.9.300: LG19 ترکیب تم بخش‌ها (data-tmx روی #top #nav #ov) + انتخاب محلی bp_ulg
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
JS_Q="(()=>{const a=document.getElementById('app'),g=i=>document.getElementById(i);const cs=(e,p)=>getComputedStyle(e).getPropertyValue(p).trim();return {lg:a.dataset.lg||'',top:g('top').dataset.tmx||'',nav:g('nav').dataset.tmx||'',ov:g('ov').dataset.tmx||'',gl:cs(a,'--lg-gl'),glTop:cs(g('top'),'--lg-gl'),glNav:cs(g('nav'),'--lg-gl'),navBf:getComputedStyle(g('nav')).backdropFilter||getComputedStyle(g('nav')).webkitBackdropFilter,ovw:document.documentElement.scrollWidth<=innerWidth}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('ice','i'):
                o='i' if m=='ice' else 'ice'
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light');pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));D.cms.TX={hd:'%s',nv:'%s',sh:'%s'};thApply();S.tab=1;S.v=null;render()"%(m,o,o,o));pg.wait_for_timeout(450)
                t=f"{w}{'d' if dark else 'l'}{m} "
                r=pg.evaluate(JS_Q)
                chk(t+'tmx set on 3 parts',r['top']==o and r['nav']==o and r['ov']==o)
                chk(t+'page flavor kept',r['lg']==m)
                chk(t+'tokens differ top/nav',r['glTop']!=r['gl'] and r['glNav']!=r['gl'])
                chk(t+'no overflow',r['ovw'])
                if m=='ice': chk(t+'nav blur 22 for simple part','22px' in (r['navBf'] or ''))
                else: chk(t+'nav blur 30 for ice part','30px' in (r['navBf'] or ''))
                # same flavor as page => no attribute
                pg.evaluate("D.cms.TX={hd:'%s',nv:'%s',sh:''};thApply()"%(m,m));r2=pg.evaluate(JS_Q)
                chk(t+'same-as-page no attr',r2['top']=='' and r2['nav']=='' and r2['ov']=='')
                # sheet live skin
                pg.evaluate("D.cms.TX={sh:'%s'};thApply();sheet('<h3>x</h3><button class=\"btn\">ok</button>')"%o);pg.wait_for_timeout(350)
                sb=pg.evaluate("(()=>{const e=document.querySelector('#ov .sheet');if(!e)return null;const s=getComputedStyle(e);return (s.backdropFilter||s.webkitBackdropFilter||'')+'|'+(document.documentElement.scrollWidth<=innerWidth)})()")
                chk(t+'sheet exists',sb is not None)
                if sb: chk(t+'sheet blur matches part',('34px' if o=='ice' else '24px') in sb and sb.endswith('true'))
                if w==360 and not dark and m=='i': pg.screenshot(path='/tmp/lg19.png')
                # local user override
                pg.evaluate("cl();D.cms.TX={};delete D.cms.TX;localStorage.setItem('bp_ulg','%s');thApply()"%o);r3=pg.evaluate(JS_Q)
                chk(t+'user override flavor',r3['lg']==o)
                # non-LG page: no tmx
                pg.evaluate("localStorage.removeItem('bp_ulg');D.cms.TH.store={m:'m'};D.cms.TX={hd:'ice',nv:'ice',sh:'ice'};thApply()");r4=pg.evaluate(JS_Q)
                chk(t+'non-LG page no tmx',r4['lg']=='' and r4['top']=='' and r4['nav']=='')
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
