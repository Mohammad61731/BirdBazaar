# تست 1.9.320: AN72 چرخش اعداد تایمر (anDl) + AN74 تیک ثبت آگهی (anOkAd)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("window.__an=0;const o=Element.prototype.animate;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};0")
            pg.evaluate("const e=document.createElement('span');e.id='tdl';e.style.cssText='position:fixed;top:100px;left:20px;direction:ltr;z-index:9';document.body.appendChild(e);0")
            pg.evaluate("anDl(document.getElementById('tdl'),'01:02:03')")
            txt=pg.evaluate("document.getElementById('tdl').textContent")
            chk(t+'anDl text first', txt=='⏱ 01:02:03')
            pg.evaluate("window.__an=0;anDl(document.getElementById('tdl'),'01:02:04')")
            n=pg.evaluate("window.__an");txt=pg.evaluate("document.getElementById('tdl').textContent")
            chk(t+'anDl text updated', txt=='⏱ 01:02:04')
            if rm=='no-preference': chk(t+'anDl animates only changed char', n==1)
            else: chk(t+'reduced: anDl no anim', n==0)
            pg.evaluate("window.__an=0;anOkAd()")
            n2=pg.evaluate("window.__an");has=pg.evaluate("!!document.getElementById('anok')")
            if rm=='no-preference':
                chk(t+'anOkAd overlay + 11 anims', has and n2==11)
                pg.evaluate("window.__an=0;anOkAd()")
                chk(t+'anOkAd no double', pg.evaluate("window.__an")==0)
                pg.wait_for_timeout(1600)
                chk(t+'anOkAd removed', pg.evaluate("!document.getElementById('anok')"))
            else:
                chk(t+'reduced: anOkAd nothing', (not has) and n2==0)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
