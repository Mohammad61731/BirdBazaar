# تست 1.9.473: پیامک آماده‌ی غرفه‌دار به پیک (کلید pm)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        X="{s:'acc',cp:'09123456789'}"
        chk(f'{w}: off -> empty',pg.evaluate(f"pmH({X})===''"))
        pg.evaluate("XF.pm=1")
        chk(f'{w}: acc -> 3 sms chips to courier',pg.evaluate(f"(()=>{{const h=pmH({X});return (h.match(/sms:09123456789\\?body=/g)||[]).length==3}})()"))
        chk(f'{w}: farsi digits ok',pg.evaluate("pmH({s:'acc',cp:'۰۹۱۲۳۴۵۶۷۸۹'}).includes('sms:09123456789')"))
        chk(f'{w}: rdy/pick/done -> none',pg.evaluate("['rdy','pick','way','done','ext'].every(s=>pmH({s:s,cp:'0912'})==='')"))
        chk(f'{w}: no cp -> none, no crash',pg.evaluate("pmH({s:'acc'})===''&&pmH(null)===''&&pmH(undefined)===''"))
        chk(f'{w}: hooked in crOwnH',pg.evaluate("crOwnH.toString().includes('pmH(c)')"))
        pg.evaluate(f"document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+pmH({X})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: 3 chips',pg.locator('#scr a.chip').count()==3)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/pm360.png')
    br.close()
print('ERRORS',errs)
