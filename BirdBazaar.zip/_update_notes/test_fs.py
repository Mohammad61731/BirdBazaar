# تست 1.9.100: ورود ذخیره‌شده قبل از اولین نمایش اعمال می‌شود؛ رد سرور ← برگشت به مهمان؛ کلید خاموش ← رفتار قبلی
import asyncio, sys, json, time
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    def sess(**k):
        d={'u':'ali','p':'1234','adm':False,'r':'user','pm':[],'vip':0,'code':'AB12','inv':1,'t':int((time.time()-3*86400)*1000)}; d.update(k); return json.dumps(d)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        async def mk(w,sv,mode,delay=0,off_key=False):
            ctx=await b.new_context(viewport={'width':w,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                req=route.request; u=req.url
                if u.startswith('file:'): return await route.continue_()
                if u.endswith('/rpc/app'):
                    bd=json.loads(req.post_data or '{}')
                    if bd.get('op')=='login':
                        if mode=='down': return await route.abort()
                        if delay: await asyncio.sleep(delay)
                        try:
                            if mode=='deny': return await route.fulfill(status=200,content_type='application/json',body='{"err":"login"}')
                            role='admin' if json.loads(sv).get('r')=='admin' else 'user'
                            return await route.fulfill(status=200,content_type='application/json',body=json.dumps({'role':role,'pm':['all'] if role=='admin' else [],'vip':0,'code':'AB12','inv':1}))
                        except Exception: return
                try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
                except Exception: pass
            await pg.route('**/*',h)
            init="if(!sessionStorage.getItem('__i')){sessionStorage.setItem('__i','1');localStorage.setItem('bp3s',%s);if(!localStorage.getItem('bp4'))localStorage.setItem('bp4','{\"products\":[],\"stories\":[],\"ads\":[]}');%s}"%(json.dumps(sv),"localStorage.setItem('bp_tls','{\"fs\":0}');" if off_key else '')
            await pg.add_init_script(init)
            await pg.goto('file://%s/www/index.html'%ROOT)
            return ctx,pg,errs
        w=360
        # A) سرور سالم ولی کند (4 ثانیه)
        for w in (320,360,412):
            ctx,pg,errs=await mk(w,sess(),'ok',delay=4)
            await pg.wait_for_timeout(1200)
            r=await pg.evaluate("({role:S.role,me:S.me,fs:S.fs})")
            chk('%d A: user applied before server answers'%w, r['role']=='user' and r['me']=='ali' and r['fs']==1)
            await pg.get_by_text('پروفایل').last.click(); await pg.wait_for_timeout(400)
            t=await pg.evaluate("document.querySelector('#scr').innerText")
            chk('%d A: profile is not guest page'%w, 'ساخت حساب' not in t and 'مهمان' not in t)
            if w==360: await pg.screenshot(path='%s/_update_notes/shots/fs_profile_360.png'%ROOT)
            await pg.wait_for_timeout(5500)
            r=await pg.evaluate("({role:S.role,fs:S.fs,off:S.off,t:JSON.parse(localStorage.getItem('bp3s')).t,ov:document.documentElement.scrollWidth>innerWidth})")
            chk('%d A: verified later, saved fresh, no overflow'%w, r['role']=='user' and not r['fs'] and not r['off'] and time.time()*1000-r['t']<60000 and not r['ov'])
            chk('%d A: no errors %s'%(w,errs), not errs); await ctx.close()
        # B) سرور رد می‌کند (بار اول): برمی‌گردد به مهمان ولی ورود ذخیره می‌ماند
        ctx,pg,errs=await mk(360,sess(),'deny',delay=2)
        await pg.wait_for_timeout(800); r1=await pg.evaluate("S.role")
        await pg.wait_for_timeout(4000)
        r=await pg.evaluate("({role:S.role,me:S.me,fs:S.fs,f:(JSON.parse(localStorage.getItem('bp3s'))||{}).f})")
        chk('B: optimistic then reverted to guest (1st deny keeps login saved)', r1=='user' and r['role'] is None and not r['me'] and not r['fs'] and r['f']==1)
        await ctx.close()
        # C) رد بار دوم: ورود پاک می‌شود
        ctx,pg,errs=await mk(360,sess(f=1),'deny',delay=2)
        await pg.wait_for_timeout(5000)
        r=await pg.evaluate("({role:S.role,saved:!!localStorage.getItem('bp3s')})")
        chk('C: 2nd deny clears saved login', r['role'] is None and not r['saved']); await ctx.close()
        # D) کلید خاموش: رفتار قبلی (اول مهمان)
        ctx,pg,errs=await mk(360,sess(),'ok',delay=4,off_key=True)
        await pg.wait_for_timeout(1200); r1=await pg.evaluate("S.role")
        await pg.wait_for_timeout(5500); r2=await pg.evaluate("S.role")
        chk('D: key off = old behaviour (guest first, user later)', r1 is None and r2=='user'); await ctx.close()
        # E) سرور قطع: همان ورود می‌ماند و آفلاین علامت می‌خورد
        ctx,pg,errs=await mk(360,sess(),'down')
        await pg.wait_for_timeout(2500)
        r=await pg.evaluate("({role:S.role,off:S.off})")
        chk('E: server down keeps login (off=1)', r['role']=='user' and r['off']==1); await ctx.close()
        # F) ادمین با دسترسی
        ctx,pg,errs=await mk(360,sess(adm=True,r='admin',pm=['all']),'ok',delay=4)
        await pg.wait_for_timeout(1200)
        r=await pg.evaluate("({role:S.role,pm:S.pm})")
        chk('F: admin applied instantly with pm', r['role']=='admin' and 'all' in r['pm']); await ctx.close()
        # G) ادمین قدیمی بدون pm: اعمال نشود
        ctx,pg,errs=await mk(360,sess(adm=True,r='admin',pm=[]),'ok',delay=4)
        await pg.wait_for_timeout(1200)
        r=await pg.evaluate("S.role")
        chk('G: admin without pm not applied early', r is None); await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
