# تست 1.9.228: پک بلوچی (IC13)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for sch in ('light','dark'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch)
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("icSheet()");pg.wait_for_timeout(300)
            chk(f'{w}/{sch}: button',pg.locator('[data-a=icmn]').count()>=2)
            pg.click('[data-a=icmn][data-v="بلوچی"]');pg.wait_for_timeout(900)
            ks=pg.evaluate("Object.keys(ikLib)");s=pg.evaluate("ikSel()")
            chk(f'{w}/{sch}: 18 icons',len(ks)==18)
            chk(f'{w}/{sch}: 18 slots set',len(s)==18)
            chk(f'{w}/{sch}: size<8000',pg.evaluate("Object.values(ikLib).every(e=>e.u.length<8000&&e.u.indexOf('data:image/svg+xml')==0&&!e.c)"))
            chk(f'{w}/{sch}: in IKL',pg.evaluate("Object.keys(D.cms.IKL||{}).length==18"))
            chk(f'{w}/{sch}: no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360:
                pg.screenshot(path=f'/tmp/ic12_{sch}.png')
            pg.evaluate("cl&&cl()")
            ok=pg.evaluate("(()=>{try{return xf('xic')}catch(e){return null}})()")
            pg.evaluate("render()");pg.wait_for_timeout(300)
            pg.evaluate("icSheet()");pg.click('[data-a=icra]');pg.wait_for_timeout(400)
            chk(f'{w}/{sch}: reset to default',pg.evaluate("Object.keys(ikSel()).length==0"))
            ctx.close()
    br.close()
print('ERRORS',errs)
