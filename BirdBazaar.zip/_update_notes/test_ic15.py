# تست 1.9.230: پک رنگی «دسته‌ها»
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("icSheet()");pg.wait_for_timeout(300)
        pg.click('[data-a=icct][data-v="2"]');pg.wait_for_timeout(900)
        chk(f'{w}: 24 icons',pg.evaluate("Object.keys(ikLib).length==24"))
        chk(f'{w}: colored + <8000',pg.evaluate("Object.values(ikLib).every(e=>e.c==1&&e.u.length<8000&&e.g=='دسته‌ها ۲')"))
        chk(f'{w}: slots untouched',pg.evaluate("Object.keys(ikSel()).length==0"))
        pg.evaluate("icPick('qa.disc')");pg.wait_for_timeout(500)
        chk(f'{w}: picker shows 24',pg.locator('[data-a=ick]').count()>=24)
        pg.click('[data-a=ick][data-v$="cu_17"]');pg.wait_for_timeout(500)
        chk(f'{w}: pick sets slot',pg.evaluate("ikSel()['qa.disc']=='cu_17'"))
        pg.evaluate("icSetMany([['qa.birds','cu_17'],['qa.booth','cu_19']])");pg.wait_for_timeout(300)
        chk(f'{w}: selectable for server',pg.evaluate("Object.keys(D.cms.IKL||{}).length==2"))
        chk(f'{w}: no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/ic15.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
