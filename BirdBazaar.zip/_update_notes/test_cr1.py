# تست 1.9.373 C5a: پیک (ثبت‌نام ، پنل ، ارسال با پیک ، صف ادمین)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
def hy(route,req):
    b=json.loads(req.post_data or '{}');CALLS.append(b['op']);o=b['op']
    r={'err':'op'}
    if o=='yreg':r={'ok':1,'me':{'name':b['a']['name'],'veh':b['a']['veh'],'area':b['a']['area'],'st':'pending'}}
    elif o=='yme':r={'ok':1,'me':{'name':'رضا','veh':'m','area':'مرکز','st':'ok'}}
    elif o=='yset':r={'ok':1}
    elif o=='yadm_list':r={'ok':1,'l':[{'id':5,'u':'09121112233','name':'پیک یک','veh':'m','area':'ب','st':'pending'}]}
    elif o=='yadm_set':r={'ok':1}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/yapp',hy)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_cru')");CALLS.clear()
        chk(t+'off: no courier btn',pg.evaluate("!crOn()&&!btActs().includes('bt_cr')"))
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1")
        chk(t+'on: btn',pg.evaluate("crOn()&&btActs().includes('bt_cr')"))
        pg.evaluate("crSheet()");pg.wait_for_timeout(200)
        chk(t+'form shown',pg.evaluate("!!document.getElementById('cru')&&!document.getElementById('crn')"))
        pg.locator('[data-a=bt_crm][data-v=up]').dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'signup fields',pg.evaluate("!!document.getElementById('crn')&&!!document.getElementById('crv')&&!!document.getElementById('cra')"))
        pg.fill('#cru','09121112233');pg.fill('#crp','1234');pg.fill('#crn','رضا');pg.fill('#cra','مرکز')
        pg.locator('[data-a=bt_cru]').dispatch_event('click');pg.wait_for_timeout(400)
        chk(t+'yreg sent',CALLS.count('yreg')==1)
        chk(t+'panel pending',pg.evaluate("document.querySelector('.sheet').innerText.includes('در انتظار تأیید')")and pg.evaluate("!!localStorage.getItem('bp_cru')"))
        pg.evaluate("CRM.r=null;crSheet()");pg.wait_for_timeout(300)
        chk(t+'yme approved',pg.evaluate("document.querySelector('.sheet').innerText.includes('تأییدشده')"))
        pg.locator('[data-a=bt_crs]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'yset sent',CALLS.count('yset')==1)
        chk(t+'no sheet overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        chk(t+'owner: ready btn',pg.evaluate("(()=>{BM={booth:{id:1}};cgSaveC({t:Date.now(),g:{1:{id:1,lvl:1}}});return crOwnH({id:3,s:'new'}).includes('bt_crr')})()"))
        chk(t+'owner: none when unverified/in-person',pg.evaluate("(()=>{BM={booth:{id:2}};return crOwnH({id:3,s:'new'})==''&&(BM={booth:{id:1}},crOwnH({id:3,s:'new',pk:{h:2}})=='')})()"))
        chk(t+'owner: status chips',pg.evaluate("crOwnH({id:3,s:'new',cr:{s:'rdy'}}).includes('آماده‌ی ارسال')&&crOwnH({id:3,s:'new',cr:{s:'rdy'}}).includes('class=\"on\"')"))
        chk(t+'admin list',pg.evaluate("(()=>{S.me='a';S.role='admin';return true})()"))
        ctx.close()
    br.close()
print('ERRORS',errs)
