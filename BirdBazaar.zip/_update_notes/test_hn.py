# تست 1.9.123: ردیف‌های تازه‌ی خانه (cfg.hn)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'تهران'},{id:2,name:'غرفه دو',n:1,views:9,logo:'',city:'قم'},{id:3,name:'غرفه سه',n:0,views:0,logo:'',city:'یزد'}];BT.prods=[];BT.ok=1;BT.t=Date.now();D.products=[{id:901,name:'ویتامین',cat:'مکمل',price:90000,img:'',vol:{},dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}}];localStorage.setItem('bp_rv',JSON.stringify(['p901','a999','zzz']));S.role=null;go({tab:0,v:null})")
            pg.wait_for_timeout(400)
            h=pg.evaluate("[...document.querySelectorAll('#scr .hbk')].map(e=>e.dataset.b).join(',')")
            chk(t+'new blocks present ('+h+')',all(x in h for x in ('srch','nb','pb','rv')))
            chk(t+'order srch first',h.startswith('srch'))
            chk(t+'new booths sorted by id desc',pg.evaluate("document.querySelector('[data-b=nb] .bm').dataset.v")=='3')
            chk(t+'popular sorted by views',pg.evaluate("document.querySelector('[data-b=pb] .bm').dataset.v")=='2')
            chk(t+'recent shows 1 product, bad keys ignored',pg.evaluate("document.querySelectorAll('[data-b=rv] .pc,[data-b=rv] .bm').length")==1)
            chk(t+'no horizontal overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
            pg.click('.hsr');pg.wait_for_timeout(200)
            chk(t+'search tile opens store',pg.evaluate("S.tab==1&&!S.v"))
            pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(200)
            if pg.locator('[data-b=srch] .chip').count():
                pg.locator('[data-b=srch] .chip').first.click();pg.wait_for_timeout(200)
                chk(t+'hot chip sets category in store',pg.evaluate("S.tab==1&&!!S.cat"))
            pg.evaluate("D.cfg.hn=0;go({tab:0,v:null})");pg.wait_for_timeout(200)
            h2=pg.evaluate("[...document.querySelectorAll('#scr .hbk')].map(e=>e.dataset.b).join(',')")
            chk(t+'hn=0 hides all new blocks',not any(x in h2.split(',') for x in ('srch','nb','pb','rv')))
            if w==360 and not dark:
                pg.evaluate("D.cfg.hn=1;go({tab:0,v:null})");pg.wait_for_timeout(300);pg.screenshot(path='../shots/hn360.png')
                pg.evaluate("go({v:'prod',id:901})");pg.wait_for_timeout(200)
                chk(t+'visiting product records recent',pg.evaluate("JSON.parse(localStorage.getItem('bp_rv'))[0]")=='p901')
            ctx.close()
    br.close()
print('ERRORS',errs)
