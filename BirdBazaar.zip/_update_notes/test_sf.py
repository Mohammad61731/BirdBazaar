# تست 1.9.102: بروزرسانی بخش‌به‌بخش + آگاهی از نوع اینترنت
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ops=[]
        async def mk(conn):
            ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            await pg.add_init_script("Object.defineProperty(navigator,'connection',{get:()=>(%s),configurable:true})"%conn)
            async def h(route):
                req=route.request; u=req.url
                if u.startswith('file:'): return await route.continue_()
                try:
                    bd=json.loads(req.post_data or '{}')
                except Exception: bd={}
                ops.append((u.rsplit('/',1)[-1],bd.get('op')))
                try:
                    if bd.get('op')=='psig': return await route.fulfill(status=200,content_type='application/json',body='{"ok":1,"s":"A","b":"B"}')
                    await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
                except Exception: pass
            await pg.route('**/*',h)
            await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1500)
            await pg.evaluate("S.role='user';S.me='ali'")
            return pg,errs
        cnt=lambda name: sum(1 for o in ops if o[1]==name)
        # نوع اینترنت
        for conn,exp,mul in [("{type:'wifi',effectiveType:'4g'}",'wifi',1),("{type:'cellular',effectiveType:'4g'}",'cell',2),("{effectiveType:'2g'}",'slow',3),("{effectiveType:'4g',saveData:true}",'slow',3),("undefined",'unk',1.5)]:
            pg,errs=await mk(conn); r=await pg.evaluate("[sfNet(),sfMul()]"); chk('net %s'%exp, r==[exp,mul]); await pg.context.close()
        pg,errs=await mk("{type:'wifi',effectiveType:'4g'}")
        # بیکار ← هیچ درخواستی
        await pg.evaluate("LV.act=Date.now()-600000;SF.pl=0"); n0=len(ops)
        await pg.evaluate("sfTick()"); await pg.wait_for_timeout(300)
        rel=[o for o in ops[n0:] if o[1] in ('ping','psig','public','public2','pidx','bpublic','adx_list')]
        chk('idle: no requests (%s)'%rel, not rel)
        # انجمن ← هیچ مهر محصول
        await pg.evaluate("LV.act=Date.now();S.v=null;S.tab=5;SF.pl=0"); n0=len(ops); p0=cnt('psig')
        await pg.evaluate("sfTick()"); await pg.wait_for_timeout(300)
        chk('forum tab: no psig', cnt('psig')==p0)
        chk('groups forum empty', await pg.evaluate("sfGroups().length")==0)
        # خانه ← psig
        await pg.evaluate("S.tab=0;SF.pl=0;LV.act=Date.now();LV.busy=0"); p0=cnt('psig')
        await pg.evaluate("sfTick()"); await pg.wait_for_timeout(500)
        chk('home tab: psig asked (%s)'%(cnt('psig')-p0), cnt('psig')>p0)
        chk('groups home pr+bt', await pg.evaluate("sfGroups().join()")=='pr,bt')
        # فاصله: بلافاصله دوباره ← اجرا نشود
        p0=cnt('psig'); await pg.evaluate("sfTick()"); await pg.wait_for_timeout(300)
        chk('too soon: skipped', cnt('psig')==p0)
        # داده‌ی همراه: 70 ثانیه کافی نیست
        await pg.evaluate("Object.defineProperty(navigator,'connection',{get:()=>({type:'cellular'}),configurable:true});SF.pl=Date.now()-70000"); p0=cnt('psig')
        await pg.evaluate("sfTick()"); await pg.wait_for_timeout(300)
        chk('cellular: 70s not enough', cnt('psig')==p0)
        # ورود به بخش با TTL
        await pg.evaluate("Object.defineProperty(navigator,'connection',{get:()=>({type:'wifi'}),configurable:true});SF.t={};LV.busy=0;LV.act=Date.now()"); p0=cnt('psig')
        await pg.evaluate("go({tab:2,v:null})"); await pg.wait_for_timeout(500)
        a=cnt('psig')-p0
        await pg.evaluate("LV.busy=0;go({tab:3,v:null})"); await pg.wait_for_timeout(500)
        chk('enter: first asks, second within TTL does not (%s,%s)'%(a,cnt('psig')-p0-a), a>=1 and cnt('psig')-p0==a)
        # کلید خاموش ← رفتار قبلی (هر ۲ تیک ping+pull)
        await pg.evaluate("tlSet('sf',0);SF.k=1"); n0=len(ops)
        await pg.evaluate("sfTick()"); await pg.wait_for_timeout(500)
        chk('off: old cadence ping', any(o[1]=='ping' for o in ops[n0:]))
        chk('tlOn sf off', await pg.evaluate("tlOn('sf')")==False)
        await pg.evaluate("tlSet('sf',1)")
        chk('tlSf html', 'ضریب' in await pg.evaluate("tlSf()"))
        chk('pollDue slower on cell', await pg.evaluate("(()=>{Object.defineProperty(navigator,'connection',{get:()=>({type:'cellular'}),configurable:true});return sfMsg()})()")==1.5)
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
