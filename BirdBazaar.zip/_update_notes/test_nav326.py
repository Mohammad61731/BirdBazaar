# تست 1.9.326: جمع‌شدن نرم نوار پایین (data-fh با rAF + transform فقط)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("['.epg','#spl','#bz'].forEach(s=>document.querySelectorAll(s).forEach(e=>e.remove()));const a=document.getElementById('app');a.dataset.lg='i';document.getElementById('scr').insertAdjacentHTML('beforeend','<div style=\"height:3000px\"></div>');0")
            pg.wait_for_timeout(300)
            pg.evaluate("document.getElementById('scr').scrollTop=300");pg.wait_for_timeout(120)
            pg.evaluate("document.getElementById('scr').scrollTop=500");pg.wait_for_timeout(700)
            fh=pg.evaluate("!!document.getElementById('app').dataset.fh")
            chk(t+'scroll down collapses',fh)
            tr=pg.evaluate("getComputedStyle(document.getElementById('nav')).transform")
            if rm=='no-preference': chk(t+'nav scaled (transform)',tr!='none' and 'matrix' in tr and tr.startswith('matrix(0.8'))
            else: chk(t+'reduced: no transform',tr=='none')
            pg.evaluate("document.getElementById('scr').scrollTop=470");pg.wait_for_timeout(500)
            chk(t+'scroll up expands',not pg.evaluate("!!document.getElementById('app').dataset.fh"))
            chk(t+'nav expanded transform none/identity',pg.evaluate("getComputedStyle(document.getElementById('nav')).transform")in('none','matrix(1, 0, 0, 1, 0, 0)'))
            pg.evaluate("document.getElementById('scr').scrollTop=900");pg.wait_for_timeout(300);pg.evaluate("document.getElementById('scr').scrollTop=0");pg.wait_for_timeout(500)
            chk(t+'top expands',not pg.evaluate("!!document.getElementById('app').dataset.fh"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
