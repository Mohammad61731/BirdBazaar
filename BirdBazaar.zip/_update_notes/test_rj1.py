# تست 1.9.476: انصراف پیک و جایگزین خودکار (کلید rj)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        chk(f'{w}: off -> empty',pg.evaluate("rjH({s:'acc',id:3})===''&&rjN({s:'rdy',rc:1})===''"))
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.rj=1")
        chk(f'{w}: acc -> cancel button',pg.evaluate("(()=>{const h=rjH({s:'acc',id:3});return h.includes('bt_crcn')&&h.includes('data-v=\"3\"')})()"))
        chk(f'{w}: pick/way/done -> no button',pg.evaluate("['pick','way','done','rdy'].every(s=>rjH({s:s,id:1})==='')"))
        chk(f'{w}: owner note only when rdy + rc>0',pg.evaluate("rjN({s:'rdy',rc:1}).includes('انصراف')&&rjN({s:'rdy'})===''&&rjN({s:'acc',rc:2})===''&&rjN(null)===''"))
        chk(f'{w}: hooked in jobs and owner views',pg.evaluate("crJobsH.toString().includes('rjH(x)')&&crOwnH.toString().includes('rjN(c)')"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+rjH({s:'acc',id:3})+rjN({s:'rdy',rc:1})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/rj360.png')
    br.close()
print('ERRORS',errs)
