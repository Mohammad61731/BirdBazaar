# تست 1.9.382 C5f/79: کلید cy ، کد رهگیری ، دکمه‌ی ارسال بیرونی ، نمایش وضعیت ext
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
TR=[]
def hb(route,req):
    b=json.loads(req.post_data or '{}')
    if b.get('op')=='cr_ext':
        CALLS.append(b['a']);route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
    elif b.get('op')=='cr_trk':
        TR.append(b['a']);route.fulfill(status=200,content_type='application/json',body='{"ok":1}')
    else:handle(route,req)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.on('dialog',lambda d:d.accept('RR123'))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',hb)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900);CALLS.clear()
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.cx=0;BM={booth:{id:1}};cgVer=()=>1")
        h0=pg.evaluate("crOwnH({id:7,s:'new'})")
        chk(t+'cx off: no external button','bt_crb' not in h0 and 'bt_crr' in h0)
        pg.evaluate("XF.cx=1")
        h1=pg.evaluate("crOwnH({id:7,s:'new'})")
        chk(t+'cx on: external button','bt_crb' in h1)
        pg.evaluate("XF.cr=0");h2=pg.evaluate("crOwnH({id:7,s:'new'})");pg.evaluate("XF.cr=1")
        chk(t+'needs cr',h2=='')
        pg.evaluate("BOR=[{id:7,name:'م',phone:'1',s:'new',t:new Date().toISOString(),lines:[],total:1}];btAct('bt_crb','7')");pg.wait_for_timeout(300)
        chk(t+'op sent',CALLS==[{'id':7,'ec':'RR123'}])
        h3=pg.evaluate("crOwnH({id:7,s:'new',cr:{s:'ext',ec:'RR123'}})")
        chk(t+'ext shown with code, no courier chips','RR123' in h3 and 'ارسال بیرونی' in h3 and 'crst' not in h3)
        pg.evaluate("XF.cy=0");hy0=pg.evaluate("crOwnH({id:7,s:'new',cr:{s:'ext',ec:'RR123'}})")
        chk(t+'cy off: no edit button','bt_crtk' not in hy0)
        pg.evaluate("XF.cy=1");hy1=pg.evaluate("crOwnH({id:7,s:'new',cr:{s:'ext',ec:'RR123'}})")
        chk(t+'cy on: edit button','bt_crtk' in hy1)
        pg.evaluate("XF.cx=0");hy2=pg.evaluate("crOwnH({id:7,s:'new'})");pg.evaluate("XF.cx=1")
        chk(t+'cy needs cx',pg.evaluate("(XF.cx=0,cyOn())")==False);pg.evaluate("XF.cx=1")
        TR.clear();pg.evaluate("BOR=[{id:7,name:'م',phone:'1',s:'new',t:new Date().toISOString(),lines:[],total:1}];btAct('bt_crtk','7')");pg.wait_for_timeout(300)
        print('TR',TR,CALLS);chk(t+'trk op sent',TR==[{'id':7,'ec':'RR123'}])
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
