# تست مورد ۱۴ (مرحله ۴): آفلاین؛ غرفه‌ها از کش، نشانگر آفلاین، بازگشت آنلاین
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            ctx=await b.new_context(viewport={'width':w,'height':700}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            st={'off':False}
            async def h(route):
                u=route.request.url
                if u.startswith('http'):
                    if st['off']: return await route.abort()
                    if 'bapp' in u: body={'ok':1,'booths':[{'id':'b1','name':'غرفه آزمون','logo':'🐦'}],'prods':[]}
                    else: body={'ok':1,'products':[{'id':9,'name':'محصول آزمون','price':1000,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[]}
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            await pg.evaluate("bpull()"); c=await pg.evaluate("localStorage.getItem('bp_bc')"); print(w,'cache saved',bool(c)); ok&=bool(c)
            st['off']=True; await ctx.set_offline(True)
            await pg.reload(); await pg.wait_for_timeout(1500)
            r=await pg.evaluate("""async()=>{await bpull();const o=document.getElementById('ofb');return {booth:BT.ok&&BT.booths.length,prods:D.products.length,badge:o&&getComputedStyle(o).display,ov:document.documentElement.scrollWidth>innerWidth}}""")
            print(w,r,errs); ok&=r['booth']==1 and r['prods']>0 and r['badge']=='block' and not r['ov'] and not errs
            st['off']=False; await ctx.set_offline(False); await pg.wait_for_timeout(500)
            bd=await pg.evaluate("getComputedStyle(document.getElementById('ofb')).display"); print(w,'badge after online',bd); ok&=bd=='none'
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
