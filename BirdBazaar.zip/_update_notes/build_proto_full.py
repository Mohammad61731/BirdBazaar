import html,base64
from playwright.sync_api import sync_playwright
app=open('demo_app.html',encoding='utf8').read()
SEED="S.me='ali';S.pw='1';BT.ok=1;BT.t=Date.now()+1e9;"
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':360,'height':740},locale='fa-IR').new_page()
    pg.goto('file:///tmp/bb/_update_notes/demo_app.html');pg.wait_for_timeout(900);pg.evaluate("bpull()");pg.wait_for_timeout(300)
    def shot(n,js):
        pg.evaluate(SEED+js);pg.wait_for_timeout(700);pg.screenshot(path='shots/f_%s.png'%n)
    shot('home',"go({tab:0,v:null})")
    shot('store',"go({tab:1,v:null,sub:0})")
    shot('forum',"go({tab:5,v:null})")
    shot('glass',"D.cms.TH=D.cms.TH||{};D.cms.TH.home={m:'g',c:'green',b:0,s:'g',g1:'#0ea5e9',g2:'#6366f1'};thApply();go({tab:0,v:null})")
    pg.evaluate("D.cms.TH={};thApply()")
    br.close()
b=lambda f:'data:image/png;base64,'+base64.b64encode(open('shots/'+f,'rb').read()).decode()
I=lambda *f:''.join('<img src="%s" alt="">'%b(x) for x in f)
S=[
('🏪 غرفه‌ها و ویترین','صفحه‌ی اختصاصی هر غرفه، محصول معمولی/وزنی/حجمی (خرده و عمده)، ویترین ترکیبی «همه | بازارچه | غرفه‌داران»، ویترین تمام‌عرض، ردیف غرفه‌داران جدید و بنرهای ویترین. درخواست همکاری هم از همان‌جا ثبت می‌شود.',I('f_store.png','p_booth.png')),
('🛒 سبد، فاکتور و سفارش','بعد از ثبت سفارش، «📤 ارسال فاکتور» (بله برای مکمل‌ها، پیامک برای غرفه‌ها) باز می‌شود. غرفه‌دار سفارش‌های جدید را بالا می‌بیند و «✔ بستن سفارش» یا «لغو» می‌زند.',I('y2_inv.png')),
('💬 گفتگوی کاربر↔غرفه‌دار','پیام‌رسان شبیه Google Messages با تیک ✓/✓✓، شمارنده‌ی نخوانده و فرستادن کارت محصول با دکمه‌ی 🛍.',I('p_list.png','p_chat.png')),
('🗣 انجمن','اتاق‌ها، پیام، پاسخ، عکس/فیلم/فایل طبق مجوز، درخواست اجازه‌ی ارسال، و ابزار مدیریتی (سنجاق، گزارش، حذف، بی‌صدا/مسدود).',I('f_forum.png')),
('🎨 تم و ظاهر','ادمین برای هر تب تم معمولی، شیشه‌ای (ساده یا گرادینت) یا عکس لایه‌باز و نئون انتخاب می‌کند. تم خودکار طبق روشن/تاریک گوشی (🌓 سه‌حالته).',I('f_glass.png','f_home.png')),
('📨 پیام مدیریت و کارت آگهی','ادمین به یک کاربر یا همه‌ی غرفه‌داران/مدیران/کاربران پیام می‌دهد (📨 در منو). کارت آگهی مدرن: عکس، عنوان، قیمت، شهر؛ پروفایل آگهی‌دهنده داخل آگهی.',''),
('⚙️ مدیریت','ورود غرفه‌داران با حساب اصلی (رمز جدا حذف شد)، لیست غرفه‌ها با جست‌وجو و فیلتر، دیدن سفارش‌ها و ویرایش غرفه، مدیر کردن (🛡) با تیک دسترسی، عکس پروفایل.',''),
('⚡ سرعت و نصب تازه','باز شدن سریع با داده‌ی ذخیره‌شده، آپدیت خودکار محتوا (۳ ثانیه)، استوری، و در نصب تازه صفحه‌ی «در حال بارگذاری…» تا محتوای فعلی سرور بیاید.',''),
]
cards=''.join('<section class="c"><h3>%s</h3><p>%s</p><div class="sh">%s</div></section>'%x for x in S)
T=[('کاربر عادی',['از ویترین یک غرفه را باز کن و «💬 پیام به غرفه‌دار» را بزن.','با 🛍 محصول بفرست یا سفارش را از سبد ثبت کن.','فاکتور را با «📤 ارسال فاکتور» بفرست.','پیام‌های تازه را در منوی ☰ ← «💬 گفتگوها» ببین.']),
('غرفه‌دار',['با همان حساب اصلی وارد شو.','در پنل غرفه‌دار محصول اضافه کن (معمولی/وزنی/حجمی).','از «💬 گفتگوها» به مشتری جواب بده؛ تیک ✓✓ یعنی خوانده شد.','در «سفارش‌ها» سفارش را ببند یا لغو کن.']),
('ادمین',['خانه را با دستگیره ⠿ و ▲▼ مرتب کن و ذخیره کن (برای نصب تازه لازم است).','از ☰ ← «🎨 تم این تب» تم هر تب را عوض کن.','از 📨 پیام‌ها اعلان بفرست؛ از «کاربران» 🏪 و 🛡 بده.','قبل از آپدیت، فایل‌های SQL را در Supabase اجرا کن: UPDATE_FINAL.sql و UPDATE_FINAL2.sql.'])]
tut=''.join('<section class="c"><h3>%s</h3><ol>%s</ol></section>'%(n,''.join('<li>%s</li>'%s for s in l)) for n,l in T)
page='''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>بازارچه پرندگان — پروتوتایپ کامل ۱.۹.۳</title>
<style>:root{--f:#12805c;--bg:#f2f4f3;--sf:#fff;--ink:#1c2b25;--mu:#66766f}@media(prefers-color-scheme:dark){:root{--f:#34c48f;--bg:#0f1714;--sf:#18231f;--ink:#e8f0ec;--mu:#8fa39a}}
*{box-sizing:border-box}body{margin:0;font-family:Vazirmatn,Tahoma,sans-serif;background:var(--bg);color:var(--ink)}
.tabs{position:sticky;top:0;display:flex;gap:6px;padding:10px;background:var(--bg);z-index:5}.tabs button{flex:1;padding:10px;border:0;border-radius:12px;background:var(--sf);color:var(--ink);font:inherit;font-weight:700}.tabs .on{background:var(--f);color:#fff}
.p{padding:0 12px 24px}.c{background:var(--sf);border-radius:16px;padding:12px;margin-bottom:12px}.c h3{margin:0 0 4px;font-size:15px}.c p,.c li{color:var(--mu);font-size:13px;line-height:1.9}.c ol{margin:0;padding-inline-start:20px}.sh{display:flex;gap:8px;overflow-x:auto}.sh img{height:340px;border-radius:12px;flex:none;margin-top:8px}
.bar{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}.bar button{flex:1 1 30%;padding:8px;border:0;border-radius:10px;background:var(--sf);color:var(--ink);font:inherit;font-size:12px}
iframe{width:100%;height:calc(100vh - 190px);min-height:560px;border:0;border-radius:16px;background:#fff}.hide{display:none}</style></head><body>
<div class="tabs"><button class="on" id="b1">تغییرات</button><button id="b2">آموزش</button><button id="b3">اپ زنده</button></div>
<div class="p" id="t1">'''+cards+'''</div><div class="p hide" id="t2">'''+tut+'''</div>
<div class="p hide" id="t3"><div class="bar"><button onclick="r(0)">🏠 خانه</button><button onclick="r(1)">🛍 ویترین</button><button onclick="r(2)">🏪 غرفه</button><button onclick="r(3)">💬 گفتگوی کاربر</button><button onclick="r(4)">🧑‍🌾 گفتگوی غرفه‌دار</button><button onclick="r(5)">🎨 تم شیشه‌ای</button></div><p style="font-size:12px;color:var(--mu)">داده‌ها نمایشی‌اند و به سرور واقعی نمی‌روند.</p><iframe id="fr" srcdoc="'''+html.escape(app,quote=True)+'''"></iframe></div>
<script>const $=i=>document.getElementById(i);function tab(n){[1,2,3].forEach(i=>{$('t'+i).classList.toggle('hide',i!=n);$('b'+i).classList.toggle('on',i==n)})}[1,2,3].forEach(i=>$('b'+i).onclick=()=>tab(i));
function r(k){const w=$('fr').contentWindow,A="BT.ok=1;BT.t=Date.now()+1e9;";const J=["S.me='ali';S.pw='1';"+A+"D.cms.TH={};thApply();go({tab:0,v:null})","S.me='ali';S.pw='1';"+A+"go({tab:1,v:null,sub:0})","S.me='ali';S.pw='1';"+A+"btNav({v:'bts',id:7})","S.me='ali';S.pw='1';"+A+"cOpen(7,'ali','u')","S.me='bob';S.pw='1';"+A+"cListOpen()","D.cms.TH=D.cms.TH||{};D.cms.TH.home={m:'g',c:'green',b:0,s:'g',g1:'#0ea5e9',g2:'#6366f1'};thApply();go({tab:0,v:null})"];try{w.eval("bpull()");setTimeout(()=>w.eval(J[k]),400)}catch(e){}}</script></body></html>'''
open('/tmp/bb/prototype_full.html','w',encoding='utf8').write(page);print(len(page))
