import json
from playwright.sync_api import sync_playwright
errs=[];calls=[];MODE={'fav':'ok'}
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);calls.append(b)
        r={'err':'x'}
        if b['op']=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':False,'perm':{},'avatar':''}
        if b['op']=='fav_set':r={'ok':1} if MODE['fav']=='ok' else {'err':'big'}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:4,v:null})");pg.wait_for_timeout(700)
    print('avatar circle clickable:',pg.locator('.avt[data-a=fpic]').count(),'camera badge:',pg.locator('.avc').count(),'| fwho calls:',sum(c['op']=='fwho' for c in calls))
    pg.screenshot(path='../shots/f2_before.png')
    # fake picker: red square wide image 400x200
    pg.evaluate("(()=>{window.pick=cb=>{const c=document.createElement('canvas');c.width=400;c.height=200;const x=c.getContext('2d');x.fillStyle='#d33';x.fillRect(0,0,400,200);x.fillStyle='#fff';x.fillRect(150,50,100,100);cb(c.toDataURL('image/jpeg'))}})()")
    pg.click('.avt[data-a=fpic]');pg.wait_for_timeout(700)
    fs=[c for c in calls if c['op']=='fav_set'];print('fav_set sent:',len(fs),'| is jpeg:',fs[0]['a']['img'].startswith('data:image/jpeg') if fs else None,'| size chars:',len(fs[0]['a']['img']) if fs else None)
    print('avatar saved in FM:',bool(pg.evaluate("FM.avatar")),'| circle shows photo:',pg.evaluate("document.querySelector('.avt').style.background.includes('data:image')"),'| camera badge still:',pg.locator('.avc').count())
    pg.screenshot(path='../shots/f2_after.png')
    MODE['fav']='bad';pg.evaluate("FM.avatar='';");pg.click('.avt[data-a=fpic]');pg.wait_for_timeout(600);print('server error keeps old avatar empty:',pg.evaluate("FM.avatar===''"))
    pg.evaluate("go({role:null,me:'',pw:'',v:null,tab:4})");pg.wait_for_timeout(300);print('guest sees no photo button:',pg.locator('.avt[data-a=fpic]').count()==0)
    for w in (320,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("S.role='user';S.me='ali';go({tab:4,v:null})");pg.wait_for_timeout(200);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
