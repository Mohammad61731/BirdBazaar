# تست 1.9.517 PF1: پروفایل کاربر عادی
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        L=[{'id':i,'st':('new' if i%3==0 else 'done' if i%3==1 else 'x'),'it':[],'tt':1000*i,'dt':'1405/09/01'} for i in range(1,8)]
        pg.evaluate("S.role='user';S.me='u1';S.tab=4;S.v=null;MO.l=%s;render()"%json.dumps(L))
        pg.wait_for_timeout(300)
        chk(t+'4 status tiles',pg.evaluate("document.querySelectorAll('#scr .pft button').length==4"))
        chk(t+'counts shown',pg.evaluate("document.querySelectorAll('#scr .pft em').length>=3"))
        chk(t+'rows exist',pg.evaluate("document.querySelectorAll('#scr .pfr').length>=8"))
        chk(t+'account details has form',pg.evaluate("!!document.querySelector('#scr .pfd #nu')"))
        chk(t+'nav label',pg.evaluate("[...document.querySelectorAll('nav button, #nav button')].some(b=>b.textContent.includes('پروفایل'))||document.body.textContent.includes('پروفایل')"))
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=document.getElementById('scr').clientWidth+1"))
        if w==360: pg.screenshot(path='/tmp/pf_%s.png'%sch[0])
        pg.locator('#scr [data-a=pfo][data-v=d]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'tile opens orders (done tab)',pg.evaluate("S.v==='mo'&&MOT==='d'"))
        ctx.close()
    br.close()
print('ERRS',errs[:5]);print('FAILS',[x for x in res if not x[0]][:6] if 'res' in dir() else '')
