# تست 1.9.503 DG3: سبد ؛ یک دکمه‌ی اصلی در نوار پایین
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900);pg.evaluate('XF.sc=1')
        for nb in (1,2):
            bs=[{'id':i,'name':'غرفه %d'%i,'phone':'1','city':'س'} for i in range(1,nb+1)]
            pr=[PR(10+i,i,'کالا%d'%i,10) for i in range(1,nb+1)]
            pg.evaluate("BT.t=Date.now()+60000;BT.booths=%s;BT.prods=%s;BC=[%s]"%(json.dumps(bs),json.dumps(pr),','.join("{p:%d,m:'r',q:2}"%(10+i) for i in range(1,nb+1))))
            pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(400)
            chk(t+'%d booth: bar has one solid main btn'%nb,pg.evaluate("document.querySelectorAll('#scr .btn:not(.o):not(.s)[data-a=bt_pay],#scr .btn:not(.o):not(.s)[data-a=scgo]').length==1"))
            chk(t+'%d booth: bar profit shown'%nb,pg.evaluate("!!document.querySelector('.sckbar .sckbs')"))
            chk(t+'%d booth: per-booth btn count'%nb,pg.evaluate("document.querySelectorAll('.sckb [data-a=bt_pay]').length")==(0 if nb==1 else nb))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("window.scrollTo(0,0)")
        pg.locator('[data-a=scgo]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'scgo with empty fields: no sheet, focus fields',pg.evaluate("!document.getElementById('bzpay')"))
        pg.fill('#bcn','علی');pg.fill('#bcp','09120000000');pg.fill('#bca','خیابان یک')
        pg.locator('[data-a=scgo]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'scgo opens pay sheet',pg.evaluate("!!document.getElementById('bzpay')"))
        if w==360 and sch=='light':
            pg.evaluate("bzPayClose();document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';window.scrollTo(0,0)");pg.screenshot(path='/tmp/claude-0/p/dg3_360.png')
        ctx.close()
    br.close()
print('ERRS',errs)
