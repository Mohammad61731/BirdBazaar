# تست 1.9.374 C5b: پنل پیک (سفارش‌ها ، پذیرش ، کدها)
import json
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
CALLS=[]
J={'av':[{'id':7,'bn':'غرفه یک','city':'سراوان','n':2,'t':50000}],'my':[]}
def hy(route,req):
    b=json.loads(req.post_data or '{}');o=b['op'];CALLS.append((o,b.get('a')))
    r={'err':'op'}
    if o=='yme':r={'ok':1,'me':{'name':'رضا','veh':'m','area':'مرکز','st':'ok'}}
    elif o=='yjobs':r={'ok':1,**J}
    elif o=='yacc':
        J['av']=[];J['my']=[{'id':7,'s':'acc','bn':'غرفه یک','bp':'0912','name':'مشتری','phone':'0935','addr':'خیابان ۱','k':'4321'}];r={'ok':1}
    elif o=='yway':J['my'][0]['s']='way';r={'ok':1}
    elif o=='ydone':r={'ok':1} if b['a']['o']=='1111' else {'err':'bad'}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/yapp',hy)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        J['av']=[{'id':7,'bn':'غرفه یک','city':'سراوان','n':2,'t':50000}];J['my']=[];CALLS.clear()
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;localStorage.setItem('bp_cru','{\"u\":\"0912\",\"p\":\"1234\"}');crSheet()");pg.wait_for_timeout(500)
        txt=lambda:pg.evaluate("document.querySelector('.sheet').innerText")
        chk(t+'available job listed, no address',('غرفه یک' in txt()) and ('بپذیر' in txt()) and ('خیابان' not in txt()))
        chk(t+'one yjobs call',[c[0] for c in CALLS].count('yjobs')==1)
        pg.locator('[data-a=bt_cry]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'accepted: no booth code shown + address + hint',('4321' not in txt()) and ('خیابان' in txt()) and ('تحویل دادم' in txt()))
        J['my'][0]['s']='pick'
        pg.locator('[data-a=bt_crj]').dispatch_event('click');pg.wait_for_timeout(400)
        chk(t+'pick: way button',pg.locator('[data-a=bt_crw]').count()==1)
        pg.locator('[data-a=bt_crw]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'way: otp field',pg.locator('[data-a=bt_crd]').count()==1)
        pg.fill('#cro7','2222');pg.locator('[data-a=bt_crd]').dispatch_event('click');pg.wait_for_timeout(300)
        chk(t+'wrong otp still active',pg.locator('[data-a=bt_crd]').count()==1)
        pg.fill('#cro7','1111');J['my']=[];pg.locator('[data-a=bt_crd]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'done: list empty',('سفارش فعالی نداری' in txt()))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        chk(t+'owner: rdy shows customer code',pg.evaluate("(()=>{BM={booth:{id:1}};const h=crOwnH({id:3,s:'new',cr:{s:'rdy',o:'7777'}});return h.includes('7777')&&!h.includes('bt_crk')})()"))
        chk(t+'owner: acc shows pickup button (no code)',pg.evaluate("(()=>{const h=crOwnH({id:3,s:'new',cr:{s:'acc',o:'7777'}});return h.includes('bt_crk')&&!h.includes('id=\"crk3')&&h.includes('تحویل دادم')})()"))
        ctx.close()
    br.close()
print('ERRORS',errs)
