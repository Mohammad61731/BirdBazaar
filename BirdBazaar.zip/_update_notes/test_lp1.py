# تست 1.9.474: «همان پیک قبلی» (کلید lp)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();localStorage.removeItem('bp_lpc')})()")
        chk(f'{w}: off -> empty',pg.evaluate("lpH({id:5})===''"))
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.lp=1")
        chk(f'{w}: no saved courier -> empty',pg.evaluate("lpH({id:5})===''"))
        pg.evaluate("crDoneO({id:9,cr:{s:'done',c:'7',cn:'علی'}})")
        chk(f'{w}: done order saves courier',pg.evaluate("JSON.parse(localStorage.getItem('bp_lpc')).c==='7'"))
        chk(f'{w}: button shows name + order id',pg.evaluate("(()=>{const h=lpH({id:5});return h.includes('bt_crl')&&h.includes('data-v=\"5\"')&&h.includes('علی')})()"))
        chk(f'{w}: non-done does not overwrite',pg.evaluate("(()=>{crDoneO({id:1,cr:{s:'acc',c:'99',cn:'x'}});return JSON.parse(localStorage.getItem('bp_lpc')).c==='7'})()"))
        chk(f'{w}: no crash on bad input',pg.evaluate("lpH(null)===''&&(localStorage.setItem('bp_lpc','{bad'),lpH({id:1})==='')"))
        chk(f'{w}: hooked in crOwnH',pg.evaluate("crOwnH.toString().includes('lpH(o)')"))
        pg.evaluate("localStorage.setItem('bp_lpc',JSON.stringify({c:'7',n:'علی'}));document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+lpH({id:5})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/lp360.png')
    br.close()
print('ERRORS',errs)
