# تست 1.9.417 G6-b: توضیح ورودی و کرایه‌ی نقدی پیک (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnCrN({id:3})===''&&pnCrSum()===''"))
        pg.evaluate("XF.pn=1;localStorage.removeItem('bp_crx')")
        chk(t+'2 chips',pg.evaluate("(pnCrN({id:3}).match(/<button/g)||[]).length==2"))
        pg.evaluate("window.bzAsk=(m,d,cb)=>cb(window.__ans);window.crSheet=()=>{}")
        def click(a,v,ans):
            pg.evaluate("window.__ans=%s"%ans)
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(200)
        click('pncn','3',"'زنگ سوم <b>'")
        chk(t+'note saved+escaped',pg.evaluate("pnCx()[3].n==='زنگ سوم b'&&pnCrN({id:3}).includes('📝 زنگ سوم b')"))
        click('pncc','3',"'۵۰۰۰۰'")
        chk(t+'cash ignores non-latin digits -> 0 clears',pg.evaluate("!pnCx()[3].c"))
        click('pncc','3',"'40000'")
        chk(t+'cash saved',pg.evaluate("pnCx()[3].c===40000&&pnCrSum().includes('۴۰٬۰۰۰')||pnCx()[3].c===40000"))
        chk(t+'sum shows',pg.evaluate("pnCrSum().includes('امروز')"))
        click('pncc','3',"''")
        chk(t+'cash cleared keeps note',pg.evaluate("!pnCx()[3].c&&pnCx()[3].n==='زنگ سوم b'&&pnCrSum()===''"))
        click('pncn','3',"''")
        chk(t+'all cleared removes row',pg.evaluate("!pnCx()[3]"))
        pg.evaluate("(()=>{const m={};for(let i=1;i<=130;i++)m[i]={c:5,t:Date.now()};pnCxS(m)})()")
        chk(t+'cap 100',pg.evaluate("Object.keys(pnCx()).length===100"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
