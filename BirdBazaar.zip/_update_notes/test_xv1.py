# تست 1.9.360: V1/V2 پیش‌نمایش زنده‌ی چیدمان
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.tab=0;render()");pg.wait_for_timeout(300)
        pg.evaluate("sheet('<h3>تست</h3><div class=\"xsb\" data-xk=\"home:s0\"><label class=\"xsr\"><span>x</span><input type=\"range\" min=\"0\" max=\"9\" value=\"1\"></label></div>')");pg.wait_for_timeout(250)
        chk(t+'live on',pg.evaluate("ov.classList.contains('xlive')&&document.getElementById('app').classList.contains('xlv')&&!!document.querySelector('.xlbar')"))
        chk(t+'sheet half height',pg.evaluate("document.querySelector('.sheet').getBoundingClientRect().height<=innerHeight*0.47+1"))
        chk(t+'overlay passes touches',pg.evaluate("getComputedStyle(document.getElementById('ov')).pointerEvents=='none'&&getComputedStyle(document.querySelector('.sheet')).pointerEvents!='none'"))
        clk(pg,'[data-xl=min]')
        chk(t+'minimized',pg.evaluate("ov.classList.contains('xmin')&&[...document.querySelectorAll('.sheet>*')].filter(e=>!e.classList.contains('xlbar')&&getComputedStyle(e).display!='none').length==0"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        clk(pg,'[data-xl=min]')
        chk(t+'reopened',pg.evaluate("!ov.classList.contains('xmin')&&document.querySelector('.xsb').offsetHeight>0"))
        clk(pg,'[data-xl=done]')
        chk(t+'closed clean',pg.evaluate("!ov.classList.contains('xlive')&&!ov.classList.contains('xmin')&&!document.getElementById('app').classList.contains('xlv')"))
        pg.evaluate("sheet('<h3>عادی</h3>')");pg.wait_for_timeout(200)
        chk(t+'plain sheet unaffected',pg.evaluate("!ov.classList.contains('xlive')&&getComputedStyle(document.getElementById('ov')).pointerEvents!='none'"))
        ctx.close()
    br.close()
print('ERRORS',errs)
