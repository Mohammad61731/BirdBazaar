# تست 1.9.507 DG7: صفحه‌ی محصول غرفه
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("BT.booths=[{id:1,name:'غرفه یک',n:2,views:5,logo:'',city:'تهران',bio:'',phone:'0912'}];BT.prods=[{id:11,b:1,s:'on',d:{name:'قفس بزرگ مخصوص پرنده',type:'plain',price:50000,disc:20,emoji:'🪺',cat:'قفس',imgs:['data:image/gif;base64,R0lGODlhAQABAAAAACw=','data:image/gif;base64,R0lGODlhAQABAAAAACw='],stock:5}},{id:12,b:1,s:'on',d:{name:'دانه',type:'plain',price:2000,cat:'دان'}}];BT.ok=1;BT.t=Date.now();S.role=null;go({v:'btp',id:11})");pg.wait_for_timeout(400)
        chk(t+'new layout',pg.evaluate("!!document.querySelector('.bzpvg')&&!!document.querySelector('.bzpvp')&&!!document.querySelector('.bzpvt')&&!!document.querySelector('.bzpvd')"))
        pass
        chk(t+'buy btn kept',pg.evaluate("!!document.querySelector('[data-a=bt_ac]')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        chk(t+'tab scroll',pg.evaluate("(()=>{const b=document.querySelector('[data-a=bz_pt][data-v=bzs2]');if(!b)return false;b.click();return b.classList.contains('on')})()"))
        pg.evaluate("go({v:'btp',id:12})");pg.wait_for_timeout(300)
        chk(t+'plain: no discount/counter',pg.evaluate("!document.querySelector('.bzpvd')"))
        chk(t+'plain: buy btn',pg.evaluate("!!document.querySelector('[data-a=bt_ac]')"))
        if w==360 and sch=='light':
            pg.evaluate("go({v:'btp',id:11})");pg.wait_for_timeout(300)
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';window.scrollTo(0,0)")
            pg.screenshot(path='/tmp/claude-0/p/dg7_360.png')
        ctx.close()
    br.close()
print('ERRS',errs)
