# تست مورد ۱۴ (مرحله ۵): رفرش با کشیدن به پایین + بازگشت به برنامه
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            ctx=await b.new_context(viewport={'width':w,'height':700},has_touch=True); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            cnt={'pub':0}
            async def h(route):
                u=route.request.url
                if u.startswith('http'):
                    if 'bapp' not in u and 'fapp' not in u and 'mapp' not in u and 'capp' not in u: cnt['pub']+=1
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'products':[{'id':1,'name':'م','price':1,'cat':'x','imgs':[]}],'stories':[],'ads':[],'cms':{},'guides':[],'booths':[],'prods':[]}))
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
            async def drag(dy):
                await pg.evaluate("""(dy)=>{const t=document.querySelector('#scr');const mk=(ty,y)=>{const tt=new Touch({identifier:1,target:t,clientX:150,clientY:y});return new TouchEvent(ty,{touches:ty=='touchend'?[]:[tt],changedTouches:[tt],bubbles:true,cancelable:true})};t.dispatchEvent(mk('touchstart',200));t.dispatchEvent(mk('touchmove',200+dy/2));t.dispatchEvent(mk('touchmove',200+dy));t.dispatchEvent(mk('touchend',200+dy))}""",dy)
            await pg.evaluate("document.querySelector('#scr').scrollTop=0")
            c0=cnt['pub']; await drag(40); await pg.wait_for_timeout(600); a=cnt['pub']-c0
            c0=cnt['pub']; await drag(150); await pg.wait_for_timeout(1500); bb=cnt['pub']-c0
            sp=await pg.evaluate("getComputedStyle(document.getElementById('ptr')).opacity")
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            print(w,'short drag calls',a,'long drag calls',bb,'indicator hidden after',sp,'overflow',ov,errs)
            ok&=a==0 and bb>=1 and not ov and not errs and sp=='0'
            # نباید وقتی اسکرول پایین‌تر است کار کند
            await pg.evaluate("const sp=document.createElement('div');sp.style.cssText='height:3000px;flex:none';document.querySelector('#scr').appendChild(sp);document.querySelector('#scr').scrollTop=300;window.__st=document.querySelector('#scr').scrollTop")
            print('scrollTop',await pg.evaluate('window.__st'));c0=cnt['pub']; await drag(150); await pg.wait_for_timeout(800); d=cnt['pub']-c0; print(w,'scrolled drag calls',d); ok&=d==0
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
