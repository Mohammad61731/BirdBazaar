# تست 1.9.88 مرحله‌ی ۴: «🧰 ابزارها» دسته‌ی ۱
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':''}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
          for sch in ('light','dark'):
            ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(900)
            t='%d/%s '%(w,sch)
            await pg.evaluate("S.me='adm';S.role='admin';S.pw='x';S.pm=['all'];S.pnl=1;S.tab=4;S.at='set';S.sx='';render()"); await pg.wait_for_timeout(250)
            chk(t+'APPV is a version', __import__('re').match(r'^1\.9\.\d+$', await pg.evaluate("APPV")) is not None)
            chk(t+'hub has tools card', 'ابزارها' in await pg.evaluate("document.getElementById('sgg').innerText"))
            await pg.evaluate("go({sx:'tl'})"); await pg.wait_for_timeout(250)
            chk(t+'13 tool cards', await pg.evaluate("document.querySelectorAll('#scr .card .tg[data-a=tl_tog]').length")==13)
            chk(t+'all off by default', await pg.evaluate("document.querySelectorAll('#scr .tg.on[data-a=tl_tog]').length")==0)
            chk(t+'off tool shows no form', not await pg.evaluate("!!document.getElementById('mt_m')"))
            chk(t+'no overflow (off)', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            # روشن کردن همه
            for k in ('mt','eg','sq','sl','np','er','dv','cs'):
                await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=%s]').click()"%k); await pg.wait_for_timeout(120)
            chk(t+'all on', await pg.evaluate("document.querySelectorAll('#scr .tg.on[data-a=tl_tog]').length")==8)
            chk(t+'no overflow (on)', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            chk(t+'sq shows list', 'public2' in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'eg without data hint', 'داده‌ای نیست' in await pg.evaluate("document.getElementById('scr').innerText"))
            # پیش‌بینی با داده‌ی ساختگی
            await pg.evaluate("STV.d={rep:3,byday:[{day:'2026-11-14',dev:3,b:3145728},{day:'2026-11-15',dev:3,b:6291456}]};render()"); await pg.wait_for_timeout(200)
            tx=await pg.evaluate("document.getElementById('scr').innerText")
            chk(t+'eg forecast shows', 'تخمین ۳۰ روز' in tx and 'MB' in tx)
            # اطلاعیه
            await pg.evaluate("document.getElementById('mt_m').value='تست اطلاعیه';document.getElementById('mt_k').value='an'"); 
            await pg.evaluate("document.querySelector('[data-a=mt_s]').click()"); await pg.wait_for_timeout(250)
            chk(t+'cms.MT saved', await pg.evaluate("D.cms.MT&&D.cms.MT.k=='an'&&D.cms.MT.msg=='تست اطلاعیه'"))
            await pg.evaluate("S.role='user';mtCheck()"); await pg.wait_for_timeout(100)
            chk(t+'user sees banner', await pg.evaluate("!!document.getElementById('mta')&&!document.getElementById('mto')"))
            await pg.evaluate("document.querySelector('#mta button').click()")
            chk(t+'banner dismisses', not await pg.evaluate("!!document.getElementById('mta')"))
            # تعمیر
            await pg.evaluate("D.cms.MT={k:'mt',msg:'تعمیر',t:Date.now()};S.role='user';mtCheck()"); await pg.wait_for_timeout(100)
            chk(t+'user blocked in maintenance', await pg.evaluate("!!document.getElementById('mto')"))
            await pg.evaluate("S.role='admin';mtCheck()"); await pg.wait_for_timeout(100)
            chk(t+'admin not blocked', not await pg.evaluate("!!document.getElementById('mto')"))
            await pg.evaluate("D.cms.MT=null;mtCheck()")
            chk(t+'cleared', not await pg.evaluate("!!document.getElementById('mta')||!!document.getElementById('mto')"))
            # قفل نرم
            await pg.evaluate("render()"); await pg.wait_for_timeout(150)
            await pg.evaluate("document.querySelector('[data-a=sl_on]').click()"); await pg.wait_for_timeout(200)
            chk(t+'soft lock set (f=0)', await pg.evaluate("D.cms.MV&&D.cms.MV.min==APPV&&D.cms.MV.f==0"))
            # توقف پولینگ
            await pg.evaluate("D.cms.MV={min:'9.0.0',url:'',msg:'',f:0,np:1}")
            chk(t+'lockedNp user true', await pg.evaluate("(S.role='user',lockedNp())"))
            chk(t+'lockedNp owner false', await pg.evaluate("(S.role='admin',lockedNp())")==False)
            chk(t+'lockedNp off when np=0', await pg.evaluate("(D.cms.MV.np=0,S.role='user',lockedNp())")==False)
            chk(t+'lockedNp off when version ok', await pg.evaluate("(D.cms.MV={min:'1.0.0',np:1},S.role='user',lockedNp())")==False)
            # msPoll واقعاً درخواست نمی‌زند وقتی قفل+np
            await pg.evaluate("D.cms.MV={min:'9.0.0',np:1};S.role='user';S.me='u1'")
            cnt=await pg.evaluate("(async()=>{let n=0;const f=window.fetch;window.fetch=function(){n++;return f.apply(this,arguments)};await msPoll();await cPoll();window.fetch=f;return n})()")
            chk(t+'pollers silent when locked+np (%s)'%cnt, cnt==0)
            # mv_s حفظ np
            await pg.evaluate("S.role='admin';S.me='adm';D.cms.MV={min:'1.9.1',url:'',msg:'',f:0,np:1};S.sx='ver';render()"); await pg.wait_for_timeout(150)
            await pg.evaluate("document.querySelector('[data-a=mv_s]').click()"); await pg.wait_for_timeout(150)
            chk(t+'mv_s keeps np', await pg.evaluate("D.cms.MV&&D.cms.MV.np==1"))
            # خاموش‌کردن ابزار = پاک شدن اثرش
            await pg.evaluate("D.cms.MT={k:'an',msg:'x',t:1};S.sx='tl';render()"); await pg.wait_for_timeout(150)
            await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=mt]').click()"); await pg.wait_for_timeout(150)
            chk(t+'turning mt off clears MT', await pg.evaluate("!D.cms.MT"))
            await pg.evaluate("document.querySelector('[data-a=tl_tog][data-v=np]').click()"); await pg.wait_for_timeout(150)
            chk(t+'turning np off clears np', await pg.evaluate("!(D.cms.MV&&D.cms.MV.np)"))
            chk(t+'ab() tools -> hub', await pg.evaluate("(()=>{const r=ab();return r==1&&!S.sx&&S.at=='set'})()"))
            # غیر مدیر اصلی: بخش را نمی‌بیند
            await pg.evaluate("S.pm=['set'];S.sx='';render()"); await pg.wait_for_timeout(150)
            chk(t+'non-owner cannot open tools', 'ابزارها' not in await pg.evaluate("document.getElementById('scr').innerText"))
            chk(t+'no errors %s'%errs, not errs)
            if w==360 and sch=='light':
                await pg.evaluate("S.pm=['all'];S.sx='tl';render()"); await pg.wait_for_timeout(200)
                await pg.screenshot(path='%s/shots/tl88.png'%ROOT)
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
