# تست 1.9.101: مدیر کش دولایه — سقف بر اساس گوشی، LRU، حفاظت آیتم باز و ضروری‌ها، کلید خاموش
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        async def mk(mem):
            ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            await pg.add_init_script("Object.defineProperty(navigator,'deviceMemory',{get:()=>%s})"%mem)
            async def h(route):
                if route.request.url.startswith('file:'): return await route.continue_()
                try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
                except Exception: pass
            await pg.route('**/*',h)
            await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
            return pg,errs
        for mem,tier,mb in [(1,'low',40),(4,'mid',120),(8,'high',300)]:
            pg,errs=await mk(mem); r=await pg.evaluate("(()=>{const p=cmProf();return [p.t,p.mb]})()")
            chk('profile %s'%tier, r==[tier,mb]); await pg.context.close()
        pg,errs=await mk(1)
        # ۷ عکس ۸ میلیون‌کاراکتری (≈۵۶MB) روی سقف ۴۰MB ؛ قدیمی‌ترین‌ها باید بروند
        await pg.evaluate("""(async()=>{await idbSet('D',{products:[{id:1}],t:1});const big='x'.repeat(8e6);for(let i=1;i<=7;i++)await idbSet('IM:p:'+i,{thk:'1',img:big,imgs:[]});const ix=await cmLoad();for(let i=1;i<=7;i++)ix.e['IM:p:'+i][1]=Date.now()-3600000*(10-i);S.v='prod';S.id=1;})()""")
        await pg.wait_for_timeout(300)
        st=await pg.evaluate("cmRun(1).then(s=>s&&{tot:s.tot,n:s.n,ev:s.ev})")
        chk('run returned', st is not None)
        left=await pg.evaluate("idbOpen().then(db=>new Promise(r=>{const o=[];const q=db.transaction('kv').objectStore('kv').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return r(o);o.push(c.key);c.continue()}}))")
        im=[k for k in left if k.startswith('IM:')]
        chk('evicted some (%s)'%len(im), 0<len(im)<7)
        chk('total under budget', st and st['tot']<=40*1048576)
        chk('open item p:1 protected', 'IM:p:1' in im)
        chk('newest kept', 'IM:p:7' in im)
        chk('2nd oldest evicted', 'IM:p:2' not in im)
        chk('essential D kept', 'D' in left)
        chk('index saved stats', st and st['ev']>=1)
        # انجمن: ۱۰ اتاق ← فقط ۶ بماند (low)
        await pg.evaluate("""(()=>{const m={};for(let i=1;i<=10;i++){localStorage.setItem('bp_fc_'+i,'[]');m['bp_fc_'+i]=1000+i}localStorage.setItem('bp_cmf',JSON.stringify(m))})()""")
        await pg.evaluate("cmRun(1)")
        n=await pg.evaluate("Object.keys(localStorage).filter(k=>k.indexOf('bp_fc_')==0).length")
        kept=await pg.evaluate("Object.keys(localStorage).filter(k=>k.indexOf('bp_fc_')==0).sort().join()")
        chk('forum rooms trimmed to 6', n==6 and 'bp_fc_10' in kept and 'bp_fc_1,' not in kept+',')
        # کلید خاموش ← پاکسازی خودکار انجام نمی‌شود
        await pg.evaluate("""(async()=>{tlSet('cm',0);const big='x'.repeat(8e6);for(let i=11;i<=20;i++)await idbSet('IM:p:'+i,{thk:'1',img:big,imgs:[]})})()""")
        await pg.wait_for_timeout(500)
        r=await pg.evaluate("cmRun().then(x=>x===undefined||x===null||!x.tot||true)")
        c2=await pg.evaluate("idbOpen().then(db=>new Promise(r=>{let n=0;const q=db.transaction('kv').objectStore('kv').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return r(n);if(String(c.key).indexOf('IM:p:')==0&&+c.key.slice(5)>=11)n++;c.continue()}}))")
        chk('off: no auto eviction (%s)'%c2, c2==10)
        chk('tlOn cm off', await pg.evaluate("tlOn('cm')")==False)
        await pg.evaluate("tlSet('cm',1)")
        chk('tlCm html', 'cm_st' in await pg.evaluate("tlCm()"))
        chk('no page errors', not errs); 
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
