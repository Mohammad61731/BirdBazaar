# تست 1.9.346: S67 لینک غرفه/محصول غرفه ، S68 زمان‌بندی بنر (fr/to)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("BT.booths=[{id:5,name:'غرفه آزمون'}];BT.prods=[{id:9,b:5,d:{name:'کالای آزمون'}}];const b=D.cms.BN[0]||{t:'a',m:'txt',bg:'#fff',bg2:'#eee',tc:'#000',f:'',k:''};D.cms.BN=[0,1,2].map(i=>Object.assign(JSON.parse(JSON.stringify(b)),{t:'ب'+i}));D.cms.BN[1].fr='2099-01-01';D.cms.BN[2].to='2000-01-01'")
        chk(t+'bnOn logic',pg.evaluate("bnOn(D.cms.BN[0])&&!bnOn(D.cms.BN[1])&&!bnOn(D.cms.BN[2])&&bnOn({fr:'2000-01-01',to:'2099-01-01'})"))
        pg.evaluate("S.role='user';S.pm=[];S.tab=0;S.v=null;S.ed=0;render()");pg.wait_for_timeout(300)
        chk(t+'user sees 1',pg.evaluate("document.querySelectorAll('#bns>.bn').length")==1)
        pg.evaluate("S.role='admin';S.pm=['all'];S.ed=1;render()");pg.wait_for_timeout(300)
        chk(t+'admin sees 3 + badges',pg.evaluate("document.querySelectorAll('#bns>.bn').length==3&&document.querySelectorAll('#bns>.bn .kb').length>=2"))
        pg.evaluate("be('bn:1')");pg.wait_for_timeout(200)
        chk(t+'date fields',pg.locator('#ov input[type=date]').count()==2)
        chk(t+'link has booth',pg.evaluate("(()=>{const o=[...document.querySelectorAll('#ov option')].map(x=>x.value);return o.includes('booth:5')&&o.includes('bprod:9')})()"))
        pg.evaluate("E.d.fr='2026-12-31';E.d.to='2026-01-01';sbe()")
        chk(t+'bad range blocked',pg.evaluate("D.cms.BN[1].fr=='2099-01-01'"))
        pg.evaluate("E.d.fr='bad';E.d.to='2099-05-05';sbe()");pg.wait_for_timeout(200)
        chk(t+'invalid date dropped',pg.evaluate("D.cms.BN[1].fr===undefined&&D.cms.BN[1].to=='2099-05-05'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("openLink('booth:5')");pg.wait_for_timeout(200)
        chk(t+'booth link opens',pg.evaluate("S.v=='bts'||S.v=='btp'||!!document.querySelector('#scr')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
