# تست سفت‌کردن رفرش با کشیدن (1.9.54): فقط کشیدن عمدی و بلند (>=210px، >=350ms، بالای صفحه)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            ctx=await b.new_context(viewport={'width':w,'height':700},has_touch=True); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            cnt={'pub':0}
            async def h(route):
                u=route.request.url
                if u.startswith('http'):
                    if 'bapp' not in u and 'fapp' not in u and 'mapp' not in u and 'capp' not in u: cnt['pub']+=1
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}))
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
            JS="""([ty,y])=>{const t=document.querySelector('#scr');const tt=new Touch({identifier:1,target:t,clientX:150,clientY:y});t.dispatchEvent(new TouchEvent(ty,{touches:ty=='touchend'?[]:[tt],changedTouches:[tt],bubbles:true,cancelable:true}))}"""
            async def drag(dy,ms):
                await pg.evaluate(JS,['touchstart',200]); n=6
                for i in range(1,n+1):
                    await pg.wait_for_timeout(ms//n); await pg.evaluate(JS,['touchmove',200+dy*i//n])
                await pg.evaluate(JS,['touchend',200+dy]); await pg.wait_for_timeout(1300)
            async def top(): await pg.evaluate("document.querySelector('#scr').scrollTop=0"); await pg.wait_for_timeout(600)
            res={}
            await top(); c=cnt['pub']; await drag(150,600); res['150px']=cnt['pub']-c
            await top(); c=cnt['pub']; await drag(260,100); res['fast260']=cnt['pub']-c
            await top(); c=cnt['pub']; await drag(260,600); res['slow260']=cnt['pub']-c
            await pg.evaluate("const sp=document.createElement('div');sp.style.cssText='height:3000px;flex:none';document.querySelector('#scr').appendChild(sp);document.querySelector('#scr').scrollTop=300"); await pg.wait_for_timeout(100)
            await pg.evaluate("document.querySelector('#scr').scrollTop=0"); c=cnt['pub']; await drag(260,600); res['justScrolled']=cnt['pub']-c
            await pg.wait_for_timeout(600); c=cnt['pub']; await drag(260,600); res['afterRest']=cnt['pub']-c
            await pg.evaluate("document.querySelector('#scr').scrollTop=300"); await pg.wait_for_timeout(700); c=cnt['pub']; await drag(260,600); res['scrolled']=cnt['pub']-c
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            print(w,res,'overflow',ov,errs)
            ok&=res['150px']==0 and res['fast260']==0 and res['slow260']>=1 and res['justScrolled']==0 and res['afterRest']>=1 and res['scrolled']==0 and not ov and not errs
            await ctx.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
