# تست 1.9.248 AN22 AN23 AN24
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend',`<input id=qt value=1><button class='btn' data-a=add data-v=0 id=ab>x</button><button class='btn s o' data-a=qd data-v=1 id=qb>+</button><div class='card cnew' id=cn>c</div>`)")
        await pg.click('#qb'); await pg.wait_for_timeout(60)
        chk('qty slide',await pg.evaluate("document.getElementById('qt').classList.contains('qs')&&getComputedStyle(document.getElementById('qt')).animationName=='ansl'"))
        await pg.evaluate("document.getElementById('ab').addEventListener('click',e=>e.stopPropagation())")
        await pg.click('#ab'); await pg.wait_for_timeout(100)
        chk('add loading',await pg.evaluate("document.getElementById('ab').classList.contains('anld')"))
        await pg.wait_for_timeout(500)
        chk('add done (ok)',await pg.evaluate("document.getElementById('ab').classList.contains('anok')&&!document.getElementById('ab').classList.contains('anld')"))
        chk('new-id marker',await pg.evaluate("typeof window.__anNt==='number'"))
        chk('cart card anim',await pg.evaluate("getComputedStyle(document.getElementById('cn')).animationName=='ancn'"))
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
