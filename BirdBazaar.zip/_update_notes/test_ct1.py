# تست 1.9.219: سبد — حالت خالی با پیشنهاد ، -/+ بزرگ ، جمع ثابت (CT1)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("D.cart=[];S.tab=3;render()");pg.wait_for_timeout(400)
        h=pg.evaluate("cartV()")
        chk(f'{w}: empty label',('بازارگردی' in h))
        chk(f'{w}: empty suggestions',pg.evaluate("D.products.length")==0 or 'پیشنهاد برای شروع' in h)
        chk(f'{w}: empty no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pid=pg.evaluate("D.products[0]&&D.products[0].id")
        if pid:
            pg.evaluate(f"D.cart=[{{id:{pid},q:1}},{{id:{pid},q:2}}];S.tab=3;render()");pg.wait_for_timeout(400)
            chk(f'{w}: dose sticky class',pg.locator('.dose.cts').count()==1)
            b=pg.locator('[data-a=cq]').first.bounding_box()
            chk(f'{w}: qty button >=44',b is not None and b['width']>=43 and b['height']>=43)
            chk(f'{w}: cart no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    br.close()
print('ERRORS',errs)
