from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(600)
        pg.evaluate("window.__o=[];window.open=(u)=>{window.__o.push(u)};window.__c=0;try{Object.defineProperty(navigator,'clipboard',{value:{writeText:()=>{window.__c++;return Promise.resolve()}},configurable:true})}catch(e){}")
        pg.evaluate("S.inv={id:5,dt:'1405/08/22',cu:'علی',ph:'0912',ad:'سراوان',it:[{n:'مکمل',q:2,u:1000,w:0}],tt:2000};go({v:'inv'})");pg.wait_for_timeout(400)
        ov=pg.evaluate("document.documentElement.scrollWidth>innerWidth")
        n=pg.locator('#scr button[data-a=bale]').count()
        pg.click('#scr button[data-a=bale]');pg.wait_for_timeout(200)
        u=pg.evaluate("window.__o[0]")
        print(w,'btn',n,'overflow',ov,'url ok',u.startswith('https://ble.ir/989190230386?text=') and 'فاکتور' in __import__('urllib.parse').parse.unquote(u),'| toast shown:',pg.evaluate("document.querySelector('#toast').classList.contains('on')"))
    print(pg.evaluate("smsUrl('0912 345 6789','سلام\\nفاکتور')"))
    ctx=br.new_context(user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)');q=ctx.new_page();q.route('**/*',lambda r,qq:r.continue_() if qq.url.startswith('file:') else r.fulfill(status=200,body='{}'));q.goto('file:///home/claude/bb/www/index.html');q.wait_for_timeout(500);print(q.evaluate("smsUrl('09123456789','x')"))
    src=open('/home/claude/bb/www/index.html',encoding='utf-8').read()
    print('auto-copy after order removed:', "S.inv=o;go({v:'inv'})});break}" in src)
    print('ERRORS',errs);br.close()
