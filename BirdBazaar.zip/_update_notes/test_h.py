import json,re
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
mid="\nDB['prods'].append({'id':2,'b':1,'d':{'name':'دان فنچ','type':'plain','price':50000,'emoji':'🌰','disc':20,'imgs':[]},'s':'on'});DB['prods'].append({'id':3,'b':1,'d':{'name':'ارزن قرمز','type':'wt','unit':'kg','rt':{'on':1,'price':100000,'steps':[]},'wh':{'on':0},'emoji':'🌾','imgs':[]},'s':'on'});DB['nid']=3\n"
ORD=[]
def handle2(route,req):
    if req.url.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);o=b['op'];a=b.get('a') or {}
        r=None
        if o=='bord':
            ORD.append({'id':len(ORD)+1,'b':a['b'],'name':a['name'],'phone':a['phone'],'addr':a['addr'],'lines':a['lines'],'total':a['total'],'s':'new','t':'2026-11-13T10:00:00Z'});r={'ok':1}
        elif o=='bords':r={'ok':1,'orders':[x for x in ORD if x['b']==1]}
        elif o=='bord_st':
            for x in ORD:
                if x['id']==a['id']:x['s']=a['s']
            r={'ok':1}
        if r is not None:return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return handle(route,req)
errs=[]
from playwright.sync_api import sync_playwright
exec(mid)
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
    pg.route('**/*',handle2);pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(1000)
    DB['booths'].append({'id':2,'owner':'reza','pw':'1234','name':'دان رضا','bio':'','logo':'','cover':'','city':'زاهدان','phone':'0915','status':'active','views':1})
    DB['prods'].append({'id':4,'b':1,'d':{'name':'دانه کتان','type':'wt','unit':'kg','rt':{'on':1,'price':150000,'steps':[1]},'wh':{'on':0},'emoji':'🌿','imgs':[],'cat':'کتان','short':'کتان تازه و بو‌داده شده برای پرندگان'},'s':'on'})
    DB['prods'].append({'id':5,'b':2,'d':{'name':'دان کاناری','type':'plain','price':65000,'emoji':'🐤','imgs':[],'cat':'دان و غذا'},'s':'on'})
    pg.evaluate("BT.t=0;bpull()");pg.wait_for_timeout(600)
    print('D.products sample keys:',pg.evaluate("JSON.stringify(Object.keys(D.products[0]||{}))"))
    pg.evaluate("D.products=[{id:901,name:'ویتامین پرنده',cat:'مکمل',price:90000,img:'',vol:{}},{id:902,name:'مکمل کلسیم',cat:'مکمل',price:70000,img:'',vol:{}}];S.role=null;S.pm=[];S.sv=undefined;go({tab:1,v:null})");pg.wait_for_timeout(600)
    print('H2 default mixed: pc cards',pg.locator('#pgrid .pc').count(),'booth cards',pg.locator('#pgrid .bxc').count(),'booth tiles',pg.locator('.hs .bm').count())
    order=pg.evaluate("[...document.querySelectorAll('#pgrid>*')].map(e=>e.classList.contains('bxc')?'B':'P').join('')");print('interleaved order:',order)
    pg.screenshot(path='../shots/h2_mixed.png')
    pg.click('[data-a=bt_sv][data-v=p]');pg.wait_for_timeout(300);print('only bazaar: P',pg.locator('#pgrid .pc').count(),'B',pg.locator('#pgrid .bxc').count())
    pg.click('[data-a=bt_sv][data-v=b]');pg.wait_for_timeout(300);print('only booths: tiles',pg.locator('.hs .bm').count(),'posts',pg.locator('.ext').count())
    pg.click('[data-a=bt_sv][data-v=a]');pg.wait_for_timeout(300)
    pg.fill('#q','کاناری');pg.wait_for_timeout(200);print('search visible cards:',pg.evaluate("[...document.querySelectorAll('#pgrid .pc,#pgrid .bxc')].filter(e=>e.style.display!='none').length"))
    pg.fill('#q','');pg.locator('.hs .bm').first.click();pg.wait_for_timeout(400)
    print('opened booth page v=',pg.evaluate("S.v+':'+S.id"),'list items',pg.locator('.bli').count());pg.screenshot(path='../shots/h1_list.png')
    pg.fill('#bvq','کتان');pg.wait_for_timeout(200);print('search in booth ->',pg.locator('.bli').count())
    pg.fill('#bvq','');pg.click('[data-a=bt_bc][data-v="ارزن"]') if pg.locator('[data-a=bt_bc][data-v="ارزن"]').count() else None
    print('cat chips:',pg.locator('[data-a=bt_bc]').count())
    pg.click('[data-a=bt_vm]');pg.wait_for_timeout(200);print('grid mode cards:',pg.locator('#bvl .bxc').count(),'list items:',pg.locator('.bli').count());pg.screenshot(path='../shots/h1_grid.png')
    pg.click('[data-a=bt_vm]');pg.click('.bli >> nth=0');pg.wait_for_timeout(300);print('opened product v=',pg.evaluate("S.v"))
    pg.evaluate("ab()");pg.wait_for_timeout(200);print('back to v=',pg.evaluate("S.v"))
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(150);print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    print('ERRORS',errs);br.close()
