# تست 1.9.309: AN59 بازشدن صفحه‌ی محصول از روی کارت
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("window.__an=0;const o=Element.prototype.animate;Element.prototype.animate=function(k,op){if(op&&op.duration==340)window.__an++;return o.call(this,k,op)};0")
            pg.evaluate("if(!D.products.length)D.products.push({id:99,name:'x',cat:'c',price:1000,short:'s',img:'',disc:0,out:0,def:'',ben:'',use:'',cau:'',dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}});S.v=null;S.tab=1;render()");pg.wait_for_timeout(400)
            n=pg.evaluate("document.querySelectorAll('#scr .pc .pi').length")
            if n:
                pg.evaluate("document.querySelector('#scr .pc .pi').click()");pg.wait_for_timeout(600)
                chk(t+'prod opened',pg.evaluate("S.v")=='prod')
                a=pg.evaluate("window.__an")
                chk(t+('animated' if rm=='no-preference' else 'no anim reduced'),(a==1) if rm=='no-preference' else (a==0))
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
                chk(t+'gal no leftover transform',pg.evaluate("getComputedStyle(document.querySelector('.gal>div')).transform")in('none','matrix(1, 0, 0, 1, 0, 0)'))
            else: print('SKIP no cards '+t)
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
