# تست 1.9.384 D1/138: کلید cv ، یادداشت روی کالای سبد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("D.cart=[{id:(D.products[0]||{id:1}).id,q:2}]")
        pg.evaluate("XF.cv=0");chk(t+'off: no box','cvn' not in pg.evaluate("cartV0()"))
        pg.evaluate("XF.cv=1");chk(t+'on: box','cvn' in pg.evaluate("cartV0()"))
        pg.evaluate("cvNote(0,'x'.repeat(90))");chk(t+'note capped 60',pg.evaluate("D.cart[0].nt.length")==60)
        pg.evaluate("cvNote(0,'قرمز')");chk(t+'note kept in box','قرمز' in pg.evaluate("cartV0()"))
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
