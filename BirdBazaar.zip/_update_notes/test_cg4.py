# تست 1.9.370 C2: تأیید غرفه
import json,base64
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')
open('/tmp/t.png','wb').write(PNG)
CALLS=[];ST={'vq':{'ok':1,'st':'','why':'','lvl':0},'q':[{'id':7,'name':'غرفه‌ی تازه','owner':'ali','city':'سراوان','phone':'09120000000','ph':'09120000000','nt':'توضیح','t':'x','im':True,'la':27.3,'ln':62.3,'ad':'نشانی'}]}
G=[{'id':1,'lvl':1,'rm':0,'acc':'x','la':27.3,'ln':62.3,'hrs':{},'ad':''},{'id':2,'lvl':2,'rm':0,'acc':'x','la':27.31,'ln':62.31,'hrs':{},'ad':''}]
def h2(route,req):
    b=json.loads(req.post_data or '{}');o=b.get('op','')
    if o in('vq_get','vq_set','badm_vq','badm_vqi','badm_vqd','badm_lvl','cg_pub','cg_get'):
        CALLS.append((o,b.get('a')))
        r={'ok':1}
        if o=='vq_get':r=ST['vq']
        elif o=='badm_vq':r={'ok':1,'l':ST['q']}
        elif o=='badm_vqi':r={'ok':1,'im':'data:image/png;base64,iVBORw0KGgo='}
        elif o=='cg_pub':r={'ok':1,'g':G}
        elif o=='cg_get':r={'ok':1,'geo':{'lat':27.3,'lng':62.3},'lvl':0}
        route.fulfill(status=200,content_type='application/json',body=json.dumps(r));return
    route.fallback()
def last(o): return next((c[1] for c in reversed(CALLS) if c[0]==o),None)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();CALLS.clear();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/rpc/bapp',h2)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("S.tab=1;S.v=null;render()");pg.wait_for_timeout(300)
        # off
        chk(t+'off: nothing',pg.evaluate("cgVerB(1)===''&&cgVerH({id:1})===''&&cgVqH()===''&&cgVqAdmin()===''&&cgLvlB(1)===''&&cgVerA(1).includes('vfb')"))
        pg.evaluate("XF.cg=1;cgSaveC({t:Date.now(),g:{1:%s,2:%s}})"%(json.dumps(G[0]),json.dumps(G[1])))
        chk(t+'badge lvl1/2',pg.evaluate("cgVerB(1).includes('cgvb')&&!cgVerB(1).includes('cgvb g')&&cgVerB(2).includes('cgvb g')&&cgVerB(9)===''"))
        chk(t+'top-card badge hidden for unverified',pg.evaluate("cgVerA(9)===''&&cgVerA(1).includes('vfb')"))
        chk(t+'unverified note',pg.evaluate("cgVerH({id:9}).includes('فقط حضوری')&&cgVerH({id:1})===''"))
        chk(t+'cgVer',pg.evaluate("cgVer(2)==2&&cgVer(9)==0"))
        # booth page
        pg.evaluate("btNav({v:'bts',id:1})");pg.wait_for_timeout(700)
        chk(t+'booth page badge',pg.evaluate("!!document.querySelector('h2 .cgvb')"))
        # owner form
        pg.evaluate("BT.u='ali';BT.p='1234';VQ.ld=0;VQ.r=null;CGM.ld=1;CGM.r={geo:{lat:27.3,lng:62.3},lvl:0}")
        pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tw\"></div>');document.getElementById('tw').innerHTML=cgVqH()");pg.wait_for_timeout(500)
        pg.evaluate("document.getElementById('tw').innerHTML=cgVqH()")
        chk(t+'owner form shown',pg.evaluate("!!document.getElementById('vqph')&&!!document.getElementById('vqim')"))
        pg.locator('#vqph').fill('۰۹۱۲۳۴۵۶۷۸۹');pg.locator('#vqnt').fill('غرفه‌ی من');pg.locator('#vqim').set_input_files('/tmp/t.png')
        pg.locator('#tw [data-cg=vqs]').dispatch_event('click');pg.wait_for_timeout(900)
        a=last('vq_set') or {}
        chk(t+'vq_set payload',a.get('ph')=='09123456789' and a.get('nt')=='غرفه‌ی من' and str(a.get('im','')).startswith('data:image'))
        chk(t+'pending state',pg.evaluate("VQ.r.st=='pending'&&cgVqH().includes('در بررسی')"))
        pg.evaluate("VQ.r={ok:1,st:'no',why:'عکس غرفه واضح نیست',lvl:0}")
        chk(t+'rejected shows reason+form',pg.evaluate("cgVqH().includes('عکس غرفه واضح نیست')&&cgVqH().includes('vqph')"))
        pg.evaluate("VQ.r={ok:1,st:'ok',lvl:1}")
        chk(t+'verified owner box',pg.evaluate("cgVqH().includes('تأییدشده است')&&!cgVqH().includes('vqph')"))
        pg.evaluate("VQ.r={ok:1,st:'',lvl:0};CGM.r={geo:{},lvl:0}")
        chk(t+'noloc hint',pg.evaluate("cgVqH().includes('اول لوکیشن')"))
        # admin
        pg.evaluate("S.me='admin';S.role='admin';S.pw='x';S.pm=['all'];VQA.ld=0;VQA.p=1;VQA.l=[]")
        pg.evaluate("document.getElementById('tw').innerHTML=cgVqAdmin()");pg.wait_for_timeout(500)
        pg.evaluate("document.getElementById('tw').innerHTML=cgVqAdmin()")
        print('DBG',[c[0] for c in CALLS],pg.evaluate("[typeof btAdminOn,btAdminOn(),VQA.ld,VQA.l.length,document.getElementById('tw')?document.getElementById('tw').innerHTML.length:-1]"))
        chk(t+'admin queue',pg.evaluate("document.querySelectorAll('#tw .cgq').length")==1 and any(c[0]=='badm_vq' for c in CALLS))
        pg.locator('#tw [data-cg=vqi]').dispatch_event('click');pg.wait_for_timeout(500)
        chk(t+'image fetched',(last('badm_vqi') or {}).get('id')==7)
        pg.evaluate("try{ov.classList.remove('on')}catch(e){}")
        pg.locator('#tw [data-cg=vqa][data-v="7:2"]').dispatch_event('click');pg.wait_for_timeout(500)
        a=last('badm_vqd') or {}
        chk(t+'approve gold',a.get('id')==7 and a.get('ok')==1 and a.get('lvl')==2)
        pg.evaluate("document.getElementById('tw').innerHTML=cgVqAdmin()")
        pg.locator('#tw [data-cg=vqx]').dispatch_event('click');pg.wait_for_timeout(300)
        pg.locator('[data-cg=vqr][data-v="7:1"]').dispatch_event('click');pg.wait_for_timeout(500)
        a=last('badm_vqd') or {}
        chk(t+'reject with reason',a.get('ok')==0 and a.get('why')=='لوکیشن با نشانی نمی‌خواند')
        pg.evaluate("document.getElementById('tw').innerHTML=cgLvlB(2)")
        chk(t+'lvl buttons',pg.evaluate("document.querySelectorAll('#tw [data-cg=lvl]').length")==3 and pg.evaluate("document.querySelector('#tw [data-cg=lvl][data-v=\"2:2\"]').classList.contains('on')"))
        pg.locator('#tw [data-cg=lvl][data-v="2:0"]').dispatch_event('click');pg.wait_for_timeout(400)
        a=last('badm_lvl') or {}
        chk(t+'lvl change',a.get('id')==2 and a.get('lvl')==0)
        pg.evaluate("document.getElementById('tw').remove()");pg.wait_for_timeout(200)
        print('OVF',pg.evaluate("(()=>{const o=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>innerWidth+1)o.push(e.tagName+'.'+e.className+' '+Math.round(r.right))});return [innerWidth,document.documentElement.scrollWidth,o.slice(0,6)]})()"))
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    h=open('/home/claude/bb/www/index.html',encoding='utf8').read()
    chk('bord sends pk',"pk:((cgOn()&&!cgVer(bid))||cm=='h')?1:0" in h and "r.err=='unv'" in h)
    s=open('/home/claude/bb/ALL_SQL.sql',encoding='utf8').read()
    chk('sql section',"[1.9.370]" in s and "'err','unv'" in s and "badm_vqd" in s and s.rstrip().endswith("select 'ALL_SQL_DONE' as result;"))
    br.close()
print('ERRORS',errs)
