# تست 1.9.475: تغییر پیک سفارش مدیر (کلید ar)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        chk(f'{w}: off -> empty',pg.evaluate("arH()===''"))
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=1;XF.ar=1")
        chk(f'{w}: on -> field + button',pg.evaluate("(()=>{const h=arH();return h.includes('id=\"crar\"')&&h.includes('bt_crar')})()"))
        chk(f'{w}: hooked in crAdm',pg.evaluate("crAdm.toString().includes('arH()')"))
        pg.evaluate("XF.cr=0")
        chk(f'{w}: needs cr',pg.evaluate("arH()===''"))
        pg.evaluate("XF.cr=1;document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+arH()+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/ar360.png')
    br.close()
print('ERRORS',errs)
