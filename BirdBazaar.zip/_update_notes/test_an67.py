# تست 1.9.315: AN67 جابه‌جایی نرم کارت‌ها هنگام تغییر شبکه/لیست (FLIP)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("window.__an=0;const o=Element.prototype.animate;Element.prototype.animate=function(){window.__an++;return o.apply(this,arguments)};D.products=[1,2,3,4,5,6].map(i=>({id:90+i,name:'p'+i,cat:'c',price:1000*i,short:'s',img:'',disc:0,out:0}));S.v=null;S.tab=1;render()");pg.wait_for_timeout(300)
            has=pg.evaluate("!!document.getElementById('pgrid')")
            if not has: print('SKIP '+t);ctx.close();continue
            pg.evaluate("window.__an=0;anFlipCap();document.getElementById('pgrid').style.setProperty('grid-template-columns','1fr','important');anFlip(document.querySelector('#scr'))");pg.wait_for_timeout(450)
            n=pg.evaluate("window.__an")
            if rm=='no-preference': chk(t+'cards animate on column switch',n>0)
            else: chk(t+'reduced: no animation',n==0)
            pg.evaluate("window.__an=0;anFlipCap();FX.l=FX.l?0:1;render()");pg.wait_for_timeout(450)
            chk(t+'grid intact after',pg.evaluate("document.querySelectorAll('#pgrid>*').length>=6"))
            chk(t+'no transform left',pg.evaluate("[...document.querySelectorAll('#pgrid>*')].every(c=>!c.style.transform)"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
