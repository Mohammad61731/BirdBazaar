import html,base64,re,json
from playwright.sync_api import sync_playwright
src=open('/tmp/bb/www/index.html',encoding='utf8').read()
MOCK=r"""<script>(function(){
const B=[{id:7,name:'غرفه ارزن',phone:'09120001122',city:'سراوان',n:2,views:48,bio:'دان و ارزن مرغوب'},{id:8,name:'غرفه کتان',phone:'09123334455',city:'تهران',n:1,views:20,bio:''}];
const P=[{id:11,b:7,d:{type:'plain',name:'ارزن سفید ممتاز',emoji:'🌾',cat:'دان',price:50000,imgs:[],wh:{on:0},rt:{on:0}}},{id:12,b:7,d:{type:'plain',name:'کتان فرادما',emoji:'🌱',cat:'دان',price:80000,imgs:[],wh:{on:0},rt:{on:0}}},{id:13,b:8,d:{type:'plain',name:'کتان درجه یک',emoji:'🌱',cat:'دان',price:70000,imgs:[],wh:{on:0},rt:{on:0}}}];
const DB=[{id:1,b:7,cu:'ali',s:'u',body:'سلام، ارزن سفید دارید؟',k:'t'},{id:2,b:7,cu:'ali',s:'b',body:'سلام، بله موجود است 🌾',k:'t'},{id:3,b:7,cu:'ali',s:'b',body:'ارزن سفید ممتاز',k:'p',x:{id:11}},{id:4,b:7,cu:'ali',s:'u',body:'عالی، ۱۰ عدد می‌خوام',k:'t'},{id:5,b:8,cu:'ali',s:'b',body:'کتان تازه رسید',k:'t'},{id:6,b:7,cu:'reza',s:'u',body:'ارسال به مشهد دارید؟',k:'t'}];
const SEEN={};const OWN={7:'bob',8:'sara'};
const ok=o=>Promise.resolve(new Response(JSON.stringify(o),{status:200,headers:{'Content-Type':'application/json'}}));
function capp(d){const op=d.op,u=d.u,a=d.a||{};
 if(op=='ccount'){let n=0;DB.forEach(m=>{if(m.cu==u&&m.s=='b'&&m.id>(SEEN[m.b+'|'+m.cu+'|u']||0))n++;if(OWN[m.b]==u&&m.s=='u'&&m.id>(SEEN[m.b+'|'+m.cu+'|b']||0))n++});return{ok:1,n}}
 if(op=='clist'){const k={};DB.forEach(m=>{if(m.cu==u||OWN[m.b]==u)k[m.b+'|'+m.cu]=m});const l=Object.keys(k).map(key=>{const m=k[key],r=m.cu==u?'u':'b';const un=DB.filter(q=>q.b==m.b&&q.cu==m.cu&&q.s!=r&&q.id>(SEEN[m.b+'|'+m.cu+'|'+r]||0)).length;return{b:m.b,cu:m.cu,lid:m.id,r,lb:m.body,lk:m.k,ls:m.s,lt:new Date().toISOString(),un}}).sort((x,y)=>y.lid-x.lid);return{ok:1,l}}
 if(op=='cmsgs'||op=='csend'){let s,cu;if(OWN[a.b]==u){s='b';cu=a.cu;if(cu==u)return{err:'self'}}else{s='u';cu=u}
  if(op=='cmsgs'){const all=DB.filter(m=>m.b==a.b&&m.cu==cu);if(all.length)SEEN[a.b+'|'+cu+'|'+s]=Math.max(...all.map(m=>m.id));const ps=SEEN[a.b+'|'+cu+'|'+(s=='u'?'b':'u')]||0;return{ok:1,ps,m:all.filter(m=>m.id>(a.after||0)).map(m=>({id:m.id,s:m.s,b:m.body,k:m.k,x:m.x,t:new Date().toISOString()}))}}
  DB.push({id:DB.length+1,b:+a.b,cu,s,body:a.body,k:a.k||'t',x:a.x});return{ok:1,id:DB.length}}
 return{err:'unknown'}}
window.fetch=function(url,o){try{const d=JSON.parse((o&&o.body)||'{}');if(/rpc\/capp/.test(url))return ok(capp(d));if(/rpc\/bapp/.test(url)&&d.op=='bpublic')return ok({ok:1,booths:B,prods:P})}catch(e){}return Promise.reject(new Error('demo'))};
})();</script>"""
app=src.replace('<head>','<head>'+MOCK,1)
assert MOCK in app
open('demo_app.html','w',encoding='utf8').write(app)
SEED="S.me='%s';S.pw='1';BT.ok=1;BT.t=Date.now()+1e9;"
def go(pg,who,js):
    pg.evaluate(SEED%who+js);pg.wait_for_timeout(700)
shots={}
with sync_playwright() as p:
    br=p.chromium.launch()
    def mk():
        pg=br.new_context(viewport={'width':360,'height':740},locale='fa-IR').new_page();pg.goto('file:///tmp/bb/_update_notes/demo_app.html');pg.wait_for_timeout(900);
        pg.evaluate("bpull()");pg.wait_for_timeout(300);return pg
    pg=mk()
    go(pg,'ali',"btNav({v:'bts',id:7})");pg.screenshot(path='shots/p_booth.png');shots['booth']='p_booth.png'
    go(pg,'ali',"cListOpen()");pg.wait_for_timeout(500);pg.screenshot(path='shots/p_list.png')
    go(pg,'ali',"cOpen(7,'ali','u')");pg.wait_for_timeout(600);pg.screenshot(path='shots/p_chat.png')
    pg.click('button[data-a=ct_pp]');pg.wait_for_timeout(400);pg.screenshot(path='shots/p_pick.png');pg.evaluate("cl()")
    go(pg,'bob',"cListOpen()");pg.wait_for_timeout(500);pg.screenshot(path='shots/p_owner.png')
    br.close()
def b64(f):return 'data:image/png;base64,'+base64.b64encode(open('shots/'+f,'rb').read()).decode()
inv=b64('y2_inv.png')
cards=[
('Y1 · ارسال فاکتور','دیگر کپی خودکار نداریم. فاکتور یک دکمه‌ی «📤 ارسال فاکتور» دارد. برای مکمل‌ها پیام‌رسان بله باز می‌شود و برای غرفه‌ها اپ پیامک گوشی با متن آماده.',[inv]),
('Y2 · سفارش غرفه و بستن سفارش','بعد از ثبت سفارش، فاکتور با «📲 ارسال پیامک به غرفه‌دار» و تماس باز می‌شود. غرفه‌دار سفارش‌های جدید را بالا می‌بیند و «✔ بستن سفارش» یا «لغو» می‌زند.',[inv]),
('Y3 · پیام‌رسان کاربر↔غرفه‌دار','دکمه‌ی «💬 پیام به غرفه‌دار» در صفحه‌ی غرفه و محصول. لیست گفتگوها با نخوانده، حباب‌ها و تیک ✓ / ✓✓. غرفه‌دار هم از منوی ☰ ← گفتگوها جواب می‌دهد.',[b64('p_booth.png'),b64('p_list.png'),b64('p_chat.png')]),
('Y4 · فرستادن محصول در گفتگو','با دکمه‌ی 🛍 هر دو طرف یکی از محصولات همان غرفه را می‌فرستند. کارت محصول (عکس، نام، قیمت) در حباب است و زدنش صفحه‌ی محصول را باز می‌کند.',[b64('p_pick.png'),b64('p_chat.png'),b64('p_owner.png')]),
]
t1=''.join('<section class="c"><h3>%s</h3><p>%s</p><div class="sh">%s</div></section>'%(h,d,''.join('<img src="%s" alt="">'%i for i in ims)) for h,d,ims in cards)
page='''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>بازارچه پرندگان — پروتوتایپ ۱.۹.۲ (Y1–Y4)</title>
<style>:root{--f:#12805c;--bg:#f2f4f3;--sf:#fff;--ink:#1c2b25;--mu:#66766f}@media(prefers-color-scheme:dark){:root{--f:#34c48f;--bg:#0f1714;--sf:#18231f;--ink:#e8f0ec;--mu:#8fa39a}}
*{box-sizing:border-box}body{margin:0;font-family:Vazirmatn,Tahoma,sans-serif;background:var(--bg);color:var(--ink)}
.tabs{position:sticky;top:0;display:flex;gap:6px;padding:10px;background:var(--bg);z-index:5}.tabs button{flex:1;padding:10px;border:0;border-radius:12px;background:var(--sf);color:var(--ink);font:inherit;font-weight:700}.tabs .on{background:var(--f);color:#fff}
.p{padding:0 12px 24px}.c{background:var(--sf);border-radius:16px;padding:12px;margin-bottom:12px}.c h3{margin:0 0 4px;font-size:15px}.c p{margin:0 0 8px;color:var(--mu);font-size:13px;line-height:1.8}.sh{display:flex;gap:8px;overflow-x:auto}.sh img{height:360px;border-radius:12px;flex:none}
.bar{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}.bar button{flex:1 1 30%;padding:8px;border:0;border-radius:10px;background:var(--sf);color:var(--ink);font:inherit;font-size:12px}
iframe{width:100%;height:calc(100vh - 170px);min-height:560px;border:0;border-radius:16px;background:#fff}.hide{display:none}</style></head><body>
<div class="tabs"><button class="on" id="b1">مراحل</button><button id="b2">اپ زنده</button></div>
<div class="p" id="t1">'''+t1+'''<section class="c"><h3>قبل از استفاده</h3><ul style="line-height:2;font-size:13px"><li>فایل UPDATE_FINAL2.sql را در Supabase اجرا کن.</li><li>در تب «اپ زنده» داده‌ها نمایشی‌اند و روی سرور واقعی نمی‌روند.</li></ul></section></div>
<div class="p hide" id="t2"><div class="bar"><button onclick="r('ba')">🏪 صفحه‌ی غرفه (علی)</button><button onclick="r('la')">💬 گفتگوهای علی</button><button onclick="r('ca')">گفتگو با غرفه‌دار</button><button onclick="r('lb')">🧑‍🌾 گفتگوهای غرفه‌دار (بوب)</button></div><iframe id="fr" srcdoc="'''+html.escape(app,quote=True)+'''"></iframe></div>
<script>const $=i=>document.getElementById(i);function tab(n){$('t1').classList.toggle('hide',n!=1);$('t2').classList.toggle('hide',n!=2);$('b1').classList.toggle('on',n==1);$('b2').classList.toggle('on',n==2)}$('b1').onclick=()=>tab(1);$('b2').onclick=()=>tab(2);
function r(k){const w=$('fr').contentWindow;const A="BT.ok=1;BT.t=Date.now()+1e9;";try{w.eval("bpull()").then?0:0;setTimeout(()=>{if(k=='ba')w.eval("S.me='ali';S.pw='1';"+A+"btNav({v:'bts',id:7})");if(k=='la')w.eval("S.me='ali';S.pw='1';"+A+"cListOpen()");if(k=='ca')w.eval("S.me='ali';S.pw='1';"+A+"cOpen(7,'ali','u')");if(k=='lb')w.eval("S.me='bob';S.pw='1';"+A+"cListOpen()")},400)}catch(e){}}</script></body></html>'''
open('/tmp/bb/prototype_y.html','w',encoding='utf8').write(page)
print(len(page))
