# تست 1.9.293: LG13 کنترل‌ها
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
H="<h3>کنترل‌ها</h3><label style=\\\"display:flex;gap:10px;align-items:center\\\"><input type=checkbox id=c1><span>سوییچ</span></label><label style=\\\"display:flex;gap:10px\\\"><input type=radio id=r1><span>رادیو</span></label><button class=btn id=b1>تأیید</button><button class=\\\"btn o\\\" id=b2>دوم</button><button class=\\\"btn r\\\" id=b3>حذف</button>"
Q="(()=>{const c=document.getElementById('c1'),r=document.getElementById('r1'),b=document.getElementById('b1'),cs=getComputedStyle(c),bs=getComputedStyle(b),cb=c.getBoundingClientRect(),bb=b.getBoundingClientRect(),k=c.checked;const kn=getComputedStyle(c,'::after'),hit=getComputedStyle(c,'::before');return {w:cb.width,h:cb.height,r:parseFloat(cs.borderTopLeftRadius),bg:cs.backgroundColor,kw:kn.width,hh:hit.height,br:parseFloat(bs.borderTopLeftRadius),bh:bb.height,bbg:bs.backgroundColor,ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=0;S.v=null;render();sheet(\"%s\")"%(m,H));pg.wait_for_timeout(500)
                r0=pg.evaluate(Q)
                pg.evaluate("document.getElementById('c1').checked=true");pg.wait_for_timeout(450)
                r1=pg.evaluate(Q)
                if m!='m':
                    chk(t+'switch 51x31',r0['w']==51 and r0['h']==31 and r0['r']==16)
                    chk(t+'hit 44',float(r0['hh'][:-2])>=44)
                    chk(t+'knob 27',r0['kw']=='27px')
                    import re as _re
                    g=[int(x) for x in _re.findall(r'\d+',r1['bg'])[:3]]
                    chk(t+'on green',r1['bg']!=r0['bg'] and g[1]>g[0] and g[1]>g[2])
                    bl=[int(x) for x in _re.findall(r'\d+',r0['bbg'])[:3]]
                    chk(t+'btn 14/50 blue',r0['br']==14 and r0['bh']>=49 and bl[2]>bl[0]+80)
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg13_%s.png'%('d' if dark else 'l'))
                chk(t+'no overflow',r0['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
