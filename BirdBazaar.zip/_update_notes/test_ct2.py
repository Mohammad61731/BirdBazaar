# تست 1.9.255: سبد — جمع قیمت اصلی و سود تخفیف (P60)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        pg=br.new_context(viewport={'width':w,'height':700},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("D.products=[{id:9001,name:'تست',price:100000,disc:10,k:'n',cat:'x',st:[1]}];D.cart=[{id:9001,q:2}];S.tab=3;render()");pg.wait_for_timeout(400)
        h=pg.evaluate("cartV()")
        chk(f'{w}: summary shown','سود شما از تخفیف' in h)
        chk(f'{w}: save value',pg.evaluate("cartSave()")==20000)
        pg.evaluate("D.products[0].disc=0;render()")
        chk(f'{w}: no discount no summary','سود شما' not in pg.evaluate("cartV()"))
        chk(f'{w}: single total row',pg.locator('.dose.cts').count()==1)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    br.close()
print('ERRORS',errs)
