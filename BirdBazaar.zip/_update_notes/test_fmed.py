# تست 1.9.76: رسانه‌ی انجمن فقط با لمس بارگیری می‌شود (op fmed) و fpull پیش‌فرض nomd دارد
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
PX='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        calls=[]
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if u.startswith('http'):
                try: j=json.loads(bd)
                except Exception: j={}
                op=j.get('op'); a=j.get('a') or {}; calls.append((op,a))
                if op=='fmed': body={'ok':1,'md':PX}
                elif op=='fpull': body={'ok':1,'mode':'on','slow':0,'rooms':[{'id':1,'name':'r','emoji':'💬','color':''}],'msgs':[{'id':7,'u':'x','k':'img','b':'','md':None,'hm':True,'t':'2026-01-01T00:00:00Z','r':{}},{'id':8,'u':'x','k':'text','b':'hi','hm':False,'t':'2026-01-01T00:00:00Z','r':{}}],'av':{},'pins':[],'reqn':0}
                else: body={'ok':1,'n':0,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2000)
        await pg.evaluate("S.me='u1';S.pw='x';S.role='user'")
        await pg.evaluate("fpull(1)"); await pg.wait_for_timeout(600)
        fp=[c for c in calls if c[0]=='fpull']; print('fpull nomd:',[c[1].get('nomd') for c in fp]); ok&=all(c[1].get('nomd')==1 for c in fp)
        await pg.evaluate("FM.room=1;FM.msgs=[{id:7,u:'x',k:'img',b:'',md:null,hm:true,t:'2026-01-01T00:00:00Z',r:{}}];go({v:'chat',id:1,fr:1})"); await pg.wait_for_timeout(800)
        html=await pg.evaluate("document.querySelector('#scr')?document.querySelector('#scr').innerHTML:document.body.innerHTML")
        has='data-a="fmld"' in html; print('placeholder shown:',has); ok&=has
        ok&= '<img src="data:' not in html
        await pg.evaluate("fmLoad(7)"); await pg.wait_for_timeout(900)
        html=await pg.evaluate("document.body.innerHTML"); got='<img src="data:image/png' in html
        print('image after tap:',got, 'fmed calls',len([c for c in calls if c[0]=='fmed'])); ok&=got and len([c for c in calls if c[0]=='fmed'])==1
        print('errors',errs); ok&=not errs
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
