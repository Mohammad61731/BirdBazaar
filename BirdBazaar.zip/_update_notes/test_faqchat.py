import json,sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w'
SH=sys.argv[2] if len(sys.argv)>2 else ''
errs=[];ok=[]
FAQ=[{'id':i,'qu':'امیر%d'%i,'q':'پرسش %d؟'%i,'a':'پاسخ ادمین %d'%i} for i in range(1,9)]
MS=[]
calls=[]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);o=b['op'];calls.append(o);r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':False,'perm':{'txt':True},'avatar':'','mode':'on','slow':0}
        if o=='fpull':r={'ok':1,'mode':'on','slow':0,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜','color':''}],'msgs':MS,'av':{},'pins':[],'reqn':0}
        if o=='ffaq':r={'ok':1,'faq':FAQ}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
        MS[:]=[];pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
        pg.evaluate("S.role='user';S.me='u1';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(1500)
        pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(1200)
        t=pg.inner_text('#msgs')
        chk(f'{w} پرسش و پاسخ داخل خود چت',t.count('پاسخ ادمین')==8 and 'امیر1' in t)
        chk(f'{w} برچسب نمونه/فرضی',('نام‌ها فرضی' in t))
        chk(f'{w} بدون سرریز',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360 and SH:pg.evaluate("document.querySelector('#scr').scrollTop=0");pg.screenshot(path=SH+'/faqchat.png')
        MS[:]=[{'id':5,'u':'reza','k':'text','b':'پیام واقعی','md':None,'rt':None,'pin':False,'ed':False,'t':'2026-11-13T08:00:00Z','r':{}}]
        pg.evaluate("go({tab:5,v:null})");pg.wait_for_timeout(600);pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(1200)
        t=pg.inner_text('#msgs');chk(f'{w} پیام واقعی بعد از نمونه‌ها',t.find('پیام واقعی')>t.find('پاسخ ادمین 8')>0 and 'پیام‌های اعضا' in t)
        n=calls.count('ffaq');pg.evaluate("go({tab:5,v:null})");pg.wait_for_timeout(400);pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
        chk(f'{w} ffaq دوباره زود گرفته نمی‌شود',calls.count('ffaq')==n)
        ctx.close()
    br.close()
print('ERR',errs);print('ALL',all(ok) and not errs)
