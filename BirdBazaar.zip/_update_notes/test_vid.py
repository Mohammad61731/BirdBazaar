import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='text/html',body='<html><body>player</body></html>'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    T=[('https://www.aparat.com/v/AbC123','frame','aparat.com/video/video/embed/videohash/AbC123/vt/frame'),
       ('https://youtu.be/dQw4w9WgXcQ','frame','youtube.com/embed/dQw4w9WgXcQ'),
       ('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=5','frame','youtube.com/embed/dQw4w9WgXcQ'),
       ('https://www.youtube.com/shorts/abcdefghijk','frame','youtube.com/embed/abcdefghijk'),
       ('https://vimeo.com/123456','frame','player.vimeo.com/video/123456'),
       ('https://www.instagram.com/reel/Cxyz12_ab/?igsh=1','frame','instagram.com/reel/Cxyz12_ab/embed'),
       ('https://www.instagram.com/p/Cxyz12/','frame','instagram.com/p/Cxyz12/embed'),
       ('https://site.ir/a/b.mp4','video','b.mp4'),
       ('https://example.com/page','ext','example.com/page'),
       ('javascript:alert(1)',None,None),('ftp://x/y.mp4',None,None),('',None,None)]
    for u,k,sub in T:
        r=pg.evaluate("vidInfo(%r)"%u)
        chk('vidInfo %s'%u[:45],(r is None) if k is None else (r and r['k']==k and sub in r['src']))
    pg.evaluate("D.guides=[{id:9,title:'آموزش',cat:'',text:'متن',img:'',video:'https://www.aparat.com/v/AbC123'}];go({v:'guide',id:9})");pg.wait_for_timeout(400)
    chk('دکمه‌ی پخش',pg.locator('[data-a=gvid]').count()==1)
    pg.click('[data-a=gvid]');pg.wait_for_timeout(500)
    chk('iframe داخل برنامه ساخته شد',pg.locator('#vp iframe').count()==1 and 'aparat.com' in pg.locator('#vp iframe').get_attribute('src'))
    chk('دکمه‌ی باز کردن در مرورگر',pg.locator('[data-a=vx]').count()==1)
    pg.screenshot(path=P+'/shots/vid.png')
    pg.evaluate("window.__o=[];window.open=u=>{window.__o.push(u);return null};0");pg.click('[data-a=vx]');chk('باز کردن بیرونی (fallback)',pg.evaluate("__o.slice(-1)[0]")=='https://www.aparat.com/v/AbC123')
    pg.evaluate("D.guides[0].video='https://site.ir/v.mp4';go({v:'guide',id:9})");pg.wait_for_timeout(300);pg.click('[data-a=gvid]');pg.wait_for_timeout(300)
    chk('mp4 با پلیر video',pg.locator('#vp video').count()==1)
    pg.evaluate("D.guides[0].video='https://www.instagram.com/reel/Cxyz12/';go({v:'guide',id:9})");pg.wait_for_timeout(300);pg.click('[data-a=gvid]');pg.wait_for_timeout(300)
    chk('اینستا → iframe با ارتفاع بلندتر',pg.locator('#vp iframe').count()==1)
    pg.evaluate("window.__o=[];0;D.guides[0].video='https://example.com/page';go({v:'guide',id:9})");pg.wait_for_timeout(300);pg.click('[data-a=gvid]');pg.wait_for_timeout(300)
    chk('سایت ناشناخته → مرورگر',pg.evaluate("__o.slice(-1)[0]")=='https://example.com/page' and pg.locator('#vp iframe').count()==0)
    pg.evaluate("D.guides[0].video='https://www.aparat.com/v/AbC123';go({v:'guide',id:9})");pg.wait_for_timeout(300);pg.click('[data-a=gvid]');pg.wait_for_timeout(300)
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
