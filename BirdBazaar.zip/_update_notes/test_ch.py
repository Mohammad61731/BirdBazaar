# تست 1.9.116: نرخ پیدا شدن کش — فقط مدیر؛ شمارش امروز/کل ؛ صفر کردن ؛ خاموش ← بدون شمارش
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default on', await pg.evaluate("chOn()&&tlOn('ch')")==True)
        await pg.evaluate("chNote(true)")
        chk('non-admin: no count', await pg.evaluate("localStorage.getItem('bp_chr')")is None)
        await pg.evaluate("S.pm=['all'];for(let i=0;i<3;i++)chNote(true);chNote(false)")
        o=await pg.evaluate("chRd()")
        chk('counts 3 hit 1 miss (%s)'%o, o.get('h')==3 and o.get('m')==1 and o.get('th')==3 and o.get('tm')==1)
        t=await pg.evaluate("tlCh()")
        chk('shows 75%', '۷۵٪' in t)
        chk('low data hint', 'داده‌ی کافی نیست' in t)
        await pg.evaluate("for(let i=0;i<20;i++)chNote(true)")
        chk('good hint', '✅' in await pg.evaluate("tlCh()"))
        await pg.evaluate("localStorage.removeItem('bp_chr')")
        chk('cleared', (await pg.evaluate("chRd()"))=={})
        await pg.evaluate("tlSet('ch',0);chNote(true)")
        chk('off: no count', await pg.evaluate("localStorage.getItem('bp_chr')")is None)
        await pg.evaluate("tlSet('ch',1)")
        chk('tlSec has row', 'گزارش نرخ پیدا شدن کش' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
