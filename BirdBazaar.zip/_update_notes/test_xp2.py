# تست 1.9.355: P8 شهر ، P10 ایموجی آواتار ، P94 خروج خودکار پنل (کلید xp)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("localStorage.removeItem('bp_px');S.role='admin';S.pm=['all'];S.ed=0;S.tab=0;XF.xp=0;render()");pg.wait_for_timeout(300)
        chk(t+'off: no city/emoji',pg.evaluate("(()=>{pxSave({city:'شیراز',em:'🐦'});const r=pxCity()==''&&pxEmoji('👤')=='👤';localStorage.removeItem('bp_px');return r})()"))
        pg.evaluate("XF.xp=1;S.sx='px';S.tab=4;render();document.getElementById('scr').insertAdjacentHTML('afterbegin',pxSec())");pg.wait_for_timeout(200)
        chk(t+'ui present',pg.evaluate("!!document.querySelector('#pxs [data-px=city]')&&document.querySelectorAll('#pxs [data-px=em]').length==8&&document.querySelectorAll('#pxs [data-px=ax]').length==4"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("const r=document.querySelector('[data-px=city]');r.value='شیراز ، معالی‌آباد';r.dispatchEvent(new Event('input',{bubbles:true}))")
        chk(t+'city saved+shown',pg.evaluate("pxGet().city=='شیراز ، معالی‌آباد'&&pxCity().includes('📍')"))
        chk(t+'city in avtBox',pg.evaluate("avtBox('👤','x','','sub').includes('معالی‌آباد')"))
        clk(pg,'#pxs [data-px=em][data-v="🦜"]')
        chk(t+'emoji set',pg.evaluate("pxGet().em=='🦜'&&pxEmoji('👤')=='🦜'&&avtBox('👤','x','','s').includes('🦜')"))
        clk(pg,'#pxs [data-px=em][data-v=""]')
        chk(t+'emoji reset',pg.evaluate("pxGet().em==''&&pxEmoji('👤')=='👤'"))
        clk(pg,'#pxs [data-px=ax][data-v="5"]')
        chk(t+'ax saved',pg.evaluate("pxGet().ax==5"))
        chk(t+'auto-exit panel',pg.evaluate("""(()=>{const st=window.setTimeout;let cb=null,ms=0;window.setTimeout=(f,m)=>{cb=f;ms=m;return 1};S.pnl=1;pxIdle();window.setTimeout=st;if(!cb||ms!=300000)return false;cb();return !S.pnl})()"""))
        chk(t+'no timer when off',pg.evaluate("""(()=>{const o=pxGet();o.ax=0;pxSave(o);const st=window.setTimeout;let c=0;window.setTimeout=(f,m)=>{c++;return 1};S.pnl=1;pxIdle();window.setTimeout=st;return c==0})()"""))
        chk(t+'no ax card for user',pg.evaluate("(S.role=null,S.pm=[],!pxBody().includes('data-px=\"ax\"'))"))
        pg.evaluate("XF.xp=0;pxApply()")
        ctx.close()
    br.close()
print('ERRORS',errs)
