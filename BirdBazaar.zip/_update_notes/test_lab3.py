# تست 1.9.498: LAB-2 غرفه‌ی آزمایشی از همه‌ی دسته‌ها
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(150)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_lab');LAB={};S.role='admin';S.pm=['all'];S.pvu=0;XF.sto=0")
        clk(pg,'lab','o')
        chk(t+'no booths before',pg.evaluate("!LAB.bs"))
        clk(pg,'lab','ba')
        chk(t+'13 booths',pg.evaluate("Object.keys(LAB.bs).length==13&&LAB.as.length==13"))
        chk(t+'4 items each',pg.evaluate("Object.values(LAB.bs).every(b=>b.it.length==4&&b.it.some(i=>i.d)&&b.it.some(i=>i.lq))"))
        chk(t+'ox in some',pg.evaluate("Object.values(LAB.bs).some(b=>b.it.some(i=>i.ox))"))
        chk(t+'shown with tag',pg.evaluate("document.getElementById('ovc').innerText.includes('آزمایشی')&&document.querySelectorAll('#ovc details.card').length==13"))
        clk(pg,'lab','bs:fd');chk(t+'select booth',pg.evaluate("LAB.b&&LAB.b.k=='fd'&&LAB.b.it.length==4"))
        clk(pg,'lab','bo');chk(t+'order from it',pg.evaluate("LAB.o&&LAB.o.t>0"))
        clk(pg,'lab','as:cl');chk(t+'ad select',pg.evaluate("LAB.a&&LAB.a.l==7"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('ovc').scrollWidth<=innerWidth+1"))
        clk(pg,'lab','bz');chk(t+'clear',pg.evaluate("!LAB.bs&&!LAB.as&&!LAB.b"))
        clk(pg,'lab','dm');chk(t+'demo auto-builds',pg.evaluate("LAB.demo.on==1&&Object.keys(LAB.bs).length==13"))
        pg.evaluate("localStorage.setItem('bp_nk','x')")
        clk(pg,'lab','de');chk(t+'end clears all',pg.evaluate("!LAB.bs&&!LAB.as&&!LAB.demo"))
        chk(t+'nothing sent to server',pg.evaluate("!(window.__req||[]).length"))
        ctx.close()
    br.close()
print('ERRS',len(errs))
