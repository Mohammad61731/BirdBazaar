# تست 1.9.263 P81: کاور پروفایل
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("S.me='کاربر تست';S.role='user';S.tab=4;S.v=null;S.pnl=0;render()");pg.wait_for_timeout(400)
            chk(f'{w}/{dark}: cover shown',pg.locator('.pcvb').count()==1 and pg.locator('.pcvr .avt').count()==1)
            pg.locator('.pcvb').click();pg.wait_for_timeout(300)
            chk(f'{w}/{dark}: tap cycles',pg.evaluate("localStorage.getItem('bbcov')")=='1' and pg.locator('.pcvb').count()==1)
            chk(f'{w}/{dark}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360: pg.screenshot(path=f'/tmp/pv_{w}_{dark}.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
