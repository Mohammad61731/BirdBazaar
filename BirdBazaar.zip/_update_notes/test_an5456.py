# تست 1.9.305: AN54 سه‌نقطه‌ی در حال نوشتن ، AN55 تیک خوانده‌شد ، AN56 چرخش ✕
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.set_default_timeout(8000)
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                # AN55 منطق fmTick
                h=pg.evaluate("window.__fk2={};[fmTick(7,false),fmTick(7,true),fmTick(7,true),fmTick(9,true)]")
                chk(t+'AN55 single ✓ no anim',('✓</span>' in h[0]) and 'fmtd' not in h[0])
                chk(t+'AN55 ✓→✓✓ anim',('✓✓' in h[1]) and 'fmtd' in h[1])
                chk(t+'AN55 stays ✓✓ no anim',('✓✓' in h[2]) and 'fmtd' not in h[2])
                chk(t+'AN55 new ✓✓ no anim',('✓✓' in h[3]) and 'fmtd' not in h[3])
                pg.evaluate("const d=document.createElement('div');d.id='tz';d.innerHTML='<span class=\"fmtk fmtd\" id=\"tk1\">✓✓</span><button class=\"btn\" id=\"tb\">x⏳ در حال نوشتن<span class=\"dts\"><i>.</i><i>.</i><i>.</i></span></button><div class=\"chips\"><button class=\"chip\" data-a=\"hrsc\" id=\"tx\">✕</button></div>';document.getElementById('scr').appendChild(d);0")
                r=pg.evaluate("(()=>{const g=(e)=>getComputedStyle(e);return {tk:g(document.getElementById('tk1')).animationName,d1:g(document.querySelector('.dts i')).animationName,d2:g(document.querySelectorAll('.dts i')[1]).animationDelay,tr:g(document.getElementById('tx')).transitionProperty,ov:document.documentElement.scrollWidth<=innerWidth}})()")
                chk(t+'no overflow',r['ov'])
                if rm=='no-preference':
                    chk(t+'AN55 css anim',r['tk']=='antd')
                    chk(t+'AN54 dots anim',r['d1']=='andt' and r['d2']!='0s')
                    chk(t+'AN56 transform transition','transform' in r['tr'])
                else:
                    chk(t+'AN55 reduced none',r['tk'] in ('none',''))
                    chk(t+'AN54 reduced none',r['d1'] in ('none',''))
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
