# تست 1.9.74: کم‌شدن پولینگ پیام/گفتگو وقتی اعلان گوشی فعال است
import sys,json
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
errs=[];ok=[];reqs=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
st={'ptok':1}
def h(r,q):
    if q.url.startswith('file:'):return r.continue_()
    try:b=json.loads(q.post_data or '{}')
    except Exception:b={}
    reqs.append(b)
    if b.get('op')=='ptoken' and not st['ptok']:return r.fulfill(status=200,content_type='application/json',body=json.dumps({'err':'login'}))
    r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':1,'n':0}))
MOCK="""window.__pn={L:{},calls:[]};window.Capacitor=window.Capacitor||{};Capacitor.Plugins=Capacitor.Plugins||{};
Capacitor.Plugins.PushNotifications={addListener:(e,f)=>{__pn.L[e]=f},requestPermissions:async()=>{return{receive:'granted'}},register:async()=>{}}"""
cnt=lambda o:len([x for x in reqs if x.get('op')==o])
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=br.new_page(viewport={'width':360,'height':760});pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',h);pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate(MOCK)
    # بدون اعلان: هر تیک مجاز است
    pg.evaluate("S.role='user';S.me='ali';S.pw='x';PD.m=0;PD.c=0")
    a=pg.evaluate("[pollDue('m'),pollDue('m'),pushLive()]")
    chk('بدون اعلان: تیک اول مجاز %s'%a[:1],a[0] is True and a[2] is False)
    pg.evaluate("PD.m=Date.now()-120000")
    chk('بدون اعلان: بعد از ۲ دقیقه دوباره مجاز',pg.evaluate("pollDue('m')") is True)
    # ثبت اعلان با موفقیت سرور
    pg.evaluate("PUSH.d=0;localStorage.removeItem('bp_pst');pushInit()");pg.wait_for_timeout(300)
    pg.evaluate("__pn.L.registration({value:'T'.repeat(40)})");pg.wait_for_timeout(400)
    chk('اعلان فعال شد',pg.evaluate("pushLive()") is True)
    pg.evaluate("PD.m=Date.now()-130000")
    chk('با اعلان: ۲ دقیقه کافی نیست',pg.evaluate("pollDue('m')") is False)
    pg.evaluate("PD.m=Date.now()-610000")
    chk('با اعلان: بعد از ۱۰ دقیقه مجاز',pg.evaluate("pollDue('m')") is True)
    # دریافت اعلان در برنامه ← فوراً mcount و ccount
    m0,c0=cnt('mcount'),cnt('ccount')
    pg.evaluate("__pn.L.pushNotificationReceived({})");pg.wait_for_timeout(600)
    chk('اعلان دریافتی: mcount و ccount فوراً (%d,%d)'%(cnt('mcount')-m0,cnt('ccount')-c0),cnt('mcount')>m0 and cnt('ccount')>c0)
    # خروج ← دوباره پولینگ عادی
    pg.evaluate("pushOff()")
    chk('بعد از خروج: دوباره عادی',pg.evaluate("pushLive()") is False)
    # سرور ptoken را نپذیرفت ← فعال حساب نمی‌شود
    st['ptok']=0
    pg.evaluate("PUSH.u='';PUSH.ok=0;S.me='sara';pushInit();__pn.L.registration({value:'U'.repeat(40)})");pg.wait_for_timeout(500)
    chk('ptoken رد شد ← پولینگ عادی می‌ماند',pg.evaluate("pushLive()") is False)
    chk('بی‌خطا %s'%errs[:1],not errs)
    br.close()
sys.exit(0 if all(ok) else 1)
