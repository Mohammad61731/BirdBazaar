# تست 1.9.203: تنظیم هر آیکن (IC7)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.effect_mandelbrot((600,400),(-2,-1.5,1,1.5),40).convert('RGBA').save('/home/claude/w/tmp/i7.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();icPick('nav.home')})()");pg.wait_for_timeout(300)
        with pg.expect_file_chooser() as fc: pg.click('[data-a=ica]')
        fc.value.set_files('/home/claude/w/tmp/i7.png');pg.wait_for_timeout(1000)
        k=pg.evaluate("Object.keys(ikLib)[0]")
        pg.evaluate(f"icSet('nav.home','{k}')")
        u0=pg.evaluate(f"ikLib['{k}'].u")
        pg.evaluate(f"icOne('nav.home','{k}')");pg.click('[data-a=ice]');pg.wait_for_timeout(600)
        chk(f'{w}: editor shown',pg.locator('#icep').count()==1 and pg.locator('#ice_z').count()==1)
        pg.evaluate("(()=>{const z=document.getElementById('ice_z');z.value=200;z.dispatchEvent(new Event('input',{bubbles:true}));const m=document.getElementById('ice_m');m.value='2';m.dispatchEvent(new Event('change',{bubbles:true}));const c=document.getElementById('ice_k');c.value='#00aa00';c.dispatchEvent(new Event('input',{bubbles:true}))})()")
        chk(f'{w}: state updated',pg.evaluate("ICE.p.z==200&&ICE.p.m==2&&ICE.p.k=='#00aa00'"))
        pg.click('[data-a=ices]');pg.wait_for_function("document.getElementById('icep')==null");pg.wait_for_timeout(300)
        chk(f'{w}: baked small webp',pg.evaluate(f"(()=>{{const e=ikLib['{k}'];return e.u!=={u0!r}&&e.u.indexOf('data:image/webp')==0&&e.u.length<=7000&&e.o==={u0!r}&&e.p.z==200}})()"))
        chk(f'{w}: slot refreshed in IKL',pg.evaluate(f"D.cms.IKL['{k}'].u==ikLib['{k}'].u&&!('o' in D.cms.IKL['{k}'])&&!('p' in D.cms.IKL['{k}'])"))
        pg.evaluate(f"icEd('nav.home','{k}')");pg.wait_for_timeout(500)
        pg.evaluate("(()=>{const m=document.getElementById('ice_m');m.value='1';m.dispatchEvent(new Event('change',{bubbles:true}))})()")
        pg.click('[data-a=ices]');pg.wait_for_timeout(600)
        chk(f'{w}: mono mask c=0',pg.evaluate(f"ikLib['{k}'].c===0&&ikLib['{k}'].o==={u0!r}"))
        pg.evaluate(f"icEd('nav.home','{k}')");pg.wait_for_timeout(500);pg.click('[data-a=icer]');pg.wait_for_timeout(500)
        chk(f'{w}: reset original',pg.evaluate(f"ikLib['{k}'].u==={u0!r}&&!ikLib['{k}'].o&&!ikLib['{k}'].p&&ikLib['{k}'].c==1&&D.cms.IKL['{k}'].u==={u0!r}"))
    br.close()
print('ERRORS',errs)
