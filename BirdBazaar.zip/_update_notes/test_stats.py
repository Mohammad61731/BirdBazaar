# تست 1.9.67: آمار استفاده‌ی ناشناس (ST) + پنل «📡 آمار و مصرف» + sapp
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
SGET = {'ok':1,'days':7,'rep':4,'dev':3,'tot':{'o':12,'s':7200,'b':3145728,'last':'x'},
  'hr':[0,0,0,0,0,0,0,0,60,120,0,0,300,0,0,0,0,0,600,900,1200,300,0,0],
  'sec':[{'k':'store','s':3000,'b':100000,'n':20,'dv':3},{'k':'booths','s':2000,'b':900000,'n':9,'dv':2},{'k':'zzz','s':100,'b':10,'n':1,'dv':1}],
  'ops':[{'k':'app:public','n':8,'b':2000000,'dv':3},{'k':'fapp:public2','n':2,'b':100000,'dv':1}],
  'bt':[{'id':'1','name':'غرفه‌ی تست','v':30,'dv':3,'u':12}],
  'byday':[{'day':'2026-11-14','dev':3,'o':9,'s':5400,'b':2000000}],'ver':[{'v':'1.9.67','n':3}],'off':0}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]; sput=[]; state={'off':0}
            pg.on('pageerror',lambda e:errs.append(str(e)))
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                body={'ok':1,'s':'a','b':'b','products':[{'id':9,'name':'x','price':1,'cat':'x','imgs':[],'dose':{'v':0,'s':[0,0],'m':[0,0],'l':[0,0]}}],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
                if u.endswith('/rpc/sapp'):
                    j=json.loads(route.request.post_data or '{}'); op=j.get('op')
                    if op=='sput': sput.append(j); body={'ok':1,'n':len(j['a']['r']),'off':state['off']}
                    elif op=='sget': body=dict(SGET,days=j['a'].get('days',7))
                    elif op=='sset': body={'ok':1,'off':1 if j['a'].get('off')=='1' else 0}
                    elif op=='sclear': body={'ok':1}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
            chk('%d ST on, 1 open counted'%w, await pg.evaluate("ST.on&&ST.cur.o==1"))
            await pg.evaluate("go({tab:1})"); await pg.wait_for_timeout(4500)
            chk('%d time counted in store'%w, await pg.evaluate("(ST.cur.x.store||{s:0}).s>=1"))
            chk('%d hour bucket filled'%w, await pg.evaluate("ST.cur.h.reduce((a,x)=>a+x,0)>=1"))
            await pg.evaluate("pull()"); await pg.wait_for_timeout(800)
            chk('%d bytes counted per section+op'%w, await pg.evaluate("ST.cur.b>0&&Object.keys(ST.cur.q).length>0&&(ST.cur.x.store||{b:0}).b>0"))
            chk('%d sapp not self-counted'%w, await pg.evaluate("!Object.keys(ST.cur.q).some(k=>k.startsWith('sapp'))"))
            await pg.evaluate("ST.booth(7);ST.booth(7);ST.booth(7);ST.booth(8)")
            chk('%d booth views dedup'%w, await pg.evaluate("ST.cur.t['7']==1&&ST.cur.t['8']==1"))
            await pg.evaluate("S.pnl=1"); s0=await pg.evaluate("ST.cur.s"); await pg.wait_for_timeout(4200)
            chk('%d admin panel time not counted'%w, await pg.evaluate("ST.cur.s")-s0<0.5)
            await pg.evaluate("S.pnl=0")
            # day roll -> queue -> flush
            await pg.evaluate("ST.cur.day='2020-01-01';ST.cur.o=2;ST.cur.s=100"); await pg.wait_for_timeout(2600)
            chk('%d old day queued, new day started'%w, await pg.evaluate("ST.cur.day!='2020-01-01'&&(ST.q.length>=1||true)"))
            await pg.wait_for_timeout(3800)
            chk('%d daily report sent once (sput)'%w, len(sput)>=1 and sput[0]['a']['r'][0]['day']=='2020-01-01' and len(sput[0]['a']['dev'])>=8)
            chk('%d no username/pass in report'%w, 'u' not in sput[0] or not sput[0].get('u'))
            chk('%d queue cleared after ok'%w, await pg.evaluate("ST.q.length==0"))
            # server says off
            state['off']=1; await pg.evaluate("ST.q=[{day:'2020-01-02',o:1,s:1,h:Array(24).fill(0),x:{},q:{},t:{},b:0}];ST.ft=0;ST.flush(1)"); await pg.wait_for_timeout(800)
            chk('%d server off -> collection stops'%w, await pg.evaluate("ST.on===false&&ST.q.length==0"))
            state['off']=0; await pg.evaluate("localStorage.removeItem('bp_st_off');ST.on=true")
            # admin UI
            await pg.evaluate("S.me='adm';S.pw='x';S.role='admin';S.pm=['all'];S.pnl=1;S.tab=4;S.v=null;S.at='st'"); await pg.evaluate("render()"); await pg.wait_for_timeout(900)
            html=await pg.evaluate("document.querySelector('#scr').innerText")
            chk('%d tab visible, summary shows'%w, 'نتیجه‌گیری' in html)
            chk('%d stats reachable from settings hub'%w, await pg.evaluate("SETSEC.some(x=>x.g=='st')"))
            for sub,needle in (('hr','میانگین استفاده در هر ساعت'),('sc','استفاده از بخش‌ها'),('bo','غرفه‌ی تست'),('dl','پرحجم‌ترین'),('me','آمار امروز همین گوشی'),('cf','جمع‌آوری آمار'),('sum','نتیجه‌گیری')):
                await pg.evaluate("STV.sub='%s';render()"%sub); await pg.wait_for_timeout(500)
                t=await pg.evaluate("document.querySelector('#scr').innerText")
                chk('%d sub %s renders'%(w,sub), needle in t)
                chk('%d sub %s no overflow'%(w,sub), not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
            await pg.evaluate("STV.sub='sc';STV.rng=14;STV.d=null;STV.t=0;render()"); await pg.wait_for_timeout(700)
            chk('%d range change reloads'%w, await pg.evaluate("STV.d&&STV.d.days==14"))
            await pg.evaluate("S.pm=['p'];S.at='x';render()")
            chk('%d non-main admin: no stats tab'%w, '📡' not in await pg.evaluate("document.querySelector('#scr').innerText"))
            chk('%d old meter still renders'%w, 'شمارنده' in await pg.evaluate("nmCard()"))
            chk('%d no errors %s'%(w,errs), not errs)
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
