# تست 1.9.193: لوگوی سردر از حافظه (L1)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.new('RGBA',(900,300),(200,98,42,255)).save('/home/claude/w/tmp/l.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2000)
        chk(f'{w}: funcs',pg.evaluate("typeof lgSheet=='function'&&typeof lgPick=='function'&&typeof lgCu=='function'"))
        chk(f'{w}: non-admin lgSetN no-op',pg.evaluate("(()=>{lgSetN('lgc_x',5);return !(D.cms.BR&&D.cms.BR.cu)})()"))
        chk(f'{w}: default logo kept',pg.evaluate("hnBrand().indexOf('class=\"lb\"')>0"))
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();lgSheet()})()");pg.wait_for_timeout(200)
        with pg.expect_file_chooser() as fc: pg.click('[data-a=lgp]')
        fc.value.set_files('/home/claude/w/tmp/l.png');pg.wait_for_timeout(900)
        chk(f'{w}: cu saved small',pg.evaluate("!!(D.cms.BR&&D.cms.BR.cu&&D.cms.BR.cu.u.length<40000&&D.cms.BR.cu.u.indexOf('data:image/webp')==0)"))
        chk(f'{w}: custom img rendered',pg.evaluate("hnBrand().indexOf('lbx cu')>0&&hnBrand().indexOf('class=\"lb\"')<0"))
        chk(f'{w}: sliders shown',pg.locator('#lgc_x').count()==1 and pg.locator('#lgc_s').count()==1)
        pg.evaluate("(()=>{const e=document.getElementById('lgc_x');e.value=40;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        chk(f'{w}: x saved',pg.evaluate("D.cms.BR.cu.x==40"))
        pg.evaluate("(()=>{const e=document.getElementById('lgc_s');e.value=150;e.dispatchEvent(new Event('change',{bubbles:true}))})()")
        chk(f'{w}: size saved',pg.evaluate("D.cms.BR.cu.s==1.5"))
        chk(f'{w}: bad data rejected',pg.evaluate("(()=>{const o=D.cms.BR.cu.u;D.cms.BR.cu.u='javascript:x';const r=lgCu()===null;D.cms.BR.cu.u=o;return r})()"))
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.click('[data-a=lgx]');pg.wait_for_timeout(200)
        chk(f'{w}: reset to original',pg.evaluate("!D.cms.BR.cu&&hnBrand().indexOf('class=\"lb\"')>0"))
        ctx.close()
    br.close()
print('ERRORS',errs)
