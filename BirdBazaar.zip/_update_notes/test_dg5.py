# تست 1.9.505 DG5: سفارش‌های من
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        L=[{'id':i,'st':('new' if i%3==0 else 'done' if i%3==1 else 'x'),'it':[{'id':1,'n':'کالای %d'%i,'q':2}],'tt':1000*i,'dt':'1405/09/0%d'%(i%9+1)} for i in range(1,31)]
        pg.evaluate("S.me='u1';MO.l=%s;MO.ld=0;MO.er='';S.v='mo';render()"%json.dumps(L,ensure_ascii=False));pg.wait_for_timeout(300)
        chk(t+'4 tabs with counters',pg.evaluate("document.querySelectorAll('.bzot .chip').length==4&&document.querySelector('.bzot .chip.on').textContent.includes('۱۰')"))
        chk(t+'current tab shows 10 cards',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==10"))
        pg.locator('[data-a=mot][data-v=d]').dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'done tab ok',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==10&&MOT=='d'"))
        pg.evaluate("MOT='c';MO.l=MO.l.map(o=>Object.assign(o,{st:'new'}));render()")
        chk(t+'paging 20 then more',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==20&&!!document.querySelector('[data-a=mopm]')"))
        pg.locator('[data-a=mopm]').dispatch_event('click');pg.wait_for_timeout(150)
        chk(t+'all 30 after more',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==30&&!document.querySelector('[data-a=mopm]')"))
        pg.fill('#mos','کالای 7');pg.wait_for_timeout(200)
        chk(t+'search filters',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==1"))
        pg.fill('#mos','zzz');pg.wait_for_timeout(200)
        chk(t+'search empty state',pg.evaluate("document.querySelectorAll('#mol .bzoc').length==0&&document.getElementById('mol').textContent.includes('پیدا نشد')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("MOQ='';MON=20;MOT='c';MO.l=MO.l.slice(0,3);render()")
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';window.scrollTo(0,0)");pg.screenshot(path='/tmp/claude-0/p/dg5_360.png')
        pg.evaluate("MO.l=[];render()")
        chk(t+'no orders: empty state',pg.evaluate("document.getElementById('scr').textContent.includes('هنوز سفارشی نداری')"))
        ctx.close()
    br.close()
print('ERRS',errs)
