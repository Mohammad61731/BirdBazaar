# تست 1.9.246 AN16 AN17 AN18
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        n=await pg.evaluate("document.querySelectorAll('#bns .bn').length"); chk('banners (%d)'%n,n>=2)
        await pg.evaluate("const e=document.getElementById('bns');e.scrollTo({left:-(e.clientWidth+10),behavior:'instant'})"); await pg.wait_for_timeout(400)
        chk('active slide marked',await pg.evaluate("document.querySelectorAll('#bns .bn.act').length==1&&document.querySelectorAll('#bns .bn')[1].classList.contains('act')"))
        chk('dot follows',await pg.evaluate("document.querySelectorAll('.dots i')[1].classList.contains('on')"))
        chk('chips/qa render',await pg.evaluate("document.querySelectorAll('#scr .hqa .qa,#scr .chips .chip').length>0"))
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
