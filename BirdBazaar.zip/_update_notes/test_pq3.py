# تست 1.9.409 G4-c2: قفل پیک تا تأیید پرداخت ، مرحله‌ی پیک برای خریدار ، لغو بعد از مهلت (کلید pq)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;XF.cd=1;XF.cg=1;XF.pq=1;XF.cp=1;XF.cr=1")
        if not pg.evaluate("pqOn()"):
            print('SKIP pqOn false');ctx.close();continue
        chk(t+'buyer sees courier stage+code',pg.evaluate("(()=>{PQS={id:5,total:1000,card:{n:'6037997700000000',h:'x'},pay:{s:'ok',f:'prep'},cr:{s:'acc',o:'4821'}};let H='';const o0=sheet;sheet=x=>{H=x};pqSheet();sheet=o0;return H.includes('پیک پذیرفت')&&H.includes('4821')})()"))
        chk(t+'no code when not ok',pg.evaluate("(()=>{PQS={id:5,total:1000,card:{n:'6037997700000000',h:'x'},pay:{s:'sent',rc:'1'},cr:null};let H='';const o0=sheet;sheet=x=>{H=x};pqSheet();sheet=o0;return H.length>20&&!H.includes('کد تحویل شما')})()"))
        chk(t+'late unpaid -> cancel button',pg.evaluate("(()=>{CDQ={n:'6037997700000000',h:'x',l:1};return pqOwnH({id:7,s:'new',t:new Date(Date.now()-30*36e5).toISOString()}).includes('data-a=\"pqcx\"')})()"))
        chk(t+'fresh unpaid -> no cancel',pg.evaluate("!pqOwnH({id:7,s:'new',t:new Date().toISOString()}).includes('pqcx')"))
        chk(t+'late but paid ok -> no cancel',pg.evaluate("!pqOwnH({id:7,s:'new',pay:{s:'ok'},t:new Date(Date.now()-30*36e5).toISOString()}).includes('pqcx')"))
        chk(t+'late but sent -> no cancel',pg.evaluate("!pqOwnH({id:7,s:'new',pay:{s:'sent',rc:'1'},t:new Date(Date.now()-30*36e5).toISOString()}).includes('pqcx')"))
        chk(t+'courier locked before pay ok',pg.evaluate("(()=>{BM=BM||{};BM.booth=BM.booth||{id:1};try{cgVer=()=>true}catch(e){}return crOwnH({id:9,s:'new',pay:{s:'sent',rc:'1'}}).includes('🔒')&&!crOwnH({id:9,s:'new',pay:{s:'sent',rc:'1'}}).includes('bt_crr')})()"))
        chk(t+'courier open after pay ok',pg.evaluate("crOwnH({id:9,s:'new',pay:{s:'ok',f:'prep'}}).includes('bt_crr')"))
        chk(t+'courier open when no pay',pg.evaluate("crOwnH({id:9,s:'new'}).includes('bt_crr')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
