# تست 1.9.269 P85: پیش‌نمایش زنده‌ی ثبت آگهی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1500)
        pg.evaluate("S.role='user';S.me='u1';S.pw='p';localStorage.removeItem('bp_addr_u1');ADSTEP=1;go({tab:2,v:null,sub:1})");pg.wait_for_timeout(400)
        chk(f'{w}: preview exists',pg.locator('#adpv .adpb').count()==1)
        pg.fill('#at','قناری زرد');pg.wait_for_timeout(100)
        chk(f'{w}: title live',pg.inner_text('#adpv b')=='قناری زرد')
        pg.evaluate("document.querySelector('[data-a=adst][data-v=\"2\"]').click()");pg.wait_for_timeout(200)
        pg.fill('#ap','500000');pg.fill('#acity','شیراز');pg.wait_for_timeout(100)
        t=pg.inner_text('#adpv')
        chk(f'{w}: price+city live','۵۰۰٬۰۰۰' in t or '۵۰۰,۰۰۰' in t or '۵۰۰' in t)
        chk(f'{w}: city live','شیراز' in t)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/ad4_360.png')
        ctx.close()
print('ERRORS',errs)
