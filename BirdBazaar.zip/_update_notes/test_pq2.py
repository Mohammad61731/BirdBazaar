# تست 1.9.408 G4-c1: مرحله‌ی آماده‌سازی بعد از تأیید پرداخت (کلید pq)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=1;XF.cd=1;XF.cg=1;XF.pq=1")
        if not pg.evaluate("pqOn()"):
            print('SKIP pqOn false');ctx.close();continue
        chk(t+'ok no stage -> prep button',pg.evaluate("pqOwnH({id:5,s:'new',pay:{s:'ok'}}).includes('data-a=\"pqpr\"')"))
        chk(t+'prep -> text no button',pg.evaluate("(()=>{const h=pqOwnH({id:5,s:'new',pay:{s:'ok',f:'prep'}});return h.includes('آماده‌سازی')&&!h.includes('pqpr')})()"))
        chk(t+'sent has no prep button',pg.evaluate("!pqOwnH({id:5,s:'new',pay:{s:'sent',rc:'123'}}).includes('pqpr')"))
        chk(t+'buyer sees stage',pg.evaluate("(()=>{PQS={id:5,total:1000,card:{n:'6037997700000000',h:'x'},pay:{s:'ok',f:'prep'}};pqSheet();return document.body.innerHTML.includes('در حال آماده‌سازی')})()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
