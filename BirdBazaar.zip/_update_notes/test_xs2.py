# تست 1.9.329: استودیو T1-b کارت و آیکن (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;render()");pg.wait_for_timeout(400)
            chk(t+'off: no button',pg.locator('[data-a=stg]').count()==0)
            pg.evaluate("XF.xs=1;render()");pg.wait_for_timeout(300)
            chk(t+'on: button',pg.locator('[data-a=stg]').count()==1)
            pg.evaluate("sgSheet()");pg.wait_for_timeout(300)
            chk(t+'sheet ranges',pg.locator('#ov input[data-sg]').count()>=5)
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            pg.evaluate("(()=>{const r=document.querySelector('#ov [data-sg=\"i.is\"]');r.value=60;r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))})()")
            pg.evaluate("document.querySelector('#ov [data-sgc=\"c.tl:2\"]').click()");pg.wait_for_timeout(200)
            pg.evaluate("document.querySelector('#ov [data-sgc=\"c.hp:1\"]').click()");pg.wait_for_timeout(200)
            st=pg.evaluate("D.cms.ST")
            chk(t+'saved',st.get('gicon',{}).get('is')==60 and st.get('gcard',{}).get('tl')==2 and st.get('gcard',{}).get('hp')==1)
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'css has size+clamp+hide','60px' in css and 'line-clamp:2' in css and '.pr' in css)
            pg.evaluate("XF.xs=0;render()");pg.wait_for_timeout(200)
            chk(t+'xs off clears css',pg.evaluate("document.getElementById('stg').textContent")=='')
            pg.evaluate("XF.xs=1;sgSheet()");pg.evaluate("document.querySelector('#ov [data-sgc=\"reset:1\"]').click()");pg.wait_for_timeout(200)
            chk(t+'reset',pg.evaluate("!D.cms.ST.gcard&&!D.cms.ST.gicon"))
            ctx.close()
    br.close()
print('ERRORS',errs)
