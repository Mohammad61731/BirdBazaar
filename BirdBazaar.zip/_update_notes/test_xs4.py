# تست 1.9.331: استودیو T1-d حرکت ورود/جهت/سرعت/تأخیر/تپش (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(120)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0,\"an\":1}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render();sgSheet()");pg.wait_for_timeout(300)
            chk(t+'default css has no xsea',pg.evaluate("!document.getElementById('stg')||!document.getElementById('stg').textContent.includes('xsea')"))
            clk(pg,'#ov [data-sgc="x.ea:2"]');clk(pg,'#ov [data-sgc="x.ed:2"]');clk(pg,'#ov [data-sgc="x.el:1"]')
            fire(pg,'#ov [data-sg="x.es"]',700);fire(pg,'#ov [data-sg="x.eg"]',60)
            clk(pg,'#ov [data-sgc="x.pl:1"]');clk(pg,'#ov [data-sgc="x.pt:1"]')
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'css entrance',('@keyframes xsea' in css) and ('translateX(24px)' in css) and ('animation:xsea 700ms ease-out backwards' in css))
            chk(t+'css stagger',('nth-child(3){animation-delay:120ms}' in css) and ('nth-child(n+9){animation-delay:420ms}' in css))
            chk(t+'css pulse',('@keyframes xspl' in css) and ('.add:not(.pop){animation:xspl 1.6s' in css))
            chk(t+'saved gx',pg.evaluate("D.cms.ST.gx.ea==2&&D.cms.ST.gx.ed==2&&D.cms.ST.gx.es==700&&D.cms.ST.gx.eg==60&&D.cms.ST.gx.pl==1&&D.cms.ST.gx.pt==1"))
            clk(pg,'#ov [data-sgc="x.pl:2"]');clk(pg,'#ov [data-sgc="x.pt:0"]');clk(pg,'#ov [data-sgc="x.ea:4"]')
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'css glow+spring',('xsgl 1.6s' in css) and ('.pc .bd{animation' in css) and ('cubic-bezier(.34,1.56,.64,1)' in css))
            clk(pg,'#ov [data-sgc="x.nm:1"]')
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'motion off wins',('animation:none!important' in css) and css.rfind('animation:none!important')>css.rfind('xsgl 1.6s'))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            chk(t+'sheet no h-scroll',pg.evaluate("(()=>{const s=document.querySelector('#ov .sheet');return !s||s.scrollWidth<=s.clientWidth+1})()"))
            clk(pg,'#ov [data-sgc="x.nm:0"]');clk(pg,'#ov [data-sgc="x.ea:0"]');clk(pg,'#ov [data-sgc="x.pl:0"]')
            css=pg.evaluate("document.getElementById('stg').textContent")
            chk(t+'back to none',('xsea' not in css) and ('xspl' not in css))
            if w==360 and not dark:
                clk(pg,'#ov [data-sgc="x.ea:2"]');clk(pg,'#ov [data-sgc="x.pl:1"]')
                pg.evaluate("document.querySelector('#ov .sheet').scrollTop=99999");pg.wait_for_timeout(200)
                pg.screenshot(path='/tmp/xs4_sheet.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
