# تست 1.9.115: ردیاب عکس‌های سنگین — پیش‌فرض خاموش ؛ مرتب‌سازی ؛ نام ؛ بدون درخواست
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        reqs=[]
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            reqs.append(route.request.url)
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1200)
        chk('default off', await pg.evaluate("tlOn('hv')")==False and await pg.evaluate("tlHv()")=='')
        await pg.evaluate("""(async()=>{D.products=[{id:1,name:'گل‌سرخ'}];D.ads=[{id:2,title:'قناری'}];await idbSet('IM:p:1',{thk:'1',img:'x'.repeat(900000),imgs:[]});await idbSet('IM:a:2',{thk:'1',img:'x'.repeat(100000),imgs:[]});await idbSet('IM:b:7',{thk:'1',img:'x'.repeat(500000),imgs:[]});tlSet('hv',1);const d=document.createElement('div');d.id='hv_st';document.body.appendChild(d)})()""")
        n0=len(reqs)
        await pg.evaluate("hvShow()"); await pg.wait_for_timeout(500)
        t=await pg.evaluate("document.getElementById('hv_st').innerText")
        chk('shows product name', 'گل‌سرخ' in t)
        chk('shows ad name', 'قناری' in t)
        chk('booth fallback name', 'غرفه' in t and '7' in t.replace('۷','7'))
        chk('heavy marker for 2 items', t.count('🔴')==2)
        chk('sorted: product first', t.index('گل‌سرخ')<t.index('قناری'))
        chk('no new request', len(reqs)==n0)
        chk('tlHv has button', 'hv_run' in await pg.evaluate("tlHv()"))
        chk('tlSec has row', 'ردیاب عکس‌های سنگین' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
