# تست مورد ۶: «لینک دلخواه» در لیست لینک مقصد (linkSel) + ایمنی (فقط http/https و کدهای داخلی)
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
SHOT = len(sys.argv) > 2
NORM = [('https://ble.ir/abc?x=1&y=2','url:https://ble.ir/abc?x=1&y=2'),('http://a.com','url:http://a.com'),
 ('url:https://a.com','url:https://a.com'),('  https://a.com/x  ','url:https://a.com/x'),
 ('home:hero','home:hero'),('tab:1','tab:1'),('guides','guides'),('cat:پرندگان زینتی','cat:پرندگان زینتی'),
 ('javascript:alert(1)',''),('JAVASCRIPT:alert(1)',''),('url:javascript:alert(1)',''),('data:text/html,<b>x</b>',''),
 ('ftp://a.com',''),('https://a b.com',''),('<script>alert(1)</script>',''),('foo:bar',''),('',''),('https://a.com/"x',''),("https://a.com/'x",'')]
async def main():
    ok=True; fails=[]
    def chk(name,cond):
        nonlocal ok
        if not cond: ok=False; fails.append(name)
        print(('OK  ' if cond else 'FAIL'),name)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            pg=await b.new_page(viewport={'width':w,'height':740})
            await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
            errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(600)
            if w==360:
                have=await pg.evaluate("typeof lkNorm")
                chk('lkNorm exists',have=='function')
                if have!='function':
                    await b.close(); print('FAIL (feature missing)'); sys.exit(1)
                for raw,exp in NORM:
                    got=await pg.evaluate("(x)=>lkNorm(x)",raw); chk('lkNorm(%r)'%raw[:28],got==exp)
                # openLink safety
                r=await pg.evaluate("""()=>{const calls=[];const o=window.open;window.open=(u)=>{calls.push(u)};
                  openLink('url:https://ble.ir/x');openLink('url:javascript:alert(1)');openLink('url:data:text/html,hi');openLink('url:http://a.com');
                  window.open=o;return calls}""")
                chk('openLink opens only http(s)',r==['https://ble.ir/x','http://a.com'])
            # linkSel UI
            h=await pg.evaluate("""()=>{document.getElementById('tt')?.remove();window.__t='init';
              document.body.insertAdjacentHTML('beforeend','<div id="tt" style="position:fixed;left:0;right:0;top:0;z-index:99999;box-sizing:border-box;padding:14px;background:var(--bg,#fff)">'
               +'<label class="fld2">🔗 لینک مقصد '+linkSel('', 'window.__t=this.value')+'</label></div>');
              const s=document.querySelector('#tt select');return {n:s.options.length,last:s.options[s.options.length-1].value,
               inpVis:getComputedStyle(document.querySelector('#tt .lkc')).display}}""")
            chk('[%d] last option is custom & input hidden'%w,h['last']=='__c' and h['inpVis']=='none')
            await pg.select_option('#tt select','__c')
            vis=await pg.evaluate("getComputedStyle(document.querySelector('#tt .lkc')).display")
            chk('[%d] input shows after choosing custom'%w,vis=='block')
            await pg.fill('#tt .lkc','https://ble.ir/mychannel')
            chk('[%d] typed url stored as url:'%w,await pg.evaluate("window.__t")=='url:https://ble.ir/mychannel')
            await pg.fill('#tt .lkc','javascript:alert(1)')
            chk('[%d] bad link rejected + hint shown'%w,(await pg.evaluate("window.__t"))=='' and await pg.evaluate("getComputedStyle(document.querySelector('#tt .lkh')).display")=='block')
            await pg.fill('#tt .lkc','home:hero')
            chk('[%d] internal code accepted'%w,await pg.evaluate("window.__t")=='home:hero')
            if SHOT and w==360:
                await pg.fill('#tt .lkc','https://ble.ir/mychannel'); await pg.locator('#tt').screenshot(path='/home/claude/shot_lk.png')
            await pg.select_option('#tt select','tab:1')
            chk('[%d] normal option still works & input hides'%w,(await pg.evaluate("window.__t"))=='tab:1' and await pg.evaluate("getComputedStyle(document.querySelector('#tt .lkc')).display")=='none')
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth"); chk('[%d] no horizontal overflow'%w,not ov)
            # existing value rendering
            e=await pg.evaluate("""()=>{const mk=v=>{const d=document.createElement('div');d.innerHTML=linkSel(v,'window.__t=this.value');return {sel:d.querySelector('select').value,inp:d.querySelector('.lkc').value,disp:d.querySelector('.lkc').style.display}};
              return [mk('url:https://a.com/x'),mk('tab:1'),mk('')]}""")
            chk('[%d] existing url shows in custom box'%w,e[0]['inp']=='https://a.com/x' and e[0]['disp']=='block')
            chk('[%d] existing list value not custom'%w,e[1]['disp']=='none' and e[2]['disp']=='none')
            chk('[%d] no page errors'%w,errs==[])
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL: '+', '.join(fails)); sys.exit(0 if ok else 1)
asyncio.run(main())
