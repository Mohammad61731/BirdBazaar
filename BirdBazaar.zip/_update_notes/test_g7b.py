# تست 1.9.420 G7-b: ترجیح تحویل + یادآوری سبد (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0;localStorage.removeItem('bp_dlv');localStorage.removeItem('bp_cmr')")
        chk(t+'off -> nothing',pg.evaluate("pnDlTxt('g')===''&&pnDlH(1)===''&&hnCm()===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'chips shown (6)',pg.evaluate("(pnDlH(1).match(/<button/g)||[]).length==6"))
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(200)
        click('pndl')
        chk(t+'door on -> text',pg.evaluate("pnDl().d==1&&pnDlTxt('g').includes('دم در')&&!pnDlTxt('p').includes('دم در')&&pnDlTxt('h')===''"))
        pg.evaluate("localStorage.setItem('bp_dlv',JSON.stringify({d:1,q:{f:22,t:8}}))")
        chk(t+'quiet text',pg.evaluate("pnDlTxt('g').includes('ساعت آرام')&&pnDlTxt('g').includes('۲۲')&&pnDl().q.t==8"))
        pg.evaluate("localStorage.setItem('bp_dlv',JSON.stringify({d:0,q:{f:5,t:5}}))")
        chk(t+'bad quiet ignored',pg.evaluate("pnDl().q===null&&pnDlTxt('g')===''"))
        click('pndl');click('pndl')
        chk(t+'toggle twice -> off',pg.evaluate("pnDl().d==0"))
        # reminder
        pg.evaluate("BC=[{p:1,m:'r',q:1}];localStorage.removeItem('bp_cmr')")
        chk(t+'first view starts timer, no card',pg.evaluate("hnCm()===''&&pnCmG().n==1"))
        chk(t+'under 3h no card',pg.evaluate("hnCm()===''"))
        pg.evaluate("pnCmS({n:1,t:Date.now()-4*36e5,h:0})")
        chk(t+'after 3h card',pg.evaluate("hnCm().includes('سبدت هنوز ثبت نشده')&&hnCm().includes('bt_cart')"))
        click('pncmx')
        chk(t+'dismiss hides',pg.evaluate("hnCm()===''&&pnCmG().h>Date.now()"))
        pg.evaluate("pnCmS({n:1,t:Date.now()-4*36e5,h:0});BC=[{p:1,m:'r',q:1},{p:2,m:'r',q:1}]")
        chk(t+'cart changed resets timer',pg.evaluate("hnCm()===''&&pnCmG().n==2"))
        pg.evaluate("BC=[]")
        chk(t+'empty cart clears',pg.evaluate("hnCm()===''&&!pnCmG().n"))
        chk(t+'home block registered',pg.evaluate("typeof BLK.cm=='function'&&BLN.cm&&HNEW.cm=='srch'"))
        pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(300)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
