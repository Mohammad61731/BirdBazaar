# تست 1.9.201: افزودن آیکن از گوشی (IC5)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
from PIL import Image
import os
os.makedirs('/home/claude/w/tmp',exist_ok=True)
Image.effect_mandelbrot((900,600),(-2,-1.5,1,1.5),60).convert('RGBA').save('/home/claude/w/tmp/i5.png')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        chk(f'{w}: funcs',pg.evaluate("typeof icAdd=='function'&&typeof icLoad=='function'"))
        pg.evaluate("icAdd('nav.home')");pg.wait_for_timeout(200)
        chk(f'{w}: non-admin no-op',pg.evaluate("Object.keys(ikLib).length")==0)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove();icPick('nav.home')})()");pg.wait_for_timeout(300)
        chk(f'{w}: add button',pg.locator('[data-a=ica]').count()==1)
        with pg.expect_file_chooser() as fc: pg.click('[data-a=ica]')
        fc.value.set_files('/home/claude/w/tmp/i5.png');pg.wait_for_timeout(1200)
        n=pg.evaluate("Object.keys(ikLib).length")
        chk(f'{w}: added one',n==1)
        chk(f'{w}: small webp',pg.evaluate("(()=>{const e=Object.values(ikLib)[0];return !!e&&e.u.indexOf('data:image/webp')==0&&e.u.length<=7000})()"))
        chk(f'{w}: shown in picker',pg.locator('[data-a=ick] img.ic').count()==1)
        chk(f'{w}: saved in idb',pg.evaluate("idbGet('ICLIB').then(v=>!!v&&Object.keys(v).length==1)"))
        pg.reload();pg.wait_for_timeout(1500)
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
        pg.evaluate("icLoad().then(()=>{window.__n=Object.keys(ikLib).length})");pg.wait_for_timeout(500)
        chk(f'{w}: survives reload',pg.evaluate("window.__n")==1)
    br.close()
print('ERRORS',errs)
