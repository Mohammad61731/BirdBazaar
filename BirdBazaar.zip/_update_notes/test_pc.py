# تست 1.9.137: مقایسه‌ی قیمت غرفه‌ها pc
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def B(i,n):return {'id':i,'owner':'o%d'%i,'pw':'1','name':n,'bio':'','logo':'','cover':'','city':'سراوان','phone':'0912','status':'active','views':1}
DB['booths']=[B(1,'غرفه علی'),B(2,'غرفه رضا'),B(3,'غرفه حسن')]
def P(i,b,n,pr,out=0):return {'id':i,'b':b,'s':'on','d':{'name':n,'type':'plain','price':pr,'unit':'kg','out':out}}
DB['prods']=[P(10,1,'ارزن سفید',100000),P(11,2,'ارزن  سفید',90000),P(12,3,'ارزن سفید',80000,1),P(13,3,'کتان',50000)]
reqs=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t='%d%s '%(w,'d' if dark else 'l')
            pg.evaluate("XF.pc=0;btFresh&&0;btNav({v:'btp',id:10})");pg.wait_for_timeout(700)
            chk(t+'off: no compare card','مقایسه‌ی قیمت غرفه‌ها' not in pg.inner_text('#scr'))
            pg.evaluate("XF.pc=1;render()");pg.wait_for_timeout(300)
            tx=pg.inner_text('#scr')
            chk(t+'on: card shown','مقایسه‌ی قیمت غرفه‌ها' in tx and 'غرفه رضا' in tx)
            chk(t+'out-of-stock booth hidden','غرفه حسن' not in tx.split('مقایسه‌ی قیمت غرفه‌ها')[-1][:200])
            chk(t+'cheapest marked',pg.evaluate("[...document.querySelectorAll('#scr .row')].some(r=>r.innerText.includes('غرفه رضا')&&r.innerText.includes('ارزان‌ترین'))"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            pg.evaluate("document.querySelector('[data-a=bt_prod][data-v=\"11\"]').click()");pg.wait_for_timeout(400)
            chk(t+'tap opens other product',pg.evaluate("String(S.id)=='11'"))
            pg.evaluate("btNav({v:'btp',id:13})");pg.wait_for_timeout(400)
            chk(t+'single product: no card','مقایسه‌ی قیمت غرفه‌ها' not in pg.inner_text('#scr'))
            ctx.close()
    br.close()
print('ERRORS',errs)
