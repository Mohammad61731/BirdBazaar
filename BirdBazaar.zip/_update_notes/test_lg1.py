# تست 1.9.281: LG1 پایه‌ی لیکویید گلس
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            chk(t+'THM has i and ice',pg.evaluate("THM.i&&THM.ice&&THM.i.includes('ساده')&&THM.ice.includes('یخی')"))
            for m,blue in (('i',None),('ice',None)):
                pg.evaluate("D.cms.TH={home:{m:'%s'}};thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(350)
                a=pg.evaluate("[document.getElementById('app').dataset.tm,document.getElementById('app').dataset.lg,getComputedStyle(document.getElementById('app')).getPropertyValue('--lg-blue').trim(),getComputedStyle(document.getElementById('app')).fontFamily]")
                chk(t+m+' attrs tm=m lg='+m,a[0]=='m' and a[1]==m)
                chk(t+m+' blue token '+a[2],a[2] in ('#007AFF','#2f8cff','#0A84FF','#5ab0ff'))
                chk(t+m+' font stack',('apple-system' in a[3]) or ('SF Pro' in a[3]) or ('system-ui' in a[3]))
                chk(t+m+' no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
                if w==360 and not dark and m=='ice': pg.screenshot(path='/tmp/lg1.png')
            pg.evaluate("D.cms.TH={home:{m:'zzz'}};thApply()")
            chk(t+'bad value falls back to m, no lg',pg.evaluate("document.getElementById('app').dataset.lg")is None and pg.evaluate("document.getElementById('app').dataset.tm")=='m')
            pg.evaluate("D.cms.TH={home:{m:'g'}};thApply()")
            chk(t+'other themes untouched (g, no lg)',pg.evaluate("document.getElementById('app').dataset.tm")=='g' and pg.evaluate("document.getElementById('app').dataset.lg")is None)
            ctx.close()
    br.close()
print('ERRORS',errs)
