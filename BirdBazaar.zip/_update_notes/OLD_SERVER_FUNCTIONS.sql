CREATE OR REPLACE FUNCTION public.app(op text, u text, p text, a jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare r jsonb;
begin
  if op !~ '^[a-z_]+$' then return '{"err":"unknown"}'; end if;
    execute format('select app_%s($1,$2,$3)',op) into r using u,p,a;
      return r;
      exception when undefined_function then return '{"err":"unknown"}';
      end
      $function$
;

CREATE OR REPLACE FUNCTION public.app_ad_add(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare n bigint; r jsonb;
begin
  if not (h_isu(u,p) or h_adm(u,p)) then return '{"err":"denied"}'; end if;
  if not h_ck(u,p,'a') then
    if coalesce((select v->>'vipOnly' from v2_kv where k='cfg'),'0') in ('1','true')
       and not exists(select 1 from users where username=u and vip) then return '{"err":"denied"}'; end if;
    r:=a||jsonb_build_object('st','pending','own',u);
  else r:=a;
  end if;
  insert into ads(d) values(r) returning id into n;
  return jsonb_build_object('id',n);
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_ad_del(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
      begin
        if not h_ck(u,p,'a') then return '{"err":"denied"}'; end if;
          delete from ads where id=(a->>'id')::bigint;
            return '{"ok":1}';
            end
            $function$
;

CREATE OR REPLACE FUNCTION public.app_ad_report(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not (h_isu(u,p) or h_adm(u,p)) then return '{"err":"denied"}'; end if;
  if not exists(select 1 from ads where id=(a->>'id')::bigint) then return '{"err":"none"}'; end if;
  insert into v2_ad_reports(ad_id,reporter) values((a->>'id')::bigint,u);
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_ad_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'a') then return '{"err":"denied"}'; end if;
    update ads set d=a->'d' where id=(a->>'id')::bigint;
      return '{"ok":1}';
      end
      $function$
;

CREATE OR REPLACE FUNCTION public.app_ads_all(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
        select case when h_ck(u,p,'a') then coalesce((select jsonb_agg(d||jsonb_build_object('id',id) order by id desc) from ads),'[]'::jsonb) else '{"err":"denied"}'::jsonb end
        $function$
;

CREATE OR REPLACE FUNCTION public.app_ads_mine(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select case when h_isu(u,p) then coalesce((select jsonb_agg(d||jsonb_build_object('id',id) order by id desc) from ads where d->>'own'=u),'[]'::jsonb) else '[]'::jsonb end
$function$
;

CREATE OR REPLACE FUNCTION public.app_cfg_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'all') then return '{"err":"denied"}'; end if;
  insert into v2_kv(k,v,updated_at) values('cfg',coalesce(a->'cfg','{}'::jsonb),now()) on conflict(k) do update set v=excluded.v,updated_at=now();
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_change(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare w text:=coalesce(a->>'np','');
begin
  if not (h_isu(u,p) or h_adm(u,p)) then return '{"err":"denied"}'; end if;
  if length(coalesce(a->>'nu',''))<3 or (w<>'' and length(w)<4) then return '{"err":"bad"}'; end if;
  if a->>'nu'<>u and (exists(select 1 from users where username=a->>'nu') or exists(select 1 from staff where username=a->>'nu')) then return '{"err":"dup"}'; end if;
  if h_adm(u,p) then
    update staff set username=a->>'nu', pass=case when w<>'' then crypt(w,gen_salt('bf')) else pass end where username=u;
  else
    update users set username=a->>'nu', pass=case when w<>'' then crypt(w,gen_salt('bf')) else pass end where username=u;
    update ads set d=jsonb_set(d,'{own}',to_jsonb(a->>'nu')) where d->>'own'=u;
    update users set invited_by=a->>'nu' where invited_by=u;
  end if;
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_cms_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'br') then return '{"err":"denied"}'; end if;
  insert into v2_kv(k,v,updated_at) values('cms',coalesce(a->'cms','{}'::jsonb),now()) on conflict(k) do update set v=excluded.v,updated_at=now();
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_guides_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'g') then return '{"err":"denied"}'; end if;
  insert into v2_kv(k,v,updated_at) values('guides',coalesce(a->'rows','[]'::jsonb),now()) on conflict(k) do update set v=excluded.v,updated_at=now();
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_login(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare r jsonb;
begin
  if h_adm(u,p) then
    select jsonb_build_object('role','admin','pm',to_jsonb(perms)) into r from staff where username=u;
  elsif h_isu(u,p) then
    select jsonb_build_object('role','user','vip',x.vip,'code',x.code,'inv',(select count(*) from users y where y.invited_by=x.username)) into r from users x where x.username=u;
  end if;
  return r;
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_order_add(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
        declare n bigint;
        begin
          insert into orders(d) values(a) returning id into n;
            return jsonb_build_object('id',n);
            end
            $function$
;

CREATE OR REPLACE FUNCTION public.app_order_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
            begin
              if not h_ck(u,p,'o') then return '{"err":"denied"}'; end if;
                update orders set d=d||jsonb_build_object('st',a->>'st') where id=(a->>'id')::bigint;
                  return '{"ok":1}';
                  end
                  $function$
;

CREATE OR REPLACE FUNCTION public.app_orders(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
            select case when h_ck(u,p,'o') then coalesce((select jsonb_agg(d||jsonb_build_object('id',id) order by id desc) from orders),'[]'::jsonb) else '{"err":"denied"}'::jsonb end
            $function$
;

CREATE OR REPLACE FUNCTION public.app_ping(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
            with x as (update users set last_seen=now() where username=u and pass=crypt(p,pass) returning 1) select '{"ok":1}'::jsonb
            $function$
;

CREATE OR REPLACE FUNCTION public.app_products_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'p') then return '{"err":"denied"}'; end if;
    delete from products where true;
      insert into products(id,d) select (e->>'id')::bigint,e from jsonb_array_elements(a->'rows') e;
        return '{"ok":1}';
        end
        $function$
;

CREATE OR REPLACE FUNCTION public.app_public(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select jsonb_build_object(
 'products',coalesce((select jsonb_agg(d order by id) from products),'[]'::jsonb),
 'stories',coalesce((select jsonb_agg(d order by id) from stories),'[]'::jsonb),
 'ads',coalesce((select jsonb_agg(d||jsonb_build_object('id',id) order by id desc) from ads where d->>'st'='ok'),'[]'::jsonb),
 'cms',coalesce((select v from v2_kv where k='cms'),'{}'::jsonb),
 'cfg',coalesce((select v from v2_kv where k='cfg'),'{}'::jsonb),
 'guides',coalesce((select v from v2_kv where k='guides'),'[]'::jsonb))
$function$
;

CREATE OR REPLACE FUNCTION public.app_register(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare ref text:=upper(trim(coalesce(a->>'ref',''))); inv text; c int; need int;
begin
  if length(coalesce(u,''))<3 or length(coalesce(p,''))<4 then return '{"err":"bad"}'; end if;
  if exists(select 1 from users where username=u) or exists(select 1 from staff where username=u) then return '{"err":"dup"}'; end if;
  if ref<>'' then select username into inv from users where code=ref; end if;
  insert into users(username,pass,last_seen,code,invited_by)
  values(u,crypt(p,gen_salt('bf')),now(),'BIRD-'||upper(substr(md5(u||random()::text),1,6)),inv);
  if inv is not null then
    select count(*) into c from users where invited_by=inv;
    need:=coalesce((select (v->>'inv')::int from v2_kv where k='cfg'),2);
    if c>=need then update users set vip=true where username=inv; end if;
  end if;
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_staff_add(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'all') then return '{"err":"denied"}'; end if;
  if length(coalesce(a->>'u',''))<3 or length(coalesce(a->>'p',''))<4 then return '{"err":"bad"}'; end if;
  if exists(select 1 from users where username=a->>'u') or exists(select 1 from staff where username=a->>'u') then return '{"err":"dup"}'; end if;
  insert into staff(username,pass,perms) values(a->>'u',crypt(a->>'p',gen_salt('bf')),array(select x from jsonb_array_elements_text(a->'pm') x where x in ('p','a','s','o','g','u','br','nt','eo')));
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_staff_del(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'all') then return '{"err":"denied"}'; end if;
    delete from staff where username=a->>'u' and not ('all'=any(perms));
      return '{"ok":1}';
      end
      $function$
;

CREATE OR REPLACE FUNCTION public.app_staff_list(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select case when h_ck(u,p,'all') then coalesce((select jsonb_agg(jsonb_build_object('u',username,'pm',to_jsonb(perms)) order by username) from staff),'[]'::jsonb) else '{"err":"denied"}'::jsonb end
$function$
;

CREATE OR REPLACE FUNCTION public.app_stats(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
                select case when h_ck(u,p,'all') then jsonb_build_object('m',(select count(*) from users),'on',(select count(*) from users where last_seen>now()-interval '3 minutes'),'n',(select count(*) from orders),'t',coalesce((select sum((d->>'tt')::numeric) from orders where d->>'st'<>'x'),0)) else '{"err":"denied"}'::jsonb end
                $function$
;

CREATE OR REPLACE FUNCTION public.app_stories_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
        begin
          if not h_ck(u,p,'s') then return '{"err":"denied"}'; end if;
            delete from stories where true;
              insert into stories(id,d) select (e->>'id')::bigint,e from jsonb_array_elements(a->'rows') e;
                return '{"ok":1}';
                end
                $function$
;

CREATE OR REPLACE FUNCTION public.app_user_set(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
begin
  if not h_ck(u,p,'u') then return '{"err":"denied"}'; end if;
  update users set vip=((a->>'vip')::int=1) where username=a->>'u';
  return '{"ok":1}';
end
$function$
;

CREATE OR REPLACE FUNCTION public.app_users(u text, p text, a jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select case when h_ck(u,p,'u') then coalesce((select jsonb_agg(jsonb_build_object('u',username,'vip',vip) order by username) from users),'[]'::jsonb) else '{"err":"denied"}'::jsonb end
$function$
;

CREATE OR REPLACE FUNCTION public.h_adm(u text, p text)
 RETURNS boolean
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select exists(select 1 from staff where username=u and pass=crypt(p,pass))
$function$
;

CREATE OR REPLACE FUNCTION public.h_ck(u text, p text, k text)
 RETURNS boolean
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select exists(select 1 from staff where username=u and pass=crypt(p,pass) and (k=any(perms) or 'all'=any(perms)))
$function$
;

CREATE OR REPLACE FUNCTION public.h_isu(u text, p text)
 RETURNS boolean
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
select exists(select 1 from users where username=u and pass=crypt(p,pass))
$function$
;

-- TRIGGERS
CREATE TRIGGER f_push_msg AFTER INSERT ON public.m_msgs FOR EACH ROW EXECUTE FUNCTION f_trg_msg();
CREATE TRIGGER f_push_order AFTER INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION f_trg_order();
CREATE TRIGGER f_push_border AFTER INSERT ON public.booth_orders FOR EACH ROW EXECUTE FUNCTION f_trg_border();
CREATE TRIGGER f_push_chat AFTER INSERT ON public.c_msgs FOR EACH ROW EXECUTE FUNCTION f_trg_chat();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.products FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.ads FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.stories FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.v2_kv FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.booth_products FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.booth_birds FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.bcfg FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_t AFTER INSERT OR DELETE OR TRUNCATE ON public.booths FOR EACH STATEMENT EXECUTE FUNCTION f_bump();
CREATE TRIGGER f_bump_u AFTER UPDATE OF name, bio, logo, cover, city, phone, status, owner, pw ON public.booths FOR EACH STATEMENT EXECUTE FUNCTION f_bump();

-- INDEXES
CREATE UNIQUE INDEX staff_pkey ON public.staff USING btree (username);
CREATE UNIQUE INDEX orders_pkey ON public.orders USING btree (id);
CREATE UNIQUE INDEX products_pkey ON public.products USING btree (id);
CREATE UNIQUE INDEX users_pkey ON public.users USING btree (username);
CREATE UNIQUE INDEX users_code_uq ON public.users USING btree (code);
CREATE UNIQUE INDEX ads_pkey ON public.ads USING btree (id);
CREATE UNIQUE INDEX v2_ad_reports_pkey ON public.v2_ad_reports USING btree (id);
CREATE UNIQUE INDEX stories_pkey ON public.stories USING btree (id);
CREATE UNIQUE INDEX v2_kv_pkey ON public.v2_kv USING btree (k);
CREATE UNIQUE INDEX booths_pkey ON public.booths USING btree (id);
CREATE UNIQUE INDEX booths_owner_key ON public.booths USING btree (owner);
CREATE UNIQUE INDEX booth_products_pkey ON public.booth_products USING btree (id);
CREATE UNIQUE INDEX booth_views_pkey ON public.booth_views USING btree (booth_id, day);
CREATE UNIQUE INDEX booth_reqs_pkey ON public.booth_reqs USING btree (id);
CREATE UNIQUE INDEX booth_orders_pkey ON public.booth_orders USING btree (id);
CREATE UNIQUE INDEX bcfg_pkey ON public.bcfg USING btree (k);
CREATE UNIQUE INDEX f_rooms_pkey ON public.f_rooms USING btree (id);
CREATE UNIQUE INDEX f_msgs_pkey ON public.f_msgs USING btree (id);
CREATE INDEX f_msgs_room_id ON public.f_msgs USING btree (room, id DESC);
CREATE UNIQUE INDEX f_push_pkey ON public.f_push USING btree (token);
CREATE INDEX f_push_u ON public.f_push USING btree (uname);
CREATE UNIQUE INDEX f_faq_pkey ON public.f_faq USING btree (id);
CREATE UNIQUE INDEX f_arep_pkey ON public.f_arep USING btree (id);
CREATE UNIQUE INDEX f_arep_ad_uname_key ON public.f_arep USING btree (ad, uname);
CREATE UNIQUE INDEX m_msgs_pkey ON public.m_msgs USING btree (id);
CREATE INDEX m_msgs_to ON public.m_msgs USING btree (to_u, id DESC);
CREATE INDEX m_msgs_grp ON public.m_msgs USING btree (grp, id DESC);
CREATE UNIQUE INDEX m_read_pkey ON public.m_read USING btree (uname, msg);
CREATE UNIQUE INDEX c_msgs_pkey ON public.c_msgs USING btree (id);
CREATE INDEX c_msgs_conv ON public.c_msgs USING btree (booth_id, cu, id DESC);
CREATE INDEX c_msgs_cu ON public.c_msgs USING btree (cu, id DESC);
CREATE UNIQUE INDEX c_seen_pkey ON public.c_seen USING btree (booth_id, cu, side);
CREATE UNIQUE INDEX f_adx_pkey ON public.f_adx USING btree (ad);
CREATE UNIQUE INDEX f_perm_pkey ON public.f_perm USING btree (uname);
CREATE UNIQUE INDEX f_reqs_pkey ON public.f_reqs USING btree (id);
CREATE UNIQUE INDEX f_react_pkey ON public.f_react USING btree (msg, uname);
CREATE UNIQUE INDEX f_reports_pkey ON public.f_reports USING btree (id);
CREATE UNIQUE INDEX f_prof_pkey ON public.f_prof USING btree (uname);
CREATE UNIQUE INDEX f_conf_pkey ON public.f_conf USING btree (k);
CREATE UNIQUE INDEX booth_birds_pkey ON public.booth_birds USING btree (id);
CREATE UNIQUE INDEX app_stats_pkey ON public.app_stats USING btree (day, dev);
CREATE INDEX app_stats_day_idx ON public.app_stats USING btree (day);