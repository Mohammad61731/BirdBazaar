# تست 1.9.336: استودیو T2-d نسبت عکس/کارت ویژه/محو لبه/برچسب روی کارت (هر بخش) + آیکن‌های نوار پایین (سراسری) ؛ کلید xs
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
Q="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        b=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelector('.grid .pc,.grid .bxc'));return b?b.dataset.b:null})()")
        chk(t+'grid block',bool(b))
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        chk(t+'controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-xc$=":ir:3"]','#ov [data-xc$=":fc:1"]','#ov [data-xc$=":ef:2"]','#ov input[data-xl]')))
        clk(pg,'#ov [data-xc$=":ir:3"]');clk(pg,'#ov [data-xc$=":fc:1"]');clk(pg,'#ov [data-xc$=":ef:1"]')
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        pg.evaluate("()=>{const r=document.querySelector('#ov input[data-xl]');r.value='پرفروش <b>\"x\"';r.dispatchEvent(new Event('change',{bubbles:true}))}");pg.wait_for_timeout(200)
        st=pg.evaluate("(i)=>D.cms.ST['home:'+i]",b)
        chk(t+'saved',st and st['ir']==3 and st['fc']==1 and st['ef']==1 and st['lb']=='پرفروش bx')
        chk(t+'label sanitized',pg.evaluate("(i)=>{const l=D.cms.ST['home:'+i].lb;return !/[<>\"']/.test(l)}",b))
        chk(t+'live label',pg.evaluate("(i)=>getComputedStyle(document.querySelector('.hg .hbk[data-b=\"'+i+'\"] .grid .pc, .hg .hbk[data-b=\"'+i+'\"] .grid .bxc'),'::after').content.includes('پرفروش')",b))
        pg.evaluate("cl();render()");pg.wait_for_timeout(300)
        r=pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]'),g=e.querySelector('.grid'),f=g.firstElementChild,im=g.querySelector('.pi,.bxi'),c=getComputedStyle(im);return [c.aspectRatio,f.getBoundingClientRect().width>=g.getBoundingClientRect().width-3,(c.maskImage||c.webkitMaskImage||'').includes('radial-gradient'),getComputedStyle(g.querySelector('.pc,.bxc'),'::after').content]}",b)
        chk(t+'ratio 16/9',r[0].replace(' ','')=='16/9')
        chk(t+'featured first full',r[1])
        chk(t+'edge fade',r[2])
        chk(t+'label after render',('پرفروش' in r[3]))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        # reset
        pg.evaluate("(i)=>{stDel('home:'+i);cl();render()}",b);pg.wait_for_timeout(250)
        chk(t+'reset clears',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return !D.cms.ST['home:'+i]&&e.style.getPropertyValue('--xir')==''&&e.style.getPropertyValue('--xlb')==''&&e.style.getPropertyValue('--xef')==''}",b))
        # global nav icons
        pg.evaluate("window.SGT=2;sgSheet()");pg.wait_for_timeout(250)
        chk(t+'nav controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-sg="x.nz"]','#ov [data-sg="x.ng"]','#ov [data-sg="x.nk"]')))
        pg.evaluate("sgSetV('x','nz',30,1);sgSetV('x','ng',6,1);sgSetV('x','nk','#336699',1)");pg.wait_for_timeout(250)
        n=pg.evaluate("()=>{const b=document.querySelector('#nav button:not(.on)'),s=b.querySelector('svg'),c=getComputedStyle(s);return [c.width,getComputedStyle(b).gap,c.stroke,document.querySelector('#nav').getBoundingClientRect().width<=innerWidth]}")
        chk(t+'nav size/gap/color',n[0]=='30px' and n[1]=='6px' and n[2]=='rgb(51, 102, 153)' and n[3])
        chk(t+'no overflow nav',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("sgSetV('x','nz',22,1);sgSetV('x','ng',1,1)");pg.wait_for_timeout(200)
        chk(t+'nav defaults back',pg.evaluate("getComputedStyle(document.querySelector('#nav button svg')).width")!='30px')
        if w==360 and not dark:
            pg.evaluate("cl()");pg.evaluate("(i)=>{stSet('home:'+i,'ir',2,0);stSet('home:'+i,'fc',1,0);stSet('home:'+i,'ef',1,0);D.cms.ST['home:'+i].lb='پرفروش';cl();render()}",b);pg.wait_for_timeout(300)
            pg.evaluate("sgSetV('x','nz',28,0);sgSetV('x','nk','#8a6a55',0)")
            pg.evaluate("(i)=>{document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').scrollIntoView({block:'start'});window.scrollBy(0,-60)}",b);pg.wait_for_timeout(300)
            pg.screenshot(path='/tmp/xs9_a.png')
        ctx.close()
    br.close()
print('ERRORS',errs)
