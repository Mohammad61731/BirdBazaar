# تست 1.9.298: LG17 بازبینی: سرریز ، تعداد blur ، کنتراست متن روی شیشه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[];info=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="""(()=>{const w=innerWidth,bad=[];document.querySelectorAll('#scr *,#nav,#top').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&r.height&&getComputedStyle(e).position!='fixed'&&!e.closest('.hs,.hsn,.chips,.bn,.hzb,.stg,.gal,.galb,[style*=overflow]')&&(r.right>w+2||r.left<-2)&&!e.closest('.hs'))bad.push(e.tagName+'.'+String(e.className).slice(0,20))});let bl=0;document.querySelectorAll('body *').forEach(e=>{const s=getComputedStyle(e);if((s.backdropFilter&&s.backdropFilter!='none')||(s.webkitBackdropFilter&&s.webkitBackdropFilter!='none'))bl++});
const lum=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};
let low=[];document.querySelectorAll('#scr h2,#scr h3,#scr h4,#scr .pb,#scr .ept').forEach(e=>{const r=e.getBoundingClientRect();if(!r.width||r.top>innerHeight)return;const fg=getComputedStyle(e).color;let b=e,bg=null;while(b&&b!==document.body){const c=getComputedStyle(b).backgroundColor;const m=c.match(/[\\d.]+/g);if(m&&(m.length==3||+m[3]>.85)){bg=c;break}b=b.parentElement}if(!bg)bg=getComputedStyle(document.body).backgroundColor;const a=lum(fg),d=lum(bg),cr=(Math.max(a,d)+.05)/(Math.min(a,d)+.05);if(cr<3)low.push(e.tagName+' '+cr.toFixed(1))});return {bad:bad.slice(0,5),ov:document.documentElement.scrollWidth<=w,bl,low:low.slice(0,4)}})()"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light');pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply()"%m)
                for tab in (0,1,2,3,4):
                    t=f"{w}{'d' if dark else 'l'}{m} tab{tab} "
                    pg.evaluate("S.tab=%d;S.v=null;render()"%tab);pg.wait_for_timeout(350)
                    r=pg.evaluate(Q)
                    chk(t+'no overflow',r['ov'] and not r['bad'])
                    chk(t+'blur<=8',r['bl']<=8)
                    if r['low']: info.append(t+'lowcontrast '+str(r['low']))
                    if w==360 and not dark and m=='ice' and tab==1: pg.screenshot(path='/tmp/lg17_t1.png')
                ctx.close()
    br.close()
print('INFO',info[:12])
print('ERRORS',errs[:12])
