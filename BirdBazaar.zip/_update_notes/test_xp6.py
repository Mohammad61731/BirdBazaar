# تست 1.9.360: P3 P5 نام نمایشی و معرفی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(200)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='user';S.me='ali';S.tab=4;S.pnl=0;S.v=null;XF.xp=1;localStorage.removeItem('bp_px');render()");pg.wait_for_timeout(400)
        chk(t+'profile shows username',pg.evaluate("document.querySelector('.pcvt b').textContent=='ali'"))
        pg.wait_for_timeout(1200)
        pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend','<div id=pxs>'+pxBody()+'</div>')")
        pg.evaluate("(()=>{const i=document.querySelector('[data-px=dn]'),b=document.querySelector('[data-px=bio]');i.value='علی سفال';b.value='سفال دست‌ساز';i.dispatchEvent(new Event('input',{bubbles:true}));b.dispatchEvent(new Event('input',{bubbles:true}))})()")
        chk(t+'saved',pg.evaluate("JSON.parse(localStorage.bp_px).dn=='علی سفال'&&JSON.parse(localStorage.bp_px).bio=='سفال دست‌ساز'"))
        chk(t+'counter',pg.evaluate("/۱۲/.test(document.querySelector('[data-pxbc]').textContent)"))
        pg.evaluate("render()");pg.wait_for_timeout(300)
        chk(t+'display name shown',pg.evaluate("document.querySelector('.pcvt b').textContent=='علی سفال'&&!!document.querySelector('.pcvt .pxbio')"))
        pg.evaluate("XF.xp=0;render()");pg.wait_for_timeout(300)
        chk(t+'off: username',pg.evaluate("document.querySelector('.pcvt b').textContent=='ali'&&!document.querySelector('.pxbio')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
