# تست 1.9.356: استایل pgs پروفایل نباید روی پنل مدیریت بیفتد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.xs=1;S.role='admin';S.pm=['all'];S.ed=0;D.cms=D.cms||{};D.cms.ST={'acct:s0':{ht:80,va:3},'acct:s1':{ht:80,va:3},'acct:s2':{ht:80,va:3},'acct:s3':{ht:80,va:3}};S.tab=4;S.pnl=1;S.at='set';render()");pg.wait_for_timeout(400)
        chk(t+'panel has no pgs wrapper',pg.evaluate("!document.querySelector('#scr .pgs')"))
        chk(t+'panel cards not fixed height',pg.evaluate("![...document.querySelectorAll('#scr .card')].some(e=>e.style.height=='80px')"))
        pg.evaluate("S.pnl=0;render()");pg.wait_for_timeout(300)
        chk(t+'profile still has pgs + style',pg.evaluate("!!document.querySelector('#scr .pgs')&&!!document.querySelector('#scr .pgs>[data-sb=s0]')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
