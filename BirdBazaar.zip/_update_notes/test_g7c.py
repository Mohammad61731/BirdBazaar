# تست 1.9.421 G7-c: بخش‌بندی کلیدها + مهلت پرداخت
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'every key once in swSec',pg.evaluate("(()=>{const h=swSec();return XL.every(x=>(h.match(new RegExp('data-v=\"'+x[0]+'\"','g'))||[]).length>=1)})()"))
        chk(t+'no key duplicated across cats',pg.evaluate("(()=>{const a=[].concat(...XCAT.map(c=>c[1]));return a.length==new Set(a).size&&XL.every(x=>a.includes(x[0]))&&a.every(k=>XL.some(x=>x[0]==k))})()"))
        chk(t+'9 section boxes or 8',pg.evaluate("(()=>{const h=swXcats(XL.map(x=>[x[1],'',false,'xf_tog',x[0]]),'');return (h.match(/<div class=\"box\">/g)||[]).length==9&&h.includes('سرعت و مصرف')&&!h.includes('سایر')})()"))
        chk(t+'unknown key goes to سایر',pg.evaluate("swXcats([['t','',false,'xf_tog','zzq']],'').includes('سایر')"))
        pg.evaluate("XF.pn=1;pqOn=()=>true;localStorage.removeItem('bp_pqr')")
        pg.evaluate("S.binv={bid:1,pq:1,bn:'غرفه',total:5000,t:Date.now()-3*36e5};pnPqAdd(S.binv)")
        chk(t+'countdown in invoice',pg.evaluate("pnPqCd().includes('مهلت پرداخت')&&pnPqCd().includes('مانده')&&pqBuyH().includes('مهلت پرداخت')"))
        chk(t+'home reminder card',pg.evaluate("pnPqR().includes('منتظر واریز')&&pnPqR().includes('pnpd')&&BLK.cm().includes('منتظر واریز')"))
        pg.evaluate("S.binv.t=Date.now()-25*36e5")
        chk(t+'expired text',pg.evaluate("pnPqCd().includes('تمام شده')"))
        pg.evaluate("pnPqS([{t:Date.now()-25*36e5,bn:'x',tt:1}])")
        chk(t+'old entry dropped',pg.evaluate("pnPqR()===''"))
        pg.evaluate("pnPqS([{t:Date.now(),bn:'x',tt:1}])")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pnpd';b.dataset.v='0';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(200)
        chk(t+'done removes',pg.evaluate("pnPqL().length==0"))
        pg.evaluate("XF.pn=0")
        chk(t+'off -> nothing',pg.evaluate("pnPqR()===''&&pnPqCd()===''"))
        pg.evaluate("S.pnl=1;S.sec='sw';render()");pg.wait_for_timeout(300)
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
