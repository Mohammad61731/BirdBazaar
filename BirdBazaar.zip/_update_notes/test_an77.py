# تست 1.9.323: AN77 پرواز حباب پیام چت (anMsgFly)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("const o=Element.prototype.animate;window.__an=0;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};const sc=document.getElementById('scr');sc.innerHTML='<div id=\"msgs\"><div class=\"fmr out\"><div class=\"fmb\">a</div></div></div>';0")
            pg.evaluate("window.__anFs={t:Date.now(),x:180,y:600,n:1};window.__an=0;anMsgFly()")
            chk(t+'no new bubble no anim', pg.evaluate("window.__an")==0 and pg.evaluate("!!window.__anFs"))
            pg.evaluate("document.getElementById('msgs').insertAdjacentHTML('beforeend','<div class=\"fmr out\"><div class=\"fmb\">b</div></div>');window.__an=0;anMsgFly()")
            n=pg.evaluate("window.__an")
            if rm=='no-preference': chk(t+'new bubble flies once', n==1)
            else: chk(t+'reduced: no anim', n==0)
            chk(t+'state cleared', pg.evaluate("!window.__anFs"))
            pg.evaluate("window.__anFs={t:Date.now()-9000,x:1,y:1,n:0};window.__an=0;anMsgFly()")
            chk(t+'stale ignored', pg.evaluate("window.__an")==0 and pg.evaluate("!window.__anFs"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
