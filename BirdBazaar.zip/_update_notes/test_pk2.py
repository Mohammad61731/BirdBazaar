# تست 1.9.511 PK2: بررسی اقلام پیک
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
J="XF.cg=1;XF.cp=1;XF.cr=1;XF.pn=1;XF.qm=1;XF.yk=1;CRM.u='u';CRM.p='p';CRM.r={st:'ok',name:'پیک',act:true,cap:3};CRM.j={my:[{id:7,b:1,bn:'غرفه یک',bp:'09120000000',s:'pick',f:15000,name:'مشتری',phone:'09121111111',addr:'تهران',n:2,t:50000},{id:8,b:1,bn:'غرفه دو',bp:'09123333333',s:'way',f:9000,name:'م۲',phone:'09124444444',addr:'کرج',n:1,t:1000},{id:9,b:1,bn:'غرفه سه',bp:'09125555555',s:'acc',f:0,name:'م۳',phone:'09126666666',addr:'ری',n:1,t:1000}],av:[]};localStorage.removeItem('bp_cri');window.CALLS=[];window.yop=async function(o,a){CALLS.push(o);if(o=='yitems')return {ok:1,it:[{n:'برنج ایرانی',q:'2',u:'کیلو'},{n:'روغن',q:'1',u:''},{n:'چای',q:'3',u:'بسته'}]};if(o=='yway')return {ok:1};return {ok:1}};crSheet()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate(J);pg.wait_for_timeout(300)
        chk(t+'btn on acc+pick only',pg.evaluate("document.querySelectorAll('[data-a=bt_cyi]').length==2"))
        pg.evaluate("document.querySelector('[data-a=bt_cyi][data-v=\"7\"]').click()");pg.wait_for_timeout(500)
        chk(t+'fetched once',pg.evaluate("CALLS.filter(x=>x=='yitems').length==1"))
        chk(t+'3 rows',pg.evaluate("document.querySelectorAll('.bzyr').length==3"))
        chk(t+'no price',pg.evaluate("!/تومان/.test(document.querySelector('.bzyr').closest('div[class]').parentElement.textContent)||!/تومان/.test([...document.querySelectorAll('.bzyr')].map(e=>e.textContent).join(''))"))
        chk(t+'confirm disabled',pg.evaluate("document.querySelector('[data-a=bt_cyg]').disabled"))
        chk(t+'sms link',pg.evaluate("document.querySelector('.bzyx').getAttribute('href').startsWith('sms:09120000000?body=')"))
        for i in range(3):
            pg.evaluate("document.querySelector('.bzyr:not(.on) .bzyc').click()");pg.wait_for_timeout(150)
        chk(t+'all ticked enabled',pg.evaluate("document.querySelectorAll('.bzyr.on').length==3&&!document.querySelector('[data-a=bt_cyg]').disabled"))
        chk(t+'cached no 2nd fetch',pg.evaluate("(()=>{ykOpen(7);return CALLS.filter(x=>x=='yitems').length==1})()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none'");pg.screenshot(path='/tmp/pk2_360.png')
        pg.evaluate("document.querySelector('[data-a=bt_cyg]').click()");pg.wait_for_timeout(400)
        chk(t+'yway called',pg.evaluate("CALLS.includes('yway')"))
        chk(t+'cache cleared',pg.evaluate("!JSON.parse(localStorage.getItem('bp_cri')||'{}')[7]"))
        pg.evaluate(J);pg.wait_for_timeout(300)
        pg.evaluate("document.querySelector('[data-a=bt_cyi][data-v=\"9\"]').click()");pg.wait_for_timeout(500)
        for i in range(3):
            pg.evaluate("document.querySelector('.bzyr:not(.on) .bzyc').click()");pg.wait_for_timeout(120)
        chk(t+'acc stays disabled',pg.evaluate("document.querySelector('[data-a=bt_cyg]').disabled"))
        pg.evaluate("XF.yk=0;CRM.j.my.forEach(x=>x.s=x.s);crSheet()");pg.wait_for_timeout(300)
        chk(t+'key off no btn',pg.evaluate("document.querySelectorAll('[data-a=bt_cyi]').length==0"))
        ctx.close()
    br.close()
print('ERRS',errs)
