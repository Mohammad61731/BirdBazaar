# تست 1.9.292: LG12 پروفایل
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const h=document.querySelector('#scr .pcv'),l=document.querySelector('#scr .lst'),ic=l&&(l.querySelector(':scope>svg:first-child')||l.querySelector(':scope>span:first-child'));const hs=h&&getComputedStyle(h),r=ic&&ic.getBoundingClientRect();return {h:h?parseFloat(hs.borderTopLeftRadius):-1,l:l?l.getBoundingClientRect().height:-1,iw:r?r.width:-1,ir:ic?parseFloat(getComputedStyle(ic).borderTopLeftRadius):-1,ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.me='test';S.role='user';S.tab=4;S.v=null;render()"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'header 28',r['h']==28)
                    if r['l']>0:
                        chk(t+'row>=48',r['l']>=47)
                        chk(t+'icon sq 30',r['iw']==30 and r['ir']==8)
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg12_%s.png'%('d' if dark else 'l'))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
