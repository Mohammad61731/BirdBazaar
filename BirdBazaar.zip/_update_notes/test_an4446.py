# تست 1.9.302: AN44 باز شدن نرم لیست جستجو ، AN45 محو فونت/سبک ، AN46 چرخش دکمه‌ی تلاش دوباره
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for rm in ('no-preference','reduce'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light',reduced_motion=rm);pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=f"{w}{'d' if dark else 'l'} {rm} "
                # AN44: باز کردن جستجو ؛ نتیجه‌ی ساختگی بعد از حالت «حداقل ۲ حرف»
                pg.evaluate("gsOpen()");pg.wait_for_timeout(300)
                pg.evaluate("(()=>{const r=document.getElementById('gsr');const o=gsRes;window.gsRes=()=>'<button class=\"gsr\">x</button>';const i=document.getElementById('gsq');i.value='ab';i.dispatchEvent(new Event('input',{bubbles:true}));window.gsRes=o})()")
                a=pg.evaluate("(()=>{const r=document.getElementById('gsr');return {c:r.classList.contains('gso'),n:getComputedStyle(r).animationName}})()")
                if rm=='no-preference':
                    chk(t+'AN44 gso added',a['c']); chk(t+'AN44 anim',a['n']=='angs')
                else:
                    chk(t+'AN44 reduced no anim',a['n'] in ('none',''))
                pg.evaluate("cl()")
                # AN45: anFade
                pg.evaluate("anFade()")
                f=pg.evaluate("getComputedStyle(document.getElementById('app')).animationName")
                if rm=='no-preference': chk(t+'AN45 fade anim',f=='anff')
                else: chk(t+'AN45 reduced no fade',f in ('none',''))
                pg.wait_for_timeout(450)
                chk(t+'AN45 fade removed',pg.evaluate("!document.getElementById('app').classList.contains('anff')"))
                # AN46: صفحه‌ی خطا + کلیک
                pg.evaluate("window.__d=0;const sp=document.createElement('div');sp.id='tsp';document.getElementById('scr').appendChild(sp);fwFail(sp,'<i id=\"okk\">ok</i>').then(()=>window.__d=1);0");pg.wait_for_timeout(200)
                pg.click('#fwr');pg.wait_for_timeout(120)
                s=pg.evaluate("(()=>{const b=document.getElementById('fwr');if(!b)return null;return {ld:b.classList.contains('ld'),an:getComputedStyle(b,'::after').animationName,ov:document.documentElement.scrollWidth<=innerWidth}})()")
                chk(t+'AN46 ld class',s is not None and s['ld'])
                if s:
                    chk(t+'AN46 no overflow',s['ov'])
                    if rm=='no-preference': chk(t+'AN46 spinner anim',s['an']=='anrt')
                pg.wait_for_timeout(600)
                chk(t+'AN46 retry runs',pg.evaluate("window.__d===1 && !!document.getElementById('okk')"))
                ctx.close()
    br.close()
print('ERRORS',errs[:8])
