# تست 1.9.412 G5-c: برچسب و یادداشت خصوصی سفارش (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnOrdX({id:5})===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'4 chips',pg.evaluate("(pnOrdX({id:5}).match(/<button/g)||[]).length==4"))
        def click(a,v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(250)
        click('pnol','5:i')
        chk(t+'label set',pg.evaluate("pnOx()[5].l==='i'&&pnOrdX({id:5}).includes('chip on\" data-a=\"pnol\" data-v=\"5:i\"')"))
        click('pnol','5:i')
        chk(t+'label toggle off',pg.evaluate("!pnOx()[5]"))
        pg.evaluate("(()=>{const m={};m[9]={n:'زنگ بزنم <b>'};pnOxS(m)})()")
        chk(t+'note escaped shown',pg.evaluate("(()=>{const h=pnOrdX({id:9});return h.includes('📝 زنگ')&&!h.includes('<b>',h.indexOf('pnkNt'))})()"))
        chk(t+'cap 200',pg.evaluate("(()=>{const m={};for(let i=1;i<=230;i++)m[i]={l:'i'};pnOxS(m);return Object.keys(pnOx()).length===200})()"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
