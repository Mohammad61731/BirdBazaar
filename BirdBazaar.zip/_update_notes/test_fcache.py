# تست مورد ۱۴ (مرحله ۱): کش انجمن؛ اتاق از حافظه فوری باز می‌شود، بعد با سرور تازه می‌شود
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
def srv(msgs):
    return {'ok':1,'rooms':[{'id':1,'name':'عمومی','emoji':'🦜'}],'pins':[],'reqn':0,'av':{},'msgs':msgs}
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            pg=await b.new_page(viewport={'width':w,'height':700})
            errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
            state={'delay':True,'msgs':[{'id':3,'u':'sara','k':'text','b':'پیام تازه سرور','t':'2026-11-14T10:00:00Z'}]}
            async def h(route):
                if 'fapp' in route.request.url:
                    if state['delay']: await asyncio.sleep(1.2)
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(srv(state['msgs'])))
                if route.request.url.startswith('http'): return await route.abort()
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
            await pg.evaluate("""()=>{S.me='ali';S.pw='x';localStorage.setItem('bp_fc_1',JSON.stringify([{id:1,u:'reza',k:'text',b:'پیام کش‌شده قدیمی',t:'2026-11-14T09:00:00Z'},{id:2,u:'ali',k:'text',b:'پیام دوم کش',t:'2026-11-14T09:01:00Z'}]));FM.rooms=[{id:1,name:'عمومی',emoji:'🦜'}];fOpen(1)}""")
            await pg.wait_for_timeout(150)
            early=await pg.evaluate("document.getElementById('msgs')?document.getElementById('msgs').textContent:''")
            await pg.wait_for_timeout(1800)
            late=await pg.evaluate("document.getElementById('msgs').textContent")
            cache=await pg.evaluate("localStorage.getItem('bp_fc_1')")
            # اتاق بدون کش: «در حال بارگذاری»
            await pg.evaluate("()=>{localStorage.removeItem('bp_fc_2');FM.rooms.push({id:2,name:'x',emoji:'🥚'});fOpen(2)}")
            await pg.wait_for_timeout(100)
            ld=await pg.evaluate("document.getElementById('msgs').textContent")
            hs=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            good=('پیام کش‌شده قدیمی' in early) and ('پیام تازه سرور' in late) and ('قدیمی' not in late) and ('پیام تازه سرور' in cache) and ('بارگذاری' in ld) and not hs and not errs
            ok&=good; print(w,'OK' if good else 'BAD',repr(early[:40]),repr(late[:40]),repr(ld[:30]),hs,errs[:1])
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
