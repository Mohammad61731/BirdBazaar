# تست 1.9.402 H3-a: نصب تازه ← درخواست داده‌ی عمومی هم‌زمان با psig (نه پشت سر آن)
import json,time,asyncio
errs=[]
from playwright.async_api import async_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
async def main():
  async with async_playwright() as p:
    br=await p.chromium.launch()
    ctx=await br.new_context(viewport={'width':360,'height':780},locale='fa-IR');pg=await ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    log=[];t0=[0]
    async def handle(route):
        u=route.request.url
        if u.startswith('file:'): return await route.continue_()
        if '/rpc/' not in u: return await route.fulfill(status=200,body='',content_type='text/plain')
        try:op=json.loads(route.request.post_data or '{}').get('op','')
        except Exception:op=''
        log.append((op,round((time.time()-t0[0])*1000)))
        await asyncio.sleep(0.8)
        pub={'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}
        body={'psig':{'ok':True,'s':'s1'},'pidx':{'ok':True,'p':[],'a':[],'s':[],'x':'1'}}.get(op,pub if op.startswith('public') else {'ok':True})
        await route.fulfill(status=200,body=json.dumps(body),content_type='application/json')
    await pg.route('**/*',handle)
    t0[0]=time.time()
    await pg.goto('file:///home/claude/bb/www/index.html')
    await pg.wait_for_selector('#spl',state='detached',timeout=15000)
    tot=round((time.time()-t0[0])*1000)
    print(log[:6],tot)
    tm={}
    for o,t in log: tm.setdefault(o,t)
    pub=[t for o,t in log if o in('public','public2')]
    chk('psig called',('psig' in tm))
    chk('public data requested',bool(pub))
    chk('public starts with psig (gap<400ms)',bool(pub) and 'psig' in tm and abs(pub[0]-tm['psig'])<400)
    chk('splash gone <3.2s with 0.8s latency',tot<3200)
    await br.close()
asyncio.run(main())
print('ERRORS',errs)
