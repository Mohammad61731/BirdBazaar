# تست 1.9.316: AN68 جهت لغزش صفحه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("D.products=[{id:91,name:'a',cat:'c',price:1000,short:'s',img:'',disc:0,out:0}];S.v=null;S.tab=0;render()");pg.wait_for_timeout(300)
            g=lambda:pg.evaluate("document.getElementById('scr').dataset.pgd||''")
            pg.evaluate("S.v='guides';render()");d1=g()
            anim1=pg.evaluate("getComputedStyle(document.getElementById('scr')).animationName")
            pg.wait_for_timeout(350)
            pg.evaluate("S.v=null;S.tab=0;render()");d2=g()
            anim2=pg.evaluate("getComputedStyle(document.getElementById('scr')).animationName")
            pg.wait_for_timeout(350)
            pg.evaluate("S.tab=1;render()");d3=g()
            chk(t+'forward=f',d1=='f');chk(t+'back=b',d2=='b');chk(t+'same depth none',d3=='')
            if rm=='no-preference': chk(t+'anim names',anim1=='pgf' and anim2=='pgb')
            else: chk(t+'reduced: no slide anim',anim1 not in('pgf','pgb') and anim2 not in('pgf','pgb'))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
