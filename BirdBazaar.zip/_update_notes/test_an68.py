# تست 1.9.243 AN6 AN7 AN8
import asyncio, sys, json, base64
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==')
BODY={'ok':1,'s':'a','b':'b','products':[{'id':i,'name':'م%d'%i,'price':1000,'cat':'x','imgs':['https://img.test/p%d.png'%i],'img':'https://img.test/p%d.png'%i,'dose':'','short':'x'} for i in range(1,9)],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            u=route.request.url
            if not u.startswith('http'): return await route.continue_()
            if 'img.test' in u:
                await asyncio.sleep(.7); return await route.fulfill(status=200,content_type='image/png',body=PNG)
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.evaluate("S.tab=1;render()"); await pg.wait_for_timeout(150)
        n=await pg.evaluate("document.querySelectorAll('#scr .stg').length"); chk('stagger <=6 (%d)'%n,0<n<=6)
        await pg.evaluate("D.products.forEach((p,i)=>{p.img='https://img.test/n'+i+'.png';p.imgs=[p.img]});render()"); await pg.wait_for_timeout(120); a=await pg.evaluate("document.querySelectorAll('#scr .iml:not(.ld)').length"); chk('new images get overlay (%d)'%a,a>0)
        await pg.wait_for_timeout(1500)
        l=await pg.evaluate("[...document.querySelectorAll('#scr .iml')].every(e=>e.classList.contains('ld'))"); chk('all loaded get ld',l)
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
