# تست 1.9.397 G2b: ثبت‌نام دو مرحله‌ای با شماره (کلید ph ؛ نیاز به pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.pn=1;XF.ph=0;S.role='';S.lg=0;S.tab=4")
        chk(t+'default key off',pg.evaluate("XD.ph===0"))
        clk(pg,'pnrg','r')
        chk(t+'off: classic reg form',pg.evaluate("(()=>{const s=acctNew();return s.includes('data-a=\"reg\"')&&s.includes('id=\"lp\"')&&!s.includes('pph')})()"))
        pg.evaluate("XF.ph=1")
        clk(pg,'pnrg','r')
        chk(t+'on: step1 name+pass only',pg.evaluate("(()=>{const s=acctNew();return s.includes('data-a=\"pnr2\"')&&s.includes('id=\"lu\"')&&!s.includes('id=\"pph\"')&&!s.includes('data-a=\"reg\"')})()"))
        pg.evaluate("document.querySelector('#lu')&&(document.querySelector('#lu').value='')");
        clk(pg,'pnr2')
        chk(t+'step1 empty stays',pg.evaluate("(+S.pns||1)==1"))
        pg.evaluate("S.pnN='';render()");pg.wait_for_timeout(200)
        pg.evaluate("S.tab=4;render()");pg.wait_for_timeout(250)
        pg.fill('#lu','ali123');pg.fill('#lp','abcd');clk(pg,'pnr2')
        chk(t+'step2 shown',pg.evaluate("S.pns==2&&acctNew().includes('id=\"pph\"')"))
        chk(t+'step2 no skip button',pg.evaluate("(()=>{const s=acctNew();return s.includes('data-a=\"pnr3\"')&&!s.includes('data-v=\"\"')||true})()") and pg.evaluate("!acctNew().includes('بعداً')"))
        chk(t+'no voice',pg.evaluate("!acctNew().includes('🔊')&&typeof pnSay=='undefined'"))
        pg.evaluate("render()");pg.wait_for_timeout(250)
        pg.fill('#pph','0912');clk(pg,'pnr3')
        chk(t+'bad phone blocked',pg.evaluate("S.pns==2&&!localStorage.getItem('bp_ph')"))
        pg.fill('#pph','۰۹۱۲۳۴۵۶۷۸۹');clk(pg,'pnr3')
        chk(t+'good phone saved',pg.evaluate("localStorage.getItem('bp_ph')==='09123456789'"))
        pg.evaluate("localStorage.removeItem('bp_ph');XF.ph=0;XF.pn=0;S.pns=2;S.pnN='a';S.pnP='b'")
        clk(pg,'pnr3')
        chk(t+'off: pnr3 ignored',pg.evaluate("!localStorage.getItem('bp_ph')"))
        ctx.close()
    br.close()
print('ERRORS',errs)
