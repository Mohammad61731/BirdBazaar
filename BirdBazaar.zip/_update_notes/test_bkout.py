# تست 1.9.81: ذخیره‌ی پشتیبان با Filesystem+Share (اندروید) و بازگشت به روش قدیمی
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.route('**/*',lambda r: r.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body='{"ok":1}') if r.request.url.startswith('http') else r.continue_())
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        r=await pg.evaluate("""async()=>{const L=[];window.Capacitor=window.Capacitor||{};Capacitor.Plugins=Capacitor.Plugins||{};
          Capacitor.Plugins.Filesystem={writeFile:async o=>{L.push(['w',o.path,o.directory,o.encoding,o.data.length]);return {uri:'file:///cache/'+o.path}}};
          Capacitor.Plugins.Share={share:async o=>{L.push(['s',o.url]);}};
          const a=await bkFileOut('{"x":1}','t.bbk');
          Capacitor.Plugins.Share={share:async o=>{throw new Error('Share canceled')}};
          const c=await bkFileOut('{"x":1}','t.bbk');
          Capacitor.Plugins.Filesystem={writeFile:async()=>{throw new Error('disk full')}};
          let d=await bkFileOut('{"x":1}','t.bbk');
          return {a,c,d,L}}""")
        print(r); ok&= r['a']==1 and r['c']==1 and r['L'][0][2]=='CACHE' and r['L'][1][1]=='file:///cache/t.bbk'
        print('errors',errs); ok&=not errs
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
