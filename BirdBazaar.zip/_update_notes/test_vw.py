# تست مورد ۳+۴: نوع محصول مکمل‌ها (معمولی/وزنی/حجمی)، قیمت یک واحد/عمده/پله‌ای، سبد، راهنمای مصرف
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
SHOT = len(sys.argv) > 2
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for scheme in ('light','dark'):
                pg=await b.new_page(viewport={'width':w,'height':760},color_scheme=scheme)
                errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                await pg.route('**/*',lambda rt: rt.abort() if rt.request.url.startswith('http') else rt.continue_())
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
                res=await pg.evaluate("""()=>{
                  const o={};
                  // 1) فرم: سوییچ نوع و ذخیره
                  S.role='admin';S.pm=['all'];S.id=0;
                  document.body.insertAdjacentHTML('beforeend','<div id=tt style="position:fixed;inset:0;z-index:99998;overflow:auto;background:var(--bg);padding:10px">'+pForm({id:0,name:'',cat:'',price:0,short:'',use:'',def:'',ben:'',cau:'',img:'',vol:{},dose:{v:0,s:[0,0],m:[0,0],l:[0,0]}})+'</div>');
                  const sh=id=>getComputedStyle(document.getElementById(id)).display;
                  o.n0=[sh('pk_a'),sh('pk_vw')];
                  document.querySelector('[data-a=pkt][data-v=w]').click();
                  o.w=[sh('pk_a'),sh('pk_vw'),[...document.getElementById('pun').options].map(x=>x.value).join()];
                  document.querySelector('[data-a=pkt][data-v=v]').click();
                  o.v=[...document.getElementById('pun').options].map(x=>x.value).join();
                  document.querySelector('[data-a=pkt][data-v=w]').click();
                  const set=(i,x)=>{document.getElementById(i).value=x};
                  set('pn','کلسیم وزنی');set('pun','kg');set('pst','۰٫۵، ۱، ۲');set('pup','100000');set('pwu','80000');set('pwm','5');set('ptr','10:70000، ۲۰:60000');
                  document.getElementById('gdo').checked=true;set('gdq','هر لیتر آب ۱ سی‌سی');set('gdw','بیش از حد ندهید');
                  const n0=D.products.length;
                  document.querySelector('[data-a=sp]').click();
                  const p=D.products[D.products.length-1];o.saved=D.products.length==n0+1&&p.k=='w'&&p.un=='kg'&&p.up==100000&&p.price==100000&&p.wu==80000&&p.minw==5&&JSON.stringify(p.st)=='[0.5,1,2]'&&p.tiers.length==2&&p.gd.on==1;
                  document.getElementById('tt')&&document.getElementById('tt').remove();
                  // 2) قیمت‌ها
                  o.u=[unit(p,0,0,1),unit(p,1,0,5),unit(p,1,0,12),unit(p,1,0,25)];
                  D.cart=[{id:p.id,w:0,v:0,q:0.5},{id:p.id,w:1,v:0,q:12}];
                  o.tot=cartTotal();
                  // 3) صفحه‌ی محصول
                  S.id=p.id;S.qp=0;S.tab=1;S.v='prod';render();
                  const h=prodView(p);o.guide=h.includes('راهنمای مصرف')&&h.includes('هشدار');
                  o.price=priceH(p).includes('کیلو');
                  o.hs=document.documentElement.scrollWidth>innerWidth;
                  // 4) افزودن به سبد
                  D.cart=[];document.querySelector('[data-a=qs][data-v="1"]').click();
                  document.querySelector('[data-a=add][data-v="0"]').click();
                  document.querySelector('[data-a=qd][data-v="1"]').click();
                  o.q=document.getElementById('qt').value;
                  document.querySelector('[data-a=add][data-v="1"]').click();
                  o.cart1=JSON.stringify(D.cart);
                  document.getElementById('qt').value='6';document.querySelector('[data-a=add][data-v="1"]').click();
                  o.cart2=D.cart.length+':'+D.cart[D.cart.length-1].q+':'+D.cart[D.cart.length-1].w;
                  // 5) سبد: تعداد
                  S.tab=3;S.v=null;render();const cb=document.querySelector('[data-a=cq]');cb.click();
                  o.cartTxt=document.getElementById('scr').textContent.includes('کیلو');
                  o.hs2=document.documentElement.scrollWidth>innerWidth;
                  // 6) محصول معمولی قدیمی بدون تغییر
                  const q={id:99,name:'x',price:10000,wp:8000,minw:3,vol:{5:3000},dose:{v:0,s:[0,0],m:[0,0],l:[0,0]},short:'',img:''};
                  o.old=[pk(q),unit(q,0,5,1),unit(q,1,0,1),unit(q,0,0,1)];
                  return o}""")
                good=(res['n0']==['contents','none'] and res['w'][:2]==['none','contents'] and res['w'][2]=='kg,g' and res['v']=='l,cc'
                      and res['saved'] and res['u']==[100000,80000,70000,60000] and res['tot']==50000+840000
                      and res['guide'] and res['price'] and not res['hs'] and res['q']=='1' and res['cart2']=='2:6:1' and res['cartTxt'] and not res['hs2']
                      and res['old']==['n',3000,8000,10000] and not errs)
                if SHOT and w==320 and scheme=='light': await pg.screenshot(path='/home/claude/shot_vw.png')
                ok&=bool(good); print(w,scheme,'OK' if good else 'BAD',res if not good else '',errs[:2]); await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
