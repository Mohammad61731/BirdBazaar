# 1.9.79: ظاهر پنل 🧪 در عرض‌ها، تاریک/روشن، و دکمه‌ی عقب ab()
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            for sch in ('light','dark'):
                ctx=await b.new_context(viewport={'width':w,'height':760},color_scheme=sch); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
                async def h(route):
                    if route.request.url.startswith('http'):
                        try: j=json.loads(route.request.post_data or '{}')
                        except Exception: j={}
                        body={'ok':1,'f':{}} if j.get('op')=='xget' else {'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}
                        return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
                    return await route.continue_()
                await pg.route('**/*',h)
                await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
                await pg.evaluate("S.me='a';S.pw='x';S.role='admin';S.pm=['all'];S.pnl=1;S.tab=4;S.v=null;S.at='xf';render()"); await pg.wait_for_timeout(500)
                ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth+1||[...document.querySelectorAll('#scr *')].some(e=>e.getBoundingClientRect().right>innerWidth+1&&!e.closest('.chips'))")
                has=await pg.evaluate("document.body.innerHTML.includes('xf_tog')")
                await pg.screenshot(path='shots/xf_%d_%s.png'%(w,sch))
                await pg.evaluate("ab()"); await pg.wait_for_timeout(300)
                back=await pg.evaluate("!S.pnl||S.at!=='xf'")
                print(w,sch,'overflow',ov,'panel',has,'back',back,errs)
                ok&= (not ov) and has and back and not errs
                await ctx.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
