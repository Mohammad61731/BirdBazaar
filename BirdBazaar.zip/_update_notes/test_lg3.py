# تست 1.9.283: LG3 پس‌زمینه‌ی mesh
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const c=getComputedStyle(document.getElementById('app'),'::before');return [c.position,c.backgroundImage.split('radial-gradient').length-1,c.animationName,c.pointerEvents]})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH={home:{m:'%s'}};thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(300)
                r=pg.evaluate(Q)
                if m=='m': chk(t+'minimal has no mesh',r[0]!='fixed' or r[1]==0)
                else:
                    chk(t+'mesh fixed 4 layers, static, no pointer',r[0]=='fixed' and r[1]==4 and r[2]=='none' and r[3]=='none')
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('scr').scrollWidth<=innerWidth+1"))
                ctx.close()
    br.close()
print('ERRORS',errs)
