# U10-T3: صفحه‌ها/کارت‌ها/برگه‌های شیشه‌ای
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
import io,re
errs=[];R={}
NEW='file:///home/claude/bb/www/index.html';OLD='file:///tmp/orig/www/index.html'
def mk(br,url,w=390,cs='light'):
    c=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=cs,reduced_motion='reduce');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto(url);pg.wait_for_timeout(900);return pg
sh=lambda pg:Image.open(io.BytesIO(pg.screenshot()))
ADM="S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"
PROBE="""(()=>{document.querySelectorAll('.pbx,.pbs').forEach(e=>e.remove());const c=document.createElement('div');c.className='card pbx';c.style.cssText='height:70px;width:100%;flex:none';document.querySelector('#scr').prepend(c);const s=document.createElement('div');s.className='sheet pbs';s.style.cssText='height:90px;z-index:40';document.querySelector('#app').appendChild(s)})()"""
def cs(pg,sel,prop):return pg.evaluate(f"getComputedStyle(document.querySelector('{sel}'))['{prop}']")
def lum(c):
    f=lambda v:(v/255/12.92) if v/255<=.03928 else (((v/255)+.055)/1.055)**2.4
    r,g,b=[f(x) for x in c[:3]];return .2126*r+.7152*g+.0722*b
def ratio(a,b):
    la,lb=lum(a),lum(b);hi,lo=max(la,lb),min(la,lb);return (hi+.05)/(lo+.05)
def rgb(s):return tuple(int(float(x)) for x in re.findall(r'[\d.]+',s)[:3])
def min_contrast(pg,sel):
    ink=rgb(pg.evaluate("getComputedStyle(document.body).color"))
    bb=pg.evaluate(f"(()=>{{const r=document.querySelector('{sel}').getBoundingClientRect();return [r.x,r.y,r.width,r.height]}})()")
    im=Image.open(io.BytesIO(pg.screenshot())).convert('RGB');x,y,w,h=bb;m=99
    for fx in (.12,.5,.88):
        for fy in (.2,.5,.8):
            m=min(m,ratio(ink,im.getpixel((int(x+w*fx),int(y+h*fy)))))
    return m
with sync_playwright() as p:
    br=p.chromium.launch()
    for cs_ in ('light','dark'):
        for m in ('p','g'):
            for b in range(0,7):
                if m=='p' and b==0:b=1
                pg=mk(br,NEW,390,cs_);pg.evaluate(ADM+f"renderTop();thSet('home',{{m:'{m}',b:{b},c:'orange'}});go({{tab:0,v:null,sub:0}})");pg.wait_for_timeout(250)
                pg.evaluate(PROBE)
                bi=pg.evaluate("getComputedStyle(document.querySelector('#app')).backgroundImage")
                R[f'{cs_}_{m}{b}_img']=bi!='none'
                c=min_contrast(pg,'.pbx')
                R[f'{cs_}_{m}{b}_contrast']=round(c,1)>=4.5
                if c<4.5:print('LOW',cs_,m,b,round(c,1))
                if cs_=='light' and m=='p' and b in (1,2,6):pg.screenshot(path=f'shots/t5_{m}{b}.png')
    # انتخاب‌گر و ذخیره
    pg=mk(br,NEW);pg.evaluate(ADM+"renderTop();drawer()");pg.click('[data-a=ths]');pg.click('[data-a=thm2][data-v=p]')
    pg.click('[data-a=thb][data-v="3"]');R['pick']=pg.evaluate("document.querySelector('#app').dataset.bg")=='3'
    R['p_no_none']=pg.locator('[data-a=thb][data-v="0"]').count()==0
    pg.click('[data-a=thm2][data-v=g]');R['g_has_none']=pg.locator('[data-a=thb][data-v="0"]').count()==1
    pg.click('[data-a=thr]');R['reset']=pg.evaluate("document.querySelector('#app').dataset.tm")=='n'
    for w in (320,360,412):
        q=mk(br,NEW,w);q.evaluate(ADM+"thSet('home',{m:'p',b:6});renderTop();drawer();document.querySelector('[data-a=ths]').click()")
        R[f'ov{w}']=q.evaluate("(()=>{const e=document.querySelector('.sheet');return e.scrollWidth<=e.clientWidth+1})()")
    br.close()
print({k:v for k,v in R.items() if not v});print('errors:',errs);print('ALL PASS' if all(R.values()) and not errs else 'FAIL')
