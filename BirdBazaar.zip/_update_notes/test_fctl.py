import json,sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
SH=sys.argv[2] if len(sys.argv)>2 else ''
errs=[];ok=[]
ST={'mode':'on','slow':0,'main':True}
ROOMS=[{'id':7,'name':'عمومی','emoji':'🦜','color':''}]
MS=[{'id':1,'u':'reza','k':'text','b':'سلام','md':None,'rt':None,'pin':False,'ed':False,'t':'2026-11-13T08:00:00Z','r':{}}]
calls=[]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);o=b['op'];a=b['a'];r={'err':'x'};calls.append((o,a))
        m=ST['main']
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'admin' if m else 'user','main':m,'perm':{'txt':True},'avatar':'','mode':ST['mode'],'slow':ST['slow']}
        if o=='fpull':
            off=ST['mode']=='off' and not m
            r={'ok':1,'mode':ST['mode'],'slow':ST['slow'],'rooms':[] if off else ROOMS,'msgs':[] if off else MS,'av':{},'pins':[],'reqn':0}
        if o=='ffaq':r={'ok':1,'faq':[]}
        if o=='fmode_set':ST['mode']=a['mode'];ST['slow']=a['slow'];r={'ok':1}
        if o=='fsend':r={'err':'slow','wait':42}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
def boot(pg,main):
    ST['main']=main
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='%s';S.me='u1';S.pw='1';go({tab:5,v:null})"%('admin' if main else 'user'));pg.wait_for_timeout(1500)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
        ST.update(mode='on',slow=0);boot(pg,True)
        chk(f'{w} دکمه کنترل انجمن برای مدیر',pg.locator('[data-a=fctl]').count()==1)
        pg.click('[data-a=fctl]');pg.wait_for_timeout(300)
        pg.click('.sheet [data-a=fctm][data-v=demo]');pg.click('.sheet [data-a=fcts][data-v="60"]');pg.wait_for_timeout(200)
        chk(f'{w} بدون سرریز افقی برگه',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360 and SH:pg.screenshot(path=SH+'/fctl_sheet.png')
        pg.click('.sheet [data-a=fctv]');pg.wait_for_timeout(700)
        chk(f'{w} ذخیره روی سرور',ST['mode']=='demo' and ST['slow']==60)
        ctx.close()
    ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    ST.update(mode='demo',slow=0);boot(pg,False)
    chk('دمو: کاربر بنر نمایشی و لیست اتاق‌ها را می‌بیند',pg.locator('.rm').count()==1 and 'نمایشی' in pg.inner_text('#app') if pg.locator('#app').count() else pg.locator('.rm').count()==1)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    chk('دمو: پیام قبلی دیده می‌شود',pg.locator('#msgs').inner_text().find('سلام')>=0)
    chk('دمو: کادر نوشتن نیست',pg.locator('#ci').count()==0)
    if SH:pg.screenshot(path=SH+'/fctl_demo.png')
    ST.update(mode='closed',slow=0);boot(pg,False)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    chk('بسته: کاربر عادی کادر ندارد',pg.locator('#ci').count()==0)
    boot(pg,True);pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    chk('بسته: مدیر اصلی هنوز کادر دارد',pg.locator('#ci').count()==1)
    ST.update(mode='on',slow=60);boot(pg,False)
    pg.evaluate("FM.perm={txt:true}");pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(900)
    if pg.locator('#ci').count():
        pg.fill('#ci','سلام');pg.click('[data-a=snd]');pg.wait_for_timeout(500)
        chk('محدودیت زمانی: پیام صبر ۴۲ ثانیه',any(c[0]=='fsend' for c in calls))
    ST.update(mode='off',slow=0);boot(pg,False)
    chk('خاموش: کاربر لیست اتاق ندارد',pg.locator('.rm').count()==0 and 'غیرفعال' in pg.content())
    if SH:pg.screenshot(path=SH+'/fctl_off.png')
    boot(pg,True)
    chk('خاموش: مدیر اصلی لیست را می‌بیند',pg.locator('.rm').count()==1)
    br.close()
print('ERR',errs);print('ALL', all(ok) and not errs)
