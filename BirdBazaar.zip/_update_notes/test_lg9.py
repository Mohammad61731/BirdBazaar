# تست 1.9.289: LG9 سبد
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const q=document.querySelector('#scr [data-a=cq]'),d=document.querySelector('#scr .dose.cts'),x=document.querySelector('#scr [data-a=cd]'),f=document.querySelector('#scr .field input');const qs=q&&getComputedStyle(q),ds=d&&getComputedStyle(d);const r=q&&q.getBoundingClientRect();return {q:r?r.width:-1,qr:q?qs.borderTopLeftRadius:'',d:d?parseFloat(ds.borderTopLeftRadius):-1,db:d?ds.backdropFilter:'',x:x?x.getBoundingClientRect().width:-1,fr:f?parseFloat(getComputedStyle(f).borderTopLeftRadius):-1,ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();var pid=D.products[0].id;D.cart=[{id:pid,q:1},{id:pid,q:2}];S.tab=3;S.v=null;render()"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'stepper round 44',r['q']==44 and r['qr']=='50%')
                    chk(t+'total glass 24',r['d']==24 and 'blur' in (r['db'] or ''))
                    chk(t+'delete 32 round',r['x']==32)
                    chk(t+'field radius 14',r['fr']==14)
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg9_%s.png'%('d' if dark else 'l'))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
