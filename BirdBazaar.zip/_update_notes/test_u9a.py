from playwright.sync_api import sync_playwright
errs=[]
P="D.products=[1,2,3,4,5].map(i=>({id:i,name:'دان شماره '+i,short:'توضیح کوتاه برای محصول',price:50000+i,cat:'دان',emoji:'🌰',img:'',imgs:[],disc:i==2?10:0,stock:5}));D.cms.LY2=undefined;"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',has_touch=True).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
        pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(700)
        pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];"+P+"go({tab:1,v:null})");pg.wait_for_timeout(400)
        cols=lambda:pg.evaluate("getComputedStyle(document.querySelector('#pgrid')).gridTemplateColumns.split(' ').length")
        ov=lambda:pg.evaluate("document.documentElement.scrollWidth>innerWidth+1||document.querySelector('#pgrid').scrollWidth>document.querySelector('#pgrid').clientWidth+1")
        res={'default':cols()}
        pg.evaluate("CURP='store';bsheet('grid','store')");pg.wait_for_timeout(200)
        assert pg.locator('[data-a=bcl]').count()==3
        for c in (1,3,2):
            pg.evaluate(f"lySet('grid',b=>b.c={c})");pg.wait_for_timeout(250);res['c%d'%c]=(cols(),ov())
        pg.evaluate("lySet('grid',b=>b.m='l')");pg.wait_for_timeout(250)
        res['list']=(cols(),pg.evaluate("getComputedStyle(document.querySelector('#pgrid .pc')).flexDirection"),ov())
        pg.evaluate("CURP='store';bsheet('grid','store')");pg.wait_for_timeout(200)
        res['sheet_hides_cols_in_list']=pg.locator('[data-a=bcl]').count()==0
        pg.evaluate("go({ed:0})")
        pg.evaluate("S.role='user';S.pm=[];render()");pg.wait_for_timeout(250);res['guest_sees_list']=pg.evaluate("document.querySelector('#pgrid').classList.contains('L')")
        pg.evaluate("S.role='admin';S.pm=['all'];render();CURP='store';cmsSave=()=>{};document.querySelector('[data-a=blr]')||0;delete D.cms.LY2;render()");pg.wait_for_timeout(250);res['reset']=cols()
        pg.screenshot(path=f'/tmp/u9a_{w}.png');print(w,res)
    print('ERRORS',errs);br.close()
