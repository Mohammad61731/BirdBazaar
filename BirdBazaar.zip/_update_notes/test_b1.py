# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.wz=0;BT.prods=[{id:1,b:1,s:'on',d:{name:'قفس بزرگ مخصوص',type:'plain',price:1000,disc:20,emoji:'🪺'}},{id:2,b:1,s:'on',d:{name:'دانه',type:'plain',price:2000}}];BT.booths=[{id:1,name:'غرفه',phone:'0912',city:'س'}];S.tab=0;S.v=null;S.cat='';render()")
        chk(t+'off: empty',pg.evaluate("hnWz()===''"))
        pg.evaluate("XF.wz=1;render()");pg.wait_for_timeout(400)
        chk(t+'on: block',pg.evaluate("hnWz().includes('wzi')&&!hnWz().includes('دانه')"))
        chk(t+'in home',pg.evaluate("!!document.querySelector('#scr .wzk')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:
            pg.evaluate("document.querySelector('#scr .wzk').scrollIntoView()");pg.wait_for_timeout(200);pg.screenshot(path='/tmp/b1_360.png')
        pg.evaluate("BT.prods=[];render()")
        chk(t+'no discount: hidden',pg.evaluate("hnWz()===''"))
        ctx.close()
print('ERRORS',errs)
