import json
from playwright.sync_api import sync_playwright
errs=[]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR',has_touch=True,is_mobile=True);pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(900)
    pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';go({tab:0,v:null,ed:1})");pg.wait_for_timeout(300)
    print('blocks',pg.locator('.hg .hbk').count(),'handles',pg.locator('.hh i').count(),'arrows',pg.locator('.hh b').count())
    print('touch-action block:',pg.evaluate("getComputedStyle(document.querySelector('.hg .hbk')).touchAction"),'handle:',pg.evaluate("getComputedStyle(document.querySelector('.hh i')).touchAction"))
    # real touch scroll in edit mode
    cdp=ctx.new_cdp_session(pg);before=pg.evaluate("document.querySelector('#scr').scrollTop")
    cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':200,'y':600}]})
    for i in range(1,13):cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':200,'y':600-400*i/12}]})
    cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});pg.wait_for_timeout(700)
    after=pg.evaluate("document.querySelector('#scr').scrollTop");print('scrollTop before/after touch swipe:',before,after,'SCROLL_OK' if after>before else 'SCROLL_FAIL')
    pg.evaluate("document.querySelector('#scr').scrollTop=0");pg.screenshot(path='../shots/b1_edit.png')
    o1=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(e=>e.dataset.b).join()")
    pg.locator('.hbk').nth(1).locator('[data-mv="-1"]').click(force=True);pg.wait_for_timeout(300)
    o2=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(e=>e.dataset.b).join()");print('order changed by arrow:',o1!=o2);print(o1,'->',o2)
    print('saved lay first:',pg.evaluate("lay('home')[0].id"),'sheet opened by arrow?',pg.locator('#ov.on').count())
    # handle drag by mouse pointer events
    box=pg.locator('.hbk').nth(0).locator('.hh i').bounding_box();t=pg.locator('.hbk').nth(2).bounding_box()
    pg.mouse.move(box['x']+10,box['y']+10);pg.mouse.down();pg.mouse.move(t['x']+50,t['y']+40,steps=8);pg.mouse.up();pg.wait_for_timeout(300)
    o3=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(e=>e.dataset.b).join()");print('order after handle drag:',o3,'changed:',o3!=o2)
    # drag from body should NOT drag
    b=pg.locator('.hbk').nth(3).bounding_box();pg.mouse.move(b['x']+b['width']/2,b['y']+b['height']/2+20);pg.mouse.down();pg.mouse.move(b['x']+50,b['y']-120,steps=6);pg.mouse.up();pg.wait_for_timeout(200)
    print('body drag leaves order:',pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(e=>e.dataset.b).join()")==o3)
    pg.keyboard.press('Escape')
    pg.evaluate("go({ed:1,cp:1})");pg.wait_for_timeout(300);pg.evaluate("document.querySelector('#scr').scrollTop=0")
    print('compact blocks visible in viewport:',pg.evaluate("[...document.querySelectorAll('.hg .hbk')].filter(e=>{const r=e.getBoundingClientRect();return r.top<innerHeight&&r.bottom>0}).length"),'of',pg.locator('.hbk').count());pg.screenshot(path='../shots/b1_compact.png')
    print('compact overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    pg.click('[data-a=cpt]');pg.wait_for_timeout(200);print('cp after toggle:',pg.evaluate("S.cp"))
    pg.click('[data-a=edx]');pg.wait_for_timeout(200);print('exit ed:',pg.evaluate("S.ed"),'handles left:',pg.locator('.hh i').count())
    pg.evaluate("go({tab:1,v:null,sv:'p',ed:1})");pg.wait_for_timeout(300);print('store ed handles:',pg.locator('.hh i').count())
    print('ERRORS',errs);br.close()
