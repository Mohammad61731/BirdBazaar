# تست 1.9.499: LAB-3 سه نقش + جریان خرید یک‌لمسی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(150)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_lab');LAB={};S.role='admin';S.pm=['all'];S.pvu=0;XF.sto=0")
        clk(pg,'lab','dm')
        chk(t+'bar has 2 buttons',pg.evaluate("document.querySelectorAll('#labbar button').length==2"))
        chk(t+'default role customer',pg.evaluate("(LAB.role||'cu')=='cu'&&document.getElementById('ovc').innerText.includes('دید مشتری')"))
        clk(pg,'lab','rl');chk(t+'rl -> ow',pg.evaluate("LAB.role=='ow'&&document.getElementById('ovc').innerText.includes('دید غرفه‌دار')"))
        clk(pg,'lab','rl');chk(t+'rl -> pk',pg.evaluate("LAB.role=='pk'&&document.getElementById('ovc').innerText.includes('دید پیک')"))
        clk(pg,'lab','rl');chk(t+'rl -> cu',pg.evaluate("LAB.role=='cu'&&document.getElementById('labbar').innerText.includes('مشتری')"))
        clk(pg,'lab','ro:pk');chk(t+'ro:pk',pg.evaluate("LAB.role=='pk'"))
        clk(pg,'lab','nx');chk(t+'nx1 order',pg.evaluate("LAB.b&&LAB.o&&LAB.o.s=='new'&&LAB.o.m=='out'&&LAB.role=='ow'"))
        clk(pg,'lab','nx');chk(t+'nx2 confirm',pg.evaluate("LAB.o.cf==1&&LAB.o.s=='new'"))
        clk(pg,'lab','nx');chk(t+'nx3 ready',pg.evaluate("LAB.o.s=='rdy'&&LAB.role=='pk'"))
        clk(pg,'lab','nx');chk(t+'nx4 accept auto courier',pg.evaluate("LAB.o.s=='acc'&&LAB.o.c==0"))
        clk(pg,'lab','nx');clk(pg,'lab','nx');chk(t+'nx6 way',pg.evaluate("LAB.o.s=='way'"))
        clk(pg,'lab','nx');chk(t+'nx7 done',pg.evaluate("LAB.o.s=='done'&&labNx(LAB.o)===null&&LAB.o.lg.length==7"))
        chk(t+'finish shown',pg.evaluate("document.getElementById('ovc').innerText.includes('جریان تمام شد')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1&&document.getElementById('ovc').scrollWidth<=innerWidth+1"))
        clk(pg,'lab','or');chk(t+'restart',pg.evaluate("LAB.o.s=='new'&&LAB.o.lg.length==0&&LAB.role=='cu'"))
        clk(pg,'lab','md:in');clk(pg,'lab','nx');clk(pg,'lab','nx');clk(pg,'lab','nx')
        chk(t+'in-person: 3 steps no courier',pg.evaluate("LAB.o.s=='done'&&LAB.o.c<0&&LAB.o.m=='in'"))
        clk(pg,'lab','or');clk(pg,'lab','md:in');clk(pg,'lab','ro:pk')
        chk(t+'pk view in-person note',pg.evaluate("document.getElementById('ovc').innerText.includes('پیک لازم نیست')"))
        clk(pg,'lab','st:rdy');clk(pg,'lab','cu:1');clk(pg,'lab','st:acc')
        chk(t+'old manual flow still works',pg.evaluate("LAB.o.s=='acc'&&LAB.o.c==1"))
        clk(pg,'lab','de');chk(t+'end clears',pg.evaluate("!LAB.o&&!LAB.role&&!document.getElementById('labbar')"))
        chk(t+'nothing sent to server',pg.evaluate("!(window.__req||[]).length"))
        ctx.close()
    br.close()
print('ERRS',len(errs))
