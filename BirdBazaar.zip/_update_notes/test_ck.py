# تست 1.9.130: بررسی سبد ck
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            for on in (1,0):
                pg.evaluate("XF.ck=%d;D.products.length||D.products.push({id:1,name:'الف',d:'',out:0,price:1000});D.products[0].out=0;D.products[0].price=1000;D.products[0].disc=0;D.products[0].k='n';D.cart=[{id:D.products[0].id,w:0,v:0,q:1}];S.role='user';S.f={cn:'a',cf:'b',cp:'09120000000',ca:'x'};go({tab:3,v:null})"%on);pg.wait_for_timeout(200)
                chk(t+'ship note on=%d'%on,(pg.locator('text=هزینه‌ی ارسال در جمع کل نیست').count()>0)==bool(on))
                pg.evaluate("D.products[0].price=2000;render()");pg.wait_for_timeout(150)
                chk(t+'price warn on=%d'%on,(pg.locator('text=قیمت تغییر کرد').count()>0)==bool(on))
                pg.evaluate("D.products[0].out=1;render()");pg.wait_for_timeout(150)
                chk(t+'out badge on=%d'%on,(pg.locator('#scr >> text=ناموجود').count()>0)==bool(on))
                if on:
                    pg.evaluate("document.querySelector('[data-a=co]').click()");pg.wait_for_timeout(200)
                    chk(t+'blocked, no order',pg.evaluate("D.cart.length")==1 and pg.evaluate("S.v")!='inv')
                chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            ctx.close()
    br.close()
print('ERRORS',errs)
