# تست 1.9.436 S1: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.route('**/rpc/bapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("localStorage.removeItem('bp_scl');XF.cg=1;XF.cp=1;XF.sc=0;BT.prods=[{id:1,b:1,s:'on',d:{name:'قفس بزرگ مخصوص مرغ عشق',type:'plain',price:1000,disc:20,emoji:'🪺'}},{id:2,b:1,s:'on',d:{name:'دانه',type:'plain',price:2000}},{id:3,b:1,s:'on',d:{name:'کالای سوم',type:'plain',price:500}}];BT.booths=[{id:1,name:'غرفه‌ی تست',phone:'0912',city:'سراوان'}];BC=[{p:1,m:'r',q:2},{p:2,m:'r',q:1}];BCF={n:'علی',p:'09121234567',a:'سراوان خیابان'};CPM[1]='g';D.cart=[];S.tab=3;S.v=null;S.cs='bt';SCT='c';render()");pg.wait_for_timeout(400)
        chk(t+'off -> old cart',pg.evaluate("!document.querySelector('#scr .sckb')&&!!document.querySelector('#scr [data-a=bt_co]')"))
        pg.evaluate("XF.sc=1;render()");pg.wait_for_timeout(400)
        chk(t+'on -> new cart parts',pg.evaluate("!!document.querySelector('#scr .sckb')&&document.querySelectorAll('#scr .sckr').length==2&&!!document.querySelector('#scr .sckbar')&&!!document.querySelector('#scr .sckg')"))
        chk(t+'discount badge',pg.evaluate("document.querySelector('#scr .sckd').textContent.includes('٪')"))
        def click(a,v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(300)
        click('scq','0:1');chk(t+'plus',pg.evaluate("BC[0].q==3"))
        click('scq','0:-1');click('scq','0:-1');chk(t+'minus',pg.evaluate("BC[0].q==1"))
        chk(t+'last -> trash button',pg.evaluate("document.querySelector('#scr .sckq button').dataset.a=='bt_cd'"))
        click('scsv','1');chk(t+'save for later',pg.evaluate("BC.length==1&&scSv().length==1&&scSv()[0].p==2"))
        click('sctab','l');chk(t+'saved tab',pg.evaluate("document.querySelector('#scr .sckh h2').textContent.includes('بعداً')&&document.querySelectorAll('#scr .sckr').length==1"))
        click('scbk','0');chk(t+'back to cart',pg.evaluate("BC.length==2&&scSv().length==0&&SCT=='c'"))
        click('scad','3');chk(t+'suggest add',pg.evaluate("BC.some(l=>l.p==3)"))
        chk(t+'checkout button + fields',pg.evaluate("!!document.querySelector('#scr .sckbar [data-a=bt_co]')&&!!document.getElementById('bcn')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:
            pg.evaluate("document.getElementById('scr').scrollTop=0");pg.wait_for_timeout(300);pg.screenshot(path='/tmp/s1_360.png')
            pg.evaluate("document.getElementById('app').dataset.dk='1';document.documentElement.dataset.theme='dark'")
        ctx.close()
    br.close()
print('ERRORS',errs)
