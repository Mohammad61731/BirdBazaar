# تست 1.9.333: استودیو T2-b فاصله‌ی داخل/تراز/ارتفاع/فاصله‌ی آیتم‌ها/نسبت/گرادیان هر بخش (کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=str(w)+('d' if dark else 'l')+' '
            pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
            ids=pg.evaluate("[...document.querySelectorAll('.hg .hbk')].map(b=>b.dataset.b)");b=ids[1]
            pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
            chk(t+'controls',all(pg.locator(s).count()>=1 for s in ('#ov [data-xs="pd"]','#ov [data-xs="gp"]','#ov [data-xs="mh"]','#ov [data-xs="g2"]','#ov [data-xc$=":ta:2"]','#ov [data-xc$=":va:2"]','#ov [data-xc$=":ar:1"]','#ov [data-xc$=":gd:1"]')))
            fire(pg,'#ov [data-xs="pd"]',16);fire(pg,'#ov [data-xs="gp"]',14);fire(pg,'#ov [data-xs="mh"]',150);fire(pg,'#ov [data-xs="g2"]','#336699')
            clk(pg,'#ov [data-xc$=":ta:2"]');clk(pg,'#ov [data-xc$=":va:2"]');clk(pg,'#ov [data-xc$=":ar:3"]');clk(pg,'#ov [data-xc$=":gd:2"]')
            st=pg.evaluate("(i)=>D.cms.ST['home:'+i]",b)
            chk(t+'saved',st and st['pd']==16 and st['gp']==14 and st['mh']==150 and st['ta']==2 and st['va']==2 and st['ar']==3 and st['gd']==2 and st['g2']=='#336699')
            pg.evaluate("cl();render()");pg.wait_for_timeout(300)
            r=pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]'),c=getComputedStyle(e);return [c.paddingTop,c.textAlign,c.display,c.justifyContent,e.style.aspectRatio,e.style.background.includes('linear-gradient'),e.style.getPropertyValue('--xg')]}",b)
            chk(t+'applied',r[0]=='16px' and r[1]=='center' and r[2]=='flex' and r[3]=='center' and r[4].replace(' ','')=='4/3' and r[5] and r[6]=='14px')
            chk(t+'gap css rule',pg.evaluate("document.getElementById('stg').textContent.includes('var(--xg)')"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            # live apply (no re-render) via slider
            pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
            fire(pg,'#ov [data-xs="pd"]',4)
            chk(t+'live pad',pg.evaluate("(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]').style.padding=='4px'",b))
            clk(pg,'#ov [data-xc$=":ar:0"]');clk(pg,'#ov [data-xc$=":va:0"]');clk(pg,'#ov [data-xc$=":gd:0"]');fire(pg,'#ov [data-xs="gp"]',0)
            pg.evaluate("cl();render()");pg.wait_for_timeout(300)
            r=pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return [e.style.aspectRatio,e.style.display,e.style.background.includes('gradient'),e.style.getPropertyValue('--xg')]}",b)
            chk(t+'defaults restore',r[0]=='' and r[1]=='' and not r[2] and r[3]=='')
            pg.evaluate("(i)=>{stDel('home:'+i);cl();render()}",b);pg.wait_for_timeout(200)
            chk(t+'reset clears',pg.evaluate("(i)=>{const e=document.querySelector('.hg .hbk[data-b=\"'+i+'\"]');return !D.cms.ST['home:'+i]&&e.style.padding==''&&e.style.textAlign==''}",b))
            if w==360 and not dark:
                pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
                pg.evaluate("document.querySelector('#ov .sheet').scrollTop=380");pg.wait_for_timeout(200)
                pg.screenshot(path='/tmp/xs6_sheet.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
