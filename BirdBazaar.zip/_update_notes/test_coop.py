# تست مورد ۸: درخواست همکاری با حساب کاربر + تأیید مستقیم
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,360,412):
            pg=await b.new_page(viewport={'width':w,'height':760}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); calls=[]
            async def h(route):
                u=route.request.url
                if not u.startswith('http'): return await route.continue_()
                try: bd=json.loads(route.request.post_data or '{}')
                except: bd={}
                if 'kapp' in u: calls.append((bd.get('op'),bd.get('u'),bd.get('a'))); body={'ok':1}
                elif 'bapp' in u: body={'ok':1,'booths':[],'prods':[]}
                else: body={'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}
                await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1000)
            out=await pg.evaluate("S.me='';S.v='btq';render();document.querySelector('#scr').textContent.includes('اول وارد حساب')")
            await pg.evaluate("S.me='ali';S.pw='x';S.role='user';S.v='btq';render()"); await pg.wait_for_timeout(200)
            has=await pg.evaluate("!!document.getElementById('bqn')&&document.querySelector('#scr').textContent.includes('ali')")
            await pg.evaluate("document.getElementById('bqn').value='علی';document.getElementById('bqp').value='09121234567';document.querySelector('[data-a=bt_rq]').click()"); await pg.wait_for_timeout(500)
            r1=[c for c in calls if c[0]=='kreq' and c[1]=='ali']
            await pg.evaluate("S.role='admin';S.pm=['all'];BAD={reqs:[{id:5,name:'سارا',shop:'غرفه',phone:'0912',uname:'sara'},{id:6,name:'رضا',shop:'',phone:'0913'}],booths:[]};document.body.insertAdjacentHTML('beforeend','<i id=t1 data-a=bt_ap data-v=5></i><i id=t2 data-a=bt_ap data-v=6></i>');document.getElementById('t1').click()"); await pg.wait_for_timeout(300)
            sh1=await pg.evaluate("document.body.textContent.includes('sara')&&!document.getElementById('bao')")
            await pg.evaluate("document.querySelector('[data-a=bt_ap2][data-v=\"5\"]').click()"); await pg.wait_for_timeout(500)
            r2=[c for c in calls if c[0]=='kapprove' and c[2].get('owner')=='sara']
            await pg.evaluate("BAD={reqs:[{id:6,name:'رضا',shop:'',phone:'0913'}],booths:[]};document.getElementById('t2').click()"); await pg.wait_for_timeout(300)
            old=await pg.evaluate("!!document.getElementById('bao')")
            ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            print(w,out,has,bool(r1),sh1,bool(r2),old,ov,errs)
            ok&=out and has and bool(r1) and sh1 and bool(r2) and old and not ov and not errs
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
