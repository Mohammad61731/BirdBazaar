# تست 1.9.247 AN19 AN20 AN21
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.getElementById('scr').scrollTop=60;document.getElementById('scr').dispatchEvent(new Event('scroll'))"); await pg.wait_for_timeout(200)
        hs=await pg.evaluate("document.getElementById('app').style.getPropertyValue('--hs')"); chk('header shadow var (%s)'%hs,hs not in ('','0','0.00'))
        chk('header ::after',await pg.evaluate("getComputedStyle(document.getElementById('top'),'::after').content!='none'"))
        await pg.evaluate("document.getElementById('scr').scrollTop=0;document.getElementById('scr').dispatchEvent(new Event('scroll'))"); await pg.wait_for_timeout(100)
        chk('shadow resets',await pg.evaluate("document.getElementById('app').style.getPropertyValue('--hs')=='0.00'"))
        await pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend',`<div class=srch id=tw><input id=tq></div><div class=chips><button class='chip on' id=tc>x</button></div>`)")
        await pg.focus('#tq'); await pg.wait_for_timeout(350)
        chk('search focus scale',await pg.evaluate("getComputedStyle(document.getElementById('tw')).transform!='none'"))
        chk('chip.on anim',await pg.evaluate("getComputedStyle(document.getElementById('tc')).animationName=='anpp'"))
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
