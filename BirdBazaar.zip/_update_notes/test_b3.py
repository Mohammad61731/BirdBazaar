# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.wz=0;HTB='';S.role=null;BT.prods=[{id:1,b:1,s:'on',d:{name:'قفس',type:'plain',price:1000,disc:20,emoji:'🪺'}}];BT.booths=[{id:1,name:'غرفه',phone:'0912',city:'س'}];S.tab=0;S.v=null;S.cat='';render()");pg.wait_for_timeout(300)
        chk(t+'off: no tabs',pg.evaluate("!document.querySelector('#scr .htb')"))
        pg.evaluate("XF.wz=1;render()");pg.wait_for_timeout(300)
        chk(t+'on: 4 tabs',pg.evaluate("document.querySelectorAll('#scr .htb .chip').length==4"))
        n0=pg.evaluate("document.querySelectorAll('#scr .hbk').length")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='hntb';b.dataset.v='d';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(300)
        n1=pg.evaluate("document.querySelectorAll('#scr .hbk').length")
        chk(t+'tab filters blocks',n1<n0 and pg.evaluate("!!document.querySelector('#scr .htb .chip.on')&&HTB=='d'"))
        chk(t+'tabs persist',pg.evaluate("document.querySelectorAll('#scr .htb .chip').length==4"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("HTB='';render()");pg.wait_for_timeout(200)
        chk(t+'all restores',pg.evaluate("document.querySelectorAll('#scr .hbk').length==%d"%n0))
        ctx.close()
print('ERRORS',errs)
