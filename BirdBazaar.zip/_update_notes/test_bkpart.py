# تست 1.9.82: پشتیبان تکه‌تکه (bkpart) + کوچک‌شدن خودکار تکه هنگام خطا + 🩺 عیب‌یابی + بازگشت به روش قدیمی
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
ROWS=[{'id':i,'d':'x'*50} for i in range(250)]
async def run(pw, mode):
    b=await pw.chromium.launch(); ctx=await b.new_context(viewport={'width':360,'height':760},accept_downloads=True); pg=await ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); st={'rows':[],'fail':0}
    async def h(route):
        u=route.request.url
        if not u.startswith('http'): return await route.continue_()
        try: j=json.loads((route.request.post_data_buffer or b'').decode('utf-8','ignore'))
        except Exception: j={}
        hd={'access-control-allow-origin':'*'}; op=j.get('op'); a=j.get('a') or {}
        if u.endswith('/rpc/bkapp'):
            body={'ok':1,'v':1,'ddl':['create table if not exists public.t(id int)'],'data':{} if (a.get('nodata') and mode!='oldsrv') else {'users':[{'username':'ali'}]}}
            if op=='bkstate': body={'ok':1,'empty':False,'armed':False}
            return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps(body))
        if u.endswith('/rpc/bkpart'):
            if mode=='nopart': return await route.fulfill(status=404,content_type='application/json',headers=hd,body='{"message":"not found"}')
            if op=='bktables': return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'tables':[{'t':'ads','sz':5000},{'t':'empty','sz':8}]}))
            if op=='bkrows':
                t,o,n=a['t'],a['o'],a['n']; st['rows'].append((t,o,n))
                if t=='ads' and n>60 and mode=='timeout': return await route.fulfill(status=500,content_type='application/json',headers=hd,body='{"code":"57014","message":"canceling statement due to statement timeout"}')
                r=ROWS[o:o+n] if t=='ads' else []
                return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'rows':r,'n':len(r),'by':len(json.dumps(r))}))
        return await route.fulfill(status=200,content_type='application/json',headers=hd,body=json.dumps({'ok':1,'products':[],'stories':[],'ads':[],'cms':{},'guides':[]}))
    await pg.route('**/*',h); await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
    await pg.evaluate("S.me='a';S.pw='x';S.role='admin';S.pm=['all'];S.pnl=1;S.tab=4;S.v=null;S.at='dash';render()"); await pg.wait_for_timeout(300)
    ok=True
    await pg.evaluate("window.__f=null;bkFileOut=async(j,fn)=>{window.__f=j;return 1}")
    await pg.evaluate("sheet(bkfCard())"); await pg.fill('#bkf_pw','secret1')
    await pg.evaluate("bkFull()"); await pg.wait_for_timeout(6000)
    j=await pg.evaluate("window.__f")
    if mode=='nopart': 
        pass
    if j:
        txt=await pg.evaluate("(async j=>await bkDec(j,'secret1'))",j); o=json.loads(txt); data=o.get('data',{})
        if mode in('ok','timeout'): ok&= len(data.get('ads',[]))==250 and data.get('empty')==[] ; print(mode,'ads',len(data.get('ads',[])),'chunks',len(st['rows']),'sizes',sorted({r[2] for r in st['rows']}))
        if mode=='timeout': ok&= any(r[2]<=50 for r in st['rows'] if r[0]=='ads')
        if mode in('nopart','oldsrv'): ok&= data.get('users')==[{'username':'ali'}]; print(mode,'fallback ok',data.get('users'))
    else: ok=False; print(mode,'NO FILE')
    if mode=='ok':
        await pg.evaluate("bkDiag()"); await pg.wait_for_timeout(3000)
        t=await pg.evaluate("document.body.innerText"); print('diag has bkpart',('پشتیبان تکه‌تکه' in t),'✅' in t); ok&= 'پشتیبان تکه‌تکه' in t and '✅' in t
        ov=await pg.evaluate("document.documentElement.scrollWidth>innerWidth+1"); ok&=not ov
    if mode=='nopart':
        await pg.evaluate("bkDiag()"); await pg.wait_for_timeout(3000)
        t=await pg.evaluate("document.body.innerText"); print('diag nopart','1.9.82' in t); ok&= '1.9.82' in t and 'HTTP 404' in t
    print(mode,'errors',errs); ok&=not errs
    await b.close(); return ok
async def main():
    async with async_playwright() as pw:
        r=[await run(pw,m) for m in ('ok','timeout','nopart','oldsrv')]
    print('PASS' if all(r) else 'FAIL'); sys.exit(0 if all(r) else 1)
asyncio.run(main())
