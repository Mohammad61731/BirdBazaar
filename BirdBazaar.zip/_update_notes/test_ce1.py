# تست 1.9.387 D1/146+135+133: cb cq cu
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("XF.ce=0;D.products.forEach(p=>p.out=0);window.__p=D.products[0];__p.k='w';__p.un='g';D.cart=[{id:__p.id,q:500}]")
        chk(t+'ce off',pg.evaluate("ceBar()")=='')
        pg.evaluate("XF.ce=1");chk(t+'ce on 0.5kg moto','موتور' in pg.evaluate("ceBar()") and 'cnb' not in pg.evaluate("ceBar()"))
        pg.evaluate("D.cart[0].q=20000");chk(t+'ce 20kg car','ماشین' in pg.evaluate("ceBar()"))
        pg.evaluate("__p.k='n';__p.un='';");chk(t+'ce no weight: no bar',pg.evaluate("ceBar()")=='')
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
