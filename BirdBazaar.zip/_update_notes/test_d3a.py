# تست 1.9.436 D3-a: تبدیل سفارش پیک به رزرو حضوری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        calls=[];RES=['{"ok":1}']
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        def dh(route):
            calls.append(route.request.post_data or '')
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=RES[0])
        pg.route('**/*',handle);pg.route('**/rpc/dapp',dh);pg.route('**/rpc/bapp',dh);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.dt=1;XF.cr=1;localStorage.removeItem('bp_dct');BT.prods=[{id:1,b:1,d:{name:'الف',type:'plain',price:1000}}];BT.booths=[{id:1,name:'غ',phone:'0912'}];BC=[{p:1,m:'r',q:1}];BCF={n:'علی',p:'09121234567',a:'سراوان خیابان'};CPM[1]='g';cgG=id=>({lvl:1,id});cgVer=id=>1;crOn=()=>true;crShip=b=>({i:0,n:'م',f:20000,m:30,pay:20000});D.cart=[];S.tab=3;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'chips shown',pg.evaluate("dtCrH(1).includes('dttip')&&dtCrH(1).includes('dtnc')"))
        pg.evaluate("XF.dt=0")
        chk(t+'off -> nothing',pg.evaluate("dtCrH(1)===''&&dtCrTxt('g',1)===''"))
        pg.evaluate("XF.dt=1")
        def click(a,v):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(300)
        click('dttip','0');click('dtnc','0')
        chk(t+'tip+cash text',pg.evaluate("dtCrG().t==5000&&dtCrG().c==1&&dtCrTxt('g',1).includes('5000')&&dtCrTxt('g',1).includes('کارت‌به‌کارت')&&dtCrTxt('h',1)===''"))
        for i in range(3): click('dttip','0')
        chk(t+'tip cycles back to 0',pg.evaluate("dtCrG().t==0"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
