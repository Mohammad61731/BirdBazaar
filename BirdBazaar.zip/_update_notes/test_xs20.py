# تست 1.9.347: S100 طرح مناسبتی خودکار (نوروز/یلدا)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page()
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='user';S.pm=[];S.tab=0;S.v=null;S.ed=0;D.cms.OC={on:1};render()");pg.wait_for_timeout(300)
        MK="([m,d])=>{const O=Intl.DateTimeFormat;Intl.DateTimeFormat=function(){return {formatToParts:()=>[{type:'month',value:String(m)},{type:'day',value:String(d)}]}};const r=ocNow();Intl.DateTimeFormat=O;return r}"
        chk(t+'nowruz dates',pg.evaluate(MK,[12,25])=='n' and pg.evaluate(MK,[1,4])=='n' and pg.evaluate(MK,[12,24])=='' and pg.evaluate(MK,[1,5])=='')
        chk(t+'yalda dates',pg.evaluate(MK,[9,30])=='y' and pg.evaluate(MK,[10,1])=='y' and pg.evaluate(MK,[9,29])=='' and pg.evaluate(MK,[10,2])=='')
        pg.evaluate("D.cms.OC={on:0}")
        chk(t+'off',pg.evaluate(MK,[12,27])=='')
        pg.evaluate("D.cms.OC={on:1};S.pvo='n';render()");pg.wait_for_timeout(250)
        chk(t+'ribbon nowruz',pg.evaluate("!!document.querySelector('#ocb.n')&&document.querySelector('#scr').firstChild.id=='ocb'"))
        pg.evaluate("S.pvo='y';render()");pg.wait_for_timeout(250)
        chk(t+'ribbon yalda',pg.evaluate("!!document.querySelector('#ocb.y')&&document.querySelectorAll('#ocb').length==1"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("S.tab=1;render()");pg.wait_for_timeout(200)
        chk(t+'only on home',pg.evaluate("!document.querySelector('#ocb')"))
        pg.evaluate("S.tab=0;S.pvo=0;render()");pg.wait_for_timeout(200)
        chk(t+'no ribbon normally',pg.evaluate("!document.querySelector('#ocb')||ocNow()!=''"))
        pg.evaluate("S.role='admin';S.pm=['all'];S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(200)
        clk(pg,'.edbar [data-pv="m"]')
        chk(t+'sheet controls',pg.locator('#ov [data-pv^="o:"]').count()==5)
        clk(pg,'#ov [data-pv="o:n"]');pg.wait_for_timeout(250)
        chk(t+'preview via sheet',pg.evaluate("S.pvo=='n'&&!!document.querySelector('#ocb.n')"))
        pg.evaluate("S.pvo=0;D.cms.OC={on:0}");clk(pg,'.edbar [data-pv="m"]');clk(pg,'#ov [data-pv="o:1"]');pg.wait_for_timeout(200)
        chk(t+'toggle on',pg.evaluate("D.cms.OC&&D.cms.OC.on===1"))
        ctx.close()
    br.close()
print('ERRORS',errs)
