# تست 1.9.266: سه پک رنگی تازه (IC16)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
PK={'3':(42,'دسته‌ها ۳','cv_'),'4':(30,'دسته‌ها ۴','cw_'),'5':(62,'دسته‌ها ۵','cx_')}
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        for v,(n,g,k) in PK.items():
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1'")
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("icSheet()");pg.wait_for_timeout(300)
            pg.click(f'[data-a=icct][data-v="{v}"]');pg.wait_for_timeout(1000)
            chk(f'{w}/{v}: {n} icons',pg.evaluate(f"Object.keys(ikLib).length=={n}"))
            chk(f'{w}/{v}: colored <8000 group',pg.evaluate(f"Object.values(ikLib).every(e=>e.c==1&&e.u.length<8000&&e.g=='{g}')"))
            chk(f'{w}/{v}: keys {k}',pg.evaluate(f"Object.keys(ikLib).every(x=>x.startsWith('{k}'))"))
            chk(f'{w}/{v}: slots untouched',pg.evaluate("Object.keys(ikSel()).length==0"))
            pg.evaluate("icPick('qa.disc')");pg.wait_for_timeout(500)
            chk(f'{w}/{v}: picker shows all',pg.locator('[data-a=ick]').count()>=n)
            pg.locator('[data-a=ick]').nth(3).click();pg.wait_for_timeout(400)
            chk(f'{w}/{v}: pick sets slot',pg.evaluate("Object.keys(ikSel()).length==1"))
            chk(f'{w}/{v}: no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
            if w==360: pg.evaluate("icPick('qa.disc')");pg.wait_for_timeout(400);pg.screenshot(path=f'/tmp/ic16_{v}.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
