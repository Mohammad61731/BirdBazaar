# تست 1.9.342: استودیو S40 S41 انتخاب و ترتیب دستی کارت (ST.co ch ؛ کلید xs)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def fire(pg,sel,val):
    pg.evaluate("(a)=>{const r=document.querySelector(a[0]);r.value=a[1];r.dispatchEvent(new Event('input',{bubbles:true}));r.dispatchEvent(new Event('change',{bubbles:true}))}",[sel,str(val)])
def clk(pg,sel):
    pg.evaluate("(s)=>document.querySelector(s).click()",sel);pg.wait_for_timeout(150)
E="(i)=>document.querySelector('.hg .hbk[data-b=\"'+i+'\"]')"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w,dark in ((320,0),(360,0),(412,0),(360,1)):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\\\"fw\\\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+('d' if dark else 'l')+' '
        pg.evaluate("S.role='admin';S.pm=['br'];S.tab=0;S.v=null;S.ed=1;XF.xs=1;render()");pg.wait_for_timeout(300)
        b=pg.evaluate("(()=>{const b=[...document.querySelectorAll('.hg .hbk')].find(b=>b.querySelectorAll('[data-a=\\\"prod\\\"],[data-a=\\\"bt_prod\\\"]').length>=4);return b?b.dataset.b:null})()")
        chk(t+'block with cards',bool(b))
        N="(i)=>stCList(stEl('home:'+i)).map(x=>x.k)"
        k0=pg.evaluate(N,b)
        pg.evaluate("(i)=>bsheet(i,'home')",b);pg.wait_for_timeout(200)
        chk(t+'open button',pg.locator('#ov [data-xg^="cd:"]').count()==1)
        clk(pg,'#ov [data-xg^="cd:"]')
        chk(t+'list rows',pg.locator('#ov [data-xg^="cv:"]').count()==2*len(k0))
        pg.evaluate("document.querySelector('#ov [data-xg$=\\\":0:1\\\"]').click()");pg.wait_for_timeout(200)
        k1=pg.evaluate(N,b)
        chk(t+'moved down',k1[0]==k0[1] and k1[1]==k0[0])
        pg.evaluate("document.querySelector('#ov [data-xg^=\\\"ce:\\\"]').click()");pg.wait_for_timeout(200)
        chk(t+'hidden first',pg.evaluate("(i)=>stCList(stEl('home:'+i))[0].c.style.display",b)=='none')
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("cl();render()");pg.wait_for_timeout(300)
        k2=pg.evaluate(N,b)
        chk(t+'persist after render',k2[0]==k1[0] and pg.evaluate("(i)=>stCList(stEl('home:'+i))[0].c.style.display",b)=='none')
        pg.evaluate("(i)=>bsheet(i,'home')",b);clk(pg,'#ov [data-xg^="cd:"]');clk(pg,'#ov [data-xg^="cr:"]');pg.wait_for_timeout(300)
        k3=pg.evaluate(N,b)
        chk(t+'reset',k3==k0 and pg.evaluate("(i)=>!D.cms.ST['home:'+i]||!D.cms.ST['home:'+i].co",b))
        ctx.close()
    br.close()
print('ERRORS',errs)
