# تست 1.9.434 D2-b: پیشنهاد تحویل با فاصله + ساعت کاری (کلید dt)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',geolocation={'latitude':35.70,'longitude':51.40},permissions=['geolocation'])
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.cp=1;XF.cr=0;XF.dt=0;DTS={};cgG=()=>({lvl:1,lat:35.701,lng:51.401,hrs:{o:'00:00',c:'23:59'}})")
        chk(t+'off -> nothing',pg.evaluate("dtH(1)===''&&dtDist(1)!==undefined"))
        pg.evaluate("XF.dt=1")
        chk(t+'button shown',pg.evaluate("dtH(1).includes('dtgo')&&dtH(1).includes('الان باز است')"))
        pg.evaluate("cgG=()=>({lvl:1,hrs:{o:'09:00',c:'21:00',off:[0,1,2,3,4,5,6]}})")
        chk(t+'off day text',pg.evaluate("dtH(1).includes('تعطیل')&&!dtH(1).includes('dtgo')"))
        pg.evaluate("cgG=()=>({lvl:1,lat:35.701,lng:51.401,hrs:{o:'00:00',c:'23:59'}})")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dtgo';b.dataset.v='1';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(1200)
        chk(t+'distance + near -> میام می‌برم',pg.evaluate("!!DTS[1]&&DTS[1].km<3&&dtDist(1).includes('میام می‌برم')"))
        pg.evaluate("DTS[1]={km:9}")
        chk(t+'far -> برام بفرست',pg.evaluate("dtDist(1).includes('برام بفرست')"))
        pg.evaluate("cgG=()=>({lvl:1,hrs:{o:'00:00',c:'23:59'}})")
        chk(t+'no location -> no button',pg.evaluate("!dtH(1).includes('dtgo')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
