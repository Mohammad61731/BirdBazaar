# تست 1.9.249 AN26 AN27 AN28
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:(errs.append(str(e)),print('ERR',str(e)[:200])))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.getElementById('scr').insertAdjacentHTML('beforeend',`<label class=tkr><input type=checkbox id=ck><span>a</span></label><input type=radio id=rd><input id=ti><button class=dt data-a=ep data-v=1 id=kb>⋮</button>`)")
        chk('checkbox custom',await pg.evaluate("getComputedStyle(document.getElementById('ck')).appearance=='none'"))
        await pg.click('#ck'); await pg.wait_for_timeout(350)
        chk('checkbox checked tick',await pg.evaluate("document.getElementById('ck').checked&&getComputedStyle(document.getElementById('ck'),'::after').clipPath.indexOf('inset(0')>=0"))
        await pg.evaluate("document.getElementById('ti').focus();toast('نام را وارد کن')"); await pg.wait_for_timeout(60)
        chk('field shake',await pg.evaluate("document.getElementById('ti').classList.contains('anshk')"))
        await pg.evaluate("sheet('<h3>x</h3>');document.getElementById('kb').addEventListener('click',e=>e.stopPropagation())")
        await pg.evaluate("document.getElementById('kb').dispatchEvent(new MouseEvent('click',{bubbles:true}))"); await pg.wait_for_timeout(80)
        chk('menu origin',await pg.evaluate("(document.querySelector('#ovc .sheet')||{}).classList&&document.querySelector('#ovc .sheet').classList.contains('anko')&&document.querySelector('#ovc .sheet').style.transformOrigin!=''"))
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
