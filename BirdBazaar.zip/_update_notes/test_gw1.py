# تست 1.9.468: بسته‌بندی هدیه + کارت پیام (کلید gw)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        chk(f'{w}: off -> empty',pg.evaluate("gwFld()==='' && gwTx()===''"))
        pg.evaluate("XF.gw=1")
        chk(f'{w}: on -> field',pg.evaluate("gwFld().includes('bgwc')&&gwFld().includes('bgwm')"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+gwFld()+'</div>'")
        pg.wait_for_timeout(200)
        chk(f'{w}: unchecked -> no text',pg.evaluate("gwTx()===''"))
        pg.check('#bgwc'); pg.fill('#bgwm','تولدت مبارک')
        t=pg.evaluate("gwTx()")
        chk(f'{w}: text has gift+card',('بسته‌بندی هدیه' in t) and ('تولدت مبارک' in t))
        pg.fill('#bgwm','x'*300)
        chk(f'{w}: card max 100',len(pg.evaluate("gwTx()"))<=140)
        b=pg.locator('#bgwc').bounding_box()
        chk(f'{w}: checkbox >=22',b is not None and b['width']>=21)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        pg.evaluate("XF.gw=0")
        chk(f'{w}: back off',pg.evaluate("gwTx()===''"))
        if w==360: pg.evaluate("XF.gw=1;document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+gwFld()+'</div>'");pg.screenshot(path='/tmp/gw360.png')
    br.close()
print('ERRORS',errs)
