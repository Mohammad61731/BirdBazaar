# تست 1.9.75: ارسال دسته‌ای بازدید غرفه (bviewn) و «دیده شد» (mread ids) + بازگشت به مسیر قدیمی
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def run(pw, newserver):
    b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':700})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    calls=[]
    async def h(route):
        u=route.request.url; bd=route.request.post_data or ''
        if u.startswith('http'):
            try: j=json.loads(bd)
            except Exception: j={}
            op=j.get('op'); a=j.get('a') or {}
            calls.append((op,a))
            if op=='bviewn' and not newserver: body={'err':'unknown'}
            elif op=='mread': body={'ok':1,'n':1} if newserver else {'ok':1}
            else: body={'ok':1,'n':0,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
        return await route.continue_()
    await pg.route('**/*',h)
    await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2000)
    await pg.evaluate("S.me='u1';S.pw='x'")
    # 3 بازدید غرفه + 3 «دیده شد»
    await pg.evaluate("[11,12,13].forEach(i=>QB.addV(i));[5,6,7].forEach(i=>QB.addR(i));QB.addR(5)")
    n0=len(calls); await pg.wait_for_timeout(500)
    pre=[c for c in calls[n0:] if c[0] in ('bview','bviewn','mread')]
    print('before flush calls:',len(pre)); ok=(len(pre)==0)
    await pg.evaluate("QB.flush()"); await pg.wait_for_timeout(1200)
    ops=[c[0] for c in calls[n0:] if c[0] in ('bview','bviewn','mread')]
    print('newserver' if newserver else 'oldserver', ops)
    if newserver:
        ok&= ops.count('bviewn')==1 and ops.count('mread')==1 and 'bview' not in ops
        mr=[c for c in calls if c[0]=='mread'][0][1]; ok&= sorted(mr['ids'])==[5,6,7]
        bv=[c for c in calls if c[0]=='bviewn'][0][1]; ok&= set(bv['v'].keys())=={'11','12','13'}
    else:
        ok&= ops.count('bview')==3 and ops.count('mread')==4
    q=await pg.evaluate("[Object.keys(QB.v).length,QB.r.length]"); print('queue after',q); ok&= q==[0,0]
    # فرار: خطای شبکه ← صف حفظ شود
    print('errors',errs); ok&=not errs
    await b.close(); return ok
async def main():
    async with async_playwright() as pw:
        r=[await run(pw,True),await run(pw,False)]
    print('PASS' if all(r) else 'FAIL'); sys.exit(0 if all(r) else 1)
asyncio.run(main())
