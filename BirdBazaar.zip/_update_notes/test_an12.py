# تست 1.9.240 AN1 AN2
import asyncio, sys
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        async def run(mem,rm):
            ctx=await b.new_context(viewport={'width':360,'height':760},reduced_motion='reduce' if rm else 'no-preference'); pg=await ctx.new_page(); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            if mem: await pg.add_init_script("Object.defineProperty(navigator,'deviceMemory',{get:()=>%d})"%mem)
            await pg.route('**/*',lambda r:r.abort() if r.request.url.startswith('http') else r.continue_())
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(800)
            return pg,errs
        pg,e=await run(8,False); chk('default on',await pg.evaluate("anOn()&&!document.body.classList.contains('an0')"))
        await pg.evaluate("tlSet('an',0)"); chk('manual off',await pg.evaluate("!anOn()&&document.body.classList.contains('an0')&&getComputedStyle(document.querySelector('#scr')).animationName=='none'"))
        await pg.evaluate("tlSet('an',1)"); chk('manual on',await pg.evaluate("anOn()&&!document.body.classList.contains('an0')")); chk('no errors',not e)
        pg,e=await run(2,False); chk('weak phone auto off',await pg.evaluate("!anOn()&&document.body.classList.contains('an0')"))
        await pg.evaluate("tlSet('an',1)"); chk('weak phone manual on',await pg.evaluate("anOn()&&!document.body.classList.contains('an0')"))
        pg,e=await run(8,True); chk('reduced-motion auto off',await pg.evaluate("!anOn()"))
        pg,e=await run(8,False); chk('in TLK',await pg.evaluate("TLK.some(x=>x[0]=='an')"))
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
