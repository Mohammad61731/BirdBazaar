# تست 1.9.387 D1/136: کلید cl ، بعداً می‌خرم
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(200)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_cll');XF.cl=0;D.cart=[{id:(D.products[0]||{id:1}).id,q:2}]")
        chk(t+'off: no button',pg.evaluate("clBtn(0)")=='' and 'cll' not in pg.evaluate("cartV0()"))
        pg.evaluate("XF.cl=1");chk(t+'on: button in cart','cll' in pg.evaluate("cartV0()"))
        clk(pg,'cll','0');chk(t+'moved out of cart',pg.evaluate("D.cart.length")==0 and pg.evaluate("clGet().length")==1)
        chk(t+'box shown in empty cart','cla' in pg.evaluate("cartV0()"))
        clk(pg,'cla','0');chk(t+'restored',pg.evaluate("D.cart.length")==1 and pg.evaluate("clGet().length")==0)
        pg.evaluate("clSet([{id:D.cart[0].id,q:1,w:0,v:0}])");clk(pg,'clx','0');chk(t+'removed',pg.evaluate("clGet().length")==0)
        chk(t+'no overflow',not pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
