# تست 1.9.313: AN64 شمارش عددی جمع سبد (+ AN73 بازدید غرفه)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("D.products=[{id:91,name:'a',cat:'c',price:1000,short:'s',img:'',disc:0,out:0}];D.cart=[{id:91,q:2}];S.v=null;S.tab=3;render()");pg.wait_for_timeout(120)
            mid=pg.evaluate("document.querySelector('.cts b')&&document.querySelector('.cts b').textContent")
            final=pg.evaluate("money(cartTotal())")
            if mid is None: print('SKIP '+t);ctx.close();continue
            if rm=='no-preference': chk(t+'counting (not final yet)',mid!=final)
            else: chk(t+'reduced: final instantly',mid==final)
            pg.wait_for_timeout(700)
            chk(t+'ends at exact total',pg.evaluate("document.querySelector('.cts b').textContent")==final)
            pg.evaluate("D.cart[0].q=3;render()");pg.wait_for_timeout(700)
            chk(t+'updates to new total',pg.evaluate("document.querySelector('.cts b').textContent")==pg.evaluate("money(cartTotal())"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
