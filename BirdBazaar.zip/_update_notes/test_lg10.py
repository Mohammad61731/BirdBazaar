# تست 1.9.290: LG10 شیت و toast
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const sh=document.querySelector('.sheet'),t=document.getElementById('toast'),ts=getComputedStyle(t),ss=sh&&getComputedStyle(sh),b=sh&&getComputedStyle(sh,'::before');const r=t.getBoundingClientRect();return {sr:ss?parseFloat(ss.borderTopLeftRadius):-1,sb:ss?ss.backdropFilter:'',gw:b?b.width:'',tr:parseFloat(ts.borderTopLeftRadius),tt:r.top,tl:r.left,tw:r.width,ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=0;S.v=null;render();sheet('<h3>عنوان</h3><button class=\"btn\">تأیید</button>');toast('ذخیره شد ✓')"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'sheet radius 28',r['sr']==28 and 'blur' in (r['sb'] or ''))
                    chk(t+'grabber 36',r['gw']=='36px')
                    chk(t+'toast pill top',r['tr']>=20 and r['tt']<60 and abs(r['tl']+r['tw']/2-w/2)<2 and r['tl']>=0 and r['tl']+r['tw']<=w)
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg10_%s.png'%('d' if dark else 'l'))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
