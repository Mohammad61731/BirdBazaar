# تست 1.9.244 AN9 AN10 AN11
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[{'id':i,'name':'م%d'%i,'price':1000,'cat':'x','imgs':[],'dose':'','short':'x'} for i in range(1,5)],'stories':[],'ads':[],'cms':{},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1200)
        await pg.evaluate("S.tab=1;render()"); await pg.wait_for_timeout(300)
        await pg.evaluate("document.querySelector('#scr .add[data-a=qadd]').dispatchEvent(new MouseEvent('click',{bubbles:true}))")
        chk('check mark shows',await pg.evaluate("!!document.querySelector('.add.okc')||D.cart.length>0"))
        await pg.wait_for_timeout(1100)
        chk('check mark gone',await pg.evaluate("!document.querySelector('.add.okc')"))
        await pg.evaluate("sheet('<h3>x</h3>')")
        chk('sheet first open animates',await pg.evaluate("document.getElementById('ov').classList.contains('ovin')"))
        await pg.wait_for_timeout(500)
        await pg.evaluate("sheet('<h3>y</h3>')")
        chk('re-render no animation',await pg.evaluate("!document.getElementById('ov').classList.contains('ovin')"))
        await pg.evaluate("toast('سلام')")
        chk('toast on',await pg.evaluate("document.getElementById('toast').classList.contains('on')"))
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
