import json,os
from playwright.sync_api import sync_playwright
errs=[];calls=[]
ST={'main':False,'perm':{'txt':True,'img':False,'vid':False,'fil':False,'muted':False,'blocked':False},'rep':[{'id':5,'msg':2,'u':'sara','why':'توهین','t':'2026-11-13T09:00:00Z','body':'این پیام دوم است','by':'reza'}]}
MS=[{'id':1,'u':'ali','k':'text','b':'پیام من','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:00:00Z','r':{'👍':2}},{'id':2,'u':'reza','k':'text','b':'این پیام دوم است','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:05:00Z','r':{}}]
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/fapp'):
        b=json.loads(req.post_data);calls.append(b);o=b['op'];a=b['a'];r={'err':'x'}
        if o=='fwho':r={'ok':1,'me':b['u'],'role':'user','main':ST['main'],'perm':ST['perm'],'avatar':''}
        if o=='fpull':
            rows=[m for m in MS if m['id']>a.get('after',0) and m['id']<a.get('before',10**9)]
            r={'ok':1,'rooms':[{'id':7,'name':'عمومی','emoji':'🦜'}],'msgs':rows if a.get('room')==7 else [],'av':{},'pins':[{'id':m['id'],'u':m['u'],'b':m['b']} for m in MS if m['pin']],'reqn':0}
        if o=='fdel':
            MS[:]=[m for m in MS if m['id']!=a['id']];r={'ok':1}
        if o=='fpin':
            for m in MS:
                if m['id']==a['id']:m['pin']=a['on']
            r={'ok':1}
        if o=='freact':
            for m in MS:
                if m['id']==a['id']:m['r']={a['e']:m['r'].get(a['e'],0)+1}
            r={'ok':1}
        if o in('freport','fmute','fblock'):r={'ok':1}
        if o=='freport_list':r={'ok':1,'reports':ST['rep']} if ST['main'] else {'err':'denied'}
        if o=='freport_del':ST['rep']=[x for x in ST['rep'] if x['id']!=a['id']];r={'ok':1}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def C(o):return [c for c in calls if c['op']==o]
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_context(viewport={'width':390,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept());pg.route('**/*',h)
    pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';S.pw='1';go({tab:5,v:null})");pg.wait_for_timeout(900)
    pg.click('[data-a=froom][data-v="7"]');pg.wait_for_timeout(800)
    print('1) reaction chip shown under bubble:',pg.locator('.frx i').count()==1)
    # normal user on other's message
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(300)
    bt=lambda a:pg.locator(f'#ov.on [data-a={a}]').count()
    print('2) user sheet: react=',pg.locator('#ov.on .fre button').count(),'report=',bt('frpt'),'| no delete/pin/mute:',bt('fdl2')+bt('fpn')+bt('fmu')+bt('fbk')==0)
    pg.click('.fre button >> nth=1');pg.wait_for_timeout(500)
    print('   react sent:',C('freact')[-1]['a'],'| chip updated:',pg.locator('.frx i').count()==2)
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250);pg.click('[data-a=frpt]');pg.wait_for_timeout(250);pg.click('[data-a=frw] >> nth=1');pg.click('[data-a=frps]');pg.wait_for_timeout(400)
    print('   report sent:',C('freport')[-1]['a'])
    # own message: delete allowed, no report
    pg.click('.fmr.out .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250)
    print('3) own msg: delete=',bt('fdl2'),'report=',bt('frpt'),'pin=',bt('fpn'))
    pg.click('[data-a=fdl2]');pg.wait_for_timeout(800)
    print('   own deleted:',C('fdel')[-1]['a'],'| bubble gone:',pg.locator('.fmr.out').count()==0)
    # main admin
    ST['main']=True;MS.insert(0,{'id':1,'u':'ali','k':'text','b':'پیام من','md':None,'rt':None,'pin':False,'t':'2026-11-13T08:00:00Z','r':{}})
    pg.evaluate("FM.main=1;fOpen(7)");pg.wait_for_timeout(800)
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250)
    print('4) admin sheet: pin=',bt('fpn'),'mute=',bt('fmu'),'block=',bt('fbk'),'delete=',bt('fdl2'))
    pg.click('[data-a=fpn]');pg.wait_for_timeout(900)
    print('   pinned:',C('fpin')[-1]['a'],'| pin bar visible:',pg.locator('#fpin').is_visible(),'| mark:',pg.locator('.fmpin').count())
    pg.screenshot(path='../shots/f6_pin.png')
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250);print('   label unpin:','برداشتن' in pg.locator('[data-a=fpn]').inner_text());pg.click('[data-a=fpn]');pg.wait_for_timeout(900)
    print('   unpinned bar hidden:',not pg.locator('#fpin').is_visible())
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250);pg.click('[data-a=fmu]');pg.wait_for_timeout(300);print('   mute sent:',C('fmute')[-1]['a'])
    pg.click('.fmr.in .fmb',position={'x':20,'y':10});pg.wait_for_timeout(250);pg.click('[data-a=fbk]');pg.wait_for_timeout(300);print('   block sent:',C('fblock')[-1]['a'])
    # reports list
    pg.click('.chh [data-a=frpl]');pg.wait_for_timeout(500)
    print('5) report card shown:',pg.locator('#ov.on .card').count()==1,'|',pg.locator('#ov.on .card').inner_text().replace('\n',' ')[:80])
    pg.screenshot(path='../shots/f6_reports.png')
    pg.click('[data-a=frpd]');pg.wait_for_timeout(900)
    print('   delete via report: fdel',C('fdel')[-1]['a'],'| freport_del',C('freport_del')[-1]['a'],'| msg gone:',pg.locator('.fmr.in').count()==0)
    # refresh drops deleted msg from other users
    MS.append({'id':9,'u':'zed','k':'text','b':'x','md':None,'rt':None,'pin':False,'t':'2026-11-13T09:10:00Z','r':{}});pg.evaluate("fPoll()");pg.wait_for_timeout(600)
    MS[:]=[m for m in MS if m['id']!=9];pg.evaluate("fRefresh()");pg.wait_for_timeout(600);print('6) refresh removes msg deleted by others:',pg.locator('.fmr[data-id="9"]').count()==0)
    # forum list button + back button
    pg.evaluate("ab()");pg.wait_for_timeout(400);print('7) list has report btn:',pg.locator('#scr [data-a=frpl]').count()==1)
    pg.evaluate("fOpen(7)");pg.wait_for_timeout(500);pg.click('.fmr .fmb >> nth=0');pg.wait_for_timeout(250);print('   back closes sheet:',pg.evaluate("ab()===1&&!ov.classList.contains('on')&&S.v==='chat'"))
    for w in (320,360,412):
        pg.set_viewport_size({'width':w,'height':780});pg.evaluate("fOpen(7)");pg.wait_for_timeout(500);pg.click('.fmr .fmb >> nth=0');pg.wait_for_timeout(250)
        print(w,'overflow-x:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'sheet overflow:',pg.evaluate("(()=>{const e=document.querySelector('.sheet');return e.scrollWidth>e.clientWidth})()"));pg.evaluate("cl()")
    print('ERRORS',errs);br.close()
