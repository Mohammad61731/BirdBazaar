# تست 1.9.457 S4: خلاصه‌ی قیمت و سود + قیمت هر عدد (کلید sc)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
SETUP="""XF.cg=1;XF.sc=1;S.me='u1';BT.booths=[{id:1,name:'غ',phone:'0912',city:'س'}];
BT.prods=[{id:11,b:1,s:'on',d:{name:'دانه',type:'plain',price:100000,disc:20,emoji:'🌾'}},{id:12,b:1,s:'on',d:{name:'قفس',type:'plain',price:50000,disc:0,emoji:'🐦'}}];
BC=[{p:11,b:1,m:'r',q:3},{p:12,b:1,m:'r',q:1}];D.cart=[];localStorage.removeItem('bp_scl');S.tab=3;S.v=null;S.cs='bt';SCT='c';render()"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate(SETUP);pg.wait_for_timeout(400)
        chk(t+'summary card',pg.evaluate("document.querySelectorAll('#scr .scksm').length==1"))
        chk(t+'saving shown',pg.evaluate("!!document.querySelector('#scr .sckdc')&&document.querySelector('#scr .sckdc').innerText.includes('سود')"))
        chk(t+'unit price on qty>1',pg.evaluate("[...document.querySelectorAll('#scr .sckm1')].some(e=>e.innerText.includes('هر عدد'))"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.evaluate("BT.prods.forEach(x=>x.d.disc=0);render()");pg.wait_for_timeout(300)
        chk(t+'no card without discount',pg.evaluate("document.querySelectorAll('#scr .scksm').length==0"))
        if w==360:
            pg.evaluate(SETUP);pg.wait_for_timeout(300);pg.screenshot(path='/tmp/s4_360.png')
            pg.evaluate("document.getElementById('app').dataset.dk='1';document.documentElement.dataset.theme='dark'");pg.wait_for_timeout(300);pg.screenshot(path='/tmp/s4_dk.png')
        ctx.close()
print('ERRORS',errs)
