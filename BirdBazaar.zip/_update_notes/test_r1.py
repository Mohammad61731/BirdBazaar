import sys,json,time
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/tmp'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
MODE={'m':'ok','role':'user'}
def h(route,req):
    u=req.url
    if u.startswith('file:'):return route.continue_()
    if u.endswith('/rpc/app'):
        b=json.loads(req.post_data or '{}')
        if b.get('op')=='login':
            m=MODE['m']
            if m=='down':return route.abort()
            if m=='hang':
                time.sleep(7);return route.abort()
            if m=='deny':return route.fulfill(status=200,content_type='application/json',body='{"err":"login"}')
            return route.fulfill(status=200,content_type='application/json',body=json.dumps({'role':MODE['role'],'pm':['all'] if MODE['role']=='admin' else [],'vip':0,'code':'AB12','inv':1}))
    route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
def sess(**k):
    d={'u':'ali','p':'1234','adm':False,'r':'user','pm':[],'vip':0,'code':'','inv':0,'t':int((time.time()-10*86400)*1000)};d.update(k);return json.dumps(d)
with sync_playwright() as p:
    br=p.chromium.launch()
    def boot(sv,mode,wait=1500):
        MODE['m']=mode
        ctx=br.new_context(viewport={'width':390,'height':780},locale='fa-IR');pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',h)
        if sv:pg.add_init_script("if(!sessionStorage.getItem('__i')){localStorage.setItem('bp3s',%s);sessionStorage.setItem('__i','1')}"%json.dumps(sv))
        pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(wait);return ctx,pg
    ctx,pg=boot(sess(),'ok')
    chk('1 سرور سالم: وارد',pg.evaluate("S.me=='ali'&&S.role=='user'&&!S.off"))
    chk('2 ذخیره‌ی ورود تازه شد (r, t جدید)',pg.evaluate("(()=>{const c=JSON.parse(localStorage.getItem('bp3s'));return c.r=='user'&&Date.now()-c.t<60000})()"))
    ctx.close()
    ctx,pg=boot(sess(),'down')
    chk('3 سرور قطع + ۱۰ روز بعد: هنوز وارد',pg.evaluate("S.me=='ali'&&S.role=='user'&&S.off==1"))
    MODE['m']='ok';pg.evaluate("reAuth()");pg.wait_for_timeout(800)
    chk('4 برگشت اینترنت: تأیید شد',pg.evaluate("S.off==0&&S.me=='ali'"))
    ctx.close()
    ctx,pg=boot(sess(adm=True,r='admin',pm=['all']),'down')
    chk('5 ادمین با سرور قطع: وارد با دسترسی',pg.evaluate("S.role=='admin'&&S.pm.includes('all')&&S.off==1"))
    ctx.close()
    ctx,pg=boot(sess(adm=True,r=None,pm=None),'down')
    chk('6 ورود قدیمی ادمین بدون نقش: وارد نشود ولی ذخیره بماند',pg.evaluate("!S.me&&!!localStorage.getItem('bp3s')"))
    ctx.close()
    ctx,pg=boot(sess(),'hang',wait=8500)
    chk('7 سرور بی‌پاسخ (۶ث): وارد می‌ماند',pg.evaluate("S.me=='ali'&&S.off==1"))
    ctx.close()
    ctx,pg=boot(sess(),'deny')
    chk('8 رد صریح بار اول: مهمان ولی ذخیره می‌ماند',pg.evaluate("!S.me&&JSON.parse(localStorage.getItem('bp3s')).f==1"))
    pg.reload();pg.wait_for_timeout(1500)
    chk('9 رد صریح بار دوم: ذخیره پاک',pg.evaluate("localStorage.getItem('bp3s')===null"))
    ctx.close()
    ctx,pg=boot(sess(),'down')
    MODE['m']='deny';pg.evaluate("reAuth()");pg.wait_for_timeout(600);pg.evaluate("reAuth()");pg.wait_for_timeout(600)
    chk('10 آنلاین شدن و رد صریح دوبار: خروج',pg.evaluate("!S.me&&localStorage.getItem('bp3s')===null"))
    ctx.close()
    ctx,pg=boot(sess(),'ok')
    pg.evaluate("document.body.insertAdjacentHTML('beforeend','<i id=o data-a=out></i>')");pg.evaluate("document.getElementById('o').click()");pg.wait_for_timeout(300)
    chk('11 خروج دستی پاک می‌کند',pg.evaluate("localStorage.getItem('bp3s')===null&&!S.me"))
    ctx.close()
    ctx,pg=boot(None,'down')
    chk('12 بدون ذخیره: مهمان',pg.evaluate("!S.me"))
    chk('بدون خطا',not errs);print(errs);ctx.close();br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
