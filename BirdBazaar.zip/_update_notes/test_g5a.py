# تست 1.9.410 G5-a: «امروز» و ۴ کاشی داشبورد غرفه‌دار (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'off -> empty',pg.evaluate("(XF.pn=0,pnToday()==='')"))
        pg.evaluate("XF.pn=1;XF.cd=1;XF.cg=1;XF.pq=1")
        chk(t+'tiles 4',pg.evaluate("(pnToday().match(/pnkT/g)||[]).length==4"))
        chk(t+'no BOR -> dash',pg.evaluate("(BOR=null,pnToday().includes('—'))"))
        chk(t+'counts',pg.evaluate("""(()=>{BOR=[{s:'new'},{s:'new',pay:{s:'sent'}},{s:'new',pay:{s:'ok'}},{s:'new',pay:{s:'ok'},cr:{s:'rdy'}},{s:'done'},{s:'new',pk:{h:1}}];const h=pnToday();const n=[...h.matchAll(/<b>([^<]+)<\\/b><span>([^<]+)<\\/span>/g)].map(m=>m[2]+':'+m[1]);return n.join('|')})()""")!='' )
        r=pg.evaluate("""(()=>{BOR=[{s:'new'},{s:'new',pay:{s:'sent'}},{s:'new',pay:{s:'ok'}},{s:'new',pay:{s:'ok'},cr:{s:'rdy'}},{s:'done'},{s:'new',pk:{h:1}}];const d=document.createElement('div');d.id='scr';d.innerHTML=pnToday();document.body.appendChild(d);const v=[...d.querySelectorAll('.pnkN')].map(x=>x.innerText.replace(/\\s+/g,' ')).join('|');return v})()""")
        print(r)
        chk(t+'count values',r=='۵ جدید|۱ منتظر پرداخت|۱ آماده ارسال')
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        pg.screenshot(path='/tmp/g5_%d.png'%w) if w==360 else None
        ctx.close()
    br.close()
print('ERRORS',errs)
