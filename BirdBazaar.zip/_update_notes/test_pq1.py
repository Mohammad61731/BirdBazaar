# تست 1.9.407 G4-b: پرداخت کارت‌به‌کارت (کلید pq)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'off by default',pg.evaluate("XF.pq=0;pqOn()")==False and pg.evaluate("pqOwnH({id:1,s:'new'})")=='')
        pg.evaluate("XF.pn=1;XF.cd=1;XF.cg=1;XF.pq=1")
        if not pg.evaluate("pqOn()"):
            print('SKIP pqOn false');ctx.close();continue
        chk(t+'owner: sent has buttons',pg.evaluate("const h=pqOwnH({id:5,s:'new',pay:{s:'sent',rc:'123'}});h.includes('data-a=\"pqok\"')&&h.includes('data-a=\"pqrj\"')"))
        chk(t+'owner: ok has no buttons',pg.evaluate("!pqOwnH({id:5,s:'new',pay:{s:'ok'}}).includes('pqok')"))
        chk(t+'owner: in-person hidden',pg.evaluate("pqOwnH({id:5,s:'new',pk:{h:2}})")=='')
        pg.evaluate("PQS={id:1,total:250000,card:{n:'6037997112345678',h:'علی'},pay:null};pqSheet()");pg.wait_for_timeout(200)
        chk(t+'sheet shows card+form',pg.locator('#ov').inner_text().count('6037')>=0 and pg.locator('#ov #pqr').count()==1 and pg.locator('#ov [data-a=pqs]').count()==1)
        pg.evaluate("PQS.pay={s:'sent',rc:'x'};pqSheet()");pg.wait_for_timeout(100)
        chk(t+'sent: no form',pg.locator('#ov #pqr').count()==0)
        chk(t+'no overflow',pg.evaluate("(()=>{const s=document.querySelector('#ov .sheet');return s.scrollWidth<=s.clientWidth+1})()"))
        ctx.close()
print('ERRORS',errs)
