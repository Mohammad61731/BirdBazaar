# تست 1.9.285: LG5 هدر شیشه‌ای و جستجوی کپسولی
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const a=document.getElementById('app'),t=getComputedStyle(document.getElementById('top')),s=getComputedStyle(document.getElementById('scr')),h=document.querySelector('#scr .hsr'),hs=h?getComputedStyle(h):null;return {tb:t.backdropFilter,sm:s.maskImage||s.webkitMaskImage,hr:hs?parseFloat(hs.borderTopLeftRadius):-1,hb:hs?hs.backdropFilter:'',ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();go({tab:0,v:null})"%m);pg.wait_for_timeout(600)
                r=pg.evaluate(Q)
                if m!='m':
                    chk(t+'top glass blur',('blur' in (r['tb'] or '')))
                    chk(t+'scr edge mask',('gradient' in (r['sm'] or '')))
                    chk(t+'search capsule',r['hr']>=30 and 'blur' in (r['hb'] or ''))
                    pg.evaluate("document.getElementById('app').dataset.lp='1'");pg.wait_for_timeout(200)
                    chk(t+'low-power no blur',pg.evaluate("getComputedStyle(document.getElementById('top')).backdropFilter")=='none')
                    if w==360:
                        pg.evaluate("delete document.getElementById('app').dataset.lp");pg.wait_for_timeout(200)
                        pg.screenshot(path='/tmp/lg5_%s_%s.png'%(m,'d' if dark else 'l'))
                else:
                    chk(t+'minimal untouched (no mask)',(r['sm'] or 'none') in ('none',''))
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
