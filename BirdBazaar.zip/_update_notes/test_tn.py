# تست 1.9.118: ریزعکس آواتار/لوگو/کاور — ساخت ، جایگزینی در نمایش ، خاموش ، پاک‌کردن ، ماندگاری ، بدون درخواست ، بدون سرریز ۳۶۰
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        reqs=[]
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            reqs.append(route.request.url)
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.add_init_script("localStorage.setItem('bp_tls',JSON.stringify({fw:0}))")
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1500)
        chk('default on', await pg.evaluate("tnOn()&&tlOn('tn')")==True)
        # عکس بزرگ نویزدار (تا فشرده شود)
        mk="""(()=>{const c=document.createElement('canvas');c.width=900;c.height=600;const x=c.getContext('2d');for(let i=0;i<4000;i++){x.fillStyle='hsl('+(i*7%360)+',70%,50%)';x.fillRect(Math.random()*900,Math.random()*600,40,40)}return c.toDataURL('image/jpeg',0.95)})()"""
        big=await pg.evaluate(mk)
        chk('big image made', len(big)>30000)
        n0=len(reqs)
        await pg.evaluate("(big)=>{window.__big=big;BT.ok=1;BT.booths=[{id:7,name:'غرفه',n:0,logo:big,cover:big,city:'',bio:''}];BT.prods=[];FM.av={ali:big,sara:'data:image/png;base64,AAAA'};tnScan()}",big)
        await pg.wait_for_timeout(4500)
        st=await pg.evaluate("tnStat()")
        chk('3 tiny made (a,l,c) %s'%st, st['n']==3)
        chk('tnUse returns tiny (shorter)', await pg.evaluate("tnUse('l',7,__big).length<__big.length*0.6 && tnUse('c',7,__big).length<__big.length && tnUse('a','ali',__big).length<__big.length*0.5"))
        chk('small avatar untouched', await pg.evaluate("tnUse('a','sara',FM.av.sara)==FM.av.sara"))
        chk('changed source -> full (sig mismatch)', await pg.evaluate("tnUse('l',7,__big+'x')==__big+'x'"))
        chk('fAv uses tiny', await pg.evaluate("fAv('ali').length<__big.length*0.5"))
        chk('btLogo uses tiny', await pg.evaluate("btLogo(BT.booths[0]).length<__big.length*0.6"))
        chk('persisted to IDB', await pg.evaluate("idbGet('TN').then(s=>!!(s&&s.v==1&&s.l&&s.l[7]&&s.l[7].d))"))
        # نمایش در صفحه‌ی غرفه‌داران
        await pg.evaluate("document.getElementById('scr').innerHTML=booth()"); await pg.wait_for_timeout(600); chk('booth list shows tiny', await pg.evaluate("document.querySelector('#scr .bcv').style.backgroundImage.length<__big.length*0.6"))
        await pg.screenshot(path='/home/claude/bb/shots/tn_booths_360.png')
        chk('no overflow 360', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        chk('tlSec has row + count', 'ریزعکس آواتار' in await pg.evaluate("tlSec()") and 'ریزعکس ساخته‌شده' in await pg.evaluate("tlSec()"))
        # خاموش
        await pg.evaluate("tlSet('tn',0)")
        chk('off: full image', await pg.evaluate("tnUse('l',7,__big)==__big && fAv('ali').length>__big.length"))
        chk('off: tlTn empty', await pg.evaluate("tlTn()")=='')
        await pg.evaluate("tlSet('tn',1)")
        # پاک‌کردن
        await pg.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=tcl data-a=tn_clr></button>');document.getElementById('tcl').click()"); await pg.wait_for_timeout(300)
        chk('clear empties', (await pg.evaluate("tnStat()"))['n']==0)
        # ریزعکس نباید درخواست شبکه‌ای بسازد
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
