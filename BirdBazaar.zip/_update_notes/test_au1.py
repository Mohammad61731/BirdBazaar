# تست 1.9.459 D3-z: کلید au (ضمانت اصالت کالا ؛ 131)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        chk(t+'default off',pg.evaluate("XD.au===0&&!xf('au')"))
        chk(t+'off: no form/rows',pg.evaluate("BF={au:1};qzForm().indexOf('bfau')<0&&qzRows({au:1}).length==0"))
        pg.evaluate("XF.au=1")
        chk(t+'on: form has tick',pg.evaluate("BF={au:1};qzForm().indexOf('bfau')>0&&qzForm().indexOf('checked')>0"))
        chk(t+'on: row shown',pg.evaluate("qzRows({au:1}).some(r=>r[0]=='اصالت')&&qzRows({}).every(r=>r[0]!='اصالت')"))
        chk(t+'snap saves au',pg.evaluate("BF={name:'x',type:'plain',price:1,au:0};const d=document.createElement('div');d.innerHTML=qzForm();document.body.appendChild(d);document.getElementById('bfau').checked=true;btSnap();const ok=BF.au===1;d.remove();ok"))
        chk(t+'key in settings list',pg.evaluate("XL.some(r=>r[0]=='au')&&NEWF[0][2].includes('131')"))
        ctx.close()
print('ERRORS',errs)
