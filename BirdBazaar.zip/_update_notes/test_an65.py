# تست 1.9.314: AN65 کشیدن شیت برای بستن + AN66 چرخش آیکن رفرش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
TJ="""([sel,y0,y1,x1,steps])=>{const el=document.querySelector(sel);const mk=(t,y,x)=>{const tc=new Touch({identifier:1,target:el,clientX:x,clientY:y});return new TouchEvent(t,{touches:t=='touchend'?[]:[tc],changedTouches:[tc],bubbles:true,cancelable:true})};
const x0=180;el.dispatchEvent(mk('touchstart',y0,x0));for(let i=1;i<=steps;i++){el.dispatchEvent(mk('touchmove',y0+(y1-y0)*i/steps,x0+(x1-x0)*i/steps))}const tr=(document.querySelector('.sheet')||{style:{}}).style.transform;el.dispatchEvent(mk('touchend',y1,x1));return tr}"""
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm,has_touch=True);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            op=lambda:pg.evaluate("sheet('<h3>تست</h3><p>سلام</p>')")
            op();pg.wait_for_timeout(500)
            tr=pg.evaluate(TJ,['.sheet h3',500,530,180,6])
            if rm=='no-preference': chk(t+'small drag follows finger',tr.startswith('translateY'))
            pg.wait_for_timeout(400)
            chk(t+'small drag springs back (stays open)',pg.evaluate("ov.classList.contains('on')"))
            if rm=='no-preference':
                pg.evaluate(TJ,['.sheet h3',500,700,180,8]);pg.wait_for_timeout(600)
                chk(t+'long drag closes',not pg.evaluate("ov.classList.contains('on')"))
                op();pg.wait_for_timeout(500)
                pg.evaluate(TJ,['.sheet h3',500,640,420,8]);pg.wait_for_timeout(500)
                chk(t+'horizontal-ish drag does not close',pg.evaluate("ov.classList.contains('on')"))
            else:
                pg.evaluate(TJ,['.sheet h3',500,700,180,8]);pg.wait_for_timeout(500)
                chk(t+'reduced: no drag effect',pg.evaluate("ov.classList.contains('on')"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    # AN66 rotation
    ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR',reduced_motion='no-preference',has_touch=True);pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
    pg.evaluate("S.v=null;S.tab=0;render()");pg.wait_for_timeout(300)
    r=pg.evaluate("""()=>{const el=document.querySelector('#scr');const mk=(t,y)=>{const tc=new Touch({identifier:1,target:el,clientX:180,clientY:y});return new TouchEvent(t,{touches:t=='touchend'?[]:[tc],changedTouches:[tc],bubbles:true,cancelable:true})};
el.dispatchEvent(mk('touchstart',200));el.dispatchEvent(mk('touchmove',300));return document.getElementById('ptr').style.transform}""")
    chk('ptr rotates while pulling',('rotate(' in (r or '')) or r=='')
    print('ptr transform:',r)
    ctx.close()
    br.close()
print('ERRORS',errs[:8])
