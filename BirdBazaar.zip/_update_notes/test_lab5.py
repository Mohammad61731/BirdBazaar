# تست 1.9.500: LAB-4 چک‌لیست تست‌شده + پایان دمو
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def clk(pg,a,v=''):
    pg.evaluate("([a,v])=>{const b=document.createElement('button');b.dataset.a=a;b.dataset.v=v;document.body.appendChild(b);b.click();b.remove()}",[a,v]);pg.wait_for_timeout(150)
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
def txt(pg): return pg.evaluate("document.getElementById('ovc').innerText")
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("localStorage.removeItem('bp_lab');LAB={};S.role='admin';S.pm=['all'];S.pvu=0")
        reqs=[]
        pg.on('request',lambda r:reqs.append(r.url) if ('rpc/' in r.url or 'supabase' in r.url) else None)
        pg.evaluate('render()');pg.wait_for_timeout(3500);reqs.clear()
        clk(pg,'lab','o');chk(t+'checklist box',('چه چیزی تست شد' in txt(pg)) and ('۰ از ۱۲' in txt(pg)))
        clk(pg,'lab','dm');chk(t+'dm marked',pg.evaluate("LAB.ck.dm==1&&LAB.ck.ba==1"))
        for v in ('nx','nx','nx','nx','nx','nx','nx'): clk(pg,'lab',v)
        chk(t+'flow marked',pg.evaluate("['bo','cf','rdy','acc','pick','way','done'].every(k=>LAB.ck[k]==1)"))
        clk(pg,'lab','ro:ow');chk(t+'role marked',pg.evaluate("LAB.ck.ro==1"))
        clk(pg,'lab','ad');clk(pg,'lab','ar');chk(t+'ad marked',pg.evaluate("LAB.ck.ad==1&&LAB.ck.ar==1"))
        chk(t+'12 of 12',('۱۲ از ۱۲' in txt(pg)))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360 and sch=='light':
            pg.evaluate("document.getElementById('ovc').scrollTop=1e5");pg.wait_for_timeout(200);pg.screenshot(path='/tmp/lab5_360.png')
        chk(t+'no server calls',len(reqs)==0) or print('  REQS',[r[:90] for r in reqs[:4]])
        clk(pg,'lab','de')
        chk(t+'end wipes all',pg.evaluate("Object.keys(LAB).length==0&&localStorage.getItem('bp_lab')===null&&!document.getElementById('labbar')"))
        clk(pg,'lab','o');chk(t+'checklist reset',('۰ از ۱۲' in txt(pg)))
        ctx.close()
    br.close()
print('ERRS',len(errs))
