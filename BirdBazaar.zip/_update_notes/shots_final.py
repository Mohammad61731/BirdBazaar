from playwright.sync_api import sync_playwright
def mk(br,scheme):
    ctx=br.new_context(viewport={'width':360,'height':740},locale='fa-IR',color_scheme=scheme);pg=ctx.new_page()
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(700)
    pg.evaluate("S.role='admin';S.me='m';S.pw='1';S.pm=['all'];D.cfg.guestAds=1;D.ads.forEach(a=>{a.st='ok'});if(D.ads[0]){D.ads[0].own='ali';D.ads[0].city='تهران'}");return pg
with sync_playwright() as p:
    br=p.chromium.launch()
    pg=mk(br,'light');pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_home_light.png')
    pg.evaluate("go({tab:1,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_store.png')
    pg.evaluate("go({tab:2,sub:0,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_ads.png')
    pg.evaluate("document.querySelector('#scr .ad').click()");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_ad_detail.png')
    pg=mk(br,'dark');pg.evaluate("go({tab:0,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_home_dark.png')
    pg.evaluate("go({tab:2,sub:0,v:null})");pg.wait_for_timeout(500);pg.screenshot(path='shots/f_ads_dark.png')
    br.close()
