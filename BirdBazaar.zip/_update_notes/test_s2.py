# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.sc=0;S.me='u1';BT.prods=[{id:1,b:1,s:'on',d:{name:'قفس',type:'plain',price:1000,emoji:'🪺'}}];BT.booths=[{id:1,name:'غرفه',phone:'0912',city:'سراوان'}];BC=[{p:1,m:'r',q:1}];BCF={n:'علی',p:'09121234567',a:'x'};MO.l=[{id:1,st:'new',it:[{id:1,n:'قفس',q:1}],tt:1000,dt:'2026-11-26 10:00'},{id:2,st:'done',it:[{id:1,n:'قفس',q:2}],tt:2000,dt:'2026-11-25 10:00'},{id:3,st:'x',it:[],tt:5,dt:'d'}];S.tab=3;S.v=null;S.cs='bt';SCT='c';render()");pg.wait_for_timeout(400)
        chk(t+'off: no tiles',pg.evaluate("!document.querySelector('#scr .sckst')"))
        pg.evaluate("XF.sc=1;render()");pg.wait_for_timeout(400)
        print(pg.evaluate("[scOnS(),!!document.querySelector('#scr .sckb'),document.querySelectorAll('#scr .sckst').length,document.querySelectorAll('#scr .sckst2').length]"));chk(t+'on: 4 tiles',pg.evaluate("document.querySelectorAll('#scr .sckst2').length==4"))
        chk(t+'counts',pg.evaluate("document.querySelectorAll('#scr .sckst2 .scki i').length==3"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:pg.screenshot(path='/tmp/s2_360.png')
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='sctl';b.dataset.v='done';document.getElementById('scr').appendChild(b);b.click()})()");pg.wait_for_timeout(400)
        chk(t+'tile -> filtered list',pg.evaluate("S.v=='mo'&&PNMF=='done'&&document.querySelectorAll('#scr .bzoc').length==1"))
        chk(t+'list no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:pg.screenshot(path='/tmp/s2_mo_360.png')
        ctx.close()
print('ERRORS',errs)
