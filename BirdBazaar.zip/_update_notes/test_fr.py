# تست 1.9.117: نشانگر تازگی — متن/رنگ بر اساس دقیقه ؛ آفلاین ؛ خاموش ؛ بدون درخواست ؛ بدون سرریز ۳۶۰
import asyncio, sys
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print('PASS' if c else 'FAIL',n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':760},locale='fa-IR'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        reqs=[]
        async def h(route):
            if route.request.url.startswith('file:'): return await route.continue_()
            reqs.append(route.request.url)
            try: await route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
            except Exception: pass
        await pg.add_init_script("localStorage.setItem('bp_tls',JSON.stringify({fw:0}))")
        await pg.route('**/*',h)
        await pg.goto('file://'+ROOT+'/www/index.html'); await pg.wait_for_timeout(1500)
        chk('default on', await pg.evaluate("frOn()&&tlOn('fr')")==True)
        n=await pg.evaluate("Date.now()")
        r=await pg.evaluate("(()=>{const n=Date.now(),o=[];SF.t.pr=n-10000;o.push(frH('pr'));SF.t.pr=n-5*60000;o.push(frH('pr'));SF.t.pr=n-30*60000;o.push(frH('pr'));delete SF.t.pr;o.push(frH('pr'));return o})()")
        chk('now green', '🟢' in r[0] and 'همین الان' in r[0])
        chk('5min yellow', '🟡' in r[1] and '۵ دقیقه' in r[1])
        chk('30min red', '🔴' in r[2] and '۳۰ دقیقه' in r[2])
        chk('unknown: empty', r[3]=='')
        await pg.evaluate("SF.t.pr=Date.now()-120000;tlSet('fr',0)")
        chk('off: empty', await pg.evaluate("frH('pr')")=='')
        await pg.evaluate("tlSet('fr',1)")
        # در صفحه‌ی ویترین و آگهی‌ها
        n0=len(reqs)
        await pg.evaluate("go({tab:1})"); await pg.wait_for_timeout(500)
        chk('store shows chip', await pg.evaluate("!!document.querySelector('#scr .frs')"))
        await pg.screenshot(path='/home/claude/bb/shots/fr_store_360.png')
        await pg.evaluate("go({tab:2})"); await pg.wait_for_timeout(500)
        chk('ads shows chip', await pg.evaluate("!!document.querySelector('#scr .frs')"))
        chk('no overflow 360', not await pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
        chk('home has no chip', (await pg.evaluate("go({tab:0})") or True) and not await pg.evaluate("!!document.querySelector('#scr .frs')"))
        chk('tlSec has row', 'نشانگر تازگی' in await pg.evaluate("tlSec()"))
        chk('no page errors', not errs)
        if errs: print(errs[:3])
        await b.close()
    print('ALL OK' if ok else 'SOME FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
