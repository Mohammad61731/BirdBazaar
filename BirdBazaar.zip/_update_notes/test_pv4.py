# تست 1.9.267 P87 منوی کناری گروه‌بندی + P42 کارت غرفه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            ctx=br.new_context(viewport={'width':w,'height':760},locale='fa-IR',color_scheme='dark' if dark else 'light')
            pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
            pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
            pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
            pg.evaluate("drawer()");pg.wait_for_timeout(200)
            chk(f'{w}/{dark}: drawer groups',pg.locator('.drw .dsh').count()>=3 and pg.locator('.drw .it').count()>=7)
            chk(f'{w}/{dark}: drawer no overflow',pg.evaluate("(()=>{const d=document.querySelector('.drw');return d.scrollWidth<=d.clientWidth+1})()"))
            if w==360 and not dark: pg.screenshot(path='/tmp/p87.png')
            pg.evaluate("cl&&cl()");pg.evaluate("S.tab=0;S.v=null;render();try{btFresh()}catch(e){}");pg.wait_for_timeout(1500)
            n=pg.locator('#scr .hs .bm').count()
            chk(f'{w}/{dark}: booth cards {n}',n>=1)
            if n:
                chk(f'{w}/{dark}: booth card no overflow',pg.evaluate("(()=>{const e=document.querySelector('#scr .hs .bm');const r=e.getBoundingClientRect();return r.width>60&&r.width<110&&e.scrollWidth<=e.clientWidth+1})()"))
                if w==360 and not dark: pg.locator('#scr .hs .bm').first.scroll_into_view_if_needed();pg.screenshot(path='/tmp/p42.png')
            ctx.close()
    br.close()
print('ERRORS',errs)
