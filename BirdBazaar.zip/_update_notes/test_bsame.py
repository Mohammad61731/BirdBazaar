# تست 1.9.78: وقتی مهر غرفه/پرنده عوض نشده، bpull/rpull دوباره دانلود نمی‌کنند؛ با تغییر مهر دانلود می‌کنند
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        calls=[]; st={'b':'B1'}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if u.startswith('http'):
                try: j=json.loads(bd)
                except Exception: j={}
                op=j.get('op'); calls.append(op)
                if op=='psig': body={'ok':1,'s':'S1','b':st['b']}
                elif op=='bpub2': body={'ok':1,'booths':[{'id':1,'name':'b','bio':'','logo':'','cover':'','city':'','phone':'','views':1,'n':0}],'prods':[]}
                elif op=='rpub2': body={'ok':1,'birds':[]}
                else: body={'ok':1,'n':0,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(body))
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.evaluate("localStorage.removeItem('bp_psigb');BT.ok=0;BDL.ok=0"); calls.clear()
        await pg.evaluate("bpull()"); await pg.wait_for_timeout(900)
        c1=[c for c in calls if c in('bpub2','rpub2')]; print('first load:',c1); ok&= c1.count('bpub2')==1 and c1.count('rpub2')==1
        calls.clear(); await pg.evaluate("bpull();rpull()"); await pg.wait_for_timeout(900)
        c2=[c for c in calls if c in('bpub2','rpub2')]; print('same stamp:',c2); ok&= c2==[]
        st['b']='B2'; calls.clear(); await pg.evaluate("bpull()"); await pg.wait_for_timeout(900)
        c3=[c for c in calls if c in('bpub2','rpub2')]; print('changed stamp:',c3); ok&= c3.count('bpub2')==1 and c3.count('rpub2')==1
        print('errors',errs); ok&=not errs
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
