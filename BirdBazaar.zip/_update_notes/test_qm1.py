# تست 1.9.469: پیام‌های آماده‌ی پیک (کلید qm)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360):
        ctx=br.new_context(viewport={'width':w,'height':700},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1800)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        X="{s:'way',phone:'۰۹۱۲۳۴۵۶۷۸۹',bp:'09120000000',b:1}"
        chk(f'{w}: off -> empty',pg.evaluate(f"qmH({X})==='' "))
        pg.evaluate("XF.qm=1")
        chk(f'{w}: way -> customer chips only',pg.evaluate(f"(()=>{{const h=qmH({X});return h.includes('sms:09123456789?body=')&&!h.includes('sms:09120000000')}})()"))
        chk(f'{w}: acc -> shop chips only',pg.evaluate("(()=>{const h=qmH({s:'acc',phone:'09123456789',bp:'09120000000'});return h.includes('sms:09120000000')&&!h.includes('sms:09123456789')})()"))
        chk(f'{w}: done -> none',pg.evaluate("qmH({s:'done',phone:'0912',bp:'0912'})===''"))
        chk(f'{w}: no phone -> no crash',pg.evaluate("qmH({s:'way'})===''"))
        pg.evaluate(f"document.getElementById('scr').innerHTML='<div style=\"padding:10px\">'+qmH({X})+'</div>'");pg.wait_for_timeout(200)
        chk(f'{w}: 5 chips',pg.locator('#scr a.chip').count()==5)
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360: pg.screenshot(path='/tmp/qm360.png')
    br.close()
print('ERRORS',errs)
