# تست 1.9.369: نقشه‌ی سراوان آنلاین/آفلاین
import json,base64
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')
T=[]
def tile(route,req):
    T.append(req.url);route.fulfill(status=200,content_type='image/png',body=PNG,headers={'access-control-allow-origin':'*'})
G={1:{'id':1,'lvl':1,'rm':0,'acc':'x','la':27.3127,'ln':62.3342,'hrs':{},'ad':''}}
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR');pg=ctx.new_page();T.clear();t=str(w)+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.route('**/tile.openstreetmap.org/**',tile)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        pg.evaluate("S.tab=1;S.v=null;render()");pg.wait_for_timeout(300)
        chk(t+'off: no map button',pg.evaluate("!document.querySelector('[data-cg=map]')"))
        pg.evaluate("XF.cg=1;cgSaveC({t:Date.now(),g:%s});render()"%json.dumps(G));pg.wait_for_timeout(500)
        pg.evaluate("S.tab=0;S.v=null;render()");pg.wait_for_timeout(500)
        chk(t+'map button in booth section',pg.evaluate("booth().includes('data-cg=\"map\"')"))
        pg.evaluate("btNav({v:'btmap'})");pg.wait_for_timeout(900)
        chk(t+'map container',pg.evaluate("!!document.getElementById('cgmv')"))
        n=pg.evaluate("document.querySelectorAll('#cgml .cgtl').length")
        chk(t+'tiles drawn %d'%n,n>=4 and len(T)>=4)
        chk(t+'tile url z14',any('/14/' in u for u in T))
        chk(t+'pin shown',pg.evaluate("document.querySelectorAll('#cgmk .cgpin').length")==1)
        x0=pg.evaluate("CGMS.x")
        pg.evaluate("try{let n=document.getElementById('fwr');while(n&&n.parentNode!==document.body)n=n.parentNode;n&&n.remove()}catch(e){}");pg.locator('#cgmv').scroll_into_view_if_needed();pg.wait_for_timeout(200);box=pg.locator('#cgmv').bounding_box();print('BOX',box)
        pg.mouse.move(box['x']+box['width']/2,box['y']+box['height']/3);pg.mouse.down();pg.mouse.move(box['x']+box['width']/2-60,box['y']+box['height']/3+10,steps=5);pg.mouse.up();pg.wait_for_timeout(200)
        print('PAN',x0,pg.evaluate('CGMS.x'));chk(t+'pan moves',abs(pg.evaluate('CGMS.x')-(x0+60))<3)
        pg.locator('[data-cg=zi]').dispatch_event('click');pg.wait_for_timeout(400)
        chk(t+'zoom in',pg.evaluate("CGMS.z")==15 and any('/15/' in u for u in T))
        pg.locator('[data-cg=zo]').dispatch_event('click');pg.locator('[data-cg=home]').dispatch_event('click');pg.wait_for_timeout(200)
        chk(t+'zoom out + home',pg.evaluate("CGMS.z")==14 and abs(pg.evaluate("CGMS.y")-cgWy(27.3127,14) if False else 0)<1)
        chk(t+'no h-overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        chk(t+'map inside screen',pg.evaluate("(()=>{const r=document.getElementById('cgmv').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1})()"))
        T.clear();T_before=0
        pg.locator('[data-cg=dl]').dispatch_event('click')
        pg.wait_for_function("document.getElementById('cgdp').textContent.includes('✅')",timeout=60000)
        chk(t+'download done (%d tiles)'%len(T),100<len(T)<400 and pg.evaluate("JSON.parse(localStorage.getItem('bp_cgoff')).n")>=len(T))
        chk(t+'dl button restored',pg.evaluate("document.getElementById('cgdb').textContent.includes('دانلود')"))
        pg.locator('[data-cg=mk]').dispatch_event('click');pg.wait_for_timeout(400)
        chk(t+'pin opens booth',pg.evaluate("S.v=='bts'&&S.id==1"))
        ctx.close()
    # sw keeps bp-tiles
    sw=open('/home/claude/bb/www/sw.js',encoding='utf8').read()
    chk("sw keeps bp-tiles","x!=='bp-tiles'" in sw)
    br.close()
print('ERRORS',errs)
