# تست 1.9.270 P6+P73: جست‌وجوی تمام‌صفحه
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(1500)
        pg.evaluate("(()=>{const s=document.getElementById('spl');if(s)s.remove()})()")
        pg.evaluate("localStorage.setItem('bp_rs',JSON.stringify(['قناری']));render()");pg.wait_for_timeout(300)
        ok=pg.evaluate("(()=>{const e=document.querySelector('.hsr');return !!e&&e.dataset.a==='sfo'})()")
        if not ok:
            pg.evaluate("sfoOpen()")
        else:
            pg.evaluate("document.querySelector('.hsr').click()")
        pg.wait_for_timeout(500)
        chk(f'{w}: overlay open',pg.locator('#ov.on .sfo').count()==1)
        chk(f'{w}: recents shown',pg.locator('#sfr .chip').count()>=1)
        chk(f'{w}: input focused',pg.evaluate("document.activeElement&&document.activeElement.id==='sfq'"))
        name=pg.evaluate("(D.products[0]||{}).name||''")
        if name:
            pg.fill('#sfq',name[:3]);pg.wait_for_timeout(200)
            chk(f'{w}: live rows',pg.locator('#sfr .sfr').count()>=1)
            chk(f'{w}: all-results btn',pg.locator('#sfr .sfa').count()==1)
            pg.click('#sfr .sfr >> nth=0');pg.wait_for_timeout(500)
            chk(f'{w}: row closes overlay',pg.locator('#ov.on').count()==0)
        pg.evaluate("sfoOpen()");pg.wait_for_timeout(300)
        pg.fill('#sfq','zzzzqq');pg.wait_for_timeout(200)
        chk(f'{w}: empty msg',pg.locator('#sfr .box').count()==1)
        pg.fill('#sfq','a');pg.keyboard.press('Enter');pg.wait_for_timeout(600)
        chk(f'{w}: enter -> store q',pg.evaluate("(document.getElementById('q')||{}).value")=='a')
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        if w==360:
            pg.evaluate("sfoOpen()");pg.wait_for_timeout(300);pg.fill('#sfq',name[:2] if name else 'ا');pg.wait_for_timeout(300)
            pg.screenshot(path='/tmp/sf2_360.png')
        ctx.close()
print('ERRORS',errs)
