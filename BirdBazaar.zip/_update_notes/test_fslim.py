# تست 1.9.50: بررسی‌های انجمن بدون آواتار/مدیا؛ مدیای محلی نمی‌پرد؛ مدیای ناشناخته با یک درخواست کامل جبران می‌شود
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w'
IMG='data:image/gif;base64,R0lGODlhAQABAAAAACw='
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        for w in (320,412):
            pg=await b.new_page(viewport={'width':w,'height':700}); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e)))
            calls=[]
            async def h(route):
                u=route.request.url
                if 'fapp' in u:
                    a=json.loads(route.request.post_data or '{}'); a=a.get('a',a)
                    calls.append(a)
                    nomd=a.get('nomd'); noav=a.get('noav')
                    msgs=[{'id':1,'u':'reza','k':'img','b':'','hm':True,'md':None if nomd else IMG,'t':'2026-11-14T09:00:00Z'},
                          {'id':2,'u':'sara','k':'text','b':'سلام','t':'2026-11-14T09:01:00Z'}]
                    return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},
                        body=json.dumps({'ok':1,'rooms':[{'id':1,'name':'عمومی','emoji':'🦜'}],'pins':[],'reqn':0,'av':{} if noav else {'reza':'x'},'msgs':msgs}))
                if u.startswith('http'): return await route.abort()
                return await route.continue_()
            await pg.route('**/*',h)
            await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(500)
            await pg.evaluate("()=>{S.me='ali';S.pw='x';FM.rooms=[{id:1,name:'عمومی',emoji:'🦜'}];FM.room=1;FM.msgs=[{id:1,u:'reza',k:'img',b:'',hm:true,md:'%s',t:'2026-11-14T09:00:00Z'}];go({v:'chat',id:1,fr:1})}"%IMG)
            await pg.wait_for_timeout(300); calls.clear()
            # 1) refresh: md محلی حفظ شود، فقط یک درخواست سبک
            await pg.evaluate("fRefresh()"); await pg.wait_for_timeout(500)
            md1=await pg.evaluate("FM.msgs.find(x=>x.id==1).md"); c1=list(calls)
            light=len(c1)==1 and c1[0].get('nomd') and c1[0].get('noav')
            # 2) refresh وقتی مدیای محلی نیست: یک درخواست کامل جبرانی
            calls.clear()
            await pg.evaluate("FM.msgs=[];fRefresh()"); await pg.wait_for_timeout(600)
            md2=await pg.evaluate("(FM.msgs.find(x=>x.id==1)||{}).md"); c2=list(calls)
            fb=len(c2)==2 and not c2[1].get('nomd')
            # 3) poll: noav، و آواتار ناشناخته فقط یک بار جدا گرفته شود
            calls.clear()
            await pg.evaluate("FM.msgs=[{id:0,u:'x',k:'text',b:'a',t:'2026-11-14T08:00:00Z'}];FM.av={};FM.avT={};fPoll()"); await pg.wait_for_timeout(600)
            c3=list(calls); pl=c3[0].get('noav')==1
            hs=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
            good=(md1==IMG) and light and (md2==IMG) and fb and pl and not hs and not errs
            ok&=good; print(w,'OK' if good else 'BAD',md1==IMG,light,md2==IMG,fb,pl,len(c3),hs,errs[:1])
            await pg.close()
        await b.close()
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
