# تست 1.9.291: LG11 چت
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
Q="(()=>{const o=document.querySelector('#scr .bb.out'),i=document.querySelector('#scr .bb.in'),c=document.querySelector('#scr .cin'),inp=document.querySelector('#scr .cin input'),sn=document.querySelector('#scr .cin .snd'),h=document.querySelector('#scr .chh');const g=e=>e&&getComputedStyle(e);return {or:o?parseFloat(g(o).borderTopLeftRadius):-1,ot:o?g(o).borderBottomRightRadius:'',ob:o?g(o).backgroundColor:'',ir:i?g(i).borderBottomLeftRadius:'',cb:c?g(c).backdropFilter:'',ir2:inp?parseFloat(g(inp).borderTopLeftRadius):-1,sw:sn?sn.getBoundingClientRect().width:-1,hb:h?g(h).backdropFilter:'',ov:document.documentElement.scrollWidth<=innerWidth+1}})()"
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light')
                pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile','msgs'].map(k=>[k,{m:'%s'}]));thApply();S.tab=2;S.v=null;S.id=0;S.fr=0;S.v='chat';render();thApply()"%m);pg.wait_for_timeout(700)
                r=pg.evaluate(Q)
                if m!='m' and r['or']>0:
                    chk(t+'out bubble 20 tail 6',r['or']==20 and r['ot']=='6px')
                    chk(t+'in tail 6',r['ir']=='6px')
                    chk(t+'input pill 20',r['ir2']==20)
                    chk(t+'send round 36',r['sw']==36)
                    chk(t+'bar glass','blur' in (r['cb'] or '') and 'blur' in (r['hb'] or ''))
                    if w==360 and m=='i': pg.screenshot(path='/tmp/lg11_%s.png'%('d' if dark else 'l'))
                elif m!='m': chk(t+'chat rendered',False)
                chk(t+'no overflow',r['ov'])
                ctx.close()
    br.close()
print('ERRORS',errs)
