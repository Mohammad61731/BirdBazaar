import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb';errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role='user';S.me='ali';D.ads=[{id:5,title:'عروس هلندی سالم',price:100,sp:'عروس هلندی',city:'قم',desc:'د',imgs:[],st:'ok',own:'r'},{id:6,title:'عروس پنهان',price:1,sp:'x',city:'',desc:'',imgs:[],st:'pending'}];D.guides=[{id:3,title:'جوجه‌کشی عروس',cat:'',text:'متن',img:'',video:''}];BT.booths=[{id:1,name:'غرفه عروس‌ها',city:'اراک',n:1,views:0}];BT.prods=[];BT.ok=1")
    pg.click('[data-a=srch]');pg.wait_for_timeout(300)
    chk('برگه‌ی جست‌وجو باز شد',pg.locator('#gsq').count()==1)
    chk('کمتر از ۲ حرف → راهنما','۲ حرف' in pg.inner_text('#gsr'))
    pg.fill('#gsq','عروس');pg.wait_for_timeout(300)
    t=pg.inner_text('#gsr');print(t.replace('\n',' | '))
    chk('آگهی منتشرشده هست و در انتظار نیست','عروس هلندی سالم' in t and 'پنهان' not in t)
    chk('غرفه و آموزش هست','غرفه عروس‌ها' in t and 'جوجه‌کشی عروس' in t)
    pg.fill('#gsq','ك'+'لسیم');pg.wait_for_timeout(300)
    chk('نرمال‌سازی ک/ی و محصول',pg.locator('.gsr').count()>=1)
    pg.fill('#gsq','zzzzq');pg.wait_for_timeout(300);chk('چیزی پیدا نشد','پیدا نشد' in pg.inner_text('#gsr'))
    pg.fill('#gsq','جوجه');pg.wait_for_timeout(300);pg.click('.gsr');pg.wait_for_timeout(500)
    chk('کلیک → صفحه‌ی آموزش و بسته شدن برگه',pg.evaluate("S.v")=='guide' and not pg.evaluate("document.getElementById('ov').classList.contains('on')"))
    pg.evaluate("go({v:null,tab:0})");pg.click('[data-a=srch]');pg.fill('#gsq','هلندی');pg.wait_for_timeout(300);pg.click('.gsr');pg.wait_for_timeout(500)
    chk('کلیک آگهی → صفحه‌ی آگهی',pg.evaluate("S.v")=='ad' and pg.evaluate("S.id")==5)
    pg.evaluate("go({v:null,tab:0})");pg.click('[data-a=srch]');pg.fill('#gsq','غرفه');pg.wait_for_timeout(300);pg.click('.gsr');pg.wait_for_timeout(500)
    chk('کلیک غرفه',pg.evaluate("S.v")=='bts')
    pg.evaluate("go({v:null,tab:0})");pg.click('[data-a=srch]');pg.fill('#gsq','عروس');pg.wait_for_timeout(300);pg.screenshot(path=P+'/shots/p2.png')
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th)
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth || document.querySelector('.sheet').scrollWidth>document.querySelector('.sheet').clientWidth"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
