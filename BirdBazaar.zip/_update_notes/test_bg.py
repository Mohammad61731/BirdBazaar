# تست 1.9.68: پولینگ پس‌زمینه وقتی برنامه مخفی یا بی‌فعالیت است متوقف می‌شود
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/bb'
INIT = "window.__iv=[];const _si=window.setInterval;window.setInterval=function(f,m){window.__iv.push({f,m});return _si.apply(this,arguments)}"
async def main():
    ok=True
    async with async_playwright() as pw:
        b=await pw.chromium.launch()
        pg=await b.new_page(viewport={'width':360,'height':700})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)+' | '+str(getattr(e,'stack',''))[:600]))
        cnt={'m':0,'c':0}
        async def h(route):
            u=route.request.url; bd=route.request.post_data or ''
            if u.startswith('http'):
                if 'mcount' in bd: cnt['m']+=1
                if 'ccount' in bd: cnt['c']+=1
                return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps({'ok':1,'n':0,'msgs':[],'rooms':[],'products':[],'stories':[],'ads':[],'cms':{},'guides':[],'cats':[],'banners':[]}))
            return await route.continue_()
        await pg.route('**/*',h)
        await pg.add_init_script(INIT)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(2500)
        print('bgIdle:',await pg.evaluate("typeof bgIdle")); ok&=await pg.evaluate("typeof bgIdle=='function'")
        await pg.evaluate("S.me='u1'")
        n=await pg.evaluate("__iv.filter(x=>x.m==120000).length"); print('120s intervals:',n); ok&=n>=2
        # بی‌فعالیت: نباید درخواست برود
        await pg.evaluate("LV.act=Date.now()-400000")
        m0,c0=cnt['m'],cnt['c']
        await pg.evaluate("__iv.filter(x=>x.m==120000).forEach(x=>x.f())"); await pg.wait_for_timeout(800)
        print('idle calls:',cnt['m']-m0,cnt['c']-c0); ok&=(cnt['m']-m0==0 and cnt['c']-c0==0)
        # فعال: باید درخواست برود
        await pg.evaluate("LV.act=Date.now()")
        m0,c0=cnt['m'],cnt['c']
        await pg.evaluate("__iv.filter(x=>x.m==120000).forEach(x=>x.f())"); await pg.wait_for_timeout(800)
        print('active calls:',cnt['m']-m0,cnt['c']-c0); ok&=(cnt['m']-m0>=1 and cnt['c']-c0>=1)
        # بیدار شدن با لمس بعد از بی‌فعالیتی طولانی ← فوراً شمارنده‌ها
        await pg.evaluate("LV.act=Date.now()-400000")
        m0,c0=cnt['m'],cnt['c']
        await pg.evaluate("document.body.dispatchEvent(new Event('click',{bubbles:true}))"); await pg.wait_for_timeout(900)
        print('wake calls:',cnt['m']-m0,cnt['c']-c0); ok&=(cnt['m']-m0>=1 and cnt['c']-c0>=1)
        m0=cnt['m']
        await pg.evaluate("document.body.dispatchEvent(new Event('click',{bubbles:true}))"); await pg.wait_for_timeout(600)
        print('second touch no extra:',cnt['m']-m0); ok&=(cnt['m']-m0==0)
        # مخفی: bgIdle درست
        h1=await pg.evaluate("(()=>{Object.defineProperty(document,'hidden',{get:()=>true,configurable:true});return bgIdle()})()")
        print('hidden->idle:',h1); ok&=h1
        print('errors',errs); ok&=not errs
    print('PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)
asyncio.run(main())
