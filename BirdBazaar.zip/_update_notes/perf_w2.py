import time,threading,os
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from playwright.sync_api import sync_playwright
ROOT={'r':''}
class H(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_GET(self):
        if self.path.startswith('/font') or self.path.startswith('/api'):
            time.sleep(3.0 if self.path.startswith('/font') else 1.5)
            css=self.path.startswith('/font');b=b'/*x*/' if css else b'{"err":"x"}'
            self.send_response(200);self.send_header('Content-Type','text/css' if css else 'application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
        f=ROOT['r']+'/www'+(self.path.split('?')[0] if self.path!='/' else '/index.html')
        if not os.path.isfile(f):self.send_response(404);self.end_headers();return
        b=open(f,'rb').read();ct='text/html' if f.endswith('.html') else 'application/javascript' if f.endswith('.js') else 'application/octet-stream'
        self.send_response(200);self.send_header('Content-Type',ct);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    do_POST=do_GET
srv=ThreadingHTTPServer(('127.0.0.1',8765),H);threading.Thread(target=srv.serve_forever,daemon=True).start()
def run(label,root):
    ROOT['r']=root
    with sync_playwright() as p:
        br=p.chromium.launch();ctx=br.new_context(viewport={'width':360,'height':780},locale='fa-IR',service_workers='block');pg=ctx.new_page()
        def h(r,q):
            if q.url.startswith('http://127.0.0.1'):return r.continue_()
            r.fulfill(response=ctx.request.get('http://127.0.0.1:8765/'+('font' if 'fonts.' in q.url else 'api')))
        pg.route('**/*',h)
        pg.add_init_script("new MutationObserver(()=>{const s=document.querySelector('#scr');if(s&&s.children.length&&!window.__fc)window.__fc=performance.now()}).observe(document,{childList:true,subtree:true})")
        pg.goto('http://127.0.0.1:8765/',wait_until='commit')
        pg.wait_for_function("window.__fc",timeout=30000);fc=pg.evaluate("window.__fc")
        pg.wait_for_function("document.readyState=='complete'",timeout=30000);ld=pg.evaluate("performance.now()")
        print(f'{label}: first content {fc/1000:.2f}s | load complete {ld/1000:.2f}s');br.close()
run('before','/tmp/before');run('after','/home/claude/bb')
