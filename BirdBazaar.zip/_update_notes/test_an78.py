# تست 1.9.324: AN78 تیتر هیرو کلمه‌به‌کلمه (anHero) + AN79 خوش‌آمد ثبت‌نام (anWelcome)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for rm in ('no-preference','reduce'):
            ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',reduced_motion=rm);pg=ctx.new_page()
            pg.set_default_timeout(8000)
            pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
            t=f"{w} {rm} "
            pg.evaluate("const o=Element.prototype.animate;window.__an=0;Element.prototype.animate=function(...a){window.__an++;return o.apply(this,a)};const sc=document.createElement('div');sc.id='tsc';sc.innerHTML='<div class=\"hero\"><h2>به بازارچه خوش آمدی عزیز</h2><p>x</p></div>';document.body.appendChild(sc);anHeroK=null;0")
            pg.evaluate("window.__an=0;anHero(document.getElementById('tsc'),'k1')")
            n=pg.evaluate("window.__an");tx=pg.evaluate("document.querySelector('#tsc .hero h2').textContent")
            chk(t+'h2 text intact',tx=='به بازارچه خوش آمدی عزیز')
            if rm=='no-preference': chk(t+'5 words animate',n==5 and pg.evaluate("document.querySelectorAll('#tsc .hero h2 span').length")==5)
            else: chk(t+'reduced: no anim',n==0)
            pg.evaluate("window.__an=0;anHero(document.getElementById('tsc'),'k1')")
            chk(t+'same page no repeat',pg.evaluate("window.__an")==0)
            pg.evaluate("window.__an=0;anWelcome('علی')")
            n=pg.evaluate("window.__an")
            if rm=='no-preference':
                chk(t+'welcome shows',pg.evaluate("!!document.getElementById('anwl')") and n>=12)
                pg.evaluate("window.__an=0;anWelcome('x')");chk(t+'welcome once',pg.evaluate("window.__an")==0)
                pg.wait_for_timeout(2000);chk(t+'welcome removed',pg.evaluate("!document.getElementById('anwl')"))
            else: chk(t+'reduced: no welcome',n==0 and pg.evaluate("!document.getElementById('anwl')"))
            chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
            ctx.close()
    br.close()
print('ERRORS',errs[:8])
