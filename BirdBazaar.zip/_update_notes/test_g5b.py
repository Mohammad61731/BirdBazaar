# تست 1.9.411 G5-b: تخفیف سریع و کپی کالا (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.on('dialog',lambda d:d.accept())
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.pn=0")
        chk(t+'off -> empty',pg.evaluate("pnQd({id:1,d:{disc:5}})===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'4 chips, active 10',pg.evaluate("(()=>{const h=pnQd({id:1,d:{disc:10}});return (h.match(/data-a=\"pnqd\"/g)||[]).length==4&&h.includes('chip on\" data-a=\"pnqd\" data-v=\"1:10\"')})()"))
        pg.evaluate("BM={booth:{id:1},prods:[{id:7,s:'on',d:{name:'دانه',type:'plain',price:100,imgs:[],pin:1}}]}")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pncp';b.dataset.v='7';document.getElementById('scr').appendChild(b);b.click()})()")
        pg.wait_for_timeout(300)
        chk(t+'copy form',pg.evaluate("!!BF&&BF.id===0&&BF.name==='دانه (کپی)'&&!BF.pin&&BF.price==100"))
        pg.evaluate("""BM={booth:{id:1},prods:[{id:7,s:'on',d:{name:'x',type:'plain',price:100,imgs:[]}}]};window.__c='';window.fetch=(u,o)=>{try{window.__c+=String(o&&o.body)}catch(e){}return Promise.resolve(new Response(JSON.stringify({ok:1}),{status:200,headers:{'content-type':'application/json'}}))}""")
        pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='pnqd';b.dataset.v='7:20';document.getElementById('scr').appendChild(b);b.click()})()")
        pg.wait_for_timeout(500)
        print(pg.evaluate("window.__c.slice(0,200)"))
        chk(t+'quick discount sends bprod_set disc 20',pg.evaluate("window.__c.includes('bprod_set')&&window.__c.includes('\"disc\":20')"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
