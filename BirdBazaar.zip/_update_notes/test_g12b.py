# تست 1.9.429 G12-b: راهنمای شروع + خلاصه‌ی امروز (کلید pn)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("localStorage.clear();XF.pn=0;BOR=null;BM={booth:{name:'تست'},prods:[]}")
        chk(t+'off -> empty',pg.evaluate("pnGuide()===''"))
        pg.evaluate("XF.pn=1")
        chk(t+'no products: all unchecked',pg.evaluate("(()=>{const h=pnGuide();return h.includes('⬜ ثبت اولین کالا')&&h.includes('pngd')})()"))
        pg.evaluate("BM.prods=[{id:1,d:{name:'x'}}]")
        chk(t+'product checked',pg.evaluate("pnGuide().includes('✅ ثبت اولین کالا')&&pnGuide().includes('⬜ گرفتن اولین سفارش')"))
        pg.evaluate("localStorage.setItem('bp_crh',JSON.stringify({f:9,t:17}));BOR=[{id:1,s:'new',t:Date.now(),total:100}]")
        chk(t+'all done -> hidden',pg.evaluate("pnGuide()===''"))
        pg.evaluate("BOR=null;localStorage.removeItem('bp_crh')")
        def click(a,v='0'):
            pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='%s';b.dataset.v='%s';document.getElementById('scr').appendChild(b);b.click()})()"%(a,v));pg.wait_for_timeout(200)
        click('pngd')
        chk(t+'dismiss',pg.evaluate("pnGuide()===''"))
        pg.evaluate("BOR=[{id:1,s:'new',t:Date.now(),total:100},{id:2,s:'done',t:Date.now(),total:300},{id:3,s:'cancel',t:Date.now(),total:900},{id:4,s:'done',t:Date.now()-3*864e5,total:777}]")
        chk(t+'day summary counts today only, excludes cancelled from total',pg.evaluate("(()=>{const x=pnExT('d');return x.includes('سفارش: ۳')&&x.includes('جدید ۱')&&x.includes('لغو ۱')&&x.includes('جمع فروش: ۴۰۰')&&x.includes('تست')})()"))
        chk(t+'summary button shown',pg.evaluate("pnExp().includes('data-v=\"d\"')"))
        pg.evaluate("window._c=null;Object.defineProperty(navigator,'share',{value:undefined,configurable:true});navigator.clipboard.writeText=x=>{window._c=x;return Promise.resolve()}")
        click('pnex','d');pg.wait_for_timeout(200)
        chk(t+'copy works',pg.evaluate("!!window._c&&window._c.includes('خلاصه‌ی امروز')"))
        pg.evaluate("document.getElementById('scr').innerHTML='<div class=wrap>'+pnExp()+'</div>'")
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        ctx.close()
    br.close()
print('ERRORS',errs)
