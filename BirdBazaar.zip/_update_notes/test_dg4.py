# تست 1.9.504 DG4: آدرس و ارسال در سبد
import json
src=open('test_cg6.py',encoding='utf-8').read().split('with sync_playwright')[0]
exec(src)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
      for sch in ('light','dark'):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme=sch);pg=ctx.new_page();t=str(w)+sch[0]+' '
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle)
        pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900);pg.evaluate('XF.sc=1')
        bs=[{'id':i,'name':'غرفه %d'%i,'phone':'1','city':'س'} for i in (1,2)]
        pr=[PR(10+i,i,'کالا%d'%i,10) for i in (1,2)]
        pg.evaluate("BT.t=Date.now()+60000;BT.booths=%s;BT.prods=%s;BC=[{p:11,m:'r',q:2},{p:12,m:'r',q:2}]"%(json.dumps(bs),json.dumps(pr)))
        pg.evaluate("S.tab=1;btNav({v:'btc'})");pg.wait_for_timeout(400)
        chk(t+'address open when empty',pg.evaluate("document.querySelector('.bzad details').open&&!!document.getElementById('bcn')"))
        chk(t+'2 shipment cards',pg.evaluate("document.querySelectorAll('.bzas').length==2&&document.querySelector('.bzas b').textContent.includes('مرسوله')"))
        pg.fill('#bcn','علی');pg.fill('#bcp','09120000000');pg.fill('#bca','خیابان یک')
        pg.evaluate('btRe()');pg.wait_for_timeout(300)
        chk(t+'collapsed with summary after fill',pg.evaluate("!document.querySelector('.bzad details').open&&document.querySelector('.bzat small').textContent.includes('علی')&&document.getElementById('bcn').value=='علی'"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360 and sch=='light':
            pg.evaluate("document.querySelectorAll('.epg').forEach(e=>e.style.display='none');var q=document.getElementById('spl');if(q)q.style.display='none';document.querySelector('.bzad').scrollIntoView()");pg.screenshot(path='/tmp/claude-0/p/dg4_360.png')
        ctx.close()
    br.close()
print('ERRS',errs)
