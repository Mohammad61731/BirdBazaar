# تست 1.9.443 S2: کاشی‌های وضعیت سفارش
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
        pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
        t=str(w)+' '
        pg.evaluate("XF.cg=1;XF.sc=1;S.me='u1';BT.prods=[];BT.booths=[{id:1,name:'غ',phone:'0912',city:'س'}];BC=[];D.cart=[];localStorage.removeItem('bp_scl');MO.l=[{id:1,st:'new',it:[],tt:1,dt:'d'}];S.tab=3;S.v=null;S.cs='bt';SCT='c';render()");pg.wait_for_timeout(400)
        print(pg.evaluate("[document.querySelectorAll('#scr .bzem').length,document.querySelectorAll('#scr .sckst2').length,document.querySelector('#scr').innerText.slice(0,120)]"));chk(t+'empty state',pg.evaluate("!!document.querySelector('#scr .bzem')&&document.querySelectorAll('#scr .sckst2').length==4"))
        chk(t+'no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
        if w==360:
            pg.screenshot(path='/tmp/s3_360.png')
            pg.evaluate("document.getElementById('app').dataset.dk='1';document.documentElement.dataset.theme='dark'");pg.wait_for_timeout(300);pg.screenshot(path='/tmp/s3_dk.png')
        ctx.close()
print('ERRORS',errs)
