# تست 1.9.296: LG16 اسکلت/خالی شیشه‌ای
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append('FAIL '+n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        for dark in (0,1):
            for m in ('i','ice','m'):
                ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR',color_scheme='dark' if dark else 'light');pg=ctx.new_page()
                pg.add_init_script("try{localStorage.setItem('bp_tls','{\"fw\":0}')}catch(e){}")
                pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)));pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(900)
                t=str(w)+('d' if dark else 'l')+m+' '
                pg.evaluate("D.cms.TH=Object.fromEntries(['home','cart','store','ads','forum','profile'].map(k=>[k,{m:'%s'}]));thApply();S.tab=0;S.v=null;render()"%m);pg.wait_for_timeout(400)
                pg.evaluate("document.getElementById('scr').innerHTML='<div class=grid>'+skH(4)+'</div><div class=epg><div class=ept>خطا</div><button class=\"btn\">تلاش دوباره</button></div>'");pg.wait_for_timeout(300)
                r=pg.evaluate("(()=>{const c=document.querySelector('#scr .pc.sk'),l=c.querySelector('.skl'),a=getComputedStyle(l,'::after'),e=document.querySelector('#scr .epg');return {an:a.animationName,bd:getComputedStyle(c).borderTopWidth,eb:getComputedStyle(e).borderTopWidth,ov:document.documentElement.scrollWidth<=innerWidth}})()")
                chk(t+'no overflow',r['ov'])
                if m!='m':
                    chk(t+'shimmer',r['an']=='lgsk')
                    chk(t+'glass border',r['bd']=='1px' and r['eb']=='1px')
                else:
                    chk(t+'minimal untouched',r['an']!='lgsk')
                if w==360 and not dark and m=='i': pg.screenshot(path='/tmp/lg16.png')
                ctx.close()
    br.close()
print('ERRORS',errs)
