import json
from playwright.sync_api import sync_playwright
errs=[];seen=[]
def h(route,req):
    if req.url.endswith('/rpc/bapp'):
        b=json.loads(req.post_data);seen.append(b)
        if b['op'].startswith('badm_'):
            ok=b.get('u')=='admin' and b.get('p')=='pw1'
            r={'ok':1,'reqs':[{'id':7,'shop':'دان‌فروشی','name':'رضا','phone':'0912','city':'زاهدان','about':'x','status':'new'}],'booths':[]} if ok else {'err':'denied'}
        else:r={'ok':1,'booths':[],'prods':[]}
        return route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
    return route.fulfill(status=200,content_type='application/json',body='{"err":"x"}')
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        pg=br.new_context(viewport={'width':w,'height':780},locale='fa-IR').new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else h(r,q))
        pg.goto('file:///home/claude/w/www/index.html');pg.wait_for_timeout(600)
        seen.clear()
        pg.evaluate("S.role='admin';S.pm=['all'];S.me='admin';S.pw='pw1';go({tab:4,pnl:1,at:'bt',v:null})");pg.wait_for_timeout(900)
        adm=[b for b in seen if b['op']=='badm_list']
        r={'no_pw_card':pg.locator('#bak').count()==0,'badm_list_sent':len(adm)==1,'u_p_ok':bool(adm) and adm[0]['u']=='admin' and adm[0]['p']=='pw1','no_k':bool(adm) and 'k' not in (adm[0].get('a') or {}),'reqs_shown':pg.locator('[data-a=bt_ap]').count(),'no_logout_btn':pg.locator('[data-a=bt_ax]').count()==0,'overflow':pg.evaluate("document.documentElement.scrollWidth>innerWidth+1")}
        pg.evaluate("S.pw='bad';BAD=null;BT.al=0;btAdmLoad()");pg.wait_for_timeout(500)
        r['denied_toast']='رد شد' in pg.evaluate("document.body.innerText")
        pg.evaluate("S.pm=['p'];S.pw='pw1';render()");pg.wait_for_timeout(300)
        r['not_main_msg']='فقط برای ادمین اصلی' in pg.evaluate("document.body.innerText") or pg.evaluate("btAdminOn()")==False
        print(w,r)
    print('ERRORS',errs);br.close()
