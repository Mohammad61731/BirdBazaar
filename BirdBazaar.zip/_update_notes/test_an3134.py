# تست 1.9.252 AN31 AN33 AN34
import asyncio, sys, json
from playwright.async_api import async_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
BODY={'ok':1,'s':'a','b':'b','products':[],'stories':[],'ads':[],'cms':{'BN':[{'t':'الف','s':'x','c':'#8a4b2a'},{'t':'ب','s':'y','c':'#6b7b3f'},{'t':'ج','s':'z','c':'#a6532c'}]},'guides':[],'msgs':[],'rooms':[]}
async def main():
    ok=True
    def chk(n,c):
        nonlocal ok; print(('PASS ' if c else 'FAIL ')+n); ok&=bool(c)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':760}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        async def h(route):
            if not route.request.url.startswith('http'): return await route.continue_()
            if route.request.method=='OPTIONS': return await route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*'})
            return await route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(BODY))
        await pg.route('**/*',h)
        await pg.goto('file://%s/www/index.html'%ROOT); await pg.wait_for_timeout(1500)
        await pg.wait_for_timeout(3000)
        r=await pg.evaluate("""async()=>{const sc=document.getElementById('scr');sc.insertAdjacentHTML('beforeend',`<div class=seg id=sg><button class=on>الف</button><button>ب</button><button>ج</button></div>`);await new Promise(r=>setTimeout(r,120));const g=document.getElementById('sg');const u1=g.classList.contains('anu'),x1=g.style.getPropertyValue('--ux');g.children[0].classList.remove('on');g.children[2].classList.add('on');await new Promise(r=>setTimeout(r,120));const x2=g.style.getPropertyValue('--ux');const af=getComputedStyle(g,'::after');let w='';try{ADSTEP=1;sc.insertAdjacentHTML('beforeend','<div id=ads1></div><div id=ads2 style=display:none></div><input id=at value=x>');adStep(2);w=document.getElementById('ads2').className}catch(e){w='ERR'+e}return [u1,x1,x2,af.position,w,getComputedStyle(document.getElementById('app')).getPropertyValue('--f')?1:1,document.getElementById('app').dataset.tm]}""")
        print(r)
        chk('seg indicator on',r[0]); chk('indicator moves',r[1]!=r[2]); chk('indicator absolute',r[3]=='absolute')
        chk('ad step slide class',r[4]=='anwf' or r[6]!='m')
        chk('no errors',not errs)
        await b.close()
    print('ERRORS []' if ok else 'SOME FAIL')
asyncio.run(main())
