# تست 1.9.192: مدیریت آیکن‌ها (IC3)
src=open('test_booth_2.py',encoding='utf-8').read().split('errs=[]')[0]
exec(src)
errs=[]
from playwright.sync_api import sync_playwright
def chk(n,c):
    print(('PASS ' if c else 'FAIL ')+n)
    if not c: errs.append(n)
with sync_playwright() as p:
    br=p.chromium.launch()
    for w in (320,360,412):
        ctx=br.new_context(viewport={'width':w,'height':780},locale='fa-IR')
        pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',handle);pg.goto('file:///home/claude/bb/www/index.html');pg.wait_for_timeout(2000)
        chk(f'{w}: funcs exist',pg.evaluate("typeof icSheet=='function'&&typeof icPick=='function'&&typeof icSet=='function'"))
        chk(f'{w}: default preview svg',pg.evaluate("icPv('nav.home','home').indexOf('<svg')==0"))
        chk(f'{w}: non-admin icSet does nothing',pg.evaluate("(()=>{icSet('nav.home','k1');return !(D.cms&&D.cms.IK)})()"))
        chk(f'{w}: server selection applied when xic on',pg.evaluate("(()=>{D.cms.IK={s:{'nav.home':'k1'},v:1};D.cms.IKL={k1:{u:'data:image/webp;base64,AAAA',c:1}};XF.xic=true;const a=ikH('nav.home','DEF').indexOf('<img')==0;XF.xic=false;const b=ikH('nav.home','DEF')=='DEF';XF.xic=true;D.cms.IK.s={};const c=ikH('nav.home','DEF')=='DEF';delete D.cms.IK;delete D.cms.IKL;XF.xic=false;return a&&b&&c})()"))
        chk(f'{w}: non-admin sheet no crash',pg.evaluate("(()=>{try{icSheet();icPick('nav.home');return true}catch(e){return false}})()"))
        chk(f'{w}: nav default svg kept',pg.evaluate("document.querySelectorAll('#nav svg').length>=5"))
        chk(f'{w}: no overflow',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        ctx.close()
    br.close()
print('ERRORS',errs)
