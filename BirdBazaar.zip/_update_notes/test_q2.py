import sys
from playwright.sync_api import sync_playwright
P=sys.argv[1] if len(sys.argv)>1 else '/home/claude/bb'
errs=[];ok=[]
def chk(n,c):print(('PASS ' if c else 'FAIL ')+n);ok.append(bool(c))
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':390,'height':780},locale='fa-IR');pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',lambda r,q:r.continue_() if q.url.startswith('file:') else r.fulfill(status=200,content_type='application/json',body='{"err":"x"}'))
    pg.goto('file://'+P+'/www/index.html');pg.wait_for_timeout(800)
    pg.evaluate("S.role=null;S.pm=[];go({tab:1,v:null})");pg.wait_for_timeout(300)
    ids=pg.evaluate("D.products.map(p=>p.id)");print('products',len(ids))
    a,b=ids[0],ids[1]
    pg.evaluate("go({tab:1,v:'prod',id:%d})"%a);pg.wait_for_timeout(400)
    chk('1 دکمه‌ی مقایسه در صفحه‌ی محصول',pg.locator('[data-a=cmp_pk]').count()==1)
    pg.click('[data-a=cmp_pk]');pg.wait_for_timeout(300)
    n=pg.locator('.sheet [data-a=cmp_go]').count()
    chk('2 فهرست محصولات دیگر (بدون خودش)',n==len(ids)-1 and pg.locator('.sheet [data-a=cmp_go][data-v^="%d:%d"]'%(a,a)).count()==0)
    pg.click('.sheet [data-a=cmp_go][data-v="%d:%d"]'%(a,b));pg.wait_for_timeout(300)
    t=pg.inner_text('.sheet')
    na=pg.evaluate("getP(%d).name"%a);nb=pg.evaluate("getP(%d).name"%b)
    chk('3 نام هر دو محصول در جدول',na in t and nb in t)
    chk('4 ردیف قیمت و دسته','قیمت' in t and 'دسته' in t)
    pg.screenshot(path=P+'/shots/q2.png')
    # ارزان‌تر: دو محصول معمولی با قیمت متفاوت
    pg.evaluate("D.products.find(p=>p.id==%d).k='n';D.products.find(p=>p.id==%d).k='n';getP(%d).price=100000;getP(%d).price=50000;getP(%d).disc=0;getP(%d).disc=0;cmpShow(%d,%d)"%(a,b,a,b,a,b,a,b));pg.wait_for_timeout(200)
    chk('5 برچسب ارزان‌تر فقط یکی',pg.locator('.sheet .cmv .pill:has-text("ارزان‌تر")').count()==1)
    chk('6 ارزان‌تر ستون دوم',pg.evaluate("[...document.querySelectorAll('.sheet .cmv')].findIndex(e=>e.textContent.includes('ارزان‌تر'))%2")==1)
    # ناهمواحد
    pg.evaluate("getP(%d).k='w';getP(%d).un='kg';getP(%d).up=90000;cmpShow(%d,%d)"%(a,a,a,a,b));pg.wait_for_timeout(200)
    chk('7 ناهمواحد: بدون برچسب + پیام',pg.locator('.sheet .pill:has-text("ارزان‌تر")').count()==0 and 'هم‌واحد نیستند' in pg.inner_text('.sheet'))
    pg.click('.sheet [data-a=cmp_pk]');pg.wait_for_timeout(200)
    chk('8 تغییر محصول دوم',pg.locator('.sheet [data-a=cmp_go]').count()==len(ids)-1)
    pg.evaluate("cmpShow(%d,%d)"%(a,b));pg.wait_for_timeout(200)
    pg.click('.sheet [data-a=cmp_op][data-v="%d"]'%b);pg.wait_for_timeout(400)
    chk('9 باز کردن محصول دوم',pg.evaluate("S.v=='prod'&&S.id==%d"%b) and pg.locator('.sheet').count()==0)
    for th in('light','dark'):
        pg.evaluate("document.documentElement.setAttribute('data-theme','%s');cmpShow(%d,%d)"%(th,a,b))
        for w in(320,360,412):
            pg.set_viewport_size({'width':w,'height':780});pg.wait_for_timeout(120)
            chk('بدون سرریز %s %d'%(th,w),not pg.evaluate("document.documentElement.scrollWidth>innerWidth || [...document.querySelectorAll('.sheet *')].some(e=>e.getBoundingClientRect().right>innerWidth+1)"))
    chk('بدون خطا',not errs);print(errs);br.close()
print('ALL PASS' if all(ok) else 'SOME FAIL')
