-- UPDATE_FINAL2.sql — فقط چیزهای تازه‌ی بعد از ۱.۸.۸ (پیام‌رسان غرفه‌ها).
-- ترتیب: ۱) اگر booth.sql را بعد از ۱.۷.۱ اجرا نکرده‌ای، اول UPDATE_FINAL.sql؛ ۲) این فایل (یک بار؛ تکرار بی‌خطر).

-- پیام‌رسان کاربر↔غرفه‌دار (Y3) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths).
-- هویت: از همان تابع اصلی public.app (op=login). غرفه‌دار = booths.owner با همان نام کاربری.
-- هر گفتگو = (غرفه، نام کاربر مشتری). ستون‌های k و x برای کارت محصول (Y4) آماده‌اند.

create table if not exists public.c_msgs(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null check (side in ('u','b')),
  body text not null default '',
  k text default 't',
  x jsonb,
  created timestamptz default now());
create index if not exists c_msgs_conv on public.c_msgs(booth_id, cu, id desc);
create index if not exists c_msgs_cu on public.c_msgs(cu, id desc);
create table if not exists public.c_seen(
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null,
  lid bigint default 0,
  primary key(booth_id, cu, side));
alter table public.c_msgs enable row level security;
alter table public.c_seen enable row level security;

create or replace function public.capp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; bt public.booths; v_bid bigint; v_cu text; v_side text;
        v_aft bigint; v_last bigint; v_ps bigint; v_n int; v_n2 int; v_nid bigint; v_t timestamptz;
        v_body text; v_k text; v_x jsonb; v_pid bigint;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='cping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;

  -- شمار نخوانده‌ها (به‌عنوان مشتری + به‌عنوان غرفه‌دار)
  if op='ccount' then
    select count(*) into v_n from public.c_msgs m
      where m.cu=who and m.side='b'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='u'),0);
    select count(*) into v_n2 from public.c_msgs m join public.booths o on o.id=m.booth_id
      where o.owner=who and m.side='u'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='b'),0);
    return jsonb_build_object('ok',1,'n',v_n+v_n2);
  end if;

  -- لیست گفتگوها
  if op='clist' then
    return jsonb_build_object('ok',1,'l',coalesce((
      select jsonb_agg(row_to_json(z)::jsonb order by z.lid desc) from (
        select c.booth_id as b, c.cu as cu, c.lid as lid,
               case when c.cu=who then 'u' else 'b' end as r,
               m.body as lb, m.k as lk, m.side as ls, m.created as lt,
               (select count(*) from public.c_msgs q
                  where q.booth_id=c.booth_id and q.cu=c.cu
                    and q.side <> (case when c.cu=who then 'u' else 'b' end)
                    and q.id > coalesce((select s.lid from public.c_seen s
                        where s.booth_id=c.booth_id and s.cu=c.cu
                          and s.side=(case when c.cu=who then 'u' else 'b' end)),0)) as un
        from (
          select g.booth_id, g.cu, max(g.id) as lid from public.c_msgs g
          where g.cu=who or g.booth_id in (select o.id from public.booths o where o.owner=who)
          group by g.booth_id, g.cu
          order by max(g.id) desc limit 60) c
        join public.c_msgs m on m.id=c.lid
      ) z), '[]'::jsonb));
  end if;

  -- پیام‌های یک گفتگو (و علامت خوانده‌شدن)
  if op='cmsgs' or op='csend' then
    v_bid := (a->>'b')::bigint;
    select * into bt from public.booths where id=v_bid;
    if not found then return jsonb_build_object('err','none'); end if;
    if bt.owner=who then
      v_side := 'b'; v_cu := nullif(btrim(coalesce(a->>'cu','')),'');
      if v_cu is null then return jsonb_build_object('err','bad'); end if;
      if v_cu=who then return jsonb_build_object('err','self'); end if;
    else
      v_side := 'u'; v_cu := who;
      if bt.status<>'active' then return jsonb_build_object('err','none'); end if;
    end if;

    if op='cmsgs' then
      v_aft := coalesce(nullif(a->>'after','')::bigint,0);
      select coalesce(max(lid),0) into v_ps from public.c_seen
        where booth_id=v_bid and cu=v_cu and side=(case when v_side='u' then 'b' else 'u' end);
      select max(id) into v_last from public.c_msgs where booth_id=v_bid and cu=v_cu;
      if v_last is not null then
        insert into public.c_seen(booth_id,cu,side,lid) values(v_bid,v_cu,v_side,v_last)
          on conflict(booth_id,cu,side) do update set lid=greatest(public.c_seen.lid, excluded.lid);
      end if;
      return jsonb_build_object('ok',1,'ps',v_ps,'m',coalesce((
        select jsonb_agg(jsonb_build_object('id',y.id,'s',y.side,'b',y.body,'k',y.k,'x',y.x,'t',y.created) order by y.id)
        from (select * from public.c_msgs where booth_id=v_bid and cu=v_cu and id>v_aft order by id desc limit 200) y),'[]'::jsonb));
    end if;

    -- ارسال
    if v_side='b' and not exists(select 1 from public.c_msgs where booth_id=v_bid and cu=v_cu) then
      return jsonb_build_object('err','perm');
    end if;
    v_k := coalesce(nullif(a->>'k',''),'t');
    if v_k not in ('t','p') then return jsonb_build_object('err','bad'); end if;
    v_body := left(btrim(coalesce(a->>'body','')),1000);
    v_x := null;
    if v_k='t' then
      if length(v_body)<1 then return jsonb_build_object('err','bad'); end if;
    else
      v_pid := nullif(a->'x'->>'id','')::bigint;
      if v_pid is null or not exists(select 1 from public.booth_products q where q.id=v_pid and q.booth_id=v_bid) then
        return jsonb_build_object('err','bad');
      end if;
      v_x := jsonb_build_object('id',v_pid);
      v_body := left(v_body,200);
    end if;
    -- سقف سرعت: حداکثر ۲۰ پیام در دقیقه برای هر طرف گفتگو
    select count(*) into v_n from public.c_msgs
      where booth_id=v_bid and cu=v_cu and side=v_side and created>now()-interval '1 minute';
    if v_n>=20 then return jsonb_build_object('err','rate'); end if;
    insert into public.c_msgs(booth_id,cu,side,body,k,x) values(v_bid,v_cu,v_side,v_body,v_k,v_x)
      returning id, created into v_nid, v_t;
    return jsonb_build_object('ok',1,'id',v_nid,'t',v_t);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.capp(text,text,text,jsonb) to anon, authenticated;
