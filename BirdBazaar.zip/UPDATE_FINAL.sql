-- ===== BirdBazaar: SQL نهایی (همه‌ی تغییرات تازه در یک فایل) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: booth.sql و msg.sql قبلاً اجرا شده باشند.

-- [مورد ۸] درخواست همکاری با حساب کاربر + تأیید مستقیم + پیام خودکار
alter table public.booth_reqs add column if not exists uname text;

create or replace function public.kapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; adm boolean := false; nid bigint; q public.booth_reqs; ow text;
begin
  a := coalesce(a,'{}'::jsonb);
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;

  -- کاربر واردشده درخواست همکاری می‌فرستد
  if op='kreq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if exists(select 1 from booths where owner=u) then return jsonb_build_object('err','has'); end if;
    if (select count(*) from booth_reqs where (uname=u or phone=a->>'phone') and status='new')>=1 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about,uname) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600),u);
    return jsonb_build_object('ok',1);
  end if;

  -- تأیید توسط ادمین اصلی: غرفه برای همان حساب ساخته می‌شود و پیام خودکار می‌رود
  if op='kapprove' then
    if not adm then return jsonb_build_object('err','denied'); end if;
    select * into q from booth_reqs where id=(a->>'id')::bigint;
    if not found then return jsonb_build_object('err','none'); end if;
    ow := coalesce(nullif(q.uname,''), nullif(a->>'owner',''));
    if ow is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from users where username=ow) then return jsonb_build_object('err','nouser'); end if;
    if exists(select 1 from booths where owner=ow) then return jsonb_build_object('err','taken'); end if;
    insert into booths(owner,pw,name,city,phone) values(ow,crypt(gen_random_uuid()::text,gen_salt('bf')),left(coalesce(nullif(q.shop,''),q.name),80),q.city,q.phone) returning id into nid;
    update booth_reqs set status='ok', uname=ow where id=q.id;
    insert into m_msgs(from_u,to_u,body,kind) values(u,ow,E'مجوز ساخت غرفه\nمجوز ساخت غرفه توسط ادمین صادر شد و هم‌اینک می‌توانید از بخش غرفه‌داران غرفه خود را مدیریت کنید.','box');
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.kapp(text,text,text,jsonb) to anon, authenticated;
