-- ===== BirdBazaar: تنها فایل SQL پروژه (ALL_SQL.sql) — نسخه‌ی 1.9.67 =====
-- اجرا: Supabase > SQL Editor > کل فایل را بچسبان > Run. چند بار اجرا بی‌خطر است.
-- آخر فایل یک خروجی «ALL_SQL_DONE» می‌دهد؛ اگر آن را دیدی یعنی کل فایل چسبیده و اجرا شده.
-- ترتیب: forum ← booth ← msg ← chat ← bird ← kapp ← push ← pushfree ← backup ← تغییرات تازه (پایین فایل)
-- از این به بعد هر SQL جدید فقط به انتهای همین فایل اضافه می‌شود (بخش «تغییرات تازه»).

-- ################ forum.sql — انجمن + پرسش‌های متداول + مهر کل psig (fapp) ################
-- انجمن بازارچه پرندگان (F1) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت کاربر: از همان تابع اصلی public.app (op=login) بررسی می‌شود؛ ادمین اصلی = role admin و pm شامل all.

create table if not exists public.f_push(
  token text primary key, uname text not null, upd timestamptz default now());
create index if not exists f_push_u on public.f_push(uname);
alter table public.f_push enable row level security;

create table if not exists public.f_rooms(
  id serial primary key, name text not null, emoji text default '💬', sort int default 0, status text default 'on');
create table if not exists public.f_msgs(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  uname text not null, kind text not null default 'text', body text default '', media text,
  reply_to bigint, pinned boolean default false, del boolean default false, created timestamptz default now());
create index if not exists f_msgs_room_id on public.f_msgs(room, id desc);
create table if not exists public.f_perm(
  uname text primary key, txt boolean default false, img boolean default false, vid boolean default false,
  fil boolean default false, muted boolean default false, blocked boolean default false);
create table if not exists public.f_reqs(
  id bigserial primary key, uname text not null, want jsonb default '{}'::jsonb, status text default 'new', created timestamptz default now());
create table if not exists public.f_react(
  msg bigint references public.f_msgs(id) on delete cascade, uname text, e text, primary key(msg, uname));
create table if not exists public.f_reports(
  id bigserial primary key, msg bigint, uname text, why text default '', created timestamptz default now());
create table if not exists public.f_prof(uname text primary key, avatar text default '');

-- [مورد ۲] مدیریت انجمن: رنگ اتاق، علامت «ویرایش شد»، پرسش‌های متداول
alter table public.f_rooms add column if not exists color text default '';
alter table public.f_msgs add column if not exists ed boolean default false;
-- [Q7] پرسش و پاسخ: qn = پیام پرسش است، sol = حل شد
alter table public.f_msgs add column if not exists qn boolean default false;
alter table public.f_msgs add column if not exists sol boolean default false;
create table if not exists public.f_faq(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  qu text default 'کاربر نمونه', q text not null, a text default '', sort int default 0, created timestamptz default now());
alter table public.f_faq enable row level security;
-- [P5] گزارش آگهی‌ها (هر کاربر برای هر آگهی یک گزارش؛ فقط ادمین می‌بیند)
create table if not exists public.f_arep(
  id bigserial primary key, ad bigint not null, uname text not null, why text default '', created timestamptz default now(), st text default 'new', unique(ad,uname));
alter table public.f_arep enable row level security;
-- [P4] فروخته شد / تمدید آگهی (جدا از جدول ads؛ صاحب آگهی از ads.d->>'own' بررسی می‌شود)
create table if not exists public.f_adx(
  ad bigint primary key, sold boolean default false, ren timestamptz, upd timestamptz default now());
alter table public.f_adx enable row level security;

alter table public.f_rooms enable row level security;
alter table public.f_msgs enable row level security;
alter table public.f_perm enable row level security;
alter table public.f_reqs enable row level security;
alter table public.f_react enable row level security;
alter table public.f_reports enable row level security;
alter table public.f_prof enable row level security;

insert into public.f_rooms(name,emoji,sort)
select x.n, x.e, x.s from (values ('گفتگوی عمومی پرندگان','🦜',1),('جوجه‌کشی و تخم‌گذاری','🥚',2),('سلامت و بیماری','🩺',3),('خرید و فروش','🛒',4)) as x(n,e,s)
where not exists (select 1 from public.f_rooms);

-- [1.9.53] کنترل انجمن از سمت سرور: fmode = on | closed | off | demo ، fslow = ثانیه‌ی فاصله‌ی بین دو پیام هر کاربر (0 = بدون محدودیت)
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;

-- [1.9.66] نسخه‌ی سبک عکس‌ها: محصول/آگهی که عکس کوچک (th) و مهر آن (thk = طول عکس اول) دارد، در خروجی public2 فقط با عکس کوچک می‌آید (lite=1)؛ عکس کامل با op pimg.
create or replace function public.f_lite(j jsonb) returns jsonb language sql stable as $f$
  select case when j is not null and jsonb_typeof(j)='array' then coalesce((
    select jsonb_agg(
      case when jsonb_typeof(e.v)='object' and coalesce(e.v->>'th','')<>'' and (e.v->>'thk') is not null
            and (e.v->>'thk') = length(coalesce(e.v->'imgs'->>0, e.v->>'img', ''))::text
           then (e.v - 'imgs' - 'img') || jsonb_build_object('imgs', jsonb_build_array(e.v->'th'), 'img', e.v->'th', 'lite', 1)
           else e.v end
      order by e.o)
    from jsonb_array_elements(j) with ordinality as e(v,o)), '[]'::jsonb) else j end
$f$;

create or replace function public.fapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb := null; who text := ''; ismain boolean := false;
  pr public.f_perm; k text; rid bigint; n int; fm text := 'on'; fs int := 0; wt int;
begin
  a := coalesce(a,'{}'::jsonb);
  select coalesce((select c.v from public.f_conf c where c.k='fmode'),'on'), coalesce(nullif((select c.v from public.f_conf c where c.k='fslow'),'')::int,0) into fm, fs;
  if fm not in ('on','closed','off','demo') then fm := 'on'; end if;
  if op='fping' then return jsonb_build_object('ok',1); end if;
  if op='psig' then return public.f_psig(); end if;
  if op='psig_old' then
    declare ps text; pb text;
    begin
      begin
        ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
      exception when others then ps := null; end;
      begin
        pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
      exception when others then pb := null; end;
      begin
        if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
      exception when others then null; end;
      return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
    end;
  end if;

  if op='pidx' then return public.f_pidx(); end if;
  if op='pget' then return public.f_pget(a); end if;
  if op='bpub2' then return public.f_bpub2(); end if;
  if op='rpub2' then return public.f_rpub2(); end if;
  if op='bimg' then return public.f_bimg(a); end if;
  if op='public2' then
    declare pj jsonb;
    begin
      pj := public.app('public','','','{}'::jsonb);
      if pj is null or jsonb_typeof(pj)<>'object' then return pj; end if;
      if (pj->'products') is not null then pj := jsonb_set(pj,'{products}',public.f_lite(pj->'products')); end if;
      if (pj->'ads') is not null then pj := jsonb_set(pj,'{ads}',public.f_lite(pj->'ads')); end if;
      return pj;
    end;
  end if;
  if op='pimg' then
    declare ij jsonb; kk text := coalesce(a->>'k','');
    begin
      if kk='p' then
        select x.d into ij from public.products x where x.id::text=a->>'id' or x.d->>'id'=a->>'id' limit 1;
      elsif kk='a' then
        if exists(select 1 from jsonb_array_elements(coalesce(public.app('public','','','{}'::jsonb)->'ads','[]'::jsonb)) e where e->>'id'=a->>'id') then
          select x.d into ij from public.ads x where x.id::text=a->>'id' or x.d->>'id'=a->>'id' limit 1;
        end if;
      end if;
      if ij is null then return jsonb_build_object('ok',0); end if;
      return jsonb_build_object('ok',1,'img',ij->'img','imgs',coalesce(ij->'imgs','[]'::jsonb));
    end;
  end if;

  -- هویت (اختیاری): از تابع اصلی app
  if coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and (me ? 'err' or coalesce(me->>'role','')='') then me := null; end if;
    if me is not null then
      who := u;
      ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    end if;
  end if;
  select * into pr from public.f_perm where uname=who;

  if op='fwho' then
    return jsonb_build_object('ok',1,'me',who,'role',coalesce(me->>'role',''),'main',ismain,
      'perm',jsonb_build_object('txt',ismain or coalesce(pr.txt,false),'img',ismain or coalesce(pr.img,false),'vid',ismain or coalesce(pr.vid,false),'fil',ismain or coalesce(pr.fil,false),'muted',coalesce(pr.muted,false),'blocked',coalesce(pr.blocked,false)),
      'avatar',coalesce((select avatar from public.f_prof where uname=who),''),'mode',fm,'slow',fs);
  end if;

  if op='fpull' then
    if fm='off' and not ismain then
      return jsonb_build_object('ok',1,'mode',fm,'slow',fs,'rooms','[]'::jsonb,'msgs','[]'::jsonb,'av','{}'::jsonb,'pins','[]'::jsonb,'reqn',0);
    end if;
    n := least(greatest(coalesce((a->>'n')::int,30),1),60);
    return jsonb_build_object('ok',1,'mode',fm,'slow',fs,
      'rooms',case when coalesce(a->>'slim','')='1' then null else coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'name',r.name,'emoji',r.emoji,'color',coalesce(r.color,'')) order by r.sort,r.id) from public.f_rooms r where r.status='on'),'[]'::jsonb) end,
      'msgs',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'k',m.kind,'b',m.body,'md',case when coalesce(a->>'nomd','')='1' then null else m.media end,'rt',m.reply_to,'pin',m.pinned,'hm',(m.media is not null),'ed',coalesce(m.ed,false),'q',coalesce(m.qn,false),'s',coalesce(m.sol,false),'t',m.created,
              'r',coalesce((select jsonb_object_agg(x.e,x.c) from (select e,count(*) c from public.f_react where msg=m.id group by e) x),'{}'::jsonb)) order by m.id)
              from (select * from public.f_msgs where room=(a->>'room')::int and del=false
                     and id>coalesce((a->>'after')::bigint,0) and id<coalesce((a->>'before')::bigint,9223372036854775807)
                     order by id desc limit n) m),'[]'::jsonb),
      'av',case when coalesce(a->>'noav','')='1' then '{}'::jsonb else coalesce((select jsonb_object_agg(f.uname,f.avatar) from public.f_prof f where f.avatar<>'' and f.uname in
              (select distinct uname from (select uname from public.f_msgs where room=(a->>'room')::int and del=false order by id desc limit 60) z)),'{}'::jsonb) end,
      'pins',case when coalesce(a->>'slim','')='1' then null else coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'b',left(m.body,120))) from public.f_msgs m where m.room=(a->>'room')::int and m.pinned and m.del=false),'[]'::jsonb) end,
      'reqn',case when ismain and not (coalesce(a->>'slim','')='1') then (select count(*) from public.f_reqs where status='new') else 0 end);
  end if;

  if op='fmed' then
    return coalesce((select jsonb_build_object('ok',1,'md',m.media) from public.f_msgs m where m.id=nullif(fapp.a->>'id','')::bigint and m.del=false and m.media is not null),jsonb_build_object('ok',0));
  end if;

  if op='ffaq' then
    return jsonb_build_object('ok',1,'faq',coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'qu',f.qu,'q',f.q,'a',f.a) order by f.sort,f.id) from public.f_faq f where f.room=(fapp.a->>'room')::int),'[]'::jsonb));
  end if;

  if who='' then return jsonb_build_object('err','login'); end if;

  if op='fsend' then
    if fm='off' and not ismain then return jsonb_build_object('err','off'); end if;
    if fm='demo' then return jsonb_build_object('err','demo'); end if;
    if fm='closed' and not ismain then return jsonb_build_object('err','closed'); end if;
    if fs>0 and not ismain then
      select ceil(fs - extract(epoch from (now()-max(created))))::int into wt from public.f_msgs where uname=who and created>now()-make_interval(secs=>fs);
      if wt is not null and wt>0 then return jsonb_build_object('err','slow','wait',wt); end if;
    end if;
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if coalesce(pr.muted,false) and not ismain then return jsonb_build_object('err','muted'); end if;
    k := coalesce(a->>'k','text');
    if k not in ('text','img','vid','file') then return jsonb_build_object('err','bad'); end if;
    if not ismain then
      if k='text' and not coalesce(pr.txt,false) then return jsonb_build_object('err','perm'); end if;
      if k='img' and not coalesce(pr.img,false) then return jsonb_build_object('err','perm'); end if;
      if k='vid' and not coalesce(pr.vid,false) then return jsonb_build_object('err','perm'); end if;
      if k='file' and not coalesce(pr.fil,false) then return jsonb_build_object('err','perm'); end if;
    end if;
    if length(coalesce(a->>'b',''))>2000 or length(coalesce(a->>'md',''))>2200000 then return jsonb_build_object('err','big'); end if;
    if k='text' and length(trim(coalesce(a->>'b','')))=0 then return jsonb_build_object('err','bad'); end if;
    if k<>'text' and coalesce(a->>'md','')='' then return jsonb_build_object('err','bad'); end if;
    if not exists (select 1 from public.f_rooms where id=(a->>'room')::int and status='on') then return jsonb_build_object('err','room'); end if;
    if (select count(*) from public.f_msgs where uname=who and created>now()-interval '1 minute')>=20 then return jsonb_build_object('err','many'); end if;
    insert into public.f_msgs(room,uname,kind,body,media,reply_to,qn)
      values((a->>'room')::int, who, k, coalesce(a->>'b',''), nullif(a->>'md',''), nullif(a->>'rt','')::bigint,
        (k='text' and coalesce(a->>'q','') in ('1','true') and nullif(a->>'rt','') is null)) returning id into rid;
    return jsonb_build_object('ok',1,'id',rid);
  end if;

  if op='fdel' then
    update public.f_msgs set del=true where id=(a->>'id')::bigint and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='freact' then
    if (a->>'e') not in ('👍','❤️','😂','🙏') then return jsonb_build_object('err','bad'); end if;
    if exists (select 1 from public.f_react where msg=(a->>'id')::bigint and uname=who and e=a->>'e') then
      delete from public.f_react where msg=(a->>'id')::bigint and uname=who;
    else
      insert into public.f_react(msg,uname,e) values((a->>'id')::bigint,who,a->>'e')
        on conflict (msg,uname) do update set e=excluded.e;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='fav_set' then
    if length(coalesce(a->>'img',''))>200000 then return jsonb_build_object('err','big'); end if;
    insert into public.f_prof(uname,avatar) values(who,coalesce(a->>'img','')) on conflict (uname) do update set avatar=excluded.avatar;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if exists (select 1 from public.f_reqs where uname=who and status='new') then return jsonb_build_object('err','dup'); end if;
    insert into public.f_reqs(uname,want) values(who,coalesce(a->'want','{}'::jsonb));
    return jsonb_build_object('ok',1);
  end if;

  if op='freport' then
    insert into public.f_reports(msg,uname,why) values((a->>'id')::bigint,who,left(coalesce(a->>'why',''),200));
    return jsonb_build_object('ok',1);
  end if;

  -- فقط ادمین اصلی
  if not ismain then return jsonb_build_object('err','denied'); end if;

  if op='freq_list' then
    return jsonb_build_object('ok',1,'reqs',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'u',q.uname,'want',q.want,'t',q.created,
      'av',coalesce((select avatar from public.f_prof where uname=q.uname),'')) order by q.id) from public.f_reqs q where q.status='new'),'[]'::jsonb));
  end if;

  if op='freq_ok' then
    insert into public.f_perm(uname,txt,img,vid,fil)
      select q.uname, coalesce((a->>'txt')::boolean,(q.want->>'txt')::boolean,true), coalesce((a->>'img')::boolean,(q.want->>'img')::boolean,false),
             coalesce((a->>'vid')::boolean,(q.want->>'vid')::boolean,false), coalesce((a->>'fil')::boolean,(q.want->>'fil')::boolean,false)
      from public.f_reqs q where q.id=(a->>'id')::bigint
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    update public.f_reqs set status='ok' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq_no' then
    update public.f_reqs set status='no' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_set' then
    insert into public.f_perm(uname,txt,img,vid,fil) values(a->>'uname',coalesce((a->>'txt')::boolean,false),coalesce((a->>'img')::boolean,false),coalesce((a->>'vid')::boolean,false),coalesce((a->>'fil')::boolean,false))
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_list' then
    return jsonb_build_object('ok',1,'perms',coalesce((select jsonb_agg(to_jsonb(x) order by x.uname) from public.f_perm x),'[]'::jsonb));
  end if;

  if op='fmute' then
    insert into public.f_perm(uname,muted) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set muted=excluded.muted;
    return jsonb_build_object('ok',1);
  end if;

  if op='fblock' then
    insert into public.f_perm(uname,blocked) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set blocked=excluded.blocked;
    return jsonb_build_object('ok',1);
  end if;

  if op='fsolve' then
    if who='' then return jsonb_build_object('err','login'); end if;
    update public.f_msgs set sol=coalesce((a->>'on')::boolean,true)
      where id=(a->>'id')::bigint and qn and del=false and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='arep' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if (select count(*) from public.f_arep where uname=who and created>now()-interval '1 minute')>=10 then return jsonb_build_object('err','many'); end if;
    insert into public.f_arep(ad,uname,why) values((a->>'ad')::bigint, who, left(coalesce(a->>'why',''),150))
      on conflict (ad,uname) do update set why=excluded.why, created=now(), st='new';
    return jsonb_build_object('ok',1);
  end if;

  if op='arep_list' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',z.ad,'n',z.n,'why',z.ws,'t',z.t) order by z.n desc, z.t desc)
      from (select ad, count(*) n, max(created) t, (array_agg(why order by created desc) filter (where why<>''))[1:3] ws
            from public.f_arep where st='new' group by ad order by count(*) desc, max(created) desc limit 100) z),'[]'::jsonb));
  end if;

  if op='arep_done' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    update public.f_arep set st='done' where ad=(a->>'ad')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='myorders' then
    if who='' then return jsonb_build_object('err','login'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'dt',z.d->>'dt','tt',z.d->'tt','st',coalesce(z.d->>'st','new'),'it',coalesce(z.d->'it','[]'::jsonb)) order by z.id desc)
      from (select id,d from public.orders where d->>'u'=who order by id desc limit 50) z),'[]'::jsonb));
  end if;

  if op='ptoken' or op='ptoken_del' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if length(coalesce(a->>'t',''))<20 then return jsonb_build_object('err','bad'); end if;
    if op='ptoken' then
      insert into public.f_push(token,uname,upd) values(a->>'t',who,now())
        on conflict (token) do update set uname=excluded.uname, upd=now();
    else
      delete from public.f_push where token=a->>'t' and uname=who;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='adx_list' then
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',ad,'s',coalesce(sold,false),'r',ren))
      from public.f_adx where coalesce(sold,false) or ren>now()-interval '30 days'),'[]'::jsonb));
  end if;

  if op='adx_sold' or op='adx_renew' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if not (ismain
        or ((me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')
        or exists(select 1 from public.ads x where x.id=(a->>'ad')::bigint and x.d->>'own'=who)) then
      return jsonb_build_object('err','denied');
    end if;
    if op='adx_sold' then
      insert into public.f_adx(ad,sold) values((a->>'ad')::bigint, coalesce((a->>'on')::boolean,true))
        on conflict (ad) do update set sold=excluded.sold, upd=now();
      return jsonb_build_object('ok',1);
    end if;
    if not ismain and exists(select 1 from public.f_adx where ad=(a->>'ad')::bigint and ren>now()-interval '1 day') then
      return jsonb_build_object('err','wait');
    end if;
    insert into public.f_adx(ad,ren) values((a->>'ad')::bigint, now())
      on conflict (ad) do update set ren=now(), upd=now();
    return jsonb_build_object('ok',1);
  end if;

  if op='fmode_set' then
    if not ismain then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'mode','') not in ('on','closed','off','demo') then return jsonb_build_object('err','bad'); end if;
    insert into public.f_conf(k,v) values('fmode',a->>'mode') on conflict on constraint f_conf_pkey do update set v=excluded.v;
    insert into public.f_conf(k,v) values('fslow',least(greatest(coalesce((a->>'slow')::int,0),0),3600)::text) on conflict on constraint f_conf_pkey do update set v=excluded.v;
    return jsonb_build_object('ok',1);
  end if;

  if op='fpin' then
    update public.f_msgs set pinned=coalesce((a->>'on')::boolean,true) where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freport_list' then
    return jsonb_build_object('ok',1,'reports',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'msg',r.msg,'u',r.uname,'why',r.why,'t',r.created,'body',(select left(body,120) from public.f_msgs where id=r.msg),'by',(select uname from public.f_msgs where id=r.msg)) order by r.id desc) from public.f_reports r),'[]'::jsonb));
  end if;

  if op='freport_del' then
    delete from public.f_reports where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_set' then
    if length(trim(coalesce(a->>'name','x')))=0 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_rooms(name,emoji,sort,color) values(left(coalesce(a->>'name','اتاق'),60),left(coalesce(a->>'emoji','💬'),8),coalesce((a->>'sort')::int,(select coalesce(max(sort),0)+1 from public.f_rooms)),left(coalesce(a->>'color',''),9)) returning id into rid;
      return jsonb_build_object('ok',1,'id',rid);
    else
      update public.f_rooms set name=left(coalesce(a->>'name',name),60), emoji=left(coalesce(a->>'emoji',emoji),8), color=left(coalesce(a->>'color',color),9), sort=coalesce((a->>'sort')::int,sort), status=coalesce(a->>'status',status) where id=(a->>'id')::int;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_del' then
    delete from public.f_rooms where id=(a->>'id')::int;
    return jsonb_build_object('ok',1);
  end if;

  if op='fedit' then
    if length(trim(coalesce(a->>'b','')))=0 or length(a->>'b')>2000 then return jsonb_build_object('err','bad'); end if;
    update public.f_msgs set body=a->>'b', ed=true where id=(a->>'id')::bigint and kind='text';
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_set' then
    if length(trim(coalesce(a->>'q','')))=0 or length(a->>'q')>400 or length(coalesce(a->>'a',''))>1500 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_faq(room,qu,q,a,sort) values((a->>'room')::int,left(coalesce(nullif(trim(a->>'qu'),''),'کاربر نمونه'),40),a->>'q',coalesce(a->>'a',''),(select coalesce(max(sort),0)+1 from public.f_faq where room=(fapp.a->>'room')::int));
    else
      update public.f_faq set qu=left(coalesce(nullif(trim(fapp.a->>'qu'),''),qu),40), q=fapp.a->>'q', a=coalesce(fapp.a->>'a',f_faq.a) where id=(fapp.a->>'id')::bigint;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_del' then
    delete from public.f_faq where id=(fapp.a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.fapp(text,text,text,jsonb) to anon, authenticated;


-- [1.9.55] پرسش و پاسخ‌های نمونه (گفتگوهای نمونه‌ی هر گروه؛ داخل خود چت نمایش داده می‌شوند، با برچسب «نمونه / نام‌ها فرضی»).
-- نمونه‌های قدیمی (نام «کاربر نمونه n») جایگزین می‌شوند؛ پرسش‌هایی که ادمین خودش ساخته یا ویرایش کرده دست نمی‌خورد. چند بار اجرا بی‌خطر است.
delete from public.f_faq where qu like 'کاربر نمونه%';
insert into public.f_faq(room,qu,q,a,sort)
select r.id, x.qu, x.q, x.a, x.s from public.f_rooms r
join (values
($q$گفتگوی عمومی پرندگان$q$,$q$امیر$q$,$q$برای شروع نگهداری از طوطی‌سانان چه چیزهایی لازم است؟$q$,$q$سلام امیر جان 🌿 یک قفس بزرگ و تمیز، ظرف آب و دانه‌ی جدا، دانه‌ی متنوع و باکیفیت، سبزی تازه، چوب‌نشیمن با ضخامت‌های مختلف و چند اسباب‌بازی ساده. قفس را دور از آشپزخانه، کوران و دود بگذارید.$q$,1),
($q$گفتگوی عمومی پرندگان$q$,$q$سارا$q$,$q$چه خوراکی‌هایی برای پرنده خطرناک است؟$q$,$q$سارا جان این‌ها را هرگز ندهید: آووکادو، شکلات، قهوه و چای، الکل، پیاز و سیر. دود ظرف‌های تفلون هم برای پرنده‌ها خیلی خطرناک است؛ هنگام پخت‌وپز پرنده را از آشپزخانه دور کنید.$q$,2),
($q$گفتگوی عمومی پرندگان$q$,$q$محمد$q$,$q$دمای مناسب نگهداری چقدر است؟$q$,$q$معمولاً بین ۲۰ تا ۲۵ درجه خوب است. مهم‌تر از عدد، ثابت‌بودن هواست: از کوران و تغییر ناگهانی دما دور نگه دارید. نور ملایم صبحگاهی هم عالی است، ولی قفس زیر آفتاب داغ ظهر نباشد.$q$,3),
($q$گفتگوی عمومی پرندگان$q$,$q$مریم$q$,$q$پرنده‌ام تنهاست، یک جفت دیگر برایش بگیرم؟$q$,$q$بستگی دارد. بیشتر طوطی‌سانان اجتماعی‌اند و به همراه یا وقت شما نیاز دارند. اگر جفت می‌گیرید، پرنده‌ی تازه را حداقل دو هفته جدا نگه دارید و بعد آرام آرام آشنا کنید.$q$,4),
($q$گفتگوی عمومی پرندگان$q$,$q$رضا$q$,$q$هر چند وقت قفس را بشویم؟$q$,$q$کف قفس را روزانه یا یک‌روز‌درمیان عوض کنید، ظرف آب و غذا را هر روز بشویید و یک‌بار در هفته شست‌وشوی کامل قفس و چوب‌ها را انجام بدهید. تمیزی بیشترین جلوگیری را از بیماری می‌کند.$q$,5),
($q$گفتگوی عمومی پرندگان$q$,$q$نرگس$q$,$q$پرنده‌ام پرهای خودش را می‌کند، چرا؟$q$,$q$دلیل‌های رایج: استرس، بی‌حوصلگی، تغذیه‌ی ضعیف، انگل یا بیماری. اول تغذیه، اسباب‌بازی و خواب کافی (حدود ۱۰ ساعت تاریکی) را بررسی کنید. اگر ادامه داشت حتماً دامپزشک پرندگان ببیند.$q$,6),
($q$گفتگوی عمومی پرندگان$q$,$q$آرمان$q$,$q$روزی چند ساعت باید با پرنده وقت بگذرانم؟$q$,$q$حداقل یکی دو ساعت تعامل و بازی خوب است. اگر چند ساعت بیرون از قفس می‌آید، حتماً زیر نظر باشید.$q$,7),
($q$گفتگوی عمومی پرندگان$q$,$q$هانیه$q$,$q$پرنده‌ام زیاد جیغ می‌زند، چه کنم؟$q$,$q$معمولاً از تنهایی، بی‌حوصلگی یا کم‌خوابی است. شب‌ها آرام و تاریک بخوابد، اسباب‌بازی بگذارید و وقتی آرام است تشویقش کنید، نه وقتی جیغ می‌زند.$q$,8),
($q$گفتگوی عمومی پرندگان$q$,$q$داریوش$q$,$q$چطور پرنده‌ام را رام کنم؟$q$,$q$با صبر. دست را آرام و بدون حرکت ناگهانی نزدیک ببرید، با کمی ارزن تشویق کنید و جلسه‌ها را کوتاه و روزانه نگه دارید. هرگز به‌زور نگیریدش.$q$,9),
($q$گفتگوی عمومی پرندگان$q$,$q$مینا$q$,$q$بهترین دانه کدام است؟$q$,$q$مخلوط مخصوص گونه‌ی خودش، به‌علاوه سبزی و میوه‌ی تازه. فقط دانه‌ی چرب مثل آفتابگردان زیاد نباشد. پلت باکیفیت هم گزینه‌ی خوبی است.$q$,10),
($q$گفتگوی عمومی پرندگان$q$,$q$فرزاد$q$,$q$پرنده را حمام کنم؟$q$,$q$اسپری آب ولرم یا ظرف کم‌عمق در هوای گرم عالی است. در هوای سرد و بعدش در کوران نگذاریدش تا خشک شود.$q$,11),
($q$گفتگوی عمومی پرندگان$q$,$q$پگاه$q$,$q$پرنده چند ساعت باید بخوابد؟$q$,$q$حدود ۱۰ تا ۱۲ ساعت تاریکی و آرامش. شب‌ها پارچه‌ی نازک روی قفس بیندازید و از تلویزیون و نور دورش کنید.$q$,12),
($q$گفتگوی عمومی پرندگان$q$,$q$کاوه$q$,$q$باز گذاشتن پرنده در خانه خطر ندارد؟$q$,$q$چرا. پنجره و در بسته، پنکه‌ی سقفی خاموش، آینه و شیشه‌ی تمیز، سیم برق و گیاهان سمی و ظرف‌های پر از آب (مثل لیوان) جزو خطرها هستند. حتماً مراقبش باشید.$q$,13),
($q$گفتگوی عمومی پرندگان$q$,$q$ترانه$q$,$q$برای سفر پرنده را چه کنم؟$q$,$q$سپردن به یک آدم مطمئن که قبلاً با پرنده کار کرده بهتر از جابه‌جایی است. غذا، آب و دستورالعمل کوتاه بدهید.$q$,14),
($q$گفتگوی عمومی پرندگان$q$,$q$بیژن$q$,$q$برای شروع مرغ‌عشق بگیرم یا کاکتیل؟$q$,$q$مرغ‌عشق کوچک‌تر و پرانرژی است؛ کاکتیل آرام‌تر و مهربان‌تر است ولی گرد و غبار بیشتری دارد. به وقتی که دارید و فضای خانه فکر کنید.$q$,15),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$علی$q$,$q$چه سنی برای جفت‌گیری مناسب است؟$q$,$q$پرنده‌ها باید کاملاً بالغ و سالم باشند، معمولاً بالای یک سال. جفت‌های لاغر یا پرنده‌های تازه‌خریداری‌شده را زود جفت نکنید. تشخیص جنسیت در بعضی گونه‌ها فقط با آزمایش DNA قطعی است.$q$,1),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$زهرا$q$,$q$جعبه‌ی لانه چه شکلی باشد؟$q$,$q$متناسب با گونه، با ورودی مناسب و کف نرم. جای آرام و کم‌رفت‌وآمد بگذارید و در روزهای اول بیش از حد سرک نکشید تا پرنده‌ها استرس نگیرند.$q$,2),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$پویا$q$,$q$تخم‌ها چند روز بعد جوجه می‌شوند؟$q$,$q$بسته به گونه فرق می‌کند؛ مثلاً قناری حدود ۱۳ تا ۱۴ روز و مرغ‌عشق و کاکتیل حدود ۱۸ تا ۲۱ روز. تاریخ شروع خوابیدن روی تخم‌ها را یادداشت کنید.$q$,3),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$مهدی$q$,$q$تخم‌ها را می‌شود دست زد؟$q$,$q$تا جای ممکن نه. اگر لازم شد با دست‌های تمیز و خیلی کوتاه. حدود ۵ تا ۷ روز بعد می‌شود با نور ملایم (شب‌تابی) پیدا کرد تخم بارور است یا نه.$q$,4),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ساناز$q$,$q$مادر روی تخم‌ها نمی‌خوابد، چه کنم؟$q$,$q$پرنده‌های تازه‌کار گاهی چند روز طول می‌کشد. محیط را آرام نگه دارید و مزاحم نشوید. اگر چند روز بیشتر طول کشید یا تخم‌ها سرد شد، با یک نفر باتجربه یا دامپزشک مشورت کنید.$q$,5),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$حسین$q$,$q$ماده تخم‌گذاری دارد؛ چه مکملی بدهم؟$q$,$q$استخوان سفید ماهی مرکب و غذای کلسیم‌دار کمک می‌کند. اگر ماده نشسته، پف کرده و بی‌حال است و تخم گیر کرده، فوراً به دامپزشک برسانید؛ گرم نگه داشتن در راه کمک می‌کند.$q$,6),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$شقایق$q$,$q$ماده چند تا تخم می‌گذارد؟$q$,$q$بسته به گونه فرق می‌کند؛ معمولاً بین سه تا هشت تا، و هر یکی دو روز یک تخم. تعداد زیاد پشت سر هم ماده را خسته می‌کند.$q$,7),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$امید$q$,$q$جوجه‌ها کی پر درمی‌آورند؟$q$,$q$معمولاً بین سه تا پنج هفته، بسته به گونه. تا آن موقع محیط گرم و آرام و بدون سر و صدا باشد.$q$,8),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سمیرا$q$,$q$تخم‌هایمان بارور نشدند، چرا؟$q$,$q$دلیل‌ها: جوانی یا ناباروری جفت، جنسیت اشتباه، تغذیه‌ی ضعیف، استرس یا دمای نامناسب. تغذیه و آرامش را بهتر کنید و چند هفته صبر کنید.$q$,9),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$وحید$q$,$q$قبل از جفت‌گیری غذای ویژه بدهم؟$q$,$q$کمی پروتئین بیشتر (مثل تخم‌مرغ آب‌پز)، دانه‌ی جوانه‌زده و کلسیم، ولی کم‌کم. زیاده‌روی در غذای چرب مناسب نیست.$q$,10),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$رها$q$,$q$جوجه‌ها را چه زمانی از والدین جدا کنم؟$q$,$q$زود نه. معمولاً بعد از اینکه خودشان غذا خوردن و پریدن را یاد گرفتند و حدود شش تا هشت هفته که بسته به گونه است.$q$,11),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$نیما$q$,$q$نور چقدر باشد؟$q$,$q$حدود ۱۲ تا ۱۴ ساعت روشنایی می‌تواند فصل جفت‌گیری را تحریک کند؛ شب‌ها هم تاریکی کامل بدهید.$q$,12),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$غزل$q$,$q$سالی چند بار جفت‌گیری مجاز است؟$q$,$q$بین دوره‌ها به ماده استراحت بدهید. پشت سر هم جوجه‌آوردن او را ضعیف می‌کند.$q$,13),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سینا$q$,$q$جوجه را دستی پرورش بدهم؟$q$,$q$فقط اگر لازم باشد و تجربه دارید؛ خطر جوجه خیلی زیاد است. بهتر است با یک فرد باتجربه یا دامپزشک مشورت کنید.$q$,14),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ملیحه$q$,$q$لانه را تمیز کنم؟$q$,$q$تا وقتی جوجه‌ها داخل‌اند دست‌کاری را حداقل کنید. بعد از جوجه‌درآمدن و ترک لانه تمیز و ضدعفونی کنید.$q$,15),
($q$سلامت و بیماری$q$,$q$آرش$q$,$q$پرنده‌ام پف کرده و کم‌غذا شده، چه کنم؟$q$,$q$این‌ها می‌تواند نشانه‌ی بیماری باشد و پرنده‌ها دردشان را تا آخر پنهان می‌کنند. گرم و آرام نگهش دارید، آب در دسترس باشد و هرچه زودتر به دامپزشک پرندگان نشانش بدهید.$q$,1),
($q$سلامت و بیماری$q$,$q$الهام$q$,$q$رنگ و حالت مدفوع عوض شده؛ نگران باشم؟$q$,$q$تغییر کوتاه بعد از خوردن میوه‌ی رنگی عادی است. اگر آبکی، بدبو، خونی یا چند روز ادامه‌دار بود و پرنده بی‌حال شد، عکس مدفوع را بگیرید و به دامپزشک نشان بدهید.$q$,2),
($q$سلامت و بیماری$q$,$q$کیان$q$,$q$عطسه و ترشح بینی دارد.$q$,$q$گاهی از گرد و غبار یا دود است، ولی ادامه‌ی آن می‌تواند عفونت تنفسی باشد. محیط را از دود و اسپری دور کنید و اگر چند روز ماند، معاینه لازم است.$q$,3),
($q$سلامت و بیماری$q$,$q$نیلوفر$q$,$q$منقار و ناخن‌ها بلند شده‌اند.$q$,$q$چوب و سنگ‌پای مخصوص بگذارید. کوتاه‌کردن را اگر بلد نیستید خودتان انجام ندهید؛ برش بیش از حد باعث خونریزی می‌شود. دامپزشک یا فرد باتجربه انجام بدهد.$q$,4),
($q$سلامت و بیماری$q$,$q$بهرام$q$,$q$می‌شود خودم دارو بدهم؟$q$,$q$لطفاً بدون تشخیص دامپزشک دارو یا آنتی‌بیوتیک ندهید؛ دوز اشتباه برای پرنده‌ی کوچک خطرناک است. این بخش برای تجربه و آگاهی است و جای دامپزشک را نمی‌گیرد.$q$,5),
($q$سلامت و بیماری$q$,$q$شیدا$q$,$q$پرنده‌ی جدید را چطور قرنطینه کنم؟$q$,$q$حداقل دو تا چهار هفته در اتاق جدا و با ظرف‌های جدا نگه دارید. اول دست‌های پرنده‌های سالم را بشویید، بعد سراغ پرنده‌ی جدید بروید تا بیماری منتقل نشود.$q$,6),
($q$سلامت و بیماری$q$,$q$رامین$q$,$q$دانه‌ی کپک‌زده را الک کنم و بدهم؟$q$,$q$نه، حتی کپک کم هم سم تولید می‌کند. دانه را دور بریزید و در ظرف دربسته و خشک نگه دارید.$q$,7),
($q$سلامت و بیماری$q$,$q$آزاده$q$,$q$پرنده با دهان باز نفس می‌کشد.$q$,$q$ممکن است تنگی نفس یا گرمازدگی باشد. محیط را خنک و آرام کنید و فوراً دامپزشک.$q$,8),
($q$سلامت و بیماری$q$,$q$احسان$q$,$q$ریزش پر طبیعی است؟$q$,$q$پرریزی فصلی عادی است. اگر جاهای بدون پر یا پوست قرمز دیدید، یا پرنده بی‌حال شد، معاینه لازم است.$q$,9),
($q$سلامت و بیماری$q$,$q$ملیکا$q$,$q$چشمش ورم کرده و ترشح دارد.$q$,$q$می‌تواند عفونت یا آسیب باشد. خودسرانه قطره نریزید؛ دامپزشک.$q$,10),
($q$سلامت و بیماری$q$,$q$شهاب$q$,$q$پایین قفس می‌نشیند و پایش ورم دارد.$q$,$q$ممکن است مشکل پا یا بیماری باشد. نشیمن نرم و کم‌ارتفاع بگذارید و برای معاینه ببرید.$q$,11),
($q$سلامت و بیماری$q$,$q$دلارام$q$,$q$پرنده‌ی تازه‌آورده بی‌حال است.$q$,$q$تغییر محیط استرس دارد. گرم، آرام و با غذا و آب در دسترس نگهش دارید؛ اگر دو روز نخورد یا بدتر شد، دامپزشک.$q$,12),
($q$سلامت و بیماری$q$,$q$بابک$q$,$q$ویتامین بدهم؟$q$,$q$غذای متنوع معمولاً کافی است. مکمل را بدون نظر دامپزشک زیاد ندهید.$q$,13),
($q$سلامت و بیماری$q$,$q$مسعود$q$,$q$چه علامت‌هایی اورژانسی است؟$q$,$q$خونریزی، نفس با دهان باز، افتادن از نشیمن، پف دائم، دو روز نخوردن یا تخم گیرکرده. فوراً به دامپزشک برسانید.$q$,14),
($q$خرید و فروش$q$,$q$یاسر$q$,$q$هنگام خرید پرنده چه چیزهایی را ببینم؟$q$,$q$پرنده فعال و کنجکاو باشد، چشم‌ها روشن، پرها مرتب، بینی خشک و تمیز، پاها و ناخن‌ها سالم. پرنده‌ای که پف‌کرده در گوشه نشسته را نخرید.$q$,1),
($q$خرید و فروش$q$,$q$فاطمه$q$,$q$پرنده را چطور با خیال راحت حمل کنم؟$q$,$q$در قفس یا جعبه‌ی کوچک با منفذ هوا، روی آن پارچه‌ی نازک بیندازید تا آرام باشد. در ماشین گرم یا سرد نگذارید و آب و میوه‌ی آبدار را فقط اگر مسیر طولانی است همراه ببرید.$q$,2),
($q$خرید و فروش$q$,$q$کامران$q$,$q$خرید حضوری بهتر است یا ارسالی؟$q$,$q$تا می‌توانید حضوری ببینید. اگر ارسالی است، از فروشنده ویدیو و عکس واضح بخواهید و پرداخت کامل پیش از دیدن پرنده را نپذیرید.$q$,3),
($q$خرید و فروش$q$,$q$لیلا$q$,$q$اطلاعات سن و جنسیت را چقدر باور کنم؟$q$,$q$تشخیص سن و جنس در بعضی گونه‌ها ظاهری نیست. اگر برایتان مهم است، از آزمایش DNA یا شناسنامه و حلقه‌ی پای پرنده کمک بگیرید.$q$,4),
($q$خرید و فروش$q$,$q$سجاد$q$,$q$بعد از خرید باید قرنطینه کنم؟$q$,$q$بله، پرنده‌ی تازه را چند هفته جدا نگه دارید و رفتارش را زیر نظر بگیرید، بعد کنار بقیه ببرید.$q$,5),
($q$خرید و فروش$q$,$q$ندا$q$,$q$اگر آگهی مشکوک بود چه کنم؟$q$,$q$از دکمه‌ی گزارش آگهی استفاده کنید تا ادمین بررسی کند. هیچ‌وقت پول بیعانه‌ی بزرگ ندهید و معامله‌ی حضوری را ترجیح بدهید. مسئولیت آگهی با ثبت‌کننده است.$q$,6),
($q$خرید و فروش$q$,$q$حمید$q$,$q$قیمت منصفانه چقدر است؟$q$,$q$با چند آگهی مشابه (گونه، سن، جهش) مقایسه کنید. عددهای پراکنده را معیار نگیرید.$q$,7),
($q$خرید و فروش$q$,$q$ثمین$q$,$q$حلقه‌ی پای پرنده چیست؟$q$,$q$حلقه‌ی بسته معمولاً نشانگر سال و محل پرورش است. به شناسایی منبع کمک می‌کند.$q$,8),
($q$خرید و فروش$q$,$q$جواد$q$,$q$از غرفه بخرم یا فروشنده‌ی خصوصی؟$q$,$q$هر دو ممکن است خوب باشند. غرفه معمولاً سابقه و پروفایل دارد؛ پروفایل و آگهی‌های قبلی فروشنده را ببینید.$q$,9),
($q$خرید و فروش$q$,$q$آیدا$q$,$q$با پرنده چه لوازمی بخرم؟$q$,$q$قفس مناسب، ظرف آب و غذا، چوب نشیمن، دانه‌ی همان برندی که فروشنده می‌دهد (تغییر ناگهانی غذا نکنید).$q$,10),
($q$خرید و فروش$q$,$q$رضوان$q$,$q$جفت بخرم؛ از جنسیت مطمئن شوم؟$q$,$q$در بسیاری از گونه‌ها ظاهر کافی نیست؛ اگر مهم است، آزمایش DNA بهترین راه است.$q$,11),
($q$خرید و فروش$q$,$q$سعید$q$,$q$می‌خواهم پرنده‌ام را بفروشم؛ آگهی چطور باشد؟$q$,$q$عکس و ویدیوی واضح، سن، جنس تقریبی، سلامت و قیمت بدون اغراق؛ و در بخش آگهی‌ها ثبت کنید.$q$,12),
($q$خرید و فروش$q$,$q$فرناز$q$,$q$بعد از فروش آگهی را چه کنم؟$q$,$q$از دکمه‌ی «فروخته شد» در صفحه‌ی آگهی استفاده کنید؛ اگر نشد، تمدیدش هم هست.$q$,13),
($q$خرید و فروش$q$,$q$پدرام$q$,$q$پرداخت امن چطور است؟$q$,$q$حضوری و بعد از دیدن پرنده؛ بیعانه‌ی بزرگ نپردازید.$q$,14),
($q$خرید و فروش$q$,$q$مهسا$q$,$q$فروشنده تضمین سلامت می‌دهد؟$q$,$q$با فروشنده درباره‌ی چند روز مهلت برای بررسی توافق کنید و بهتر است مکتوب باشد.$q$,15)
) as x(rn,qu,q,a,s) on x.rn=r.name
where not exists (select 1 from public.f_faq f where f.room=r.id and f.q=x.q);

-- ################ booth.sql — غرفه‌داران (bapp) ################
-- ===== BirdBazaar: غرفه‌داران (G1) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- بعد از اجرا حتماً رمز مدیریت را عوض کن (آخر فایل).
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.booths(
  id bigserial primary key, owner text unique not null, pw text not null,
  name text not null, bio text default '', logo text default '', cover text default '',
  city text default '', phone text default '', status text default 'active',
  views int default 0, created timestamptz default now());
create table if not exists public.booth_products(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null, status text default 'on', created timestamptz default now());
create table if not exists public.booth_views(
  booth_id bigint references public.booths(id) on delete cascade, day date, n int default 0,
  primary key(booth_id,day));
create table if not exists public.booth_reqs(
  id bigserial primary key, name text, phone text, city text, shop text, about text,
  status text default 'new', created timestamptz default now());
create table if not exists public.bcfg(k text primary key, v text);

alter table public.booths enable row level security;
alter table public.booth_products enable row level security;
alter table public.booth_views enable row level security;
create table if not exists public.booth_orders(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  name text, phone text, addr text default '', lines jsonb not null default '[]'::jsonb,
  total bigint default 0, status text default 'new', created timestamptz default now());
alter table public.booth_reqs enable row level security;
alter table public.booth_orders enable row level security;
alter table public.bcfg enable row level security;

-- رمز جدای مدیریت غرفه‌ها حذف شد؛ ادمین اصلی با حساب اصلی وارد می‌شود.
delete from public.bcfg where k='admin_key';

create or replace function public.bapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; adm boolean := false; r jsonb; nid bigint; bid bigint; me jsonb := null;
begin
  a := coalesce(a,'{}'::jsonb);
  -- ادمین اصلی: هویت با همان تابع app (role admin و pm شامل all)
  if op like 'badm_%' and coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and not (me ? 'err') and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;
  end if;

  if op='bpublic' then
    return jsonb_build_object('ok',1,
      'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'name',x.name,'bio',x.bio,'logo',x.logo,'cover',x.cover,'city',x.city,'phone',x.phone,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id and q.status='on')) order by x.id) from booths x where x.status='active'),'[]'::jsonb),
      'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'d',q.d,'t',q.created) order by q.id desc) from booth_products q join booths x on x.id=q.booth_id where x.status='active' and q.status='on'),'[]'::jsonb));
  end if;

  if op='bviewn' then
    with x as (select (case when e.key ~ '^[0-9]{1,15}$' then e.key::bigint end) id, (case when e.value ~ '^[0-9]{1,3}$' then least(greatest(e.value::int,1),50) else 1 end) c
               from jsonb_each_text(case when jsonb_typeof(a->'v')='object' then a->'v' else '{}'::jsonb end) e limit 40),
    ok as (select x.id,x.c from x join booths b on b.id=x.id and b.status='active' where x.id is not null),
    i as (insert into booth_views(booth_id,day,n) select id,current_date,c from ok on conflict(booth_id,day) do update set n=booth_views.n+excluded.n returning 1)
    update booths set views=booths.views+ok.c from ok where booths.id=ok.id;
    return jsonb_build_object('ok',1,'n',1);
  end if;

  if op='bview' then
    bid := (a->>'id')::bigint;
    if not exists(select 1 from booths where id=bid and status='active') then return jsonb_build_object('err','none'); end if;
    insert into booth_views(booth_id,day,n) values(bid,current_date,1) on conflict(booth_id,day) do update set n=booth_views.n+1;
    update booths set views=views+1 where id=bid;
    return jsonb_build_object('ok',1);
  end if;

  if op='breq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_reqs where phone=a->>'phone' and status='new')>=3 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600));
    return jsonb_build_object('ok',1);
  end if;

  -- ثبت سفارش مشتری (O1) — عمومی
  if op='bord' then
    if jsonb_typeof(a->'lines')<>'array' or jsonb_array_length(a->'lines')=0 or jsonb_array_length(a->'lines')>40 then return jsonb_build_object('err','bad'); end if;
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_orders where phone=left(a->>'phone',30) and created>now()-interval '1 hour')>=5 then return jsonb_build_object('err','many'); end if;
    select * into b from booths where id=(a->>'b')::bigint and status='active';
    if not found then return jsonb_build_object('err','off'); end if;
    insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'addr',''),400),a->'lines',coalesce((a->>'total')::bigint,0));
    return jsonb_build_object('ok',1);
  end if;

  -- ورود غرفه‌دار
  if op in ('blogin','bme','bprod_set','bprod_del','bset','bpw','bords','bord_st') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then
      -- ورود با حساب اصلی (U4): اگر غرفه‌ای به نام همین کاربر وصل شده باشد
      begin
        me := public.app('login', u, p, '{}'::jsonb);
      exception when others then
        me := null;
      end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then
        select * into b from booths where owner=u and status<>'off';
      end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;

    if op in ('blogin','bme') then
      return jsonb_build_object('ok',1,
        'booth',jsonb_build_object('id',b.id,'name',b.name,'bio',b.bio,'logo',b.logo,'cover',b.cover,'city',b.city,'phone',b.phone,'views',b.views,'status',b.status),
        'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'s',q.status,'t',q.created) order by q.id desc) from booth_products q where q.booth_id=b.id),'[]'::jsonb),
        'days',coalesce((select jsonb_agg(jsonb_build_object('day',v.day,'n',v.n) order by v.day) from booth_views v where v.booth_id=b.id and v.day>=current_date-6),'[]'::jsonb));
    end if;

    if op='bprod_set' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      if (a->>'id') is null then
        insert into booth_products(booth_id,d,status) values(b.id,a->'d',coalesce(a->>'s','on')) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_products set d=a->'d', status=coalesce(a->>'s',status) where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='bords' then
      return jsonb_build_object('ok',1,'orders',coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'phone',o.phone,'addr',o.addr,'lines',o.lines,'total',o.total,'s',o.status,'t',o.created) order by o.id desc) from (select * from booth_orders where booth_id=b.id order by id desc limit 100) o),'[]'::jsonb));
    end if;
    if op='bord_st' then
      update booth_orders set status=a->>'s' where id=(a->>'id')::bigint and booth_id=b.id and (a->>'s') in ('new','done','cancel');
      return jsonb_build_object('ok',1);
    end if;

    if op='bprod_del' then
      delete from booth_products where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bset' then
      if length(coalesce(a->>'logo',''))>120000 or length(coalesce(a->>'cover',''))>250000 then return jsonb_build_object('err','big'); end if;
      update booths set name=left(coalesce(nullif(a->>'name',''),name),80), bio=left(coalesce(a->>'bio',bio),600),
        logo=coalesce(a->>'logo',logo), cover=coalesce(a->>'cover',cover), city=left(coalesce(a->>'city',city),60), phone=left(coalesce(a->>'phone',phone),30)
      where id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bpw' then
      if length(coalesce(a->>'np',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'np',gen_salt('bf')) where id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  -- مدیریت (فقط ادمین اصلی با حساب خودش)
  if op like 'badm_%' then
    if not adm then return jsonb_build_object('err','denied'); end if;

    if op='badm_list' then
      return jsonb_build_object('ok',1,
        'reqs',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from booth_reqs x where x.status='new'),'[]'::jsonb),
        'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'owner',x.owner,'name',x.name,'city',x.city,'bio',x.bio,'phone',x.phone,'status',x.status,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id),'o',(select count(*) from booth_orders w where w.booth_id=x.id)) order by x.id desc) from booths x),'[]'::jsonb));
    end if;

    if op='badm_approve' then
      if length(coalesce(a->>'owner',''))<3 or length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from booths where owner=a->>'owner') then return jsonb_build_object('err','taken'); end if;
      insert into booths(owner,pw,name,city,phone)
        select a->>'owner',crypt(a->>'pw',gen_salt('bf')),coalesce(nullif(shop,''),name),city,phone from booth_reqs where id=(a->>'id')::bigint
        returning id into nid;
      if nid is null then return jsonb_build_object('err','none'); end if;
      update booth_reqs set status='ok' where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    -- U4: وصل کردن غرفه به حساب اصلی یک کاربر (بدون رمز جدا؛ رمز داخلی تصادفی)
    if op='badm_link' then
      if length(coalesce(a->>'owner',''))<3 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from booths where owner=a->>'owner') then return jsonb_build_object('err','taken'); end if;
      insert into booths(owner,pw,name) values(a->>'owner',crypt(gen_random_uuid()::text,gen_salt('bf')),left(coalesce(nullif(a->>'name',''),a->>'owner'),80)) returning id into nid;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='badm_reject' then update booth_reqs set status='no' where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_status' then update booths set status=a->>'status' where id=(a->>'id')::bigint and (a->>'status') in ('active','off'); return jsonb_build_object('ok',1); end if;
    if op='badm_del' then delete from booths where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_reset' then
      if length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'pw',gen_salt('bf')) where id=(a->>'id')::bigint; return jsonb_build_object('ok',1);
    end if;
    -- U2: ادمین اصلی: دیدن/تغییر وضعیت سفارش‌های یک غرفه و ویرایش اطلاعات غرفه
    if op='badm_ords' then
      return jsonb_build_object('ok',1,'orders',coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'phone',o.phone,'addr',o.addr,'lines',o.lines,'total',o.total,'s',o.status,'t',o.created) order by o.id desc) from (select * from booth_orders where booth_id=(a->>'id')::bigint order by id desc limit 100) o),'[]'::jsonb));
    end if;
    if op='badm_ord_st' then
      update booth_orders set status=a->>'s' where id=(a->>'id')::bigint and (a->>'s') in ('new','done','cancel');
      return jsonb_build_object('ok',1);
    end if;
    if op='badm_edit' then
      if length(coalesce(a->>'name',''))<1 then return jsonb_build_object('err','bad'); end if;
      update booths set name=left(a->>'name',80), bio=left(coalesce(a->>'bio',''),600), city=left(coalesce(a->>'city',''),60), phone=left(coalesce(a->>'phone',''),30) where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1);
    end if;

    if op='badm_pdel' then delete from booth_products where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;

    -- U4: مدیر کردن یک کاربر (پیش‌فرض بدون دسترسی؛ pm = دسترسی‌های تیک‌خورده) و برداشتن نقش
    if op='badm_mkadm' then
      if length(coalesce(a->>'u',''))<1 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from staff where username=a->>'u' and 'all'=any(perms)) then return jsonb_build_object('err','main'); end if;
      if exists(select 1 from staff where username=a->>'u') then
        update staff set perms=array(select x from jsonb_array_elements_text(coalesce(a->'pm','[]'::jsonb)) x where x in ('p','a','s','o','g','u','br','nt'))::text[] where username=a->>'u';
      else
        if not exists(select 1 from users where username=a->>'u') then return jsonb_build_object('err','none'); end if;
        insert into staff(username,pass,perms)
          select username,pass,array(select x from jsonb_array_elements_text(coalesce(a->'pm','[]'::jsonb)) x where x in ('p','a','s','o','g','u','br','nt'))::text[] from users where username=a->>'u';
      end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='badm_rmadm' then
      delete from staff where username=a->>'u' and not ('all'=any(perms));
      return jsonb_build_object('ok',1);
    end if;
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.bapp(text,text,text,jsonb) to anon, authenticated;

-- ################ msg.sql — صندوق پیام و پاپ‌آپ (mapp) ################
-- صندوق پیام و اعلان (U3 + 1.9.16: پیام پاپ‌آپ و مخاطب «فقط کاربران عادی») — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت: از همان تابع اصلی public.app (op=login). مدیر = role admin. ارسال به «همه» فقط ادمین اصلی (pm شامل all).

create table if not exists public.m_msgs(
  id bigserial primary key, from_u text not null, to_u text, grp text,
  body text not null, created timestamptz default now());
create index if not exists m_msgs_to on public.m_msgs(to_u, id desc);
create index if not exists m_msgs_grp on public.m_msgs(grp, id desc);
create table if not exists public.m_read(
  uname text not null, msg bigint references public.m_msgs(id) on delete cascade, primary key(uname,msg));
alter table public.m_msgs add column if not exists kind text default 'box';
alter table public.m_msgs enable row level security;
alter table public.m_read enable row level security;

create or replace function public.mapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; ismain boolean := false; isadm boolean := false;
        isbooth boolean := false; k text := 'box'; nid bigint; g text; t text; b text; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='mping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  isbooth := exists(select 1 from public.booths x where x.owner=who and x.status='active');

  -- پیام‌های من: شخصی + گروهی که عضوشم
  if op='minbox' or op='mcount' then
    if op='mcount' then
      select count(*) into n from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
          and m.from_u<>who
          and not exists(select 1 from public.m_read r where r.uname=who and r.msg=m.id);
      return jsonb_build_object('ok',1,'n',n,'adm',isadm,'main',ismain,'booth',isbooth,
        'pop',(select jsonb_build_object('id',m.id,'f',m.from_u,'g',m.grp,'b',m.body,'t',m.created) from public.m_msgs m
          where m.kind='pop' and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
            and m.from_u<>who and not exists(select 1 from public.m_read r where r.uname=who and r.msg=m.id)
          order by m.id asc limit 1));
    end if;
    return jsonb_build_object('ok',1,'adm',isadm,'main',ismain,'booth',isbooth,
      'in',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'f',x.from_u,'g',x.grp,'b',x.body,'t',x.created,'k',x.kind,
            'r',exists(select 1 from public.m_read r where r.uname=who and r.msg=x.id)) order by x.id desc)
          from (select * from public.m_msgs m where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth)) and m.from_u<>who order by m.id desc limit 60) x),'[]'::jsonb),
      'sent',case when isadm then coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'to',x.to_u,'g',x.grp,'b',x.body,'t',x.created) order by x.id desc)
          from (select * from public.m_msgs m where m.from_u=who order by m.id desc limit 40) x),'[]'::jsonb) else '[]'::jsonb end);
  end if;

  if op='mread' and a ? 'ids' and jsonb_typeof(a->'ids')='array' then
    insert into public.m_read(uname,msg)
      select who,m.id from public.m_msgs m
      where m.id in (select (case when t.v ~ '^[0-9]{1,15}$' then t.v::bigint end) from (select jsonb_array_elements_text(a->'ids') v limit 100) t)
        and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
      on conflict do nothing;
    return jsonb_build_object('ok',1,'n',1);
  end if;

  if op='mread' then
    if a ? 'all' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth)) and m.from_u<>who
        on conflict do nothing;
    elsif a ? 'id' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m where m.id=(a->>'id')::bigint
          and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
        on conflict do nothing;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  -- ارسال: فقط مدیران. «همه» فقط ادمین اصلی.
  if op='msend' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    b := left(btrim(coalesce(a->>'b','')),1000);
    if length(b)<1 then return jsonb_build_object('err','bad'); end if;
    k := case when a->>'k'='pop' then 'pop' else 'box' end;
    g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
    if g is not null then
      if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
      if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
      insert into public.m_msgs(from_u,grp,body,kind) values(who,g,b,k) returning id into nid;
    else
      if t is null then return jsonb_build_object('err','bad'); end if;
      if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
      insert into public.m_msgs(from_u,to_u,body,kind) values(who,t,b,k) returning id into nid;
    end if;
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  -- حذف پیام ارسالی (فرستنده یا ادمین اصلی)
  if op='mdel' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    delete from public.m_msgs where id=(a->>'id')::bigint and (from_u=who or ismain);
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.mapp(text,text,text,jsonb) to anon, authenticated;

-- ################ chat.sql — گفتگوی کاربر و غرفه‌دار (capp) ################
-- پیام‌رسان کاربر↔غرفه‌دار (Y3) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths).
-- هویت: از همان تابع اصلی public.app (op=login). غرفه‌دار = booths.owner با همان نام کاربری.
-- هر گفتگو = (غرفه، نام کاربر مشتری). ستون‌های k و x برای کارت محصول (Y4) آماده‌اند.

create table if not exists public.c_msgs(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null check (side in ('u','b')),
  body text not null default '',
  k text default 't',
  x jsonb,
  created timestamptz default now());
create index if not exists c_msgs_conv on public.c_msgs(booth_id, cu, id desc);
create index if not exists c_msgs_cu on public.c_msgs(cu, id desc);
create table if not exists public.c_seen(
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null,
  lid bigint default 0,
  primary key(booth_id, cu, side));
alter table public.c_msgs enable row level security;
alter table public.c_seen enable row level security;

create or replace function public.capp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; bt public.booths; v_bid bigint; v_cu text; v_side text;
        v_aft bigint; v_last bigint; v_ps bigint; v_n int; v_n2 int; v_nid bigint; v_t timestamptz;
        v_body text; v_k text; v_x jsonb; v_pid bigint;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='cping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;

  -- شمار نخوانده‌ها (به‌عنوان مشتری + به‌عنوان غرفه‌دار)
  if op='ccount' then
    select count(*) into v_n from public.c_msgs m
      where m.cu=who and m.side='b'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='u'),0);
    select count(*) into v_n2 from public.c_msgs m join public.booths o on o.id=m.booth_id
      where o.owner=who and m.side='u'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='b'),0);
    return jsonb_build_object('ok',1,'n',v_n+v_n2);
  end if;

  -- لیست گفتگوها
  if op='clist' then
    return jsonb_build_object('ok',1,'l',coalesce((
      select jsonb_agg(row_to_json(z)::jsonb order by z.lid desc) from (
        select c.booth_id as b, c.cu as cu, c.lid as lid,
               case when c.cu=who then 'u' else 'b' end as r,
               m.body as lb, m.k as lk, m.side as ls, m.created as lt,
               (select count(*) from public.c_msgs q
                  where q.booth_id=c.booth_id and q.cu=c.cu
                    and q.side <> (case when c.cu=who then 'u' else 'b' end)
                    and q.id > coalesce((select s.lid from public.c_seen s
                        where s.booth_id=c.booth_id and s.cu=c.cu
                          and s.side=(case when c.cu=who then 'u' else 'b' end)),0)) as un
        from (
          select g.booth_id, g.cu, max(g.id) as lid from public.c_msgs g
          where g.cu=who or g.booth_id in (select o.id from public.booths o where o.owner=who)
          group by g.booth_id, g.cu
          order by max(g.id) desc limit 60) c
        join public.c_msgs m on m.id=c.lid
      ) z), '[]'::jsonb));
  end if;

  -- پیام‌های یک گفتگو (و علامت خوانده‌شدن)
  if op='cmsgs' or op='csend' then
    v_bid := (a->>'b')::bigint;
    select * into bt from public.booths where id=v_bid;
    if not found then return jsonb_build_object('err','none'); end if;
    if bt.owner=who then
      v_side := 'b'; v_cu := nullif(btrim(coalesce(a->>'cu','')),'');
      if v_cu is null then return jsonb_build_object('err','bad'); end if;
      if v_cu=who then return jsonb_build_object('err','self'); end if;
    else
      v_side := 'u'; v_cu := who;
      if bt.status<>'active' then return jsonb_build_object('err','none'); end if;
    end if;

    if op='cmsgs' then
      v_aft := coalesce(nullif(a->>'after','')::bigint,0);
      select coalesce(max(lid),0) into v_ps from public.c_seen
        where booth_id=v_bid and cu=v_cu and side=(case when v_side='u' then 'b' else 'u' end);
      select max(id) into v_last from public.c_msgs where booth_id=v_bid and cu=v_cu;
      if v_last is not null then
        insert into public.c_seen(booth_id,cu,side,lid) values(v_bid,v_cu,v_side,v_last)
          on conflict(booth_id,cu,side) do update set lid=greatest(public.c_seen.lid, excluded.lid);
      end if;
      return jsonb_build_object('ok',1,'ps',v_ps,'m',coalesce((
        select jsonb_agg(jsonb_build_object('id',y.id,'s',y.side,'b',y.body,'k',y.k,'x',y.x,'t',y.created) order by y.id)
        from (select * from public.c_msgs where booth_id=v_bid and cu=v_cu and id>v_aft order by id desc limit 200) y),'[]'::jsonb));
    end if;

    -- ارسال
    if v_side='b' and not exists(select 1 from public.c_msgs where booth_id=v_bid and cu=v_cu) then
      return jsonb_build_object('err','perm');
    end if;
    v_k := coalesce(nullif(a->>'k',''),'t');
    if v_k not in ('t','p') then return jsonb_build_object('err','bad'); end if;
    v_body := left(btrim(coalesce(a->>'body','')),1000);
    v_x := null;
    if v_k='t' then
      if length(v_body)<1 then return jsonb_build_object('err','bad'); end if;
    else
      v_pid := nullif(a->'x'->>'id','')::bigint;
      if v_pid is null or not exists(select 1 from public.booth_products q where q.id=v_pid and q.booth_id=v_bid) then
        return jsonb_build_object('err','bad');
      end if;
      v_x := jsonb_build_object('id',v_pid);
      v_body := left(v_body,200);
    end if;
    -- سقف سرعت: حداکثر ۲۰ پیام در دقیقه برای هر طرف گفتگو
    select count(*) into v_n from public.c_msgs
      where booth_id=v_bid and cu=v_cu and side=v_side and created>now()-interval '1 minute';
    if v_n>=20 then return jsonb_build_object('err','rate'); end if;
    insert into public.c_msgs(booth_id,cu,side,body,k,x) values(v_bid,v_cu,v_side,v_body,v_k,v_x)
      returning id, created into v_nid, v_t;
    return jsonb_build_object('ok',1,'id',v_nid,'t',v_t);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.capp(text,text,text,jsonb) to anon, authenticated;

-- ################ bird.sql — سالن فروش و پرورش (rapp) ################
-- ===== BirdBazaar: سالن فروش و پرورش (مورد ۱۰) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths). به bapp دست نمی‌زند؛ تابع جدید rapp می‌سازد.
create table if not exists public.booth_birds(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null,
  k text default 'sale',
  status text default 'on',
  created timestamptz default now());
alter table public.booth_birds enable row level security;

create or replace function public.rapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; me jsonb := null; nid bigint; kk text;
begin
  a := coalesce(a,'{}'::jsonb);

  -- عمومی: پرنده‌های روشن غرفه‌های فعال
  if op='rpublic' then
    return jsonb_build_object('ok',1,'birds',coalesce((
      select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'bn',x.name,'ph',x.phone,'city',x.city,'d',q.d,'k',q.k,'t',q.created) order by q.id desc)
      from (select * from booth_birds where status='on' order by id desc limit 120) q
      join booths x on x.id=q.booth_id where x.status='active'),'[]'::jsonb));
  end if;

  if op in ('rme','rset','rdel') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then
      begin
        me := public.app('login', u, p, '{}'::jsonb);
      exception when others then
        me := null;
      end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then
        select * into b from booths where owner=u and status<>'off';
      end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;

    if op='rme' then
      return jsonb_build_object('ok',1,'birds',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'k',q.k,'s',q.status,'t',q.created) order by q.id desc) from booth_birds q where q.booth_id=b.id),'[]'::jsonb));
    end if;

    if op='rset' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      kk := case when (a->>'k')='show' then 'show' else 'sale' end;
      if (a->>'id') is null then
        if (select count(*) from booth_birds where booth_id=b.id)>=60 then return jsonb_build_object('err','many'); end if;
        insert into booth_birds(booth_id,d,k,status) values(b.id,a->'d',kk,case when (a->>'s')='off' then 'off' else 'on' end) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_birds set d=coalesce(a->'d',d), k=kk, status=case when (a->>'s') in ('on','off') then a->>'s' else status end where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='rdel' then
      delete from booth_birds where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.rapp(text,text,text,jsonb) to anon, authenticated;

-- ################ UPDATE_FINAL.sql — همکاری غرفه‌داران (kapp) ################
-- ===== BirdBazaar: SQL نهایی (همه‌ی تغییرات تازه در یک فایل) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: booth.sql و msg.sql قبلاً اجرا شده باشند.

-- [مورد ۸] درخواست همکاری با حساب کاربر + تأیید مستقیم + پیام خودکار
alter table public.booth_reqs add column if not exists uname text;

create or replace function public.kapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; adm boolean := false; nid bigint; q public.booth_reqs; ow text;
begin
  a := coalesce(a,'{}'::jsonb);
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;

  -- کاربر واردشده درخواست همکاری می‌فرستد
  if op='kreq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if exists(select 1 from booths where owner=u) then return jsonb_build_object('err','has'); end if;
    if (select count(*) from booth_reqs where (uname=u or phone=a->>'phone') and status='new')>=1 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about,uname) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600),u);
    return jsonb_build_object('ok',1);
  end if;

  -- تأیید توسط ادمین اصلی: غرفه برای همان حساب ساخته می‌شود و پیام خودکار می‌رود
  if op='kapprove' then
    if not adm then return jsonb_build_object('err','denied'); end if;
    select * into q from booth_reqs where id=(a->>'id')::bigint;
    if not found then return jsonb_build_object('err','none'); end if;
    ow := coalesce(nullif(q.uname,''), nullif(a->>'owner',''));
    if ow is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from users where username=ow) then return jsonb_build_object('err','nouser'); end if;
    if exists(select 1 from booths where owner=ow) then return jsonb_build_object('err','taken'); end if;
    insert into booths(owner,pw,name,city,phone) values(ow,crypt(gen_random_uuid()::text,gen_salt('bf')),left(coalesce(nullif(q.shop,''),q.name),80),q.city,q.phone) returning id into nid;
    update booth_reqs set status='ok', uname=ow where id=q.id;
    insert into m_msgs(from_u,to_u,body,kind) values(u,ow,E'مجوز ساخت غرفه\nمجوز ساخت غرفه توسط ادمین صادر شد و هم‌اینک می‌توانید از بخش غرفه‌داران غرفه خود را مدیریت کنید.','box');
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.kapp(text,text,text,jsonb) to anon, authenticated;

-- ################ PUSH.sql — اعلان گوشی (تریگرها + f_push_send) ################
-- اعلان گوشی (۹-ب مرحله‌ی ۲) — بعد از forum.sql در SQL Editor اجرا شود. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: Edge Function با نام push (supabase_functions/push.ts) و Secrets (PUSH_SETUP.txt).
-- کلید PUSH_KEY در این فایل نیست؛ جدا با یک دستور کوتاه گذاشته می‌شود.

create extension if not exists pg_net with schema extensions;
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;
insert into public.f_conf(k,v) values('pushurl','https://axgntmiouzwfotestwcs.supabase.co/functions/v1/push')
  on conflict (k) do update set v=excluded.v;

create or replace function public.f_push_send(unames text[], ttl text, bdy text)
returns void language plpgsql security definer set search_path=public, extensions as $$
declare kk text; uu text;
begin
  select v into kk from public.f_conf where k='pushkey';
  select v into uu from public.f_conf where k='pushurl';
  if coalesce(kk,'')='' or coalesce(uu,'')='' or unames is null or coalesce(array_length(unames,1),0)=0 then return; end if;
  perform net.http_post(url:=uu, body:=jsonb_build_object('users',to_jsonb(unames),'title',ttl,'body',left(coalesce(bdy,''),120)),
    headers:=jsonb_build_object('Content-Type','application/json','x-push-key',kk));
exception when others then null;
end $$;

-- پیام‌ها (m_msgs)
create or replace function public.f_trg_msg() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[]; t text := '📨 پیام جدید';
begin
  if coalesce(new.to_u,'')<>'' then r:=array[new.to_u];
  elsif new.grp='all' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u);
  elsif new.grp='admin' then t:='🛡 پیام مدیران'; r:=array(select username from public.staff where username<>new.from_u);
  elsif new.grp='booth' then t:='🏪 پیام غرفه‌داران'; r:=array(select owner from public.booths where owner<>new.from_u);
  elsif new.grp='user' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u
      and uname not in (select username from public.staff) and uname not in (select owner from public.booths));
  end if;
  perform public.f_push_send(r, t, new.body);
  return new;
exception when others then return new;
end $$;

-- سفارش اصلی (orders) → ادمین‌هایی که مجوز سفارش‌ها دارند
create or replace function public.f_trg_order() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[];
begin
  r:=array(select username from public.staff where (to_jsonb(perms) ? 'o') or (to_jsonb(perms) ? 'all'));
  perform public.f_push_send(r, '🛒 سفارش جدید', coalesce(new.d->>'cu','')||' — '||coalesce(new.d->>'tt','')||' تومان');
  return new;
exception when others then return new;
end $$;

-- سفارش غرفه (booth_orders) → صاحب غرفه
create or replace function public.f_trg_border() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '🛒 سفارش جدید غرفه', coalesce(new.name,''));
  return new;
exception when others then return new;
end $$;

-- گفتگوی کاربر ↔ غرفه‌دار (c_msgs)
create or replace function public.f_trg_chat() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  if new.side='u' then
    perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '💬 پیام جدید از مشتری', case when new.k='t' then new.body else '📎' end);
  else
    perform public.f_push_send(array[new.cu], '💬 پاسخ غرفه‌دار', case when new.k='t' then new.body else '📎' end);
  end if;
  return new;
exception when others then return new;
end $$;

do $$ begin
  if to_regclass('public.m_msgs') is not null then
    drop trigger if exists f_push_msg on public.m_msgs;
    create trigger f_push_msg after insert on public.m_msgs for each row execute function public.f_trg_msg();
  end if;
  if to_regclass('public.orders') is not null then
    drop trigger if exists f_push_order on public.orders;
    create trigger f_push_order after insert on public.orders for each row execute function public.f_trg_order();
  end if;
  if to_regclass('public.booth_orders') is not null then
    drop trigger if exists f_push_border on public.booth_orders;
    create trigger f_push_border after insert on public.booth_orders for each row execute function public.f_trg_border();
  end if;
  if to_regclass('public.c_msgs') is not null then
    drop trigger if exists f_push_chat on public.c_msgs;
    create trigger f_push_chat after insert on public.c_msgs for each row execute function public.f_trg_chat();
  end if;
end $$;

-- ################ PUSHFREE.sql — اعلان آزاد ادمین (pnapp) ################
-- اعلان آزاد ادمین (مورد ۱۵) — بعد از PUSH.sql اجرا شود. چند بار اجرا بی‌خطر است. به توابع قبلی دست نمی‌زند.
create or replace function public.pnapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; isadm boolean; ismain boolean; g text; t text; ttl text; b text; r text[];
begin
  a := coalesce(a,'{}'::jsonb);
  if op<>'pnotify' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  if not isadm then return jsonb_build_object('err','perm'); end if;
  b := left(btrim(coalesce(a->>'b','')),120);
  ttl := left(btrim(coalesce(a->>'title','')),60);
  if length(b)<1 then return jsonb_build_object('err','bad'); end if;
  if ttl='' then ttl := '📢 بازارچه پرندگان'; end if;
  g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
  if g is not null then
    if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
    if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
    if g='all' then r:=array(select distinct uname from public.f_push);
    elsif g='admin' then r:=array(select distinct username from public.staff);
    elsif g='booth' then r:=array(select distinct owner from public.booths);
    else r:=array(select distinct uname from public.f_push where uname not in (select username from public.staff) and uname not in (select owner from public.booths));
    end if;
  else
    if t is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
    r:=array[t];
  end if;
  perform public.f_push_send(r, ttl, b);
  return jsonb_build_object('ok',1,'n',coalesce(array_length(r,1),0),
    'reg',(select count(distinct uname) from public.f_push where uname=any(r)));
end $$;
grant execute on function public.pnapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as pushfree;

-- ################ BACKUP.sql — پشتیبان کامل داخل برنامه (bkapp) ################
-- پشتیبان کامل داخل برنامه (1.9.64) — روی هر دو سرور (قدیمی و جدید) یک‌بار اجرا شود. چندبار اجرا بی‌خطر است.
-- bkexport: فقط مدیر اصلی؛ همه‌ی جدول‌ها + ساختار (جدول، تابع، تریگر) را برمی‌گرداند. bkimport: فقط با «کلید راه‌اندازی» روی سرور خالی.
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;

create or replace function public.bkapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb; r record; rows jsonb; tb jsonb := '{}'::jsonb; ddl jsonb := '[]'::jsonb; q text; kk text; res jsonb := '{}'::jsonb;
  errs jsonb := '[]'::jsonb; n bigint; skip text[] := array['f_conf','f_push']; st text; cols text; nonempty boolean := false;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='bkstate' then
    if to_regclass('public.users') is not null then execute 'select exists(select 1 from public.users)' into nonempty; end if;
    return jsonb_build_object('ok',1,'empty',not nonempty,'armed',exists(select 1 from public.f_conf where k='bkkey' and coalesce(v,'')<>''));
  end if;

  if op='bkexport' then
    begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
    if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
    -- ساختار: توالی‌ها
    for r in select c.relname, format_type(sq.seqtypid,null) as ty from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_sequence sq on sq.seqrelid=c.oid where n.nspname='public' and c.relkind='S' order by 1 loop
      ddl := ddl || to_jsonb('create sequence if not exists public.'||quote_ident(r.relname)||' as '||r.ty);
    end loop;
    -- جدول‌ها
    for r in select c.oid, c.relname, c.relrowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' order by 2 loop
      select string_agg(quote_ident(at.attname)||' '||format_type(at.atttypid,at.atttypmod)
          ||case when at.attidentity='a' then ' generated always as identity' when at.attidentity='d' then ' generated by default as identity'
                 when at.attgenerated='s' then ' generated always as ('||pg_get_expr(d.adbin,d.adrelid)||') stored'
                 when d.adbin is not null then ' default '||pg_get_expr(d.adbin,d.adrelid) else '' end
          ||case when at.attnotnull then ' not null' else '' end, ', ' order by at.attnum) into cols
        from pg_attribute at left join pg_attrdef d on d.adrelid=at.attrelid and d.adnum=at.attnum
        where at.attrelid=r.oid and at.attnum>0 and not at.attisdropped;
      ddl := ddl || to_jsonb('create table if not exists public.'||quote_ident(r.relname)||' ('||cols||')');
      if r.relrowsecurity then ddl := ddl || to_jsonb('alter table public.'||quote_ident(r.relname)||' enable row level security'); end if;
      if r.relname = any(skip) then continue; end if;
      execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from public.%I x', r.relname) into rows;
      tb := tb || jsonb_build_object(r.relname, rows);
    end loop;
    for r in select sc.relname as sq, tc.relname as t, at.attname as col from pg_depend dp join pg_class sc on sc.oid=dp.objid and sc.relkind='S' join pg_class tc on tc.oid=dp.refobjid
             join pg_attribute at on at.attrelid=tc.oid and at.attnum=dp.refobjsubid where dp.deptype in ('a','i') and sc.relnamespace='public'::regnamespace and tc.relnamespace='public'::regnamespace loop
      ddl := ddl || to_jsonb('alter sequence public.'||quote_ident(r.sq)||' owned by public.'||quote_ident(r.t)||'.'||quote_ident(r.col));
    end loop;
    -- قیدها (به‌جز کلید خارجی) و ایندکس‌ها
    for r in select conrelid::regclass::text as t, conname, pg_get_constraintdef(oid) as d from pg_constraint where connamespace='public'::regnamespace and contype in ('p','u','c') order by 1,2 loop
      ddl := ddl || to_jsonb('alter table '||r.t||' add constraint '||quote_ident(r.conname)||' '||r.d);
    end loop;
    for r in select pg_get_indexdef(i.indexrelid) as d from pg_index i join pg_class c on c.oid=i.indexrelid join pg_namespace n on n.oid=c.relnamespace
             where n.nspname='public' and not exists(select 1 from pg_constraint k where k.conindid=i.indexrelid) order by 1 loop
      ddl := ddl || to_jsonb(replace(r.d,'CREATE INDEX','CREATE INDEX IF NOT EXISTS')) ;
    end loop;
    -- سیاست‌های RLS
    for r in select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check from pg_policies where schemaname='public' loop
      ddl := ddl || to_jsonb('drop policy if exists '||quote_ident(r.policyname)||' on public.'||quote_ident(r.tablename));
      ddl := ddl || to_jsonb('create policy '||quote_ident(r.policyname)||' on public.'||quote_ident(r.tablename)||' as '||r.permissive||' for '||r.cmd||' to '||array_to_string(r.roles,',')
        ||coalesce(' using ('||r.qual||')','')||coalesce(' with check ('||r.with_check||')',''));
    end loop;
    -- توابع (به‌جز خود bkapp)
    for r in select pg_get_functiondef(p.oid) as d from pg_proc p where p.pronamespace='public'::regnamespace and p.prokind='f' and p.proname<>'bkapp'
             and not exists(select 1 from pg_depend dp where dp.objid=p.oid and dp.deptype='e') order by p.proname loop
      ddl := ddl || to_jsonb(r.d);
    end loop;
    -- تریگرها
    for r in select t.tgrelid::regclass::text as tb, t.tgname, pg_get_triggerdef(t.oid) as d from pg_trigger t where not t.tgisinternal and t.tgrelid in (select oid from pg_class where relnamespace='public'::regnamespace) loop
      ddl := ddl || to_jsonb('drop trigger if exists '||quote_ident(r.tgname)||' on '||r.tb);
      ddl := ddl || to_jsonb(r.d);
    end loop;
    -- کلیدهای خارجی آخر از همه (بعد از ورود داده)
    for r in select conrelid::regclass::text as t, conname, pg_get_constraintdef(oid) as d from pg_constraint where connamespace='public'::regnamespace and contype='f' order by 1,2 loop
      ddl := ddl || to_jsonb('alter table '||r.t||' add constraint '||quote_ident(r.conname)||' '||r.d);
    end loop;
    return jsonb_build_object('ok',1,'v',1,'ddl',ddl,'data',tb);
  end if;

  if op='bkimport' then
    select v into kk from public.f_conf where k='bkkey';
    if coalesce(kk,'')='' or a->>'k' is distinct from kk then return jsonb_build_object('err','key'); end if;
    if to_regclass('public.users') is not null then execute 'select exists(select 1 from public.users)' into nonempty; end if;
    if nonempty then return jsonb_build_object('err','notempty'); end if;
    perform set_config('check_function_bodies','off',true);
    begin create extension if not exists pg_net with schema extensions; exception when others then null; end;
    -- ساخت ساختار (به ترتیب خروجی)؛ هر خطا ثبت می‌شود ولی ادامه می‌دهد؛ کلید خارجی‌ها بعد از داده
    for r in select value as s, ord from jsonb_array_elements_text(a->'ddl') with ordinality as x(value,ord) where value not like 'alter table % add constraint % FOREIGN KEY%' order by ord loop
      begin execute r.s; exception when duplicate_object or duplicate_table or duplicate_function or invalid_table_definition then null; when others then errs := errs || to_jsonb(left(sqlerrm,160)); end;
    end loop;
    -- داده‌ها
    for r in select key as t, value as rws from jsonb_each(coalesce(a->'data','{}'::jsonb)) loop
      if r.t = any(skip) or to_regclass('public.'||quote_ident(r.t)) is null then errs := errs || to_jsonb('skip '||r.t); continue; end if;
      begin
        execute format('insert into public.%I overriding system value select * from jsonb_populate_recordset(null::public.%I, $1) on conflict do nothing', r.t, r.t) using r.rws;
        get diagnostics n = row_count; res := res || jsonb_build_object(r.t, n);
      exception when others then errs := errs || to_jsonb(r.t||': '||left(sqlerrm,140)); end;
    end loop;
    -- شمارنده‌های ID
    for r in select c.relname as t, at.attname as col, (regexp_match(pg_get_expr(d.adbin,d.adrelid),'nextval\(''([^'']+)''::regclass'))[1] as sq
             from pg_class c join pg_attribute at on at.attrelid=c.oid and at.attnum>0 and not at.attisdropped
             join pg_attrdef d on d.adrelid=at.attrelid and d.adnum=at.attnum
             where c.relnamespace='public'::regnamespace and c.relkind='r' loop
      if r.sq is not null then
        begin execute format('select setval(%L, greatest(coalesce((select max(%I) from public.%I),0),1), (select count(*)>0 from public.%I))', r.sq, r.col, r.t, r.t); exception when others then null; end;
      end if;
    end loop;
    -- کلیدهای خارجی
    for r in select value as s from jsonb_array_elements_text(a->'ddl') where value like 'alter table % add constraint % FOREIGN KEY%' loop
      begin execute r.s; exception when duplicate_object then null; when others then errs := errs || to_jsonb(left(sqlerrm,160)); end;
    end loop;
    -- دسترسی توابع
    for r in select p.oid::regprocedure as f from pg_proc p where p.pronamespace='public'::regnamespace and p.proname in ('app','fapp','bapp','mapp','capp','rapp','kapp','pnapp','bkapp','sapp') loop
      begin execute 'grant execute on function '||r.f||' to anon, authenticated'; exception when others then null; end;
    end loop;
    for r in select p.oid::regprocedure as f from pg_proc p where p.pronamespace='public'::regnamespace and p.proname='f_push_send' loop
      begin execute 'revoke execute on function '||r.f||' from public, anon, authenticated'; exception when others then null; end;
    end loop;
    if coalesce(a->>'url','')<>'' then
      insert into public.f_conf(k,v) values('pushurl', (a->>'url')||'/functions/v1/push') on conflict (k) do update set v=excluded.v;
    end if;
    delete from public.f_conf where k='bkkey';
    return jsonb_build_object('ok',1,'rows',res,'errs',errs);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as backup_sql;


-- ################ تغییرات تازه (از این‌جا به بعد فقط به همین بخش اضافه کن) ################
-- [1.9.66] f_lite + ops public2/pimg داخل fapp (بخش forum بالا) اضافه شد؛ بدون جدول یا ستون تازه.

-- [1.9.67] آمار استفاده‌ی ناشناس (sapp): هر گوشی روزی یک بار گزارش ۲۴ ساعته می‌فرستد (بدون نام کاربری)؛ فقط مدیر اصلی می‌خواند.
create table if not exists public.app_stats(
  day date not null, dev text not null, v text default '', d jsonb not null default '{}'::jsonb,
  ts timestamptz not null default now(), primary key(day,dev));
alter table public.app_stats enable row level security;
create index if not exists app_stats_day_idx on public.app_stats(day);

create or replace function public.s_num(j jsonb, cap numeric) returns numeric language sql immutable as $f$
  select case when jsonb_typeof(j)='number' then least(greatest((j#>>'{}')::numeric,0),cap) else 0 end
$f$;

create or replace function public.sapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; ismain boolean := false; off boolean; dv text; dy date; n int := 0; rec record; dd int;
  rep int; dvc int; hrs jsonb; secs jsonb; ops jsonb; bts jsonb; days jsonb; vers jsonb; tot jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  off := coalesce((select c.v from public.f_conf c where c.k='stoff'),'')='1';

  if op='sput' then
    if off then return jsonb_build_object('ok',1,'off',1); end if;
    if length(a::text)>24000 then return jsonb_build_object('err','big'); end if;
    dv := left(coalesce(a->>'dev',''),40);
    if length(dv)<8 or jsonb_typeof(a->'r')<>'array' then return jsonb_build_object('err','bad'); end if;
    for rec in select value as r from jsonb_array_elements(a->'r') limit 5 loop
      begin
        dy := (rec.r->>'day')::date;
        if dy is not null and dy<=current_date+1 and dy>=current_date-10 and jsonb_typeof(rec.r)='object' then
          insert into public.app_stats(day,dev,v,d) values(dy,dv,left(coalesce(rec.r->>'v',''),12),(rec.r - 'day' - 'v'))
            on conflict(day,dev) do update set d=excluded.d, v=excluded.v, ts=now();
          n := n+1;
        end if;
      exception when others then null;
      end;
    end loop;
    if random()<0.02 then delete from public.app_stats where day<current_date-120; end if;
    return jsonb_build_object('ok',1,'n',n,'off',0);
  end if;

  if op='xget' then
    return jsonb_build_object('ok',1,'f',coalesce((select nullif(c.v,'')::jsonb from public.f_conf c where c.k='xf'),'{}'::jsonb));
  end if;

  if op in ('sget','sset','sclear','xset') then
    begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
    if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
    ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    if not ismain then return jsonb_build_object('err','perm'); end if;
  end if;

  if op='xset' then
    if coalesce(a->>'k','') not in ('sto','dl','lt','md','qb') or coalesce(a->>'v','') not in ('0','1') then return jsonb_build_object('err','bad'); end if;
    insert into public.f_conf(k,v) values('xf', jsonb_build_object(a->>'k',(a->>'v')::int)::text)
      on conflict (k) do update set v=(coalesce(nullif(f_conf.v,'')::jsonb,'{}'::jsonb) || jsonb_build_object(a->>'k',(a->>'v')::int))::text;
    return jsonb_build_object('ok',1,'f',(select c.v::jsonb from public.f_conf c where c.k='xf'));
  end if;
  if op='sset' then
    insert into public.f_conf(k,v) values('stoff', case when coalesce(a->>'off','')='1' then '1' else '0' end)
      on conflict (k) do update set v=excluded.v;
    return jsonb_build_object('ok',1,'off',case when coalesce(a->>'off','')='1' then 1 else 0 end);
  end if;
  if op='sclear' then
    delete from public.app_stats;
    return jsonb_build_object('ok',1);
  end if;

  if op='sget' then
    dd := least(greatest(coalesce(nullif(a->>'days','')::int,7),1),90);
    select count(*), count(distinct dev) into rep, dvc from public.app_stats where day>current_date-dd;
    select jsonb_build_object('o',coalesce(sum(public.s_num(d->'o',300)),0),'s',coalesce(sum(public.s_num(d->'s',86400)),0),
        'b',coalesce(sum(public.s_num(d->'b',2000000000)),0),'last',max(ts)) into tot
      from public.app_stats where day>current_date-dd;
    select coalesce(jsonb_agg(round(t.v) order by t.h),'[]'::jsonb) into hrs from (
      select g.h, coalesce(sum(public.s_num(s.d->'h'->g.h,3600)),0) as v
      from generate_series(0,23) g(h) left join (select d from public.app_stats where day>current_date-dd) s on true group by g.h) t;
    select coalesce(jsonb_agg(jsonb_build_object('k',q.k,'s',q.ss,'b',q.bb,'n',q.nn,'dv',q.c) order by q.ss desc),'[]'::jsonb) into secs from (
      select e.key as k, sum(public.s_num(e.value->'s',86400)) as ss, sum(public.s_num(e.value->'b',2000000000)) as bb,
             sum(public.s_num(e.value->'n',5000)) as nn, count(*) as c
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'x')='object' then t.d->'x' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by ss desc limit 30) q;
    select coalesce(jsonb_agg(jsonb_build_object('k',q.k,'n',q.nn,'b',q.bb,'dv',q.c) order by q.bb desc),'[]'::jsonb) into ops from (
      select e.key as k, sum(public.s_num(e.value->'n',100000)) as nn, sum(public.s_num(e.value->'b',2000000000)) as bb, count(*) as c
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'q')='object' then t.d->'q' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by bb desc limit 30) q;
    select coalesce(jsonb_agg(jsonb_build_object('id',q.k,'name',q.nm,'v',q.vv,'dv',q.c,'u',q.uu) order by q.vv desc),'[]'::jsonb) into bts from (
      select e.key as k, coalesce((select b.name from public.booths b where b.id::text=e.key limit 1),'؟') as nm,
             sum(public.s_num(e.value,5000)) as vv, count(*) as c,
             coalesce((select sum(v2.n) from public.booth_views v2 where v2.booth_id::text=e.key and v2.day>current_date-dd),0) as uu
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'t')='object' then t.d->'t' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by vv desc limit 20) q;
    select coalesce(jsonb_agg(jsonb_build_object('day',q.day,'dev',q.c,'o',q.oo,'s',q.ss,'b',q.bb) order by q.day desc),'[]'::jsonb) into days from (
      select day, count(*) as c, sum(public.s_num(d->'o',300)) as oo, sum(public.s_num(d->'s',86400)) as ss, sum(public.s_num(d->'b',2000000000)) as bb
      from public.app_stats where day>current_date-dd group by day) q;
    select coalesce(jsonb_agg(jsonb_build_object('v',q.v,'n',q.c) order by q.c desc),'[]'::jsonb) into vers from (
      select coalesce(nullif(v,''),'؟') as v, count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;
    return jsonb_build_object('ok',1,'days',dd,'rep',rep,'dev',dvc,'tot',tot,'hr',hrs,'sec',secs,'ops',ops,'bt',bts,'byday',days,'ver',vers,'off',case when off then 1 else 0 end);
  end if;

  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.sapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.69] مهر کل با شمارنده‌ی نسخه (Revision): محاسبه‌ی سنگین md5 فقط وقتی انجام می‌شود که داده تغییر کرده باشد (یا هر ۱۰ دقیقه برای انقضای زمانی)؛ خروجی psig همان قبلی است و کلاینت تغییری نمی‌خواهد.
create or replace function public.f_bump() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.f_conf(k,v) values('rev','1')
  on conflict (k) do update set v=(coalesce(nullif(f_conf.v,''),'0')::bigint+1)::text;
  return null;
end $$;

do $do$
declare t text;
begin
  foreach t in array array['products','ads','stories','v2_kv','booths','booth_products','booth_birds','bcfg'] loop
    if to_regclass('public.'||t) is not null then
      execute format('drop trigger if exists f_bump_t on public.%I', t);
      execute format('create trigger f_bump_t after insert or update or delete or truncate on public.%I for each statement execute function public.f_bump()', t);
    end if;
  end loop;
end $do$;

create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; ps text; pb text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pb := null; end;
  begin
    if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
  exception when others then null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا psig از f_psig استفاده کند (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_psig()' in d)=0 and position('if op=''psig'' then' in d)>0 then
    d := replace(d,'if op=''psig'' then','if op=''psig'' then return public.f_psig(); end if;'||chr(10)||'  if op=''psig_old'' then');
    execute d;
  end if;
end $do$;

-- [1.9.70] انجمن سبک: op fpull با slim=1 فقط پیام‌های جدید را می‌دهد (بدون فهرست اتاق‌ها/پین‌ها/شمارنده‌ی درخواست)؛ روی سرور فعلی تابع زنده‌ی fapp را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد یا متن تابع فرق داشته باشد کاری نمی‌کند).
do $do$
declare d text; ok boolean := true;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('slim' in d)>0 then return; end if;
  if position('''rooms'',coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id' in d)=0 then ok := false; end if;
  if position('from public.f_rooms r where r.status=''on''),''[]''::jsonb),' in d)=0 then ok := false; end if;
  if position('''pins'',coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))' in d)=0 then ok := false; end if;
  if position('m.pinned and m.del=false),''[]''::jsonb),' in d)=0 then ok := false; end if;
  if position('''reqn'',case when ismain then' in d)=0 then ok := false; end if;
  if ok then
    d := replace(d,'''rooms'',coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id','''rooms'',case when coalesce(a->>''slim'','''')=''1'' then null else coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id');
    d := replace(d,'from public.f_rooms r where r.status=''on''),''[]''::jsonb),','from public.f_rooms r where r.status=''on''),''[]''::jsonb) end,');
    d := replace(d,'''pins'',coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))','''pins'',case when coalesce(a->>''slim'','''')=''1'' then null else coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))');
    d := replace(d,'m.pinned and m.del=false),''[]''::jsonb),','m.pinned and m.del=false),''[]''::jsonb) end,');
    d := replace(d,'''reqn'',case when ismain then','''reqn'',case when ismain and not (coalesce(a->>''slim'','''')=''1'') then');
    execute d;
  end if;
end $do$;

-- [1.9.71] دانلود فقط تغییرات: pidx = فهرست «شناسه+مهر» محصول/آگهی/استوری (کش‌شده با rev همان‌طور که psig)؛ pget = فقط آیتم‌های خواسته‌شده (+ بقیه‌ی public مثل cms/guides اگر rest=1).
create or replace function public.f_pub() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare pj jsonb;
begin
  pj := public.app('public','','','{}'::jsonb);
  if pj is null or jsonb_typeof(pj)<>'object' then return pj; end if;
  if (pj->'products') is not null then pj := jsonb_set(pj,'{products}',public.f_lite(pj->'products')); end if;
  if (pj->'ads') is not null then pj := jsonb_set(pj,'{ads}',public.f_lite(pj->'ads')); end if;
  return pj;
end $$;

create or replace function public.f_pidx() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cj text; pj jsonb; ix jsonb;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='pxr';
  select v into ct from public.f_conf where k='pxt';
  select v into cj from public.f_conf where k='pxj';
  if cj is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return cj::jsonb;
  end if;
  pj := public.f_pub();
  if pj is null or jsonb_typeof(pj)<>'object' then return jsonb_build_object('ok',0); end if;
  ix := jsonb_build_object('ok',1,
    'p',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'products')='array' then pj->'products' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    'a',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'ads')='array' then pj->'ads' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    's',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'stories')='array' then pj->'stories' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    'x',md5((pj - 'products' - 'ads' - 'stories')::text));
  insert into public.f_conf(k,v) values('pxj',ix::text),('pxr',rv),('pxt',extract(epoch from now())::bigint::text)
  on conflict (k) do update set v=excluded.v;
  return ix;
end $$;

create or replace function public.f_pget(a jsonb) returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare pj jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  if jsonb_typeof(coalesce(a->'p','[]'::jsonb))<>'array' or jsonb_typeof(coalesce(a->'a','[]'::jsonb))<>'array' or jsonb_typeof(coalesce(a->'s','[]'::jsonb))<>'array' then return jsonb_build_object('ok',0); end if;
  if jsonb_array_length(coalesce(a->'p','[]'::jsonb))>400 or jsonb_array_length(coalesce(a->'a','[]'::jsonb))>400 or jsonb_array_length(coalesce(a->'s','[]'::jsonb))>400 then return jsonb_build_object('ok',0); end if;
  pj := public.f_pub();
  if pj is null or jsonb_typeof(pj)<>'object' then return jsonb_build_object('ok',0); end if;
  return jsonb_build_object('ok',1,
    'products',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'products')='array' then pj->'products' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'p','[]'::jsonb)))),'[]'::jsonb),
    'ads',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'ads')='array' then pj->'ads' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'a','[]'::jsonb)))),'[]'::jsonb),
    'stories',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'stories')='array' then pj->'stories' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'s','[]'::jsonb)))),'[]'::jsonb),
    'rest',case when coalesce(a->>'rest','')='1' then pj - 'products' - 'ads' - 'stories' else null end);
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا opهای pidx و pget را بشناسد (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_pidx()' in d)=0 and position('if op=''public2'' then' in d)>0 then
    d := replace(d,'if op=''public2'' then','if op=''pidx'' then return public.f_pidx(); end if;'||chr(10)||'  if op=''pget'' then return public.f_pget(a); end if;'||chr(10)||'  if op=''public2'' then');
    execute d;
  end if;
end $do$;

-- [1.9.73] عکس سبک برای غرفه‌ها و پرنده‌ها: bpub2/rpub2 = همان bpublic/rpublic ولی d هر محصول/پرنده (اگر th و thk دارد) فقط با عکس کوچک؛ bimg = عکس کامل یک محصول غرفه (k=b) یا پرنده (k=r). به bapp/rapp دست نمی‌زند.
create or replace function public.f_lite_rows(j jsonb) returns jsonb language sql stable as $f$
  select case when j is not null and jsonb_typeof(j)='array' then coalesce((
    select jsonb_agg(
      case when jsonb_typeof(e.v)='object' and jsonb_typeof(e.v->'d')='object'
           then jsonb_set(e.v,'{d}',(public.f_lite(jsonb_build_array(e.v->'d')))->0)
           else e.v end
      order by e.o)
    from jsonb_array_elements(j) with ordinality as e(v,o)), '[]'::jsonb) else j end
$f$;

create or replace function public.f_bpub2() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare r jsonb;
begin
  r := public.bapp('bpublic','','','{}'::jsonb);
  if r is null or jsonb_typeof(r)<>'object' or (r->'prods') is null then return r; end if;
  return jsonb_set(r,'{prods}',public.f_lite_rows(r->'prods'));
end $$;

create or replace function public.f_rpub2() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare r jsonb;
begin
  r := public.rapp('rpublic','','','{}'::jsonb);
  if r is null or jsonb_typeof(r)<>'object' or (r->'birds') is null then return r; end if;
  return jsonb_set(r,'{birds}',public.f_lite_rows(r->'birds'));
end $$;

create or replace function public.f_bimg(a jsonb) returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare ij jsonb; kk text;
begin
  a := coalesce(a,'{}'::jsonb); kk := coalesce(a->>'k','');
  if kk='b' then
    select q.d into ij from public.booth_products q join public.booths x on x.id=q.booth_id
     where q.id::text=a->>'id' and q.status='on' and x.status='active' limit 1;
  elsif kk='r' then
    select q.d into ij from public.booth_birds q join public.booths x on x.id=q.booth_id
     where q.id::text=a->>'id' and q.status='on' and x.status='active' limit 1;
  end if;
  if ij is null then return jsonb_build_object('ok',0); end if;
  return jsonb_build_object('ok',1,'img',ij->'img','imgs',coalesce(ij->'imgs','[]'::jsonb));
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا opهای bpub2 / rpub2 / bimg را بشناسد (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_bpub2()' in d)=0 and position('if op=''public2'' then' in d)>0 then
    d := replace(d,'if op=''public2'' then','if op=''bpub2'' then return public.f_bpub2(); end if;'||chr(10)||'  if op=''rpub2'' then return public.f_rpub2(); end if;'||chr(10)||'  if op=''bimg'' then return public.f_bimg(a); end if;'||chr(10)||'  if op=''public2'' then');
    execute d;
  end if;
end $do$;

-- [1.9.75] ارسال دسته‌ای: bviewn (bapp؛ چند بازدید غرفه در یک درخواست) و mread با ids (mapp؛ چند «دیده شد» در یک درخواست). بدون جدول تازه. بخش‌های بالا (bapp / mapp) هم همین را دارند؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند).
do $do$
declare d text; bv text; mr text;
begin
  bv := $q$  if op='bviewn' then
    with x as (select (case when e.key ~ '^[0-9]{1,15}$' then e.key::bigint end) id, (case when e.value ~ '^[0-9]{1,3}$' then least(greatest(e.value::int,1),50) else 1 end) c
               from jsonb_each_text(case when jsonb_typeof(a->'v')='object' then a->'v' else '{}'::jsonb end) e limit 40),
    ok as (select x.id,x.c from x join booths b on b.id=x.id and b.status='active' where x.id is not null),
    i as (insert into booth_views(booth_id,day,n) select id,current_date,c from ok on conflict(booth_id,day) do update set n=booth_views.n+excluded.n returning 1)
    update booths set views=booths.views+ok.c from ok where booths.id=ok.id;
    return jsonb_build_object('ok',1,'n',1);
  end if;

$q$;
  mr := $q$  if op='mread' and a ? 'ids' and jsonb_typeof(a->'ids')='array' then
    insert into public.m_read(uname,msg)
      select who,m.id from public.m_msgs m
      where m.id in (select (case when t.v ~ '^[0-9]{1,15}$' then t.v::bigint end) from (select jsonb_array_elements_text(a->'ids') v limit 100) t)
        and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
      on conflict do nothing;
    return jsonb_build_object('ok',1,'n',1);
  end if;

$q$;
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('bviewn' in d)=0 and position('  if op=''bview'' then' in d)>0 then
    execute replace(d,'  if op=''bview'' then',bv||'  if op=''bview'' then');
  end if;
  d := pg_get_functiondef('public.mapp(text,text,text,jsonb)'::regprocedure);
  if position('a ? ''ids''' in d)=0 and position('  if op=''mread'' then' in d)>0 then
    execute replace(d,'  if op=''mread'' then',mr||'  if op=''mread'' then');
  end if;
end $do$;

-- [1.9.76] رسانه‌ی انجمن سبک: op جدید fmed (گرفتن رسانه‌ی یک پیام با لمس) و سقف حجم رسانه از 4.2MB به 2.2MB. بخش fapp بالا هم همین را دارد؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند).
do $do$
declare d text; fm text;
begin
  fm := $q$  if op='fmed' then
    return coalesce((select jsonb_build_object('ok',1,'md',m.media) from public.f_msgs m where m.id=nullif(fapp.a->>'id','')::bigint and m.del=false and m.media is not null),jsonb_build_object('ok',0));
  end if;

$q$;
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('op=''fmed''' in d)=0 and position('  if op=''ffaq'' then' in d)>0 then
    d := replace(d,'  if op=''ffaq'' then',fm||'  if op=''ffaq'' then');
    d := replace(d,'>4200000','>2200000');
    execute d;
  end if;
end $do$;

-- [1.9.77] سقف اندازه‌ی لوگو (120KB) و کاور (250KB) غرفه در op bset (bapp). بخش bapp بالا هم همین را دارد؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند). گوشی قبل از ارسال لوگو/کاور را خودکار کوچک می‌کند.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('>120000' in d)=0 and position('    if op=''bset'' then'||chr(10) in d)>0 then
    execute replace(d,'    if op=''bset'' then'||chr(10),'    if op=''bset'' then'||chr(10)||'      if length(coalesce(a->>''logo'',''''))>120000 or length(coalesce(a->>''cover'',''''))>250000 then return jsonb_build_object(''err'',''big''); end if;'||chr(10));
  end if;
end $do$;

-- [1.9.78] مهر غرفه/پرنده با «بازدید» عوض نشود: (۱) f_psig شمارنده‌ی views را از مهر غرفه‌ها حذف می‌کند (قبلاً هر بازدید غرفه مهر را عوض می‌کرد و کش بی‌اثر می‌شد)؛ (۲) تریگر booths با تغییر ستون views دیگر rev را بالا نمی‌برد. بدون جدول تازه. f_psig بالا هم همین را دارد؛ این بخش دوباره آن را می‌سازد (create or replace).
create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; ps text; pb text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pb := null; end;
  begin
    if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
  exception when others then null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
end $$;

do $do$
begin
  if to_regclass('public.booths') is not null then
    drop trigger if exists f_bump_t on public.booths;
    drop trigger if exists f_bump_u on public.booths;
    create trigger f_bump_t after insert or delete or truncate on public.booths for each statement execute function public.f_bump();
    create trigger f_bump_u after update of name,bio,logo,cover,city,phone,status,owner,pw on public.booths for each statement execute function public.f_bump();
  end if;
end $do$;

-- [1.9.79] 🧪 آزمایشی: کلیدهای خاموش/روشن (sapp: xget عمومی / xset فقط مدیر اصلی؛ ذخیره در f_conf.xf) + سطل Storage «bbimg» (عمومی، حداکثر 400KB، فقط webp/jpeg/png؛ هر کسی با کلید Publishable می‌تواند در آن آپلود کند). sapp بالا (بخش 1.9.67) همین را دارد. اگر بخش Storage خطا داد بقیه‌ی فایل اثر نمی‌گیرد و فقط «آزمایش Storage» در برنامه رد می‌شود.
do $do$
begin
  insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
    values('bbimg','bbimg',true,400000,array['image/webp','image/jpeg','image/png'])
    on conflict (id) do update set public=true,file_size_limit=400000,allowed_mime_types=array['image/webp','image/jpeg','image/png'];
  drop policy if exists bbimg_ins on storage.objects;
  create policy bbimg_ins on storage.objects for insert to anon, authenticated with check (bucket_id='bbimg');
exception when others then
  raise notice 'storage setup skipped: %', sqlerrm;
end $do$;

-- [1.9.80] مقایسه‌ی نسخه‌ها در 📡: خروجی sget بخش ver حالا میانگین بازشدن/زمان/دانلود هر نسخه را هم می‌دهد (روی تابع زنده‌ی sapp؛ اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''o'',q.oo' in d)=0
     and position('jsonb_build_object(''v'',q.v,''n'',q.c) order by q.c desc)' in d)>0
     and position('count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;' in d)>0 then
    d := replace(d,'jsonb_build_object(''v'',q.v,''n'',q.c) order by q.c desc)','jsonb_build_object(''v'',q.v,''n'',q.c,''o'',q.oo,''s'',q.ss,''b'',q.bb) order by q.c desc)');
    d := replace(d,'count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;','count(*) as c, sum(public.s_num(d->''o'',300)) as oo, sum(public.s_num(d->''s'',86400)) as ss, sum(public.s_num(d->''b'',2000000000)) as bb from public.app_stats where day>current_date-dd group by 1 limit 12) q;');
    execute d;
  end if;
end $do$;

-- [1.9.82] پشتیبان کامل تکه‌تکه (برای رفع timeout/حجم زیاد): bkapp با nodata:1 فقط ساختار می‌دهد؛ تابع تازه‌ی bkpart جدول‌ها را تکه‌تکه می‌دهد (فقط مدیر اصلی). فایل .bbk و بازگردانی تغییری نکرد.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.bkapp(text,text,text,jsonb)'::regprocedure);
  if position('nodata' in d)=0 and position('      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;' in d)>0 then
    d := replace(d,'      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;','      if coalesce(a->>''nodata'','''')=''1'' then continue; end if;
      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;');
    execute d;
  end if;
end $do$;

create or replace function public.bkpart(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; r record; t text; n int; o int; rows jsonb; tl jsonb := '[]'::jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
  if op='bktables' then
    for r in select c.relname, pg_total_relation_size(c.oid) as sz from pg_class c where c.relnamespace='public'::regnamespace and c.relkind='r' and c.relname not in ('f_conf','f_push') order by 1 loop
      tl := tl || jsonb_build_object('t',r.relname,'sz',r.sz);
    end loop;
    return jsonb_build_object('ok',1,'tables',tl);
  end if;
  if op='bkrows' then
    t := a->>'t'; n := least(greatest(coalesce((a->>'n')::int,50),1),2000); o := greatest(coalesce((a->>'o')::int,0),0);
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null then return jsonb_build_object('err','table'); end if;
    execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from (select * from public.%I order by ctid offset %s limit %s) x', t, o, n) into rows;
    return jsonb_build_object('ok',1,'rows',rows,'n',jsonb_array_length(rows),'by',length(rows::text));
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkpart(text,text,text,jsonb) to anon, authenticated;

-- [1.9.92] اطلاعات سرور داخل داشبورد (فقط مدیر اصلی؛ فقط خواندن)
create or replace function public.vapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; tl jsonb := '[]'::jsonb; cn jsonb := '{}'::jsonb; r record; t text; c bigint;
  dbs bigint; sto bigint; stn bigint; con int; mx int; up bigint; ver text; eg numeric := 0; dvc int := 0;
begin
  if op<>'vget' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if not (((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all')) then return jsonb_build_object('err','perm'); end if;
  dbs := pg_database_size(current_database());
  for r in select c2.relname as n, pg_total_relation_size(c2.oid) as sz from pg_class c2
      where c2.relnamespace='public'::regnamespace and c2.relkind='r' order by 2 desc limit 8 loop
    tl := tl || jsonb_build_object('t',r.n,'sz',r.sz);
  end loop;
  foreach t in array array['users','products','ads','orders','stories'] loop
    begin execute format('select count(*) from public.%I',t) into c; cn := cn || jsonb_build_object(t,c);
    exception when others then null; end;
  end loop;
  begin select coalesce(sum((o.metadata->>'size')::bigint),0), count(*) into sto, stn from storage.objects o;
  exception when others then sto := null; stn := null; end;
  begin select count(*) into con from pg_stat_activity where datname=current_database(); exception when others then con := null; end;
  begin mx := current_setting('max_connections')::int; exception when others then mx := null; end;
  begin up := extract(epoch from (now()-pg_postmaster_start_time()))::bigint; exception when others then up := null; end;
  begin ver := split_part(version(),' ',2); exception when others then ver := null; end;
  begin select coalesce(sum(public.s_num(d->'b',2000000000)),0), count(distinct dev) into eg, dvc from public.app_stats where day>current_date-30;
  exception when others then eg := 0; dvc := 0; end;
  return jsonb_build_object('ok',1,'db',dbs,'tables',tl,'rows',cn,'sto',sto,'stn',stn,'con',con,'mx',mx,'up',up,'ver',ver,'eg',eg,'dvc',dvc);
end $$;
grant execute on function public.vapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.97] بازگردانی پشتیبان کامل داخل پنل مدیر: op تازه‌ی bkput در bkpart (فقط مدیر اصلی؛ فقط جدول‌های مجاز؛ فقط ردیف‌های جاافتاده اضافه می‌شود و ردیف موجود رونویسی نمی‌شود). bktables و bkrows همان قبلی‌اند. (تأییدنشده روی PostgreSQL واقعی)
create or replace function public.bkpart(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; r record; t text; n int; o int; rows jsonb; tl jsonb := '[]'::jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
  if op='bktables' then
    for r in select c.relname, pg_total_relation_size(c.oid) as sz from pg_class c where c.relnamespace='public'::regnamespace and c.relkind='r' and c.relname not in ('f_conf','f_push') order by 1 loop
      tl := tl || jsonb_build_object('t',r.relname,'sz',r.sz);
    end loop;
    return jsonb_build_object('ok',1,'tables',tl);
  end if;
  if op='bkrows' then
    t := a->>'t'; n := least(greatest(coalesce((a->>'n')::int,50),1),2000); o := greatest(coalesce((a->>'o')::int,0),0);
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null then return jsonb_build_object('err','table'); end if;
    execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from (select * from public.%I order by ctid offset %s limit %s) x', t, o, n) into rows;
    return jsonb_build_object('ok',1,'rows',rows,'n',jsonb_array_length(rows),'by',length(rows::text));
  end if;
  if op='bkput' then
    t := a->>'t'; rows := a->'rows';
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null or not exists (select 1 from pg_class c where c.oid=to_regclass('public.'||quote_ident(t)) and c.relkind='r') then return jsonb_build_object('err','table'); end if;
    if rows is null or jsonb_typeof(rows)<>'array' then return jsonb_build_object('err','rows'); end if;
    begin
      execute format('insert into public.%I select * from jsonb_populate_recordset(null::public.%I, $1) on conflict do nothing', t, t) using rows;
      get diagnostics n = row_count;
    exception when others then return jsonb_build_object('err','put','m',left(sqlerrm,200));
    end;
    return jsonb_build_object('ok',1,'ins',n);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkpart(text,text,text,jsonb) to anon, authenticated;

-- [1.9.103] مهر جدا برای غرفه‌ها و پرنده‌ها + کلیدهای سروری sf و cm
-- (۱) f_psig حالا علاوه بر s (محصول/آگهی/استوری/آموزش) و b (غرفه+پرنده؛ مثل قبل برای نسخه‌های قدیمی) دو مهر جدا هم می‌دهد: bb (فقط غرفه‌ها) و r (فقط پرنده‌ها). گوشی‌ها اگر bb/r نبود همان b قدیمی را به‌کار می‌برند. تأییدنشده روی PostgreSQL واقعی.
create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; cbb text; crr text; ps text; pb text; pbb text; prr text; rt text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  select v into cbb from public.f_conf where k='psbb';
  select v into crr from public.f_conf where k='psrr';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''),'bb',nullif(cbb,''),'r',nullif(crr,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pbb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pbb := null; end;
  begin
    rt := coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'');
    prr := md5(rt);
    if pbb is not null then pb := md5(pbb||rt); end if;
  exception when others then prr := null; pb := null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psbb',coalesce(pbb,'')),('psrr',coalesce(prr,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb,'bb',pbb,'r',prr);
end $$;

-- (۲) کلیدهای سروری sf (بروزرسانی بخش‌به‌بخش) و cm (کش هوشمند) برای xset: لیست مجاز کلیدها را در تابع زنده‌ی sapp بزرگ می‌کند (اگر قبلاً شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''cm''' in d)=0 and position('(''sto'',''dl'',''lt'',''md'',''qb'')' in d)>0 then
    d := replace(d,'(''sto'',''dl'',''lt'',''md'',''qb'')','(''sto'',''dl'',''lt'',''md'',''qb'',''sf'',''cm'')');
    execute d;
  end if;
end $do$;

select 'ALL_SQL_DONE' as result;
