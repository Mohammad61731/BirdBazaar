-- ===== BirdBazaar: تنها فایل SQL پروژه (ALL_SQL.sql) — نسخه‌ی 1.9.67 =====
-- اجرا: Supabase > SQL Editor > کل فایل را بچسبان > Run. چند بار اجرا بی‌خطر است.
-- آخر فایل یک خروجی «ALL_SQL_DONE» می‌دهد؛ اگر آن را دیدی یعنی کل فایل چسبیده و اجرا شده.
-- ترتیب: forum ← booth ← msg ← chat ← bird ← kapp ← push ← pushfree ← backup ← تغییرات تازه (پایین فایل)
-- از این به بعد هر SQL جدید فقط به انتهای همین فایل اضافه می‌شود (بخش «تغییرات تازه»).

-- ################ forum.sql — انجمن + پرسش‌های متداول + مهر کل psig (fapp) ################
-- انجمن بازارچه پرندگان (F1) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت کاربر: از همان تابع اصلی public.app (op=login) بررسی می‌شود؛ ادمین اصلی = role admin و pm شامل all.

create table if not exists public.f_push(
  token text primary key, uname text not null, upd timestamptz default now());
create index if not exists f_push_u on public.f_push(uname);
alter table public.f_push enable row level security;

create table if not exists public.f_rooms(
  id serial primary key, name text not null, emoji text default '💬', sort int default 0, status text default 'on');
create table if not exists public.f_msgs(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  uname text not null, kind text not null default 'text', body text default '', media text,
  reply_to bigint, pinned boolean default false, del boolean default false, created timestamptz default now());
create index if not exists f_msgs_room_id on public.f_msgs(room, id desc);
create table if not exists public.f_perm(
  uname text primary key, txt boolean default false, img boolean default false, vid boolean default false,
  fil boolean default false, muted boolean default false, blocked boolean default false);
create table if not exists public.f_reqs(
  id bigserial primary key, uname text not null, want jsonb default '{}'::jsonb, status text default 'new', created timestamptz default now());
create table if not exists public.f_react(
  msg bigint references public.f_msgs(id) on delete cascade, uname text, e text, primary key(msg, uname));
create table if not exists public.f_reports(
  id bigserial primary key, msg bigint, uname text, why text default '', created timestamptz default now());
create table if not exists public.f_prof(uname text primary key, avatar text default '');

-- [مورد ۲] مدیریت انجمن: رنگ اتاق، علامت «ویرایش شد»، پرسش‌های متداول
alter table public.f_rooms add column if not exists color text default '';
alter table public.f_msgs add column if not exists ed boolean default false;
-- [Q7] پرسش و پاسخ: qn = پیام پرسش است، sol = حل شد
alter table public.f_msgs add column if not exists qn boolean default false;
alter table public.f_msgs add column if not exists sol boolean default false;
create table if not exists public.f_faq(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  qu text default 'کاربر نمونه', q text not null, a text default '', sort int default 0, created timestamptz default now());
alter table public.f_faq enable row level security;
-- [P5] گزارش آگهی‌ها (هر کاربر برای هر آگهی یک گزارش؛ فقط ادمین می‌بیند)
create table if not exists public.f_arep(
  id bigserial primary key, ad bigint not null, uname text not null, why text default '', created timestamptz default now(), st text default 'new', unique(ad,uname));
alter table public.f_arep enable row level security;
-- [P4] فروخته شد / تمدید آگهی (جدا از جدول ads؛ صاحب آگهی از ads.d->>'own' بررسی می‌شود)
create table if not exists public.f_adx(
  ad bigint primary key, sold boolean default false, ren timestamptz, upd timestamptz default now());
alter table public.f_adx enable row level security;

alter table public.f_rooms enable row level security;
alter table public.f_msgs enable row level security;
alter table public.f_perm enable row level security;
alter table public.f_reqs enable row level security;
alter table public.f_react enable row level security;
alter table public.f_reports enable row level security;
alter table public.f_prof enable row level security;

insert into public.f_rooms(name,emoji,sort)
select x.n, x.e, x.s from (values ('گفتگوی عمومی پرندگان','🦜',1),('جوجه‌کشی و تخم‌گذاری','🥚',2),('سلامت و بیماری','🩺',3),('خرید و فروش','🛒',4)) as x(n,e,s)
where not exists (select 1 from public.f_rooms);

-- [1.9.53] کنترل انجمن از سمت سرور: fmode = on | closed | off | demo ، fslow = ثانیه‌ی فاصله‌ی بین دو پیام هر کاربر (0 = بدون محدودیت)
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;

-- [1.9.66] نسخه‌ی سبک عکس‌ها: محصول/آگهی که عکس کوچک (th) و مهر آن (thk = طول عکس اول) دارد، در خروجی public2 فقط با عکس کوچک می‌آید (lite=1)؛ عکس کامل با op pimg.
create or replace function public.f_lite(j jsonb) returns jsonb language sql stable as $f$
  select case when j is not null and jsonb_typeof(j)='array' then coalesce((
    select jsonb_agg(
      case when jsonb_typeof(e.v)='object' and coalesce(e.v->>'th','')<>'' and (e.v->>'thk') is not null
            and (e.v->>'thk') = length(coalesce(e.v->'imgs'->>0, e.v->>'img', ''))::text
           then (e.v - 'imgs' - 'img') || jsonb_build_object('imgs', jsonb_build_array(e.v->'th'), 'img', e.v->'th', 'lite', 1)
           else e.v end
      order by e.o)
    from jsonb_array_elements(j) with ordinality as e(v,o)), '[]'::jsonb) else j end
$f$;

create or replace function public.fapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb := null; who text := ''; ismain boolean := false;
  pr public.f_perm; k text; rid bigint; n int; fm text := 'on'; fs int := 0; wt int;
begin
  a := coalesce(a,'{}'::jsonb);
  select coalesce((select c.v from public.f_conf c where c.k='fmode'),'on'), coalesce(nullif((select c.v from public.f_conf c where c.k='fslow'),'')::int,0) into fm, fs;
  if fm not in ('on','closed','off','demo') then fm := 'on'; end if;
  if op='fping' then return jsonb_build_object('ok',1); end if;
  if op='psig' then return public.f_psig(); end if;
  if op='psig_old' then
    declare ps text; pb text;
    begin
      begin
        ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
      exception when others then ps := null; end;
      begin
        pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
      exception when others then pb := null; end;
      begin
        if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
      exception when others then null; end;
      return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
    end;
  end if;

  if op='pidx' then return public.f_pidx(); end if;
  if op='pget' then return public.f_pget(a); end if;
  if op='bpub2' then return public.f_bpub2(); end if;
  if op='rpub2' then return public.f_rpub2(); end if;
  if op='bimg' then return public.f_bimg(a); end if;
  if op='public2' then
    declare pj jsonb;
    begin
      pj := public.app('public','','','{}'::jsonb);
      if pj is null or jsonb_typeof(pj)<>'object' then return pj; end if;
      if (pj->'products') is not null then pj := jsonb_set(pj,'{products}',public.f_lite(pj->'products')); end if;
      if (pj->'ads') is not null then pj := jsonb_set(pj,'{ads}',public.f_lite(pj->'ads')); end if;
      return pj;
    end;
  end if;
  if op='pimg' then
    declare ij jsonb; kk text := coalesce(a->>'k','');
    begin
      if kk='p' then
        select x.d into ij from public.products x where x.id::text=a->>'id' or x.d->>'id'=a->>'id' limit 1;
      elsif kk='a' then
        if exists(select 1 from jsonb_array_elements(coalesce(public.app('public','','','{}'::jsonb)->'ads','[]'::jsonb)) e where e->>'id'=a->>'id') then
          select x.d into ij from public.ads x where x.id::text=a->>'id' or x.d->>'id'=a->>'id' limit 1;
        end if;
      end if;
      if ij is null then return jsonb_build_object('ok',0); end if;
      return jsonb_build_object('ok',1,'img',ij->'img','imgs',coalesce(ij->'imgs','[]'::jsonb));
    end;
  end if;

  -- هویت (اختیاری): از تابع اصلی app
  if coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and (me ? 'err' or coalesce(me->>'role','')='') then me := null; end if;
    if me is not null then
      who := u;
      ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    end if;
  end if;
  select * into pr from public.f_perm where uname=who;

  if op='fwho' then
    return jsonb_build_object('ok',1,'me',who,'role',coalesce(me->>'role',''),'main',ismain,
      'perm',jsonb_build_object('txt',ismain or coalesce(pr.txt,false),'img',ismain or coalesce(pr.img,false),'vid',ismain or coalesce(pr.vid,false),'fil',ismain or coalesce(pr.fil,false),'muted',coalesce(pr.muted,false),'blocked',coalesce(pr.blocked,false)),
      'avatar',coalesce((select avatar from public.f_prof where uname=who),''),'mode',fm,'slow',fs);
  end if;

  if op='fpull' then
    if fm='off' and not ismain then
      return jsonb_build_object('ok',1,'mode',fm,'slow',fs,'rooms','[]'::jsonb,'msgs','[]'::jsonb,'av','{}'::jsonb,'pins','[]'::jsonb,'reqn',0);
    end if;
    n := least(greatest(coalesce((a->>'n')::int,30),1),60);
    return jsonb_build_object('ok',1,'mode',fm,'slow',fs,
      'rooms',case when coalesce(a->>'slim','')='1' then null else coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'name',r.name,'emoji',r.emoji,'color',coalesce(r.color,'')) order by r.sort,r.id) from public.f_rooms r where r.status='on'),'[]'::jsonb) end,
      'msgs',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'k',m.kind,'b',m.body,'md',case when coalesce(a->>'nomd','')='1' then null else m.media end,'rt',m.reply_to,'pin',m.pinned,'hm',(m.media is not null),'ed',coalesce(m.ed,false),'q',coalesce(m.qn,false),'s',coalesce(m.sol,false),'t',m.created,
              'r',coalesce((select jsonb_object_agg(x.e,x.c) from (select e,count(*) c from public.f_react where msg=m.id group by e) x),'{}'::jsonb)) order by m.id)
              from (select * from public.f_msgs where room=(a->>'room')::int and del=false
                     and id>coalesce((a->>'after')::bigint,0) and id<coalesce((a->>'before')::bigint,9223372036854775807)
                     order by id desc limit n) m),'[]'::jsonb),
      'av',case when coalesce(a->>'noav','')='1' then '{}'::jsonb else coalesce((select jsonb_object_agg(f.uname,f.avatar) from public.f_prof f where f.avatar<>'' and f.uname in
              (select distinct uname from (select uname from public.f_msgs where room=(a->>'room')::int and del=false order by id desc limit 60) z)),'{}'::jsonb) end,
      'pins',case when coalesce(a->>'slim','')='1' then null else coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'b',left(m.body,120))) from public.f_msgs m where m.room=(a->>'room')::int and m.pinned and m.del=false),'[]'::jsonb) end,
      'reqn',case when ismain and not (coalesce(a->>'slim','')='1') then (select count(*) from public.f_reqs where status='new') else 0 end);
  end if;

  if op='fmed' then
    return coalesce((select jsonb_build_object('ok',1,'md',m.media) from public.f_msgs m where m.id=nullif(fapp.a->>'id','')::bigint and m.del=false and m.media is not null),jsonb_build_object('ok',0));
  end if;

  if op='ffaq' then
    return jsonb_build_object('ok',1,'faq',coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'qu',f.qu,'q',f.q,'a',f.a) order by f.sort,f.id) from public.f_faq f where f.room=(fapp.a->>'room')::int),'[]'::jsonb));
  end if;

  if who='' then return jsonb_build_object('err','login'); end if;

  if op='fsend' then
    if fm='off' and not ismain then return jsonb_build_object('err','off'); end if;
    if fm='demo' then return jsonb_build_object('err','demo'); end if;
    if fm='closed' and not ismain then return jsonb_build_object('err','closed'); end if;
    if fs>0 and not ismain then
      select ceil(fs - extract(epoch from (now()-max(created))))::int into wt from public.f_msgs where uname=who and created>now()-make_interval(secs=>fs);
      if wt is not null and wt>0 then return jsonb_build_object('err','slow','wait',wt); end if;
    end if;
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if coalesce(pr.muted,false) and not ismain then return jsonb_build_object('err','muted'); end if;
    k := coalesce(a->>'k','text');
    if k not in ('text','img','vid','file') then return jsonb_build_object('err','bad'); end if;
    if not ismain then
      if k='text' and not coalesce(pr.txt,false) then return jsonb_build_object('err','perm'); end if;
      if k='img' and not coalesce(pr.img,false) then return jsonb_build_object('err','perm'); end if;
      if k='vid' and not coalesce(pr.vid,false) then return jsonb_build_object('err','perm'); end if;
      if k='file' and not coalesce(pr.fil,false) then return jsonb_build_object('err','perm'); end if;
    end if;
    if length(coalesce(a->>'b',''))>2000 or length(coalesce(a->>'md',''))>2200000 then return jsonb_build_object('err','big'); end if;
    if k='text' and length(trim(coalesce(a->>'b','')))=0 then return jsonb_build_object('err','bad'); end if;
    if k<>'text' and coalesce(a->>'md','')='' then return jsonb_build_object('err','bad'); end if;
    if not exists (select 1 from public.f_rooms where id=(a->>'room')::int and status='on') then return jsonb_build_object('err','room'); end if;
    if (select count(*) from public.f_msgs where uname=who and created>now()-interval '1 minute')>=20 then return jsonb_build_object('err','many'); end if;
    insert into public.f_msgs(room,uname,kind,body,media,reply_to,qn)
      values((a->>'room')::int, who, k, coalesce(a->>'b',''), nullif(a->>'md',''), nullif(a->>'rt','')::bigint,
        (k='text' and coalesce(a->>'q','') in ('1','true') and nullif(a->>'rt','') is null)) returning id into rid;
    return jsonb_build_object('ok',1,'id',rid);
  end if;

  if op='fdel' then
    update public.f_msgs set del=true where id=(a->>'id')::bigint and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='freact' then
    if (a->>'e') not in ('👍','❤️','😂','🙏') then return jsonb_build_object('err','bad'); end if;
    if exists (select 1 from public.f_react where msg=(a->>'id')::bigint and uname=who and e=a->>'e') then
      delete from public.f_react where msg=(a->>'id')::bigint and uname=who;
    else
      insert into public.f_react(msg,uname,e) values((a->>'id')::bigint,who,a->>'e')
        on conflict (msg,uname) do update set e=excluded.e;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='fav_set' then
    if length(coalesce(a->>'img',''))>200000 then return jsonb_build_object('err','big'); end if;
    insert into public.f_prof(uname,avatar) values(who,coalesce(a->>'img','')) on conflict (uname) do update set avatar=excluded.avatar;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if exists (select 1 from public.f_reqs where uname=who and status='new') then return jsonb_build_object('err','dup'); end if;
    insert into public.f_reqs(uname,want) values(who,coalesce(a->'want','{}'::jsonb));
    return jsonb_build_object('ok',1);
  end if;

  if op='freport' then
    insert into public.f_reports(msg,uname,why) values((a->>'id')::bigint,who,left(coalesce(a->>'why',''),200));
    return jsonb_build_object('ok',1);
  end if;

  -- فقط ادمین اصلی
  if not ismain then return jsonb_build_object('err','denied'); end if;

  if op='freq_list' then
    return jsonb_build_object('ok',1,'reqs',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'u',q.uname,'want',q.want,'t',q.created,
      'av',coalesce((select avatar from public.f_prof where uname=q.uname),'')) order by q.id) from public.f_reqs q where q.status='new'),'[]'::jsonb));
  end if;

  if op='freq_ok' then
    insert into public.f_perm(uname,txt,img,vid,fil)
      select q.uname, coalesce((a->>'txt')::boolean,(q.want->>'txt')::boolean,true), coalesce((a->>'img')::boolean,(q.want->>'img')::boolean,false),
             coalesce((a->>'vid')::boolean,(q.want->>'vid')::boolean,false), coalesce((a->>'fil')::boolean,(q.want->>'fil')::boolean,false)
      from public.f_reqs q where q.id=(a->>'id')::bigint
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    update public.f_reqs set status='ok' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq_no' then
    update public.f_reqs set status='no' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_set' then
    insert into public.f_perm(uname,txt,img,vid,fil) values(a->>'uname',coalesce((a->>'txt')::boolean,false),coalesce((a->>'img')::boolean,false),coalesce((a->>'vid')::boolean,false),coalesce((a->>'fil')::boolean,false))
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_list' then
    return jsonb_build_object('ok',1,'perms',coalesce((select jsonb_agg(to_jsonb(x) order by x.uname) from public.f_perm x),'[]'::jsonb));
  end if;

  if op='fmute' then
    insert into public.f_perm(uname,muted) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set muted=excluded.muted;
    return jsonb_build_object('ok',1);
  end if;

  if op='fblock' then
    insert into public.f_perm(uname,blocked) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set blocked=excluded.blocked;
    return jsonb_build_object('ok',1);
  end if;

  if op='fsolve' then
    if who='' then return jsonb_build_object('err','login'); end if;
    update public.f_msgs set sol=coalesce((a->>'on')::boolean,true)
      where id=(a->>'id')::bigint and qn and del=false and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='arep' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if (select count(*) from public.f_arep where uname=who and created>now()-interval '1 minute')>=10 then return jsonb_build_object('err','many'); end if;
    insert into public.f_arep(ad,uname,why) values((a->>'ad')::bigint, who, left(coalesce(a->>'why',''),150))
      on conflict (ad,uname) do update set why=excluded.why, created=now(), st='new';
    return jsonb_build_object('ok',1);
  end if;

  if op='arep_list' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',z.ad,'n',z.n,'why',z.ws,'t',z.t) order by z.n desc, z.t desc)
      from (select ad, count(*) n, max(created) t, (array_agg(why order by created desc) filter (where why<>''))[1:3] ws
            from public.f_arep where st='new' group by ad order by count(*) desc, max(created) desc limit 100) z),'[]'::jsonb));
  end if;

  if op='arep_done' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    update public.f_arep set st='done' where ad=(a->>'ad')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='myorders' then
    if who='' then return jsonb_build_object('err','login'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'dt',z.d->>'dt','tt',z.d->'tt','st',coalesce(z.d->>'st','new'),'it',coalesce(z.d->'it','[]'::jsonb)) order by z.id desc)
      from (select id,d from public.orders where d->>'u'=who order by id desc limit 50) z),'[]'::jsonb));
  end if;

  if op='ptoken' or op='ptoken_del' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if length(coalesce(a->>'t',''))<20 then return jsonb_build_object('err','bad'); end if;
    if op='ptoken' then
      insert into public.f_push(token,uname,upd) values(a->>'t',who,now())
        on conflict (token) do update set uname=excluded.uname, upd=now();
    else
      delete from public.f_push where token=a->>'t' and uname=who;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='adx_list' then
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',ad,'s',coalesce(sold,false),'r',ren))
      from public.f_adx where coalesce(sold,false) or ren>now()-interval '30 days'),'[]'::jsonb));
  end if;

  if op='adx_sold' or op='adx_renew' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if not (ismain
        or ((me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')
        or exists(select 1 from public.ads x where x.id=(a->>'ad')::bigint and x.d->>'own'=who)) then
      return jsonb_build_object('err','denied');
    end if;
    if op='adx_sold' then
      insert into public.f_adx(ad,sold) values((a->>'ad')::bigint, coalesce((a->>'on')::boolean,true))
        on conflict (ad) do update set sold=excluded.sold, upd=now();
      return jsonb_build_object('ok',1);
    end if;
    if not ismain and exists(select 1 from public.f_adx where ad=(a->>'ad')::bigint and ren>now()-interval '1 day') then
      return jsonb_build_object('err','wait');
    end if;
    insert into public.f_adx(ad,ren) values((a->>'ad')::bigint, now())
      on conflict (ad) do update set ren=now(), upd=now();
    return jsonb_build_object('ok',1);
  end if;

  if op='fmode_set' then
    if not ismain then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'mode','') not in ('on','closed','off','demo') then return jsonb_build_object('err','bad'); end if;
    insert into public.f_conf(k,v) values('fmode',a->>'mode') on conflict on constraint f_conf_pkey do update set v=excluded.v;
    insert into public.f_conf(k,v) values('fslow',least(greatest(coalesce((a->>'slow')::int,0),0),3600)::text) on conflict on constraint f_conf_pkey do update set v=excluded.v;
    return jsonb_build_object('ok',1);
  end if;

  if op='fpin' then
    update public.f_msgs set pinned=coalesce((a->>'on')::boolean,true) where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freport_list' then
    return jsonb_build_object('ok',1,'reports',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'msg',r.msg,'u',r.uname,'why',r.why,'t',r.created,'body',(select left(body,120) from public.f_msgs where id=r.msg),'by',(select uname from public.f_msgs where id=r.msg)) order by r.id desc) from public.f_reports r),'[]'::jsonb));
  end if;

  if op='freport_del' then
    delete from public.f_reports where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_set' then
    if length(trim(coalesce(a->>'name','x')))=0 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_rooms(name,emoji,sort,color) values(left(coalesce(a->>'name','اتاق'),60),left(coalesce(a->>'emoji','💬'),8),coalesce((a->>'sort')::int,(select coalesce(max(sort),0)+1 from public.f_rooms)),left(coalesce(a->>'color',''),9)) returning id into rid;
      return jsonb_build_object('ok',1,'id',rid);
    else
      update public.f_rooms set name=left(coalesce(a->>'name',name),60), emoji=left(coalesce(a->>'emoji',emoji),8), color=left(coalesce(a->>'color',color),9), sort=coalesce((a->>'sort')::int,sort), status=coalesce(a->>'status',status) where id=(a->>'id')::int;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_del' then
    delete from public.f_rooms where id=(a->>'id')::int;
    return jsonb_build_object('ok',1);
  end if;

  if op='fedit' then
    if length(trim(coalesce(a->>'b','')))=0 or length(a->>'b')>2000 then return jsonb_build_object('err','bad'); end if;
    update public.f_msgs set body=a->>'b', ed=true where id=(a->>'id')::bigint and kind='text';
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_set' then
    if length(trim(coalesce(a->>'q','')))=0 or length(a->>'q')>400 or length(coalesce(a->>'a',''))>1500 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_faq(room,qu,q,a,sort) values((a->>'room')::int,left(coalesce(nullif(trim(a->>'qu'),''),'کاربر نمونه'),40),a->>'q',coalesce(a->>'a',''),(select coalesce(max(sort),0)+1 from public.f_faq where room=(fapp.a->>'room')::int));
    else
      update public.f_faq set qu=left(coalesce(nullif(trim(fapp.a->>'qu'),''),qu),40), q=fapp.a->>'q', a=coalesce(fapp.a->>'a',f_faq.a) where id=(fapp.a->>'id')::bigint;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_del' then
    delete from public.f_faq where id=(fapp.a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.fapp(text,text,text,jsonb) to anon, authenticated;


-- [1.9.55] پرسش و پاسخ‌های نمونه (گفتگوهای نمونه‌ی هر گروه؛ داخل خود چت نمایش داده می‌شوند، با برچسب «نمونه / نام‌ها فرضی»).
-- نمونه‌های قدیمی (نام «کاربر نمونه n») جایگزین می‌شوند؛ پرسش‌هایی که ادمین خودش ساخته یا ویرایش کرده دست نمی‌خورد. چند بار اجرا بی‌خطر است.
delete from public.f_faq where qu like 'کاربر نمونه%';
insert into public.f_faq(room,qu,q,a,sort)
select r.id, x.qu, x.q, x.a, x.s from public.f_rooms r
join (values
($q$گفتگوی عمومی پرندگان$q$,$q$امیر$q$,$q$برای شروع نگهداری از طوطی‌سانان چه چیزهایی لازم است؟$q$,$q$سلام امیر جان 🌿 یک قفس بزرگ و تمیز، ظرف آب و دانه‌ی جدا، دانه‌ی متنوع و باکیفیت، سبزی تازه، چوب‌نشیمن با ضخامت‌های مختلف و چند اسباب‌بازی ساده. قفس را دور از آشپزخانه، کوران و دود بگذارید.$q$,1),
($q$گفتگوی عمومی پرندگان$q$,$q$سارا$q$,$q$چه خوراکی‌هایی برای پرنده خطرناک است؟$q$,$q$سارا جان این‌ها را هرگز ندهید: آووکادو، شکلات، قهوه و چای، الکل، پیاز و سیر. دود ظرف‌های تفلون هم برای پرنده‌ها خیلی خطرناک است؛ هنگام پخت‌وپز پرنده را از آشپزخانه دور کنید.$q$,2),
($q$گفتگوی عمومی پرندگان$q$,$q$محمد$q$,$q$دمای مناسب نگهداری چقدر است؟$q$,$q$معمولاً بین ۲۰ تا ۲۵ درجه خوب است. مهم‌تر از عدد، ثابت‌بودن هواست: از کوران و تغییر ناگهانی دما دور نگه دارید. نور ملایم صبحگاهی هم عالی است، ولی قفس زیر آفتاب داغ ظهر نباشد.$q$,3),
($q$گفتگوی عمومی پرندگان$q$,$q$مریم$q$,$q$پرنده‌ام تنهاست، یک جفت دیگر برایش بگیرم؟$q$,$q$بستگی دارد. بیشتر طوطی‌سانان اجتماعی‌اند و به همراه یا وقت شما نیاز دارند. اگر جفت می‌گیرید، پرنده‌ی تازه را حداقل دو هفته جدا نگه دارید و بعد آرام آرام آشنا کنید.$q$,4),
($q$گفتگوی عمومی پرندگان$q$,$q$رضا$q$,$q$هر چند وقت قفس را بشویم؟$q$,$q$کف قفس را روزانه یا یک‌روز‌درمیان عوض کنید، ظرف آب و غذا را هر روز بشویید و یک‌بار در هفته شست‌وشوی کامل قفس و چوب‌ها را انجام بدهید. تمیزی بیشترین جلوگیری را از بیماری می‌کند.$q$,5),
($q$گفتگوی عمومی پرندگان$q$,$q$نرگس$q$,$q$پرنده‌ام پرهای خودش را می‌کند، چرا؟$q$,$q$دلیل‌های رایج: استرس، بی‌حوصلگی، تغذیه‌ی ضعیف، انگل یا بیماری. اول تغذیه، اسباب‌بازی و خواب کافی (حدود ۱۰ ساعت تاریکی) را بررسی کنید. اگر ادامه داشت حتماً دامپزشک پرندگان ببیند.$q$,6),
($q$گفتگوی عمومی پرندگان$q$,$q$آرمان$q$,$q$روزی چند ساعت باید با پرنده وقت بگذرانم؟$q$,$q$حداقل یکی دو ساعت تعامل و بازی خوب است. اگر چند ساعت بیرون از قفس می‌آید، حتماً زیر نظر باشید.$q$,7),
($q$گفتگوی عمومی پرندگان$q$,$q$هانیه$q$,$q$پرنده‌ام زیاد جیغ می‌زند، چه کنم؟$q$,$q$معمولاً از تنهایی، بی‌حوصلگی یا کم‌خوابی است. شب‌ها آرام و تاریک بخوابد، اسباب‌بازی بگذارید و وقتی آرام است تشویقش کنید، نه وقتی جیغ می‌زند.$q$,8),
($q$گفتگوی عمومی پرندگان$q$,$q$داریوش$q$,$q$چطور پرنده‌ام را رام کنم؟$q$,$q$با صبر. دست را آرام و بدون حرکت ناگهانی نزدیک ببرید، با کمی ارزن تشویق کنید و جلسه‌ها را کوتاه و روزانه نگه دارید. هرگز به‌زور نگیریدش.$q$,9),
($q$گفتگوی عمومی پرندگان$q$,$q$مینا$q$,$q$بهترین دانه کدام است؟$q$,$q$مخلوط مخصوص گونه‌ی خودش، به‌علاوه سبزی و میوه‌ی تازه. فقط دانه‌ی چرب مثل آفتابگردان زیاد نباشد. پلت باکیفیت هم گزینه‌ی خوبی است.$q$,10),
($q$گفتگوی عمومی پرندگان$q$,$q$فرزاد$q$,$q$پرنده را حمام کنم؟$q$,$q$اسپری آب ولرم یا ظرف کم‌عمق در هوای گرم عالی است. در هوای سرد و بعدش در کوران نگذاریدش تا خشک شود.$q$,11),
($q$گفتگوی عمومی پرندگان$q$,$q$پگاه$q$,$q$پرنده چند ساعت باید بخوابد؟$q$,$q$حدود ۱۰ تا ۱۲ ساعت تاریکی و آرامش. شب‌ها پارچه‌ی نازک روی قفس بیندازید و از تلویزیون و نور دورش کنید.$q$,12),
($q$گفتگوی عمومی پرندگان$q$,$q$کاوه$q$,$q$باز گذاشتن پرنده در خانه خطر ندارد؟$q$,$q$چرا. پنجره و در بسته، پنکه‌ی سقفی خاموش، آینه و شیشه‌ی تمیز، سیم برق و گیاهان سمی و ظرف‌های پر از آب (مثل لیوان) جزو خطرها هستند. حتماً مراقبش باشید.$q$,13),
($q$گفتگوی عمومی پرندگان$q$,$q$ترانه$q$,$q$برای سفر پرنده را چه کنم؟$q$,$q$سپردن به یک آدم مطمئن که قبلاً با پرنده کار کرده بهتر از جابه‌جایی است. غذا، آب و دستورالعمل کوتاه بدهید.$q$,14),
($q$گفتگوی عمومی پرندگان$q$,$q$بیژن$q$,$q$برای شروع مرغ‌عشق بگیرم یا کاکتیل؟$q$,$q$مرغ‌عشق کوچک‌تر و پرانرژی است؛ کاکتیل آرام‌تر و مهربان‌تر است ولی گرد و غبار بیشتری دارد. به وقتی که دارید و فضای خانه فکر کنید.$q$,15),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$علی$q$,$q$چه سنی برای جفت‌گیری مناسب است؟$q$,$q$پرنده‌ها باید کاملاً بالغ و سالم باشند، معمولاً بالای یک سال. جفت‌های لاغر یا پرنده‌های تازه‌خریداری‌شده را زود جفت نکنید. تشخیص جنسیت در بعضی گونه‌ها فقط با آزمایش DNA قطعی است.$q$,1),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$زهرا$q$,$q$جعبه‌ی لانه چه شکلی باشد؟$q$,$q$متناسب با گونه، با ورودی مناسب و کف نرم. جای آرام و کم‌رفت‌وآمد بگذارید و در روزهای اول بیش از حد سرک نکشید تا پرنده‌ها استرس نگیرند.$q$,2),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$پویا$q$,$q$تخم‌ها چند روز بعد جوجه می‌شوند؟$q$,$q$بسته به گونه فرق می‌کند؛ مثلاً قناری حدود ۱۳ تا ۱۴ روز و مرغ‌عشق و کاکتیل حدود ۱۸ تا ۲۱ روز. تاریخ شروع خوابیدن روی تخم‌ها را یادداشت کنید.$q$,3),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$مهدی$q$,$q$تخم‌ها را می‌شود دست زد؟$q$,$q$تا جای ممکن نه. اگر لازم شد با دست‌های تمیز و خیلی کوتاه. حدود ۵ تا ۷ روز بعد می‌شود با نور ملایم (شب‌تابی) پیدا کرد تخم بارور است یا نه.$q$,4),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ساناز$q$,$q$مادر روی تخم‌ها نمی‌خوابد، چه کنم؟$q$,$q$پرنده‌های تازه‌کار گاهی چند روز طول می‌کشد. محیط را آرام نگه دارید و مزاحم نشوید. اگر چند روز بیشتر طول کشید یا تخم‌ها سرد شد، با یک نفر باتجربه یا دامپزشک مشورت کنید.$q$,5),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$حسین$q$,$q$ماده تخم‌گذاری دارد؛ چه مکملی بدهم؟$q$,$q$استخوان سفید ماهی مرکب و غذای کلسیم‌دار کمک می‌کند. اگر ماده نشسته، پف کرده و بی‌حال است و تخم گیر کرده، فوراً به دامپزشک برسانید؛ گرم نگه داشتن در راه کمک می‌کند.$q$,6),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$شقایق$q$,$q$ماده چند تا تخم می‌گذارد؟$q$,$q$بسته به گونه فرق می‌کند؛ معمولاً بین سه تا هشت تا، و هر یکی دو روز یک تخم. تعداد زیاد پشت سر هم ماده را خسته می‌کند.$q$,7),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$امید$q$,$q$جوجه‌ها کی پر درمی‌آورند؟$q$,$q$معمولاً بین سه تا پنج هفته، بسته به گونه. تا آن موقع محیط گرم و آرام و بدون سر و صدا باشد.$q$,8),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سمیرا$q$,$q$تخم‌هایمان بارور نشدند، چرا؟$q$,$q$دلیل‌ها: جوانی یا ناباروری جفت، جنسیت اشتباه، تغذیه‌ی ضعیف، استرس یا دمای نامناسب. تغذیه و آرامش را بهتر کنید و چند هفته صبر کنید.$q$,9),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$وحید$q$,$q$قبل از جفت‌گیری غذای ویژه بدهم؟$q$,$q$کمی پروتئین بیشتر (مثل تخم‌مرغ آب‌پز)، دانه‌ی جوانه‌زده و کلسیم، ولی کم‌کم. زیاده‌روی در غذای چرب مناسب نیست.$q$,10),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$رها$q$,$q$جوجه‌ها را چه زمانی از والدین جدا کنم؟$q$,$q$زود نه. معمولاً بعد از اینکه خودشان غذا خوردن و پریدن را یاد گرفتند و حدود شش تا هشت هفته که بسته به گونه است.$q$,11),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$نیما$q$,$q$نور چقدر باشد؟$q$,$q$حدود ۱۲ تا ۱۴ ساعت روشنایی می‌تواند فصل جفت‌گیری را تحریک کند؛ شب‌ها هم تاریکی کامل بدهید.$q$,12),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$غزل$q$,$q$سالی چند بار جفت‌گیری مجاز است؟$q$,$q$بین دوره‌ها به ماده استراحت بدهید. پشت سر هم جوجه‌آوردن او را ضعیف می‌کند.$q$,13),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سینا$q$,$q$جوجه را دستی پرورش بدهم؟$q$,$q$فقط اگر لازم باشد و تجربه دارید؛ خطر جوجه خیلی زیاد است. بهتر است با یک فرد باتجربه یا دامپزشک مشورت کنید.$q$,14),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ملیحه$q$,$q$لانه را تمیز کنم؟$q$,$q$تا وقتی جوجه‌ها داخل‌اند دست‌کاری را حداقل کنید. بعد از جوجه‌درآمدن و ترک لانه تمیز و ضدعفونی کنید.$q$,15),
($q$سلامت و بیماری$q$,$q$آرش$q$,$q$پرنده‌ام پف کرده و کم‌غذا شده، چه کنم؟$q$,$q$این‌ها می‌تواند نشانه‌ی بیماری باشد و پرنده‌ها دردشان را تا آخر پنهان می‌کنند. گرم و آرام نگهش دارید، آب در دسترس باشد و هرچه زودتر به دامپزشک پرندگان نشانش بدهید.$q$,1),
($q$سلامت و بیماری$q$,$q$الهام$q$,$q$رنگ و حالت مدفوع عوض شده؛ نگران باشم؟$q$,$q$تغییر کوتاه بعد از خوردن میوه‌ی رنگی عادی است. اگر آبکی، بدبو، خونی یا چند روز ادامه‌دار بود و پرنده بی‌حال شد، عکس مدفوع را بگیرید و به دامپزشک نشان بدهید.$q$,2),
($q$سلامت و بیماری$q$,$q$کیان$q$,$q$عطسه و ترشح بینی دارد.$q$,$q$گاهی از گرد و غبار یا دود است، ولی ادامه‌ی آن می‌تواند عفونت تنفسی باشد. محیط را از دود و اسپری دور کنید و اگر چند روز ماند، معاینه لازم است.$q$,3),
($q$سلامت و بیماری$q$,$q$نیلوفر$q$,$q$منقار و ناخن‌ها بلند شده‌اند.$q$,$q$چوب و سنگ‌پای مخصوص بگذارید. کوتاه‌کردن را اگر بلد نیستید خودتان انجام ندهید؛ برش بیش از حد باعث خونریزی می‌شود. دامپزشک یا فرد باتجربه انجام بدهد.$q$,4),
($q$سلامت و بیماری$q$,$q$بهرام$q$,$q$می‌شود خودم دارو بدهم؟$q$,$q$لطفاً بدون تشخیص دامپزشک دارو یا آنتی‌بیوتیک ندهید؛ دوز اشتباه برای پرنده‌ی کوچک خطرناک است. این بخش برای تجربه و آگاهی است و جای دامپزشک را نمی‌گیرد.$q$,5),
($q$سلامت و بیماری$q$,$q$شیدا$q$,$q$پرنده‌ی جدید را چطور قرنطینه کنم؟$q$,$q$حداقل دو تا چهار هفته در اتاق جدا و با ظرف‌های جدا نگه دارید. اول دست‌های پرنده‌های سالم را بشویید، بعد سراغ پرنده‌ی جدید بروید تا بیماری منتقل نشود.$q$,6),
($q$سلامت و بیماری$q$,$q$رامین$q$,$q$دانه‌ی کپک‌زده را الک کنم و بدهم؟$q$,$q$نه، حتی کپک کم هم سم تولید می‌کند. دانه را دور بریزید و در ظرف دربسته و خشک نگه دارید.$q$,7),
($q$سلامت و بیماری$q$,$q$آزاده$q$,$q$پرنده با دهان باز نفس می‌کشد.$q$,$q$ممکن است تنگی نفس یا گرمازدگی باشد. محیط را خنک و آرام کنید و فوراً دامپزشک.$q$,8),
($q$سلامت و بیماری$q$,$q$احسان$q$,$q$ریزش پر طبیعی است؟$q$,$q$پرریزی فصلی عادی است. اگر جاهای بدون پر یا پوست قرمز دیدید، یا پرنده بی‌حال شد، معاینه لازم است.$q$,9),
($q$سلامت و بیماری$q$,$q$ملیکا$q$,$q$چشمش ورم کرده و ترشح دارد.$q$,$q$می‌تواند عفونت یا آسیب باشد. خودسرانه قطره نریزید؛ دامپزشک.$q$,10),
($q$سلامت و بیماری$q$,$q$شهاب$q$,$q$پایین قفس می‌نشیند و پایش ورم دارد.$q$,$q$ممکن است مشکل پا یا بیماری باشد. نشیمن نرم و کم‌ارتفاع بگذارید و برای معاینه ببرید.$q$,11),
($q$سلامت و بیماری$q$,$q$دلارام$q$,$q$پرنده‌ی تازه‌آورده بی‌حال است.$q$,$q$تغییر محیط استرس دارد. گرم، آرام و با غذا و آب در دسترس نگهش دارید؛ اگر دو روز نخورد یا بدتر شد، دامپزشک.$q$,12),
($q$سلامت و بیماری$q$,$q$بابک$q$,$q$ویتامین بدهم؟$q$,$q$غذای متنوع معمولاً کافی است. مکمل را بدون نظر دامپزشک زیاد ندهید.$q$,13),
($q$سلامت و بیماری$q$,$q$مسعود$q$,$q$چه علامت‌هایی اورژانسی است؟$q$,$q$خونریزی، نفس با دهان باز، افتادن از نشیمن، پف دائم، دو روز نخوردن یا تخم گیرکرده. فوراً به دامپزشک برسانید.$q$,14),
($q$خرید و فروش$q$,$q$یاسر$q$,$q$هنگام خرید پرنده چه چیزهایی را ببینم؟$q$,$q$پرنده فعال و کنجکاو باشد، چشم‌ها روشن، پرها مرتب، بینی خشک و تمیز، پاها و ناخن‌ها سالم. پرنده‌ای که پف‌کرده در گوشه نشسته را نخرید.$q$,1),
($q$خرید و فروش$q$,$q$فاطمه$q$,$q$پرنده را چطور با خیال راحت حمل کنم؟$q$,$q$در قفس یا جعبه‌ی کوچک با منفذ هوا، روی آن پارچه‌ی نازک بیندازید تا آرام باشد. در ماشین گرم یا سرد نگذارید و آب و میوه‌ی آبدار را فقط اگر مسیر طولانی است همراه ببرید.$q$,2),
($q$خرید و فروش$q$,$q$کامران$q$,$q$خرید حضوری بهتر است یا ارسالی؟$q$,$q$تا می‌توانید حضوری ببینید. اگر ارسالی است، از فروشنده ویدیو و عکس واضح بخواهید و پرداخت کامل پیش از دیدن پرنده را نپذیرید.$q$,3),
($q$خرید و فروش$q$,$q$لیلا$q$,$q$اطلاعات سن و جنسیت را چقدر باور کنم؟$q$,$q$تشخیص سن و جنس در بعضی گونه‌ها ظاهری نیست. اگر برایتان مهم است، از آزمایش DNA یا شناسنامه و حلقه‌ی پای پرنده کمک بگیرید.$q$,4),
($q$خرید و فروش$q$,$q$سجاد$q$,$q$بعد از خرید باید قرنطینه کنم؟$q$,$q$بله، پرنده‌ی تازه را چند هفته جدا نگه دارید و رفتارش را زیر نظر بگیرید، بعد کنار بقیه ببرید.$q$,5),
($q$خرید و فروش$q$,$q$ندا$q$,$q$اگر آگهی مشکوک بود چه کنم؟$q$,$q$از دکمه‌ی گزارش آگهی استفاده کنید تا ادمین بررسی کند. هیچ‌وقت پول بیعانه‌ی بزرگ ندهید و معامله‌ی حضوری را ترجیح بدهید. مسئولیت آگهی با ثبت‌کننده است.$q$,6),
($q$خرید و فروش$q$,$q$حمید$q$,$q$قیمت منصفانه چقدر است؟$q$,$q$با چند آگهی مشابه (گونه، سن، جهش) مقایسه کنید. عددهای پراکنده را معیار نگیرید.$q$,7),
($q$خرید و فروش$q$,$q$ثمین$q$,$q$حلقه‌ی پای پرنده چیست؟$q$,$q$حلقه‌ی بسته معمولاً نشانگر سال و محل پرورش است. به شناسایی منبع کمک می‌کند.$q$,8),
($q$خرید و فروش$q$,$q$جواد$q$,$q$از غرفه بخرم یا فروشنده‌ی خصوصی؟$q$,$q$هر دو ممکن است خوب باشند. غرفه معمولاً سابقه و پروفایل دارد؛ پروفایل و آگهی‌های قبلی فروشنده را ببینید.$q$,9),
($q$خرید و فروش$q$,$q$آیدا$q$,$q$با پرنده چه لوازمی بخرم؟$q$,$q$قفس مناسب، ظرف آب و غذا، چوب نشیمن، دانه‌ی همان برندی که فروشنده می‌دهد (تغییر ناگهانی غذا نکنید).$q$,10),
($q$خرید و فروش$q$,$q$رضوان$q$,$q$جفت بخرم؛ از جنسیت مطمئن شوم؟$q$,$q$در بسیاری از گونه‌ها ظاهر کافی نیست؛ اگر مهم است، آزمایش DNA بهترین راه است.$q$,11),
($q$خرید و فروش$q$,$q$سعید$q$,$q$می‌خواهم پرنده‌ام را بفروشم؛ آگهی چطور باشد؟$q$,$q$عکس و ویدیوی واضح، سن، جنس تقریبی، سلامت و قیمت بدون اغراق؛ و در بخش آگهی‌ها ثبت کنید.$q$,12),
($q$خرید و فروش$q$,$q$فرناز$q$,$q$بعد از فروش آگهی را چه کنم؟$q$,$q$از دکمه‌ی «فروخته شد» در صفحه‌ی آگهی استفاده کنید؛ اگر نشد، تمدیدش هم هست.$q$,13),
($q$خرید و فروش$q$,$q$پدرام$q$,$q$پرداخت امن چطور است؟$q$,$q$حضوری و بعد از دیدن پرنده؛ بیعانه‌ی بزرگ نپردازید.$q$,14),
($q$خرید و فروش$q$,$q$مهسا$q$,$q$فروشنده تضمین سلامت می‌دهد؟$q$,$q$با فروشنده درباره‌ی چند روز مهلت برای بررسی توافق کنید و بهتر است مکتوب باشد.$q$,15)
) as x(rn,qu,q,a,s) on x.rn=r.name
where not exists (select 1 from public.f_faq f where f.room=r.id and f.q=x.q);

-- ################ booth.sql — غرفه‌داران (bapp) ################
-- ===== BirdBazaar: غرفه‌داران (G1) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- بعد از اجرا حتماً رمز مدیریت را عوض کن (آخر فایل).
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.booths(
  id bigserial primary key, owner text unique not null, pw text not null,
  name text not null, bio text default '', logo text default '', cover text default '',
  city text default '', phone text default '', status text default 'active',
  views int default 0, created timestamptz default now());
create table if not exists public.booth_products(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null, status text default 'on', created timestamptz default now());
create table if not exists public.booth_views(
  booth_id bigint references public.booths(id) on delete cascade, day date, n int default 0,
  primary key(booth_id,day));
create table if not exists public.booth_reqs(
  id bigserial primary key, name text, phone text, city text, shop text, about text,
  status text default 'new', created timestamptz default now());
create table if not exists public.bcfg(k text primary key, v text);

alter table public.booths enable row level security;
alter table public.booth_products enable row level security;
alter table public.booth_views enable row level security;
create table if not exists public.booth_orders(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  name text, phone text, addr text default '', lines jsonb not null default '[]'::jsonb,
  total bigint default 0, status text default 'new', created timestamptz default now());
alter table public.booth_reqs enable row level security;
alter table public.booth_orders enable row level security;
alter table public.bcfg enable row level security;

-- رمز جدای مدیریت غرفه‌ها حذف شد؛ ادمین اصلی با حساب اصلی وارد می‌شود.
delete from public.bcfg where k='admin_key';

create or replace function public.bapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; adm boolean := false; r jsonb; nid bigint; bid bigint; me jsonb := null;
begin
  a := coalesce(a,'{}'::jsonb);
  -- ادمین اصلی: هویت با همان تابع app (role admin و pm شامل all)
  if op like 'badm_%' and coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and not (me ? 'err') and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;
  end if;

  if op='bpublic' then
    return jsonb_build_object('ok',1,
      'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'name',x.name,'bio',x.bio,'logo',x.logo,'cover',x.cover,'city',x.city,'phone',x.phone,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id and q.status='on')) order by x.id) from booths x where x.status='active'),'[]'::jsonb),
      'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'d',q.d,'t',q.created) order by q.id desc) from booth_products q join booths x on x.id=q.booth_id where x.status='active' and q.status='on'),'[]'::jsonb));
  end if;

  if op='bviewn' then
    with x as (select (case when e.key ~ '^[0-9]{1,15}$' then e.key::bigint end) id, (case when e.value ~ '^[0-9]{1,3}$' then least(greatest(e.value::int,1),50) else 1 end) c
               from jsonb_each_text(case when jsonb_typeof(a->'v')='object' then a->'v' else '{}'::jsonb end) e limit 40),
    ok as (select x.id,x.c from x join booths b on b.id=x.id and b.status='active' where x.id is not null),
    i as (insert into booth_views(booth_id,day,n) select id,current_date,c from ok on conflict(booth_id,day) do update set n=booth_views.n+excluded.n returning 1)
    update booths set views=booths.views+ok.c from ok where booths.id=ok.id;
    return jsonb_build_object('ok',1,'n',1);
  end if;

  if op='bview' then
    bid := (a->>'id')::bigint;
    if not exists(select 1 from booths where id=bid and status='active') then return jsonb_build_object('err','none'); end if;
    insert into booth_views(booth_id,day,n) values(bid,current_date,1) on conflict(booth_id,day) do update set n=booth_views.n+1;
    update booths set views=views+1 where id=bid;
    return jsonb_build_object('ok',1);
  end if;

  if op='breq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_reqs where phone=a->>'phone' and status='new')>=3 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600));
    return jsonb_build_object('ok',1);
  end if;

  -- ثبت سفارش مشتری (O1) — عمومی
  if op='bord' then
    if jsonb_typeof(a->'lines')<>'array' or jsonb_array_length(a->'lines')=0 or jsonb_array_length(a->'lines')>40 then return jsonb_build_object('err','bad'); end if;
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_orders where phone=left(a->>'phone',30) and created>now()-interval '1 hour')>=5 then return jsonb_build_object('err','many'); end if;
    select * into b from booths where id=(a->>'b')::bigint and status='active';
    if not found then return jsonb_build_object('err','off'); end if;
    insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'addr',''),400),a->'lines',coalesce((a->>'total')::bigint,0));
    return jsonb_build_object('ok',1);
  end if;

  -- ورود غرفه‌دار
  if op in ('blogin','bme','bprod_set','bprod_del','bset','bpw','bords','bord_st') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then
      -- ورود با حساب اصلی (U4): اگر غرفه‌ای به نام همین کاربر وصل شده باشد
      begin
        me := public.app('login', u, p, '{}'::jsonb);
      exception when others then
        me := null;
      end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then
        select * into b from booths where owner=u and status<>'off';
      end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;

    if op in ('blogin','bme') then
      return jsonb_build_object('ok',1,
        'booth',jsonb_build_object('id',b.id,'name',b.name,'bio',b.bio,'logo',b.logo,'cover',b.cover,'city',b.city,'phone',b.phone,'views',b.views,'status',b.status),
        'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'s',q.status,'t',q.created) order by q.id desc) from booth_products q where q.booth_id=b.id),'[]'::jsonb),
        'days',coalesce((select jsonb_agg(jsonb_build_object('day',v.day,'n',v.n) order by v.day) from booth_views v where v.booth_id=b.id and v.day>=current_date-6),'[]'::jsonb));
    end if;

    if op='bprod_set' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      if (a->>'id') is null then
        insert into booth_products(booth_id,d,status) values(b.id,a->'d',coalesce(a->>'s','on')) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_products set d=a->'d', status=coalesce(a->>'s',status) where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='bords' then
      return jsonb_build_object('ok',1,'orders',coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'phone',o.phone,'addr',o.addr,'lines',o.lines,'total',o.total,'s',o.status,'t',o.created) order by o.id desc) from (select * from booth_orders where booth_id=b.id order by id desc limit 100) o),'[]'::jsonb));
    end if;
    if op='bord_st' then
      update booth_orders set status=a->>'s' where id=(a->>'id')::bigint and booth_id=b.id and (a->>'s') in ('new','done','cancel');
      return jsonb_build_object('ok',1);
    end if;

    if op='bprod_del' then
      delete from booth_products where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bset' then
      if length(coalesce(a->>'logo',''))>120000 or length(coalesce(a->>'cover',''))>250000 then return jsonb_build_object('err','big'); end if;
      update booths set name=left(coalesce(nullif(a->>'name',''),name),80), bio=left(coalesce(a->>'bio',bio),600),
        logo=coalesce(a->>'logo',logo), cover=coalesce(a->>'cover',cover), city=left(coalesce(a->>'city',city),60), phone=left(coalesce(a->>'phone',phone),30)
      where id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bpw' then
      if length(coalesce(a->>'np',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'np',gen_salt('bf')) where id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  -- مدیریت (فقط ادمین اصلی با حساب خودش)
  if op like 'badm_%' then
    if not adm then return jsonb_build_object('err','denied'); end if;

    if op='badm_list' then
      return jsonb_build_object('ok',1,
        'reqs',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from booth_reqs x where x.status='new'),'[]'::jsonb),
        'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'owner',x.owner,'name',x.name,'city',x.city,'bio',x.bio,'phone',x.phone,'status',x.status,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id),'o',(select count(*) from booth_orders w where w.booth_id=x.id)) order by x.id desc) from booths x),'[]'::jsonb));
    end if;

    if op='badm_approve' then
      if length(coalesce(a->>'owner',''))<3 or length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from booths where owner=a->>'owner') then return jsonb_build_object('err','taken'); end if;
      insert into booths(owner,pw,name,city,phone)
        select a->>'owner',crypt(a->>'pw',gen_salt('bf')),coalesce(nullif(shop,''),name),city,phone from booth_reqs where id=(a->>'id')::bigint
        returning id into nid;
      if nid is null then return jsonb_build_object('err','none'); end if;
      update booth_reqs set status='ok' where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    -- U4: وصل کردن غرفه به حساب اصلی یک کاربر (بدون رمز جدا؛ رمز داخلی تصادفی)
    if op='badm_link' then
      if length(coalesce(a->>'owner',''))<3 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from booths where owner=a->>'owner') then return jsonb_build_object('err','taken'); end if;
      insert into booths(owner,pw,name) values(a->>'owner',crypt(gen_random_uuid()::text,gen_salt('bf')),left(coalesce(nullif(a->>'name',''),a->>'owner'),80)) returning id into nid;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='badm_reject' then update booth_reqs set status='no' where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_status' then update booths set status=a->>'status' where id=(a->>'id')::bigint and (a->>'status') in ('active','off'); return jsonb_build_object('ok',1); end if;
    if op='badm_del' then delete from booths where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_reset' then
      if length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'pw',gen_salt('bf')) where id=(a->>'id')::bigint; return jsonb_build_object('ok',1);
    end if;
    -- U2: ادمین اصلی: دیدن/تغییر وضعیت سفارش‌های یک غرفه و ویرایش اطلاعات غرفه
    if op='badm_ords' then
      return jsonb_build_object('ok',1,'orders',coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'phone',o.phone,'addr',o.addr,'lines',o.lines,'total',o.total,'s',o.status,'t',o.created) order by o.id desc) from (select * from booth_orders where booth_id=(a->>'id')::bigint order by id desc limit 100) o),'[]'::jsonb));
    end if;
    if op='badm_ord_st' then
      update booth_orders set status=a->>'s' where id=(a->>'id')::bigint and (a->>'s') in ('new','done','cancel');
      return jsonb_build_object('ok',1);
    end if;
    if op='badm_edit' then
      if length(coalesce(a->>'name',''))<1 then return jsonb_build_object('err','bad'); end if;
      update booths set name=left(a->>'name',80), bio=left(coalesce(a->>'bio',''),600), city=left(coalesce(a->>'city',''),60), phone=left(coalesce(a->>'phone',''),30) where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1);
    end if;

    if op='badm_pdel' then delete from booth_products where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;

    -- U4: مدیر کردن یک کاربر (پیش‌فرض بدون دسترسی؛ pm = دسترسی‌های تیک‌خورده) و برداشتن نقش
    if op='badm_mkadm' then
      if length(coalesce(a->>'u',''))<1 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from staff where username=a->>'u' and 'all'=any(perms)) then return jsonb_build_object('err','main'); end if;
      if exists(select 1 from staff where username=a->>'u') then
        update staff set perms=array(select x from jsonb_array_elements_text(coalesce(a->'pm','[]'::jsonb)) x where x in ('p','a','s','o','g','u','br','nt'))::text[] where username=a->>'u';
      else
        if not exists(select 1 from users where username=a->>'u') then return jsonb_build_object('err','none'); end if;
        insert into staff(username,pass,perms)
          select username,pass,array(select x from jsonb_array_elements_text(coalesce(a->'pm','[]'::jsonb)) x where x in ('p','a','s','o','g','u','br','nt'))::text[] from users where username=a->>'u';
      end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='badm_rmadm' then
      delete from staff where username=a->>'u' and not ('all'=any(perms));
      return jsonb_build_object('ok',1);
    end if;
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.bapp(text,text,text,jsonb) to anon, authenticated;

-- ################ msg.sql — صندوق پیام و پاپ‌آپ (mapp) ################
-- صندوق پیام و اعلان (U3 + 1.9.16: پیام پاپ‌آپ و مخاطب «فقط کاربران عادی») — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت: از همان تابع اصلی public.app (op=login). مدیر = role admin. ارسال به «همه» فقط ادمین اصلی (pm شامل all).

create table if not exists public.m_msgs(
  id bigserial primary key, from_u text not null, to_u text, grp text,
  body text not null, created timestamptz default now());
create index if not exists m_msgs_to on public.m_msgs(to_u, id desc);
create index if not exists m_msgs_grp on public.m_msgs(grp, id desc);
create table if not exists public.m_read(
  uname text not null, msg bigint references public.m_msgs(id) on delete cascade, primary key(uname,msg));
alter table public.m_msgs add column if not exists kind text default 'box';
alter table public.m_msgs enable row level security;
alter table public.m_read enable row level security;

create or replace function public.mapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; ismain boolean := false; isadm boolean := false;
        isbooth boolean := false; k text := 'box'; nid bigint; g text; t text; b text; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='mping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  isbooth := exists(select 1 from public.booths x where x.owner=who and x.status='active');

  -- پیام‌های من: شخصی + گروهی که عضوشم
  if op='minbox' or op='mcount' then
    if op='mcount' then
      select count(*) into n from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
          and m.from_u<>who
          and not exists(select 1 from public.m_read r where r.uname=who and r.msg=m.id);
      return jsonb_build_object('ok',1,'n',n,'adm',isadm,'main',ismain,'booth',isbooth,
        'pop',(select jsonb_build_object('id',m.id,'f',m.from_u,'g',m.grp,'b',m.body,'t',m.created) from public.m_msgs m
          where m.kind='pop' and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
            and m.from_u<>who and not exists(select 1 from public.m_read r where r.uname=who and r.msg=m.id)
          order by m.id asc limit 1));
    end if;
    return jsonb_build_object('ok',1,'adm',isadm,'main',ismain,'booth',isbooth,
      'in',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'f',x.from_u,'g',x.grp,'b',x.body,'t',x.created,'k',x.kind,
            'r',exists(select 1 from public.m_read r where r.uname=who and r.msg=x.id)) order by x.id desc)
          from (select * from public.m_msgs m where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth)) and m.from_u<>who order by m.id desc limit 60) x),'[]'::jsonb),
      'sent',case when isadm then coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'to',x.to_u,'g',x.grp,'b',x.body,'t',x.created) order by x.id desc)
          from (select * from public.m_msgs m where m.from_u=who order by m.id desc limit 40) x),'[]'::jsonb) else '[]'::jsonb end);
  end if;

  if op='mread' and a ? 'ids' and jsonb_typeof(a->'ids')='array' then
    insert into public.m_read(uname,msg)
      select who,m.id from public.m_msgs m
      where m.id in (select (case when t.v ~ '^[0-9]{1,15}$' then t.v::bigint end) from (select jsonb_array_elements_text(a->'ids') v limit 100) t)
        and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
      on conflict do nothing;
    return jsonb_build_object('ok',1,'n',1);
  end if;

  if op='mread' then
    if a ? 'all' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth)) and m.from_u<>who
        on conflict do nothing;
    elsif a ? 'id' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m where m.id=(a->>'id')::bigint
          and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
        on conflict do nothing;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  -- ارسال: فقط مدیران. «همه» فقط ادمین اصلی.
  if op='msend' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    b := left(btrim(coalesce(a->>'b','')),1000);
    if length(b)<1 then return jsonb_build_object('err','bad'); end if;
    k := case when a->>'k'='pop' then 'pop' else 'box' end;
    g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
    if g is not null then
      if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
      if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
      insert into public.m_msgs(from_u,grp,body,kind) values(who,g,b,k) returning id into nid;
    else
      if t is null then return jsonb_build_object('err','bad'); end if;
      if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
      insert into public.m_msgs(from_u,to_u,body,kind) values(who,t,b,k) returning id into nid;
    end if;
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  -- حذف پیام ارسالی (فرستنده یا ادمین اصلی)
  if op='mdel' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    delete from public.m_msgs where id=(a->>'id')::bigint and (from_u=who or ismain);
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.mapp(text,text,text,jsonb) to anon, authenticated;

-- ################ chat.sql — گفتگوی کاربر و غرفه‌دار (capp) ################
-- پیام‌رسان کاربر↔غرفه‌دار (Y3) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths).
-- هویت: از همان تابع اصلی public.app (op=login). غرفه‌دار = booths.owner با همان نام کاربری.
-- هر گفتگو = (غرفه، نام کاربر مشتری). ستون‌های k و x برای کارت محصول (Y4) آماده‌اند.

create table if not exists public.c_msgs(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null check (side in ('u','b')),
  body text not null default '',
  k text default 't',
  x jsonb,
  created timestamptz default now());
create index if not exists c_msgs_conv on public.c_msgs(booth_id, cu, id desc);
create index if not exists c_msgs_cu on public.c_msgs(cu, id desc);
create table if not exists public.c_seen(
  booth_id bigint references public.booths(id) on delete cascade,
  cu text not null,
  side text not null,
  lid bigint default 0,
  primary key(booth_id, cu, side));
alter table public.c_msgs enable row level security;
alter table public.c_seen enable row level security;

create or replace function public.capp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; bt public.booths; v_bid bigint; v_cu text; v_side text;
        v_aft bigint; v_last bigint; v_ps bigint; v_n int; v_n2 int; v_nid bigint; v_t timestamptz;
        v_body text; v_k text; v_x jsonb; v_pid bigint;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='cping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;

  -- شمار نخوانده‌ها (به‌عنوان مشتری + به‌عنوان غرفه‌دار)
  if op='ccount' then
    select count(*) into v_n from public.c_msgs m
      where m.cu=who and m.side='b'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='u'),0);
    select count(*) into v_n2 from public.c_msgs m join public.booths o on o.id=m.booth_id
      where o.owner=who and m.side='u'
        and m.id > coalesce((select s.lid from public.c_seen s where s.booth_id=m.booth_id and s.cu=m.cu and s.side='b'),0);
    return jsonb_build_object('ok',1,'n',v_n+v_n2);
  end if;

  -- لیست گفتگوها
  if op='clist' then
    return jsonb_build_object('ok',1,'l',coalesce((
      select jsonb_agg(row_to_json(z)::jsonb order by z.lid desc) from (
        select c.booth_id as b, c.cu as cu, c.lid as lid,
               case when c.cu=who then 'u' else 'b' end as r,
               m.body as lb, m.k as lk, m.side as ls, m.created as lt,
               (select count(*) from public.c_msgs q
                  where q.booth_id=c.booth_id and q.cu=c.cu
                    and q.side <> (case when c.cu=who then 'u' else 'b' end)
                    and q.id > coalesce((select s.lid from public.c_seen s
                        where s.booth_id=c.booth_id and s.cu=c.cu
                          and s.side=(case when c.cu=who then 'u' else 'b' end)),0)) as un
        from (
          select g.booth_id, g.cu, max(g.id) as lid from public.c_msgs g
          where g.cu=who or g.booth_id in (select o.id from public.booths o where o.owner=who)
          group by g.booth_id, g.cu
          order by max(g.id) desc limit 60) c
        join public.c_msgs m on m.id=c.lid
      ) z), '[]'::jsonb));
  end if;

  -- پیام‌های یک گفتگو (و علامت خوانده‌شدن)
  if op='cmsgs' or op='csend' then
    v_bid := (a->>'b')::bigint;
    select * into bt from public.booths where id=v_bid;
    if not found then return jsonb_build_object('err','none'); end if;
    if bt.owner=who then
      v_side := 'b'; v_cu := nullif(btrim(coalesce(a->>'cu','')),'');
      if v_cu is null then return jsonb_build_object('err','bad'); end if;
      if v_cu=who then return jsonb_build_object('err','self'); end if;
    else
      v_side := 'u'; v_cu := who;
      if bt.status<>'active' then return jsonb_build_object('err','none'); end if;
    end if;

    if op='cmsgs' then
      v_aft := coalesce(nullif(a->>'after','')::bigint,0);
      select coalesce(max(lid),0) into v_ps from public.c_seen
        where booth_id=v_bid and cu=v_cu and side=(case when v_side='u' then 'b' else 'u' end);
      select max(id) into v_last from public.c_msgs where booth_id=v_bid and cu=v_cu;
      if v_last is not null then
        insert into public.c_seen(booth_id,cu,side,lid) values(v_bid,v_cu,v_side,v_last)
          on conflict(booth_id,cu,side) do update set lid=greatest(public.c_seen.lid, excluded.lid);
      end if;
      return jsonb_build_object('ok',1,'ps',v_ps,'m',coalesce((
        select jsonb_agg(jsonb_build_object('id',y.id,'s',y.side,'b',y.body,'k',y.k,'x',y.x,'t',y.created) order by y.id)
        from (select * from public.c_msgs where booth_id=v_bid and cu=v_cu and id>v_aft order by id desc limit 200) y),'[]'::jsonb));
    end if;

    -- ارسال
    if v_side='b' and not exists(select 1 from public.c_msgs where booth_id=v_bid and cu=v_cu) then
      return jsonb_build_object('err','perm');
    end if;
    v_k := coalesce(nullif(a->>'k',''),'t');
    if v_k not in ('t','p') then return jsonb_build_object('err','bad'); end if;
    v_body := left(btrim(coalesce(a->>'body','')),1000);
    v_x := null;
    if v_k='t' then
      if length(v_body)<1 then return jsonb_build_object('err','bad'); end if;
    else
      v_pid := nullif(a->'x'->>'id','')::bigint;
      if v_pid is null or not exists(select 1 from public.booth_products q where q.id=v_pid and q.booth_id=v_bid) then
        return jsonb_build_object('err','bad');
      end if;
      v_x := jsonb_build_object('id',v_pid);
      v_body := left(v_body,200);
    end if;
    -- سقف سرعت: حداکثر ۲۰ پیام در دقیقه برای هر طرف گفتگو
    select count(*) into v_n from public.c_msgs
      where booth_id=v_bid and cu=v_cu and side=v_side and created>now()-interval '1 minute';
    if v_n>=20 then return jsonb_build_object('err','rate'); end if;
    insert into public.c_msgs(booth_id,cu,side,body,k,x) values(v_bid,v_cu,v_side,v_body,v_k,v_x)
      returning id, created into v_nid, v_t;
    return jsonb_build_object('ok',1,'id',v_nid,'t',v_t);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.capp(text,text,text,jsonb) to anon, authenticated;

-- ################ bird.sql — سالن فروش و پرورش (rapp) ################
-- ===== BirdBazaar: سالن فروش و پرورش (مورد ۱۰) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths). به bapp دست نمی‌زند؛ تابع جدید rapp می‌سازد.
create table if not exists public.booth_birds(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null,
  k text default 'sale',
  status text default 'on',
  created timestamptz default now());
alter table public.booth_birds enable row level security;

create or replace function public.rapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; me jsonb := null; nid bigint; kk text;
begin
  a := coalesce(a,'{}'::jsonb);

  -- عمومی: پرنده‌های روشن غرفه‌های فعال
  if op='rpublic' then
    return jsonb_build_object('ok',1,'birds',coalesce((
      select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'bn',x.name,'ph',x.phone,'city',x.city,'d',q.d,'k',q.k,'t',q.created) order by q.id desc)
      from (select * from booth_birds where status='on' order by id desc limit 120) q
      join booths x on x.id=q.booth_id where x.status='active'),'[]'::jsonb));
  end if;

  if op in ('rme','rset','rdel') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then
      begin
        me := public.app('login', u, p, '{}'::jsonb);
      exception when others then
        me := null;
      end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then
        select * into b from booths where owner=u and status<>'off';
      end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;

    if op='rme' then
      return jsonb_build_object('ok',1,'birds',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'k',q.k,'s',q.status,'t',q.created) order by q.id desc) from booth_birds q where q.booth_id=b.id),'[]'::jsonb));
    end if;

    if op='rset' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      kk := case when (a->>'k')='show' then 'show' else 'sale' end;
      if (a->>'id') is null then
        if (select count(*) from booth_birds where booth_id=b.id)>=60 then return jsonb_build_object('err','many'); end if;
        insert into booth_birds(booth_id,d,k,status) values(b.id,a->'d',kk,case when (a->>'s')='off' then 'off' else 'on' end) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_birds set d=coalesce(a->'d',d), k=kk, status=case when (a->>'s') in ('on','off') then a->>'s' else status end where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='rdel' then
      delete from booth_birds where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.rapp(text,text,text,jsonb) to anon, authenticated;

-- ################ UPDATE_FINAL.sql — همکاری غرفه‌داران (kapp) ################
-- ===== BirdBazaar: SQL نهایی (همه‌ی تغییرات تازه در یک فایل) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: booth.sql و msg.sql قبلاً اجرا شده باشند.

-- [مورد ۸] درخواست همکاری با حساب کاربر + تأیید مستقیم + پیام خودکار
alter table public.booth_reqs add column if not exists uname text;

create or replace function public.kapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; adm boolean := false; nid bigint; q public.booth_reqs; ow text;
begin
  a := coalesce(a,'{}'::jsonb);
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;

  -- کاربر واردشده درخواست همکاری می‌فرستد
  if op='kreq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if exists(select 1 from booths where owner=u) then return jsonb_build_object('err','has'); end if;
    if (select count(*) from booth_reqs where (uname=u or phone=a->>'phone') and status='new')>=1 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about,uname) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600),u);
    return jsonb_build_object('ok',1);
  end if;

  -- تأیید توسط ادمین اصلی: غرفه برای همان حساب ساخته می‌شود و پیام خودکار می‌رود
  if op='kapprove' then
    if not adm then return jsonb_build_object('err','denied'); end if;
    select * into q from booth_reqs where id=(a->>'id')::bigint;
    if not found then return jsonb_build_object('err','none'); end if;
    ow := coalesce(nullif(q.uname,''), nullif(a->>'owner',''));
    if ow is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from users where username=ow) then return jsonb_build_object('err','nouser'); end if;
    if exists(select 1 from booths where owner=ow) then return jsonb_build_object('err','taken'); end if;
    insert into booths(owner,pw,name,city,phone) values(ow,crypt(gen_random_uuid()::text,gen_salt('bf')),left(coalesce(nullif(q.shop,''),q.name),80),q.city,q.phone) returning id into nid;
    update booth_reqs set status='ok', uname=ow where id=q.id;
    insert into m_msgs(from_u,to_u,body,kind) values(u,ow,E'مجوز ساخت غرفه\nمجوز ساخت غرفه توسط ادمین صادر شد و هم‌اینک می‌توانید از بخش غرفه‌داران غرفه خود را مدیریت کنید.','box');
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.kapp(text,text,text,jsonb) to anon, authenticated;

-- ################ PUSH.sql — اعلان گوشی (تریگرها + f_push_send) ################
-- اعلان گوشی (۹-ب مرحله‌ی ۲) — بعد از forum.sql در SQL Editor اجرا شود. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: Edge Function با نام push (supabase_functions/push.ts) و Secrets (PUSH_SETUP.txt).
-- کلید PUSH_KEY در این فایل نیست؛ جدا با یک دستور کوتاه گذاشته می‌شود.

create extension if not exists pg_net with schema extensions;
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;
insert into public.f_conf(k,v) values('pushurl','https://aalnajorkrrrkcoskagz.supabase.co/functions/v1/push')
  on conflict (k) do update set v=excluded.v;

create or replace function public.f_push_send(unames text[], ttl text, bdy text)
returns void language plpgsql security definer set search_path=public, extensions as $$
declare kk text; uu text;
begin
  select v into kk from public.f_conf where k='pushkey';
  select v into uu from public.f_conf where k='pushurl';
  if coalesce(kk,'')='' or coalesce(uu,'')='' or unames is null or coalesce(array_length(unames,1),0)=0 then return; end if;
  perform net.http_post(url:=uu, body:=jsonb_build_object('users',to_jsonb(unames),'title',ttl,'body',left(coalesce(bdy,''),120)),
    headers:=jsonb_build_object('Content-Type','application/json','x-push-key',kk));
exception when others then null;
end $$;

-- پیام‌ها (m_msgs)
create or replace function public.f_trg_msg() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[]; t text := '📨 پیام جدید';
begin
  if coalesce(new.to_u,'')<>'' then r:=array[new.to_u];
  elsif new.grp='all' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u);
  elsif new.grp='admin' then t:='🛡 پیام مدیران'; r:=array(select username from public.staff where username<>new.from_u);
  elsif new.grp='booth' then t:='🏪 پیام غرفه‌داران'; r:=array(select owner from public.booths where owner<>new.from_u);
  elsif new.grp='user' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u
      and uname not in (select username from public.staff) and uname not in (select owner from public.booths));
  end if;
  perform public.f_push_send(r, t, new.body);
  return new;
exception when others then return new;
end $$;

-- سفارش اصلی (orders) → ادمین‌هایی که مجوز سفارش‌ها دارند
create or replace function public.f_trg_order() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[];
begin
  r:=array(select username from public.staff where (to_jsonb(perms) ? 'o') or (to_jsonb(perms) ? 'all'));
  perform public.f_push_send(r, '🛒 سفارش جدید', coalesce(new.d->>'cu','')||' — '||coalesce(new.d->>'tt','')||' تومان');
  return new;
exception when others then return new;
end $$;

-- سفارش غرفه (booth_orders) → صاحب غرفه
create or replace function public.f_trg_border() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '🛒 سفارش جدید غرفه', coalesce(new.name,''));
  return new;
exception when others then return new;
end $$;

-- گفتگوی کاربر ↔ غرفه‌دار (c_msgs)
create or replace function public.f_trg_chat() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  if new.side='u' then
    perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '💬 پیام جدید از مشتری', case when new.k='t' then new.body else '📎' end);
  else
    perform public.f_push_send(array[new.cu], '💬 پاسخ غرفه‌دار', case when new.k='t' then new.body else '📎' end);
  end if;
  return new;
exception when others then return new;
end $$;

do $$ begin
  if to_regclass('public.m_msgs') is not null then
    drop trigger if exists f_push_msg on public.m_msgs;
    create trigger f_push_msg after insert on public.m_msgs for each row execute function public.f_trg_msg();
  end if;
  if to_regclass('public.orders') is not null then
    drop trigger if exists f_push_order on public.orders;
    create trigger f_push_order after insert on public.orders for each row execute function public.f_trg_order();
  end if;
  if to_regclass('public.booth_orders') is not null then
    drop trigger if exists f_push_border on public.booth_orders;
    create trigger f_push_border after insert on public.booth_orders for each row execute function public.f_trg_border();
  end if;
  if to_regclass('public.c_msgs') is not null then
    drop trigger if exists f_push_chat on public.c_msgs;
    create trigger f_push_chat after insert on public.c_msgs for each row execute function public.f_trg_chat();
  end if;
end $$;

-- ################ PUSHFREE.sql — اعلان آزاد ادمین (pnapp) ################
-- اعلان آزاد ادمین (مورد ۱۵) — بعد از PUSH.sql اجرا شود. چند بار اجرا بی‌خطر است. به توابع قبلی دست نمی‌زند.
create or replace function public.pnapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; isadm boolean; ismain boolean; g text; t text; ttl text; b text; r text[];
begin
  a := coalesce(a,'{}'::jsonb);
  if op<>'pnotify' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  if not isadm then return jsonb_build_object('err','perm'); end if;
  b := left(btrim(coalesce(a->>'b','')),120);
  ttl := left(btrim(coalesce(a->>'title','')),60);
  if length(b)<1 then return jsonb_build_object('err','bad'); end if;
  if ttl='' then ttl := '📢 بازارچه پرندگان'; end if;
  g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
  if g is not null then
    if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
    if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
    if g='all' then r:=array(select distinct uname from public.f_push);
    elsif g='admin' then r:=array(select distinct username from public.staff);
    elsif g='booth' then r:=array(select distinct owner from public.booths);
    else r:=array(select distinct uname from public.f_push where uname not in (select username from public.staff) and uname not in (select owner from public.booths));
    end if;
  else
    if t is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
    r:=array[t];
  end if;
  perform public.f_push_send(r, ttl, b);
  return jsonb_build_object('ok',1,'n',coalesce(array_length(r,1),0),
    'reg',(select count(distinct uname) from public.f_push where uname=any(r)));
end $$;
grant execute on function public.pnapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as pushfree;

-- ################ BACKUP.sql — پشتیبان کامل داخل برنامه (bkapp) ################
-- پشتیبان کامل داخل برنامه (1.9.64) — روی هر دو سرور (قدیمی و جدید) یک‌بار اجرا شود. چندبار اجرا بی‌خطر است.
-- bkexport: فقط مدیر اصلی؛ همه‌ی جدول‌ها + ساختار (جدول، تابع، تریگر) را برمی‌گرداند. bkimport: فقط با «کلید راه‌اندازی» روی سرور خالی.
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;

create or replace function public.bkapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb; r record; rows jsonb; tb jsonb := '{}'::jsonb; ddl jsonb := '[]'::jsonb; q text; kk text; res jsonb := '{}'::jsonb;
  errs jsonb := '[]'::jsonb; n bigint; skip text[] := array['f_conf','f_push']; st text; cols text; nonempty boolean := false;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='bkstate' then
    if to_regclass('public.users') is not null then execute 'select exists(select 1 from public.users)' into nonempty; end if;
    return jsonb_build_object('ok',1,'empty',not nonempty,'armed',exists(select 1 from public.f_conf where k='bkkey' and coalesce(v,'')<>''));
  end if;

  if op='bkexport' then
    begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
    if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
    -- ساختار: توالی‌ها
    for r in select c.relname, format_type(sq.seqtypid,null) as ty from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_sequence sq on sq.seqrelid=c.oid where n.nspname='public' and c.relkind='S' order by 1 loop
      ddl := ddl || to_jsonb('create sequence if not exists public.'||quote_ident(r.relname)||' as '||r.ty);
    end loop;
    -- جدول‌ها
    for r in select c.oid, c.relname, c.relrowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' order by 2 loop
      select string_agg(quote_ident(at.attname)||' '||format_type(at.atttypid,at.atttypmod)
          ||case when at.attidentity='a' then ' generated always as identity' when at.attidentity='d' then ' generated by default as identity'
                 when at.attgenerated='s' then ' generated always as ('||pg_get_expr(d.adbin,d.adrelid)||') stored'
                 when d.adbin is not null then ' default '||pg_get_expr(d.adbin,d.adrelid) else '' end
          ||case when at.attnotnull then ' not null' else '' end, ', ' order by at.attnum) into cols
        from pg_attribute at left join pg_attrdef d on d.adrelid=at.attrelid and d.adnum=at.attnum
        where at.attrelid=r.oid and at.attnum>0 and not at.attisdropped;
      ddl := ddl || to_jsonb('create table if not exists public.'||quote_ident(r.relname)||' ('||cols||')');
      if r.relrowsecurity then ddl := ddl || to_jsonb('alter table public.'||quote_ident(r.relname)||' enable row level security'); end if;
      if r.relname = any(skip) then continue; end if;
      execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from public.%I x', r.relname) into rows;
      tb := tb || jsonb_build_object(r.relname, rows);
    end loop;
    for r in select sc.relname as sq, tc.relname as t, at.attname as col from pg_depend dp join pg_class sc on sc.oid=dp.objid and sc.relkind='S' join pg_class tc on tc.oid=dp.refobjid
             join pg_attribute at on at.attrelid=tc.oid and at.attnum=dp.refobjsubid where dp.deptype in ('a','i') and sc.relnamespace='public'::regnamespace and tc.relnamespace='public'::regnamespace loop
      ddl := ddl || to_jsonb('alter sequence public.'||quote_ident(r.sq)||' owned by public.'||quote_ident(r.t)||'.'||quote_ident(r.col));
    end loop;
    -- قیدها (به‌جز کلید خارجی) و ایندکس‌ها
    for r in select conrelid::regclass::text as t, conname, pg_get_constraintdef(oid) as d from pg_constraint where connamespace='public'::regnamespace and contype in ('p','u','c') order by 1,2 loop
      ddl := ddl || to_jsonb('alter table '||r.t||' add constraint '||quote_ident(r.conname)||' '||r.d);
    end loop;
    for r in select pg_get_indexdef(i.indexrelid) as d from pg_index i join pg_class c on c.oid=i.indexrelid join pg_namespace n on n.oid=c.relnamespace
             where n.nspname='public' and not exists(select 1 from pg_constraint k where k.conindid=i.indexrelid) order by 1 loop
      ddl := ddl || to_jsonb(replace(r.d,'CREATE INDEX','CREATE INDEX IF NOT EXISTS')) ;
    end loop;
    -- سیاست‌های RLS
    for r in select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check from pg_policies where schemaname='public' loop
      ddl := ddl || to_jsonb('drop policy if exists '||quote_ident(r.policyname)||' on public.'||quote_ident(r.tablename));
      ddl := ddl || to_jsonb('create policy '||quote_ident(r.policyname)||' on public.'||quote_ident(r.tablename)||' as '||r.permissive||' for '||r.cmd||' to '||array_to_string(r.roles,',')
        ||coalesce(' using ('||r.qual||')','')||coalesce(' with check ('||r.with_check||')',''));
    end loop;
    -- توابع (به‌جز خود bkapp)
    for r in select pg_get_functiondef(p.oid) as d from pg_proc p where p.pronamespace='public'::regnamespace and p.prokind='f' and p.proname<>'bkapp'
             and not exists(select 1 from pg_depend dp where dp.objid=p.oid and dp.deptype='e') order by p.proname loop
      ddl := ddl || to_jsonb(r.d);
    end loop;
    -- تریگرها
    for r in select t.tgrelid::regclass::text as tb, t.tgname, pg_get_triggerdef(t.oid) as d from pg_trigger t where not t.tgisinternal and t.tgrelid in (select oid from pg_class where relnamespace='public'::regnamespace) loop
      ddl := ddl || to_jsonb('drop trigger if exists '||quote_ident(r.tgname)||' on '||r.tb);
      ddl := ddl || to_jsonb(r.d);
    end loop;
    -- کلیدهای خارجی آخر از همه (بعد از ورود داده)
    for r in select conrelid::regclass::text as t, conname, pg_get_constraintdef(oid) as d from pg_constraint where connamespace='public'::regnamespace and contype='f' order by 1,2 loop
      ddl := ddl || to_jsonb('alter table '||r.t||' add constraint '||quote_ident(r.conname)||' '||r.d);
    end loop;
    return jsonb_build_object('ok',1,'v',1,'ddl',ddl,'data',tb);
  end if;

  if op='bkimport' then
    select v into kk from public.f_conf where k='bkkey';
    if coalesce(kk,'')='' or a->>'k' is distinct from kk then return jsonb_build_object('err','key'); end if;
    if to_regclass('public.users') is not null then execute 'select exists(select 1 from public.users)' into nonempty; end if;
    if nonempty then return jsonb_build_object('err','notempty'); end if;
    perform set_config('check_function_bodies','off',true);
    begin create extension if not exists pg_net with schema extensions; exception when others then null; end;
    -- ساخت ساختار (به ترتیب خروجی)؛ هر خطا ثبت می‌شود ولی ادامه می‌دهد؛ کلید خارجی‌ها بعد از داده
    for r in select value as s, ord from jsonb_array_elements_text(a->'ddl') with ordinality as x(value,ord) where value not like 'alter table % add constraint % FOREIGN KEY%' order by ord loop
      begin execute r.s; exception when duplicate_object or duplicate_table or duplicate_function or invalid_table_definition then null; when others then errs := errs || to_jsonb(left(sqlerrm,160)); end;
    end loop;
    -- داده‌ها
    for r in select key as t, value as rws from jsonb_each(coalesce(a->'data','{}'::jsonb)) loop
      if r.t = any(skip) or to_regclass('public.'||quote_ident(r.t)) is null then errs := errs || to_jsonb('skip '||r.t); continue; end if;
      begin
        execute format('insert into public.%I overriding system value select * from jsonb_populate_recordset(null::public.%I, $1) on conflict do nothing', r.t, r.t) using r.rws;
        get diagnostics n = row_count; res := res || jsonb_build_object(r.t, n);
      exception when others then errs := errs || to_jsonb(r.t||': '||left(sqlerrm,140)); end;
    end loop;
    -- شمارنده‌های ID
    for r in select c.relname as t, at.attname as col, (regexp_match(pg_get_expr(d.adbin,d.adrelid),'nextval\(''([^'']+)''::regclass'))[1] as sq
             from pg_class c join pg_attribute at on at.attrelid=c.oid and at.attnum>0 and not at.attisdropped
             join pg_attrdef d on d.adrelid=at.attrelid and d.adnum=at.attnum
             where c.relnamespace='public'::regnamespace and c.relkind='r' loop
      if r.sq is not null then
        begin execute format('select setval(%L, greatest(coalesce((select max(%I) from public.%I),0),1), (select count(*)>0 from public.%I))', r.sq, r.col, r.t, r.t); exception when others then null; end;
      end if;
    end loop;
    -- کلیدهای خارجی
    for r in select value as s from jsonb_array_elements_text(a->'ddl') where value like 'alter table % add constraint % FOREIGN KEY%' loop
      begin execute r.s; exception when duplicate_object then null; when others then errs := errs || to_jsonb(left(sqlerrm,160)); end;
    end loop;
    -- دسترسی توابع
    for r in select p.oid::regprocedure as f from pg_proc p where p.pronamespace='public'::regnamespace and p.proname in ('app','fapp','bapp','mapp','capp','rapp','kapp','pnapp','bkapp','sapp') loop
      begin execute 'grant execute on function '||r.f||' to anon, authenticated'; exception when others then null; end;
    end loop;
    for r in select p.oid::regprocedure as f from pg_proc p where p.pronamespace='public'::regnamespace and p.proname='f_push_send' loop
      begin execute 'revoke execute on function '||r.f||' from public, anon, authenticated'; exception when others then null; end;
    end loop;
    if coalesce(a->>'url','')<>'' then
      insert into public.f_conf(k,v) values('pushurl', (a->>'url')||'/functions/v1/push') on conflict (k) do update set v=excluded.v;
    end if;
    delete from public.f_conf where k='bkkey';
    return jsonb_build_object('ok',1,'rows',res,'errs',errs);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as backup_sql;


-- ################ تغییرات تازه (از این‌جا به بعد فقط به همین بخش اضافه کن) ################
-- [1.9.66] f_lite + ops public2/pimg داخل fapp (بخش forum بالا) اضافه شد؛ بدون جدول یا ستون تازه.

-- [1.9.67] آمار استفاده‌ی ناشناس (sapp): هر گوشی روزی یک بار گزارش ۲۴ ساعته می‌فرستد (بدون نام کاربری)؛ فقط مدیر اصلی می‌خواند.
create table if not exists public.app_stats(
  day date not null, dev text not null, v text default '', d jsonb not null default '{}'::jsonb,
  ts timestamptz not null default now(), primary key(day,dev));
alter table public.app_stats enable row level security;
create index if not exists app_stats_day_idx on public.app_stats(day);

create or replace function public.s_num(j jsonb, cap numeric) returns numeric language sql immutable as $f$
  select case when jsonb_typeof(j)='number' then least(greatest((j#>>'{}')::numeric,0),cap) else 0 end
$f$;

create or replace function public.sapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; ismain boolean := false; off boolean; dv text; dy date; n int := 0; rec record; dd int;
  rep int; dvc int; hrs jsonb; secs jsonb; ops jsonb; bts jsonb; days jsonb; vers jsonb; tot jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  off := coalesce((select c.v from public.f_conf c where c.k='stoff'),'')='1';

  if op='sput' then
    if off then return jsonb_build_object('ok',1,'off',1); end if;
    if length(a::text)>24000 then return jsonb_build_object('err','big'); end if;
    dv := left(coalesce(a->>'dev',''),40);
    if length(dv)<8 or jsonb_typeof(a->'r')<>'array' then return jsonb_build_object('err','bad'); end if;
    for rec in select value as r from jsonb_array_elements(a->'r') limit 5 loop
      begin
        dy := (rec.r->>'day')::date;
        if dy is not null and dy<=current_date+1 and dy>=current_date-10 and jsonb_typeof(rec.r)='object' then
          insert into public.app_stats(day,dev,v,d) values(dy,dv,left(coalesce(rec.r->>'v',''),12),(rec.r - 'day' - 'v'))
            on conflict(day,dev) do update set d=excluded.d, v=excluded.v, ts=now();
          n := n+1;
        end if;
      exception when others then null;
      end;
    end loop;
    if random()<0.02 then delete from public.app_stats where day<current_date-120; end if;
    return jsonb_build_object('ok',1,'n',n,'off',0);
  end if;

  if op='xget' then
    return jsonb_build_object('ok',1,'f',coalesce((select nullif(c.v,'')::jsonb from public.f_conf c where c.k='xf'),'{}'::jsonb));
  end if;

  if op in ('sget','sset','sclear','xset') then
    begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
    if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
    ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    if not ismain then return jsonb_build_object('err','perm'); end if;
  end if;

  if op='xset' then
    if coalesce(a->>'k','') not in ('sto','dl','lt','md','qb') or coalesce(a->>'v','') not in ('0','1') then return jsonb_build_object('err','bad'); end if;
    insert into public.f_conf(k,v) values('xf', jsonb_build_object(a->>'k',(a->>'v')::int)::text)
      on conflict (k) do update set v=(coalesce(nullif(f_conf.v,'')::jsonb,'{}'::jsonb) || jsonb_build_object(a->>'k',(a->>'v')::int))::text;
    return jsonb_build_object('ok',1,'f',(select c.v::jsonb from public.f_conf c where c.k='xf'));
  end if;
  if op='sset' then
    insert into public.f_conf(k,v) values('stoff', case when coalesce(a->>'off','')='1' then '1' else '0' end)
      on conflict (k) do update set v=excluded.v;
    return jsonb_build_object('ok',1,'off',case when coalesce(a->>'off','')='1' then 1 else 0 end);
  end if;
  if op='sclear' then
    delete from public.app_stats;
    return jsonb_build_object('ok',1);
  end if;

  if op='sget' then
    dd := least(greatest(coalesce(nullif(a->>'days','')::int,7),1),90);
    select count(*), count(distinct dev) into rep, dvc from public.app_stats where day>current_date-dd;
    select jsonb_build_object('o',coalesce(sum(public.s_num(d->'o',300)),0),'s',coalesce(sum(public.s_num(d->'s',86400)),0),
        'b',coalesce(sum(public.s_num(d->'b',2000000000)),0),'last',max(ts)) into tot
      from public.app_stats where day>current_date-dd;
    select coalesce(jsonb_agg(round(t.v) order by t.h),'[]'::jsonb) into hrs from (
      select g.h, coalesce(sum(public.s_num(s.d->'h'->g.h,3600)),0) as v
      from generate_series(0,23) g(h) left join (select d from public.app_stats where day>current_date-dd) s on true group by g.h) t;
    select coalesce(jsonb_agg(jsonb_build_object('k',q.k,'s',q.ss,'b',q.bb,'n',q.nn,'dv',q.c) order by q.ss desc),'[]'::jsonb) into secs from (
      select e.key as k, sum(public.s_num(e.value->'s',86400)) as ss, sum(public.s_num(e.value->'b',2000000000)) as bb,
             sum(public.s_num(e.value->'n',5000)) as nn, count(*) as c
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'x')='object' then t.d->'x' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by ss desc limit 30) q;
    select coalesce(jsonb_agg(jsonb_build_object('k',q.k,'n',q.nn,'b',q.bb,'dv',q.c) order by q.bb desc),'[]'::jsonb) into ops from (
      select e.key as k, sum(public.s_num(e.value->'n',100000)) as nn, sum(public.s_num(e.value->'b',2000000000)) as bb, count(*) as c
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'q')='object' then t.d->'q' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by bb desc limit 30) q;
    select coalesce(jsonb_agg(jsonb_build_object('id',q.k,'name',q.nm,'v',q.vv,'dv',q.c,'u',q.uu) order by q.vv desc),'[]'::jsonb) into bts from (
      select e.key as k, coalesce((select b.name from public.booths b where b.id::text=e.key limit 1),'؟') as nm,
             sum(public.s_num(e.value,5000)) as vv, count(*) as c,
             coalesce((select sum(v2.n) from public.booth_views v2 where v2.booth_id::text=e.key and v2.day>current_date-dd),0) as uu
      from public.app_stats t, jsonb_each(case when jsonb_typeof(t.d->'t')='object' then t.d->'t' else '{}'::jsonb end) e
      where t.day>current_date-dd group by e.key order by vv desc limit 20) q;
    select coalesce(jsonb_agg(jsonb_build_object('day',q.day,'dev',q.c,'o',q.oo,'s',q.ss,'b',q.bb) order by q.day desc),'[]'::jsonb) into days from (
      select day, count(*) as c, sum(public.s_num(d->'o',300)) as oo, sum(public.s_num(d->'s',86400)) as ss, sum(public.s_num(d->'b',2000000000)) as bb
      from public.app_stats where day>current_date-dd group by day) q;
    select coalesce(jsonb_agg(jsonb_build_object('v',q.v,'n',q.c) order by q.c desc),'[]'::jsonb) into vers from (
      select coalesce(nullif(v,''),'؟') as v, count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;
    return jsonb_build_object('ok',1,'days',dd,'rep',rep,'dev',dvc,'tot',tot,'hr',hrs,'sec',secs,'ops',ops,'bt',bts,'byday',days,'ver',vers,'off',case when off then 1 else 0 end);
  end if;

  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.sapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.69] مهر کل با شمارنده‌ی نسخه (Revision): محاسبه‌ی سنگین md5 فقط وقتی انجام می‌شود که داده تغییر کرده باشد (یا هر ۱۰ دقیقه برای انقضای زمانی)؛ خروجی psig همان قبلی است و کلاینت تغییری نمی‌خواهد.
create or replace function public.f_bump() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.f_conf(k,v) values('rev','1')
  on conflict (k) do update set v=(coalesce(nullif(f_conf.v,''),'0')::bigint+1)::text;
  return null;
end $$;

do $do$
declare t text;
begin
  foreach t in array array['products','ads','stories','v2_kv','booths','booth_products','booth_birds','bcfg'] loop
    if to_regclass('public.'||t) is not null then
      execute format('drop trigger if exists f_bump_t on public.%I', t);
      execute format('create trigger f_bump_t after insert or update or delete or truncate on public.%I for each statement execute function public.f_bump()', t);
    end if;
  end loop;
end $do$;

create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; ps text; pb text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pb := null; end;
  begin
    if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
  exception when others then null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا psig از f_psig استفاده کند (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_psig()' in d)=0 and position('if op=''psig'' then' in d)>0 then
    d := replace(d,'if op=''psig'' then','if op=''psig'' then return public.f_psig(); end if;'||chr(10)||'  if op=''psig_old'' then');
    execute d;
  end if;
end $do$;

-- [1.9.70] انجمن سبک: op fpull با slim=1 فقط پیام‌های جدید را می‌دهد (بدون فهرست اتاق‌ها/پین‌ها/شمارنده‌ی درخواست)؛ روی سرور فعلی تابع زنده‌ی fapp را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد یا متن تابع فرق داشته باشد کاری نمی‌کند).
do $do$
declare d text; ok boolean := true;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('slim' in d)>0 then return; end if;
  if position('''rooms'',coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id' in d)=0 then ok := false; end if;
  if position('from public.f_rooms r where r.status=''on''),''[]''::jsonb),' in d)=0 then ok := false; end if;
  if position('''pins'',coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))' in d)=0 then ok := false; end if;
  if position('m.pinned and m.del=false),''[]''::jsonb),' in d)=0 then ok := false; end if;
  if position('''reqn'',case when ismain then' in d)=0 then ok := false; end if;
  if ok then
    d := replace(d,'''rooms'',coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id','''rooms'',case when coalesce(a->>''slim'','''')=''1'' then null else coalesce((select jsonb_agg(jsonb_build_object(''id'',r.id');
    d := replace(d,'from public.f_rooms r where r.status=''on''),''[]''::jsonb),','from public.f_rooms r where r.status=''on''),''[]''::jsonb) end,');
    d := replace(d,'''pins'',coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))','''pins'',case when coalesce(a->>''slim'','''')=''1'' then null else coalesce((select jsonb_agg(jsonb_build_object(''id'',m.id,''u'',m.uname,''b'',left(m.body,120)))');
    d := replace(d,'m.pinned and m.del=false),''[]''::jsonb),','m.pinned and m.del=false),''[]''::jsonb) end,');
    d := replace(d,'''reqn'',case when ismain then','''reqn'',case when ismain and not (coalesce(a->>''slim'','''')=''1'') then');
    execute d;
  end if;
end $do$;

-- [1.9.71] دانلود فقط تغییرات: pidx = فهرست «شناسه+مهر» محصول/آگهی/استوری (کش‌شده با rev همان‌طور که psig)؛ pget = فقط آیتم‌های خواسته‌شده (+ بقیه‌ی public مثل cms/guides اگر rest=1).
create or replace function public.f_pub() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare pj jsonb;
begin
  pj := public.app('public','','','{}'::jsonb);
  if pj is null or jsonb_typeof(pj)<>'object' then return pj; end if;
  if (pj->'products') is not null then pj := jsonb_set(pj,'{products}',public.f_lite(pj->'products')); end if;
  if (pj->'ads') is not null then pj := jsonb_set(pj,'{ads}',public.f_lite(pj->'ads')); end if;
  return pj;
end $$;

create or replace function public.f_pidx() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cj text; pj jsonb; ix jsonb;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='pxr';
  select v into ct from public.f_conf where k='pxt';
  select v into cj from public.f_conf where k='pxj';
  if cj is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return cj::jsonb;
  end if;
  pj := public.f_pub();
  if pj is null or jsonb_typeof(pj)<>'object' then return jsonb_build_object('ok',0); end if;
  ix := jsonb_build_object('ok',1,
    'p',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'products')='array' then pj->'products' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    'a',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'ads')='array' then pj->'ads' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    's',coalesce((select jsonb_agg(jsonb_build_array(e.v->>'id', md5(e.v::text)) order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'stories')='array' then pj->'stories' else '[]'::jsonb end) with ordinality as e(v,o)),'[]'::jsonb),
    'x',md5((pj - 'products' - 'ads' - 'stories')::text));
  insert into public.f_conf(k,v) values('pxj',ix::text),('pxr',rv),('pxt',extract(epoch from now())::bigint::text)
  on conflict (k) do update set v=excluded.v;
  return ix;
end $$;

create or replace function public.f_pget(a jsonb) returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare pj jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  if jsonb_typeof(coalesce(a->'p','[]'::jsonb))<>'array' or jsonb_typeof(coalesce(a->'a','[]'::jsonb))<>'array' or jsonb_typeof(coalesce(a->'s','[]'::jsonb))<>'array' then return jsonb_build_object('ok',0); end if;
  if jsonb_array_length(coalesce(a->'p','[]'::jsonb))>400 or jsonb_array_length(coalesce(a->'a','[]'::jsonb))>400 or jsonb_array_length(coalesce(a->'s','[]'::jsonb))>400 then return jsonb_build_object('ok',0); end if;
  pj := public.f_pub();
  if pj is null or jsonb_typeof(pj)<>'object' then return jsonb_build_object('ok',0); end if;
  return jsonb_build_object('ok',1,
    'products',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'products')='array' then pj->'products' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'p','[]'::jsonb)))),'[]'::jsonb),
    'ads',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'ads')='array' then pj->'ads' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'a','[]'::jsonb)))),'[]'::jsonb),
    'stories',coalesce((select jsonb_agg(e.v order by e.o) from jsonb_array_elements(case when jsonb_typeof(pj->'stories')='array' then pj->'stories' else '[]'::jsonb end) with ordinality as e(v,o) where (e.v->>'id') in (select jsonb_array_elements_text(coalesce(a->'s','[]'::jsonb)))),'[]'::jsonb),
    'rest',case when coalesce(a->>'rest','')='1' then pj - 'products' - 'ads' - 'stories' else null end);
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا opهای pidx و pget را بشناسد (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_pidx()' in d)=0 and position('if op=''public2'' then' in d)>0 then
    d := replace(d,'if op=''public2'' then','if op=''pidx'' then return public.f_pidx(); end if;'||chr(10)||'  if op=''pget'' then return public.f_pget(a); end if;'||chr(10)||'  if op=''public2'' then');
    execute d;
  end if;
end $do$;

-- [1.9.73] عکس سبک برای غرفه‌ها و پرنده‌ها: bpub2/rpub2 = همان bpublic/rpublic ولی d هر محصول/پرنده (اگر th و thk دارد) فقط با عکس کوچک؛ bimg = عکس کامل یک محصول غرفه (k=b) یا پرنده (k=r). به bapp/rapp دست نمی‌زند.
create or replace function public.f_lite_rows(j jsonb) returns jsonb language sql stable as $f$
  select case when j is not null and jsonb_typeof(j)='array' then coalesce((
    select jsonb_agg(
      case when jsonb_typeof(e.v)='object' and jsonb_typeof(e.v->'d')='object'
           then jsonb_set(e.v,'{d}',(public.f_lite(jsonb_build_array(e.v->'d')))->0)
           else e.v end
      order by e.o)
    from jsonb_array_elements(j) with ordinality as e(v,o)), '[]'::jsonb) else j end
$f$;

create or replace function public.f_bpub2() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare r jsonb;
begin
  r := public.bapp('bpublic','','','{}'::jsonb);
  if r is null or jsonb_typeof(r)<>'object' or (r->'prods') is null then return r; end if;
  return jsonb_set(r,'{prods}',public.f_lite_rows(r->'prods'));
end $$;

create or replace function public.f_rpub2() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare r jsonb;
begin
  r := public.rapp('rpublic','','','{}'::jsonb);
  if r is null or jsonb_typeof(r)<>'object' or (r->'birds') is null then return r; end if;
  return jsonb_set(r,'{birds}',public.f_lite_rows(r->'birds'));
end $$;

create or replace function public.f_bimg(a jsonb) returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare ij jsonb; kk text;
begin
  a := coalesce(a,'{}'::jsonb); kk := coalesce(a->>'k','');
  if kk='b' then
    select q.d into ij from public.booth_products q join public.booths x on x.id=q.booth_id
     where q.id::text=a->>'id' and q.status='on' and x.status='active' limit 1;
  elsif kk='r' then
    select q.d into ij from public.booth_birds q join public.booths x on x.id=q.booth_id
     where q.id::text=a->>'id' and q.status='on' and x.status='active' limit 1;
  end if;
  if ij is null then return jsonb_build_object('ok',0); end if;
  return jsonb_build_object('ok',1,'img',ij->'img','imgs',coalesce(ij->'imgs','[]'::jsonb));
end $$;

-- روی سرور فعلی: تابع زنده‌ی fapp را کوتاه عوض می‌کند تا opهای bpub2 / rpub2 / bimg را بشناسد (اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('f_bpub2()' in d)=0 and position('if op=''public2'' then' in d)>0 then
    d := replace(d,'if op=''public2'' then','if op=''bpub2'' then return public.f_bpub2(); end if;'||chr(10)||'  if op=''rpub2'' then return public.f_rpub2(); end if;'||chr(10)||'  if op=''bimg'' then return public.f_bimg(a); end if;'||chr(10)||'  if op=''public2'' then');
    execute d;
  end if;
end $do$;

-- [1.9.75] ارسال دسته‌ای: bviewn (bapp؛ چند بازدید غرفه در یک درخواست) و mread با ids (mapp؛ چند «دیده شد» در یک درخواست). بدون جدول تازه. بخش‌های بالا (bapp / mapp) هم همین را دارند؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند).
do $do$
declare d text; bv text; mr text;
begin
  bv := $q$  if op='bviewn' then
    with x as (select (case when e.key ~ '^[0-9]{1,15}$' then e.key::bigint end) id, (case when e.value ~ '^[0-9]{1,3}$' then least(greatest(e.value::int,1),50) else 1 end) c
               from jsonb_each_text(case when jsonb_typeof(a->'v')='object' then a->'v' else '{}'::jsonb end) e limit 40),
    ok as (select x.id,x.c from x join booths b on b.id=x.id and b.status='active' where x.id is not null),
    i as (insert into booth_views(booth_id,day,n) select id,current_date,c from ok on conflict(booth_id,day) do update set n=booth_views.n+excluded.n returning 1)
    update booths set views=booths.views+ok.c from ok where booths.id=ok.id;
    return jsonb_build_object('ok',1,'n',1);
  end if;

$q$;
  mr := $q$  if op='mread' and a ? 'ids' and jsonb_typeof(a->'ids')='array' then
    insert into public.m_read(uname,msg)
      select who,m.id from public.m_msgs m
      where m.id in (select (case when t.v ~ '^[0-9]{1,15}$' then t.v::bigint end) from (select jsonb_array_elements_text(a->'ids') v limit 100) t)
        and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm) or (m.grp='user' and not isadm and not isbooth))
      on conflict do nothing;
    return jsonb_build_object('ok',1,'n',1);
  end if;

$q$;
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('bviewn' in d)=0 and position('  if op=''bview'' then' in d)>0 then
    execute replace(d,'  if op=''bview'' then',bv||'  if op=''bview'' then');
  end if;
  d := pg_get_functiondef('public.mapp(text,text,text,jsonb)'::regprocedure);
  if position('a ? ''ids''' in d)=0 and position('  if op=''mread'' then' in d)>0 then
    execute replace(d,'  if op=''mread'' then',mr||'  if op=''mread'' then');
  end if;
end $do$;

-- [1.9.76] رسانه‌ی انجمن سبک: op جدید fmed (گرفتن رسانه‌ی یک پیام با لمس) و سقف حجم رسانه از 4.2MB به 2.2MB. بخش fapp بالا هم همین را دارد؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند).
do $do$
declare d text; fm text;
begin
  fm := $q$  if op='fmed' then
    return coalesce((select jsonb_build_object('ok',1,'md',m.media) from public.f_msgs m where m.id=nullif(fapp.a->>'id','')::bigint and m.del=false and m.media is not null),jsonb_build_object('ok',0));
  end if;

$q$;
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position('op=''fmed''' in d)=0 and position('  if op=''ffaq'' then' in d)>0 then
    d := replace(d,'  if op=''ffaq'' then',fm||'  if op=''ffaq'' then');
    d := replace(d,'>4200000','>2200000');
    execute d;
  end if;
end $do$;

-- [1.9.77] سقف اندازه‌ی لوگو (120KB) و کاور (250KB) غرفه در op bset (bapp). بخش bapp بالا هم همین را دارد؛ این DO فقط روی سرور فعلی تابع زنده را کوتاه عوض می‌کند (اگر قبلاً عوض شده باشد کاری نمی‌کند). گوشی قبل از ارسال لوگو/کاور را خودکار کوچک می‌کند.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('>120000' in d)=0 and position('    if op=''bset'' then'||chr(10) in d)>0 then
    execute replace(d,'    if op=''bset'' then'||chr(10),'    if op=''bset'' then'||chr(10)||'      if length(coalesce(a->>''logo'',''''))>120000 or length(coalesce(a->>''cover'',''''))>250000 then return jsonb_build_object(''err'',''big''); end if;'||chr(10));
  end if;
end $do$;

-- [1.9.78] مهر غرفه/پرنده با «بازدید» عوض نشود: (۱) f_psig شمارنده‌ی views را از مهر غرفه‌ها حذف می‌کند (قبلاً هر بازدید غرفه مهر را عوض می‌کرد و کش بی‌اثر می‌شد)؛ (۲) تریگر booths با تغییر ستون views دیگر rev را بالا نمی‌برد. بدون جدول تازه. f_psig بالا هم همین را دارد؛ این بخش دوباره آن را می‌سازد (create or replace).
create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; ps text; pb text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pb := null; end;
  begin
    if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
  exception when others then null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
end $$;

do $do$
begin
  if to_regclass('public.booths') is not null then
    drop trigger if exists f_bump_t on public.booths;
    drop trigger if exists f_bump_u on public.booths;
    create trigger f_bump_t after insert or delete or truncate on public.booths for each statement execute function public.f_bump();
    create trigger f_bump_u after update of name,bio,logo,cover,city,phone,status,owner,pw on public.booths for each statement execute function public.f_bump();
  end if;
end $do$;

-- [1.9.79] 🧪 آزمایشی: کلیدهای خاموش/روشن (sapp: xget عمومی / xset فقط مدیر اصلی؛ ذخیره در f_conf.xf) + سطل Storage «bbimg» (عمومی، حداکثر 400KB، فقط webp/jpeg/png؛ هر کسی با کلید Publishable می‌تواند در آن آپلود کند). sapp بالا (بخش 1.9.67) همین را دارد. اگر بخش Storage خطا داد بقیه‌ی فایل اثر نمی‌گیرد و فقط «آزمایش Storage» در برنامه رد می‌شود.
do $do$
begin
  insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
    values('bbimg','bbimg',true,400000,array['image/webp','image/jpeg','image/png'])
    on conflict (id) do update set public=true,file_size_limit=400000,allowed_mime_types=array['image/webp','image/jpeg','image/png'];
  drop policy if exists bbimg_ins on storage.objects;
  create policy bbimg_ins on storage.objects for insert to anon, authenticated with check (bucket_id='bbimg');
exception when others then
  raise notice 'storage setup skipped: %', sqlerrm;
end $do$;

-- [1.9.80] مقایسه‌ی نسخه‌ها در 📡: خروجی sget بخش ver حالا میانگین بازشدن/زمان/دانلود هر نسخه را هم می‌دهد (روی تابع زنده‌ی sapp؛ اگر قبلاً عوض شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''o'',q.oo' in d)=0
     and position('jsonb_build_object(''v'',q.v,''n'',q.c) order by q.c desc)' in d)>0
     and position('count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;' in d)>0 then
    d := replace(d,'jsonb_build_object(''v'',q.v,''n'',q.c) order by q.c desc)','jsonb_build_object(''v'',q.v,''n'',q.c,''o'',q.oo,''s'',q.ss,''b'',q.bb) order by q.c desc)');
    d := replace(d,'count(*) as c from public.app_stats where day>current_date-dd group by 1 limit 12) q;','count(*) as c, sum(public.s_num(d->''o'',300)) as oo, sum(public.s_num(d->''s'',86400)) as ss, sum(public.s_num(d->''b'',2000000000)) as bb from public.app_stats where day>current_date-dd group by 1 limit 12) q;');
    execute d;
  end if;
end $do$;

-- [1.9.82] پشتیبان کامل تکه‌تکه (برای رفع timeout/حجم زیاد): bkapp با nodata:1 فقط ساختار می‌دهد؛ تابع تازه‌ی bkpart جدول‌ها را تکه‌تکه می‌دهد (فقط مدیر اصلی). فایل .bbk و بازگردانی تغییری نکرد.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.bkapp(text,text,text,jsonb)'::regprocedure);
  if position('nodata' in d)=0 and position('      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;' in d)>0 then
    d := replace(d,'      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;','      if coalesce(a->>''nodata'','''')=''1'' then continue; end if;
      execute format(''select coalesce(jsonb_agg(to_jsonb(x)),''''[]''''::jsonb) from public.%I x'', r.relname) into rows;');
    execute d;
  end if;
end $do$;

create or replace function public.bkpart(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; r record; t text; n int; o int; rows jsonb; tl jsonb := '[]'::jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
  if op='bktables' then
    for r in select c.relname, pg_total_relation_size(c.oid) as sz from pg_class c where c.relnamespace='public'::regnamespace and c.relkind='r' and c.relname not in ('f_conf','f_push') order by 1 loop
      tl := tl || jsonb_build_object('t',r.relname,'sz',r.sz);
    end loop;
    return jsonb_build_object('ok',1,'tables',tl);
  end if;
  if op='bkrows' then
    t := a->>'t'; n := least(greatest(coalesce((a->>'n')::int,50),1),2000); o := greatest(coalesce((a->>'o')::int,0),0);
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null then return jsonb_build_object('err','table'); end if;
    execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from (select * from public.%I order by ctid offset %s limit %s) x', t, o, n) into rows;
    return jsonb_build_object('ok',1,'rows',rows,'n',jsonb_array_length(rows),'by',length(rows::text));
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkpart(text,text,text,jsonb) to anon, authenticated;

-- [1.9.92] اطلاعات سرور داخل داشبورد (فقط مدیر اصلی؛ فقط خواندن)
create or replace function public.vapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; tl jsonb := '[]'::jsonb; cn jsonb := '{}'::jsonb; r record; t text; c bigint;
  dbs bigint; sto bigint; stn bigint; con int; mx int; up bigint; ver text; eg numeric := 0; dvc int := 0;
begin
  if op<>'vget' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if not (((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all')) then return jsonb_build_object('err','perm'); end if;
  dbs := pg_database_size(current_database());
  for r in select c2.relname as n, pg_total_relation_size(c2.oid) as sz from pg_class c2
      where c2.relnamespace='public'::regnamespace and c2.relkind='r' order by 2 desc limit 8 loop
    tl := tl || jsonb_build_object('t',r.n,'sz',r.sz);
  end loop;
  foreach t in array array['users','products','ads','orders','stories'] loop
    begin execute format('select count(*) from public.%I',t) into c; cn := cn || jsonb_build_object(t,c);
    exception when others then null; end;
  end loop;
  begin select coalesce(sum((o.metadata->>'size')::bigint),0), count(*) into sto, stn from storage.objects o;
  exception when others then sto := null; stn := null; end;
  begin select count(*) into con from pg_stat_activity where datname=current_database(); exception when others then con := null; end;
  begin mx := current_setting('max_connections')::int; exception when others then mx := null; end;
  begin up := extract(epoch from (now()-pg_postmaster_start_time()))::bigint; exception when others then up := null; end;
  begin ver := split_part(version(),' ',2); exception when others then ver := null; end;
  begin select coalesce(sum(public.s_num(d->'b',2000000000)),0), count(distinct dev) into eg, dvc from public.app_stats where day>current_date-30;
  exception when others then eg := 0; dvc := 0; end;
  return jsonb_build_object('ok',1,'db',dbs,'tables',tl,'rows',cn,'sto',sto,'stn',stn,'con',con,'mx',mx,'up',up,'ver',ver,'eg',eg,'dvc',dvc);
end $$;
grant execute on function public.vapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.97] بازگردانی پشتیبان کامل داخل پنل مدیر: op تازه‌ی bkput در bkpart (فقط مدیر اصلی؛ فقط جدول‌های مجاز؛ فقط ردیف‌های جاافتاده اضافه می‌شود و ردیف موجود رونویسی نمی‌شود). bktables و bkrows همان قبلی‌اند. (تأییدنشده روی PostgreSQL واقعی)
create or replace function public.bkpart(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; r record; t text; n int; o int; rows jsonb; tl jsonb := '[]'::jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')<>'admin' or not (coalesce(me->'pm','[]'::jsonb) ? 'all') then return jsonb_build_object('err','perm'); end if;
  if op='bktables' then
    for r in select c.relname, pg_total_relation_size(c.oid) as sz from pg_class c where c.relnamespace='public'::regnamespace and c.relkind='r' and c.relname not in ('f_conf','f_push') order by 1 loop
      tl := tl || jsonb_build_object('t',r.relname,'sz',r.sz);
    end loop;
    return jsonb_build_object('ok',1,'tables',tl);
  end if;
  if op='bkrows' then
    t := a->>'t'; n := least(greatest(coalesce((a->>'n')::int,50),1),2000); o := greatest(coalesce((a->>'o')::int,0),0);
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null then return jsonb_build_object('err','table'); end if;
    execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from (select * from public.%I order by ctid offset %s limit %s) x', t, o, n) into rows;
    return jsonb_build_object('ok',1,'rows',rows,'n',jsonb_array_length(rows),'by',length(rows::text));
  end if;
  if op='bkput' then
    t := a->>'t'; rows := a->'rows';
    if t is null or t in ('f_conf','f_push') or to_regclass('public.'||quote_ident(t)) is null or not exists (select 1 from pg_class c where c.oid=to_regclass('public.'||quote_ident(t)) and c.relkind='r') then return jsonb_build_object('err','table'); end if;
    if rows is null or jsonb_typeof(rows)<>'array' then return jsonb_build_object('err','rows'); end if;
    begin
      execute format('insert into public.%I select * from jsonb_populate_recordset(null::public.%I, $1) on conflict do nothing', t, t) using rows;
      get diagnostics n = row_count;
    exception when others then return jsonb_build_object('err','put','m',left(sqlerrm,200));
    end;
    return jsonb_build_object('ok',1,'ins',n);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.bkpart(text,text,text,jsonb) to anon, authenticated;

-- [1.9.103] مهر جدا برای غرفه‌ها و پرنده‌ها + کلیدهای سروری sf و cm
-- (۱) f_psig حالا علاوه بر s (محصول/آگهی/استوری/آموزش) و b (غرفه+پرنده؛ مثل قبل برای نسخه‌های قدیمی) دو مهر جدا هم می‌دهد: bb (فقط غرفه‌ها) و r (فقط پرنده‌ها). گوشی‌ها اگر bb/r نبود همان b قدیمی را به‌کار می‌برند. تأییدنشده روی PostgreSQL واقعی.
create or replace function public.f_psig() returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare rv text; cr text; ct text; cs text; cb text; cbb text; crr text; ps text; pb text; pbb text; prr text; rt text;
begin
  select v into rv from public.f_conf where k='rev'; rv := coalesce(rv,'0');
  select v into cr from public.f_conf where k='psr';
  select v into ct from public.f_conf where k='pst';
  select v into cs from public.f_conf where k='pss';
  select v into cb from public.f_conf where k='psb';
  select v into cbb from public.f_conf where k='psbb';
  select v into crr from public.f_conf where k='psrr';
  if cs is not null and cr = rv and ct is not null and extract(epoch from now()) - ct::numeric < 600 then
    return jsonb_build_object('ok',1,'s',cs,'b',nullif(cb,''),'bb',nullif(cbb,''),'r',nullif(crr,''));
  end if;
  begin
    ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
  exception when others then ps := null; end;
  begin
    pbb := md5(coalesce(regexp_replace(public.bapp('bpublic','','','{}'::jsonb)::text,'"views": [0-9]+','"views": 0','g'),''));
  exception when others then pbb := null; end;
  begin
    rt := coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'');
    prr := md5(rt);
    if pbb is not null then pb := md5(pbb||rt); end if;
  exception when others then prr := null; pb := null; end;
  if ps is not null then
    insert into public.f_conf(k,v) values('pss',ps),('psb',coalesce(pb,'')),('psbb',coalesce(pbb,'')),('psrr',coalesce(prr,'')),('psr',rv),('pst',extract(epoch from now())::bigint::text)
    on conflict (k) do update set v=excluded.v;
  end if;
  return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb,'bb',pbb,'r',prr);
end $$;

-- (۲) کلیدهای سروری sf (بروزرسانی بخش‌به‌بخش) و cm (کش هوشمند) برای xset: لیست مجاز کلیدها را در تابع زنده‌ی sapp بزرگ می‌کند (اگر قبلاً شده باشد کاری نمی‌کند)
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''cm''' in d)=0 and position('(''sto'',''dl'',''lt'',''md'',''qb'')' in d)>0 then
    d := replace(d,'(''sto'',''dl'',''lt'',''md'',''qb'')','(''sto'',''dl'',''lt'',''md'',''qb'',''sf'',''cm'')');
    execute d;
  end if;
end $do$;

-- [1.9.131] تأییدنشده: ده کلید تازه برای xset مجاز می‌شود (hn ex bd bf rl kr rw rh ck ot) تا خاموش/روشن‌کردنشان روی همه‌ی گوشی‌ها اثر کند. بدون این بخش برنامه مثل قبل (همه روشن) کار می‌کند و فقط دکمه‌ها خطا می‌دهند.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''rh''' in d)=0 and position('''sf'',''cm'')' in d)>0 then
    d := replace(d,'''sf'',''cm'')','''sf'',''cm'',''hn'',''ex'',''bd'',''bf'',''rl'',''kr'',''rw'',''rh'',''ck'',''ot'')');
    execute d;
  end if;
end $do$;

-- [1.9.132] تأییدنشده: ردیابی سفارش — جدول order_track + تابع تازه‌ی tapp (tset: فقط مدیر ؛ tmine: مشتری فقط سفارش خودش) + کلید tr برای xset. بدون این بخش و با کلید tr خاموش هیچ اثری ندارد.
create table if not exists public.order_track(oid bigint primary key, c text not null default '', n text not null default '', t timestamptz default now());
alter table public.order_track enable row level security;
create or replace function public.tapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; oid_ bigint; cc text; nn text; l jsonb;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  if op='tset' then
    if not ((me->>'role')='admin' and (coalesce(me->'pm','[]'::jsonb) ? 'all' or coalesce(me->'pm','[]'::jsonb) ? 'o')) then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint; cc := left(coalesce(a->>'c',''),40); nn := left(coalesce(a->>'n',''),120);
    if cc='' then delete from public.order_track where oid=oid_; else
      insert into public.order_track(oid,c,n) values(oid_,cc,nn) on conflict(oid) do update set c=excluded.c,n=excluded.n,t=now(); end if;
    return jsonb_build_object('ok',1);
  end if;
  if op='tmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'c',x.c,'n',x.n)),'[]'::jsonb) into l
      from public.order_track x join public.orders o on o.id=x.oid
      where o.d->>'u'=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.tapp(text,text,text,jsonb) to anon, authenticated;
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''tr''' in d)=0 and position('''ot'')' in d)>0 then
    d := replace(d,'''ot'')','''ot'',''tr'')');
    execute d;
  end if;
end $do$;

-- [1.9.133] تأییدنشده: مرجوعی/گزارش مشکل سفارش — جدول order_return + گسترش تابع tapp (rset/rmine: مشتری فقط سفارش خودش ؛ rlist/rdone: فقط مدیر) + کلید rt برای xset. با کلید rt خاموش هیچ اثری ندارد.
create table if not exists public.order_return(oid bigint primary key, u text not null default '', r int not null default 4, t text not null default '', s text not null default 'new', ts timestamptz default now());
alter table public.order_return enable row level security;
create or replace function public.tapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; oid_ bigint; cc text; nn text; l jsonb; isadm boolean; ex text;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin' and (coalesce(me->'pm','[]'::jsonb) ? 'all' or coalesce(me->'pm','[]'::jsonb) ? 'o');
  if op='tset' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint; cc := left(coalesce(a->>'c',''),40); nn := left(coalesce(a->>'n',''),120);
    if cc='' then delete from public.order_track where oid=oid_; else
      insert into public.order_track(oid,c,n) values(oid_,cc,nn) on conflict(oid) do update set c=excluded.c,n=excluded.n,t=now(); end if;
    return jsonb_build_object('ok',1);
  end if;
  if op='tmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'c',x.c,'n',x.n)),'[]'::jsonb) into l
      from public.order_track x join public.orders o on o.id=x.oid
      where o.d->>'u'=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rset' then
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' or coalesce(a->>'r','') !~ '^[1-4]$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint;
    if not exists(select 1 from public.orders o where o.id=oid_ and o.d->>'u'=u) then return jsonb_build_object('err','perm'); end if;
    select s into ex from public.order_return where oid=oid_;
    if ex='ok' then return jsonb_build_object('err','locked'); end if;
    insert into public.order_return(oid,u,r,t) values(oid_,u,(a->>'r')::int,left(coalesce(a->>'t',''),200))
      on conflict(oid) do update set r=excluded.r,t=excluded.t,ts=now();
    return jsonb_build_object('ok',1);
  end if;
  if op='rmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'r',x.r,'t',x.t,'s',x.s)),'[]'::jsonb) into l
      from public.order_return x
      where x.u=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rlist' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',y.oid,'r',y.r,'t',y.t,'s',y.s)),'[]'::jsonb) into l
      from (select oid,r,t,s from public.order_return order by ts desc limit 100) y;
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rdone' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    update public.order_return set s='ok',ts=now() where oid=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.tapp(text,text,text,jsonb) to anon, authenticated;
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''rt''' in d)=0 and position('''tr'')' in d)>0 then
    d := replace(d,'''tr'')','''tr'',''rt'')');
    execute d;
  end if;
end $do$;

-- [1.9.137] کلید pc (مقایسه‌ی قیمت غرفه‌ها) — تأییدنشده؛ بعد از [1.9.133] اجرا شود
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''pc''' in d)=0 and position('''rt'')' in d)>0 then
    d := replace(d,'''rt'')','''rt'',''pc'')');
    execute d;
  end if;
end $do$;

-- [1.9.139] کلید bs (خلاصه‌ی سبد غرفه‌ها) — تأییدنشده؛ بعد از [1.9.137] اجرا شود
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''bs''' in d)=0 and position('''pc'')' in d)>0 then
    d := replace(d,'''pc'')','''pc'',''bs'')');
    execute d;
  end if;
end $do$;

-- [1.9.143] کلید pr (اعلان پاسخ به من در انجمن) — تأییدنشده؛ بعد از [1.9.139] اجرا شود. پیش‌فرض خاموش.
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''pr''' in d)=0 and position('''bs'')' in d)>0 then
    d := replace(d,'''bs'')','''bs'',''pr'')');
    execute d;
  end if;
end $do$;

create or replace function public.f_trg_reply() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare au text; on_ text;
begin
  if new.reply_to is null then return new; end if;
  select v::jsonb->>'pr' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return new; end if;
  select uname into au from public.f_msgs where id=new.reply_to;
  if au is null or au=new.uname then return new; end if;
  perform public.f_push_send(array[au], '↩️ پاسخ به پیام شما', case when new.kind='text' then left(coalesce(new.body,''),80) else '📎' end);
  return new;
exception when others then return new;
end $$;
drop trigger if exists f_push_reply on public.f_msgs;
create trigger f_push_reply after insert on public.f_msgs for each row execute function public.f_trg_reply();

-- [1.9.145] کلید pf (اعلان محصول تازه به دنبال‌کنندگان غرفه) — تأییدنشده؛ بعد از [1.9.143] اجرا شود. پیش‌فرض خاموش.
create table if not exists public.booth_follow(uname text not null, booth_id bigint not null references public.booths(id) on delete cascade, primary key(uname,booth_id));
create table if not exists public.booth_follow_last(booth_id bigint primary key references public.booths(id) on delete cascade, ts timestamptz default now());
alter table public.booth_follow enable row level security;
alter table public.booth_follow_last enable row level security;
create or replace function public.tapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; oid_ bigint; cc text; nn text; l jsonb; isadm boolean; ex text;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin' and (coalesce(me->'pm','[]'::jsonb) ? 'all' or coalesce(me->'pm','[]'::jsonb) ? 'o');
  if op='tset' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint; cc := left(coalesce(a->>'c',''),40); nn := left(coalesce(a->>'n',''),120);
    if cc='' then delete from public.order_track where oid=oid_; else
      insert into public.order_track(oid,c,n) values(oid_,cc,nn) on conflict(oid) do update set c=excluded.c,n=excluded.n,t=now(); end if;
    return jsonb_build_object('ok',1);
  end if;
  if op='tmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'c',x.c,'n',x.n)),'[]'::jsonb) into l
      from public.order_track x join public.orders o on o.id=x.oid
      where o.d->>'u'=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rset' then
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' or coalesce(a->>'r','') !~ '^[1-4]$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint;
    if not exists(select 1 from public.orders o where o.id=oid_ and o.d->>'u'=u) then return jsonb_build_object('err','perm'); end if;
    select s into ex from public.order_return where oid=oid_;
    if ex='ok' then return jsonb_build_object('err','locked'); end if;
    insert into public.order_return(oid,u,r,t) values(oid_,u,(a->>'r')::int,left(coalesce(a->>'t',''),200))
      on conflict(oid) do update set r=excluded.r,t=excluded.t,ts=now();
    return jsonb_build_object('ok',1);
  end if;
  if op='rmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'r',x.r,'t',x.t,'s',x.s)),'[]'::jsonb) into l
      from public.order_return x
      where x.u=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rlist' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',y.oid,'r',y.r,'t',y.t,'s',y.s)),'[]'::jsonb) into l
      from (select oid,r,t,s from public.order_return order by ts desc limit 100) y;
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rdone' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    update public.order_return set s='ok',ts=now() where oid=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;
  if op='fsync' then
    delete from public.booth_follow where uname=u;
    insert into public.booth_follow(uname,booth_id)
      select u, b.id from public.booths b where b.id in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30);
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.tapp(text,text,text,jsonb) to anon, authenticated;
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''pf''' in d)=0 and position('''pr'')' in d)>0 then
    d := replace(d,'''pr'')','''pr'',''pf'')');
    execute d;
  end if;
end $do$;
create or replace function public.f_trg_bprod() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare on_ text; bn text; bo text; us text[]; lt timestamptz;
begin
  if coalesce(new.status,'on')<>'on' then return new; end if;
  select v::jsonb->>'pf' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return new; end if;
  select ts into lt from public.booth_follow_last where booth_id=new.booth_id;
  if lt is not null and lt>now()-interval '1 hour' then return new; end if;
  select name, owner into bn, bo from public.booths where id=new.booth_id;
  select array_agg(f.uname) into us from public.booth_follow f where f.booth_id=new.booth_id and f.uname<>coalesce(bo,'');
  if us is null then return new; end if;
  insert into public.booth_follow_last(booth_id,ts) values(new.booth_id,now()) on conflict(booth_id) do update set ts=now();
  perform public.f_push_send(us, '🆕 محصول تازه از '||coalesce(bn,'غرفه'), left(coalesce(new.d->>'name',''),80));
  return new;
exception when others then return new;
end $$;
drop trigger if exists f_push_bprod on public.booth_products;
create trigger f_push_bprod after insert on public.booth_products for each row execute function public.f_trg_bprod();-- [1.9.157] کلید wn (خبرم کن: موجود شد / ارزان شد) — تأییدنشده؛ بعد از [1.9.145] اجرا شود. پیش‌فرض خاموش.
create table if not exists public.prod_watch(uname text not null, pid bigint not null references public.booth_products(id) on delete cascade, p numeric default 0, o boolean default false, ts timestamptz, primary key(uname,pid));
alter table public.prod_watch enable row level security;
create or replace function public.f_bp_price(d jsonb) returns numeric language sql immutable as $f$
  select coalesce(case when d->>'price' ~ '^[0-9]+(\.[0-9]+)?$' then (d->>'price')::numeric when d->'rt'->>'price' ~ '^[0-9]+(\.[0-9]+)?$' then (d->'rt'->>'price')::numeric else 0 end,0)
    * (100 - least(greatest(case when d->>'disc' ~ '^[0-9]{1,2}$' then (d->>'disc')::numeric else 0 end,0),90)) / 100 $f$;
create or replace function public.tapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; oid_ bigint; cc text; nn text; l jsonb; isadm boolean; ex text;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin' and (coalesce(me->'pm','[]'::jsonb) ? 'all' or coalesce(me->'pm','[]'::jsonb) ? 'o');
  if op='tset' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint; cc := left(coalesce(a->>'c',''),40); nn := left(coalesce(a->>'n',''),120);
    if cc='' then delete from public.order_track where oid=oid_; else
      insert into public.order_track(oid,c,n) values(oid_,cc,nn) on conflict(oid) do update set c=excluded.c,n=excluded.n,t=now(); end if;
    return jsonb_build_object('ok',1);
  end if;
  if op='tmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'c',x.c,'n',x.n)),'[]'::jsonb) into l
      from public.order_track x join public.orders o on o.id=x.oid
      where o.d->>'u'=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rset' then
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' or coalesce(a->>'r','') !~ '^[1-4]$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint;
    if not exists(select 1 from public.orders o where o.id=oid_ and o.d->>'u'=u) then return jsonb_build_object('err','perm'); end if;
    select s into ex from public.order_return where oid=oid_;
    if ex='ok' then return jsonb_build_object('err','locked'); end if;
    insert into public.order_return(oid,u,r,t) values(oid_,u,(a->>'r')::int,left(coalesce(a->>'t',''),200))
      on conflict(oid) do update set r=excluded.r,t=excluded.t,ts=now();
    return jsonb_build_object('ok',1);
  end if;
  if op='rmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'r',x.r,'t',x.t,'s',x.s)),'[]'::jsonb) into l
      from public.order_return x
      where x.u=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rlist' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',y.oid,'r',y.r,'t',y.t,'s',y.s)),'[]'::jsonb) into l
      from (select oid,r,t,s from public.order_return order by ts desc limit 100) y;
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rdone' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    update public.order_return set s='ok',ts=now() where oid=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;
  if op='fsync' then
    delete from public.booth_follow where uname=u;
    insert into public.booth_follow(uname,booth_id)
      select u, b.id from public.booths b where b.id in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30);
    return jsonb_build_object('ok',1);
  end if;
  if op='wsync' then
    delete from public.prod_watch where uname=u and pid not in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30);
    insert into public.prod_watch(uname,pid,p,o)
      select u, b.id, public.f_bp_price(b.d), coalesce(b.d->>'out','') in ('1','true') from public.booth_products b
      where b.id in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30)
      on conflict(uname,pid) do nothing;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.tapp(text,text,text,jsonb) to anon, authenticated;
do $do$
declare d text;
begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''wn''' in d)=0 and position('''pf'')' in d)>0 then
    d := replace(d,'''pf'')','''pf'',''wn'')');
    execute d;
  end if;
end $do$;
create or replace function public.f_trg_bpwatch() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare on_ text; bo text; us text[]; np numeric; op_ numeric; no_ boolean; oo boolean; ttl text;
begin
  if coalesce(new.status,'on')<>'on' then return new; end if;
  select v::jsonb->>'wn' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return new; end if;
  np := public.f_bp_price(new.d); op_ := public.f_bp_price(old.d);
  no_ := coalesce(new.d->>'out','') in ('1','true'); oo := coalesce(old.d->>'out','') in ('1','true');
  if oo and not no_ then ttl := '✅ موجود شد';
  elsif np>0 and op_>0 and np<op_ then ttl := '💰 ارزان شد';
  else
    update public.prod_watch set p=np, o=no_ where pid=new.id and (p<>np or o<>no_);
    return new;
  end if;
  select owner into bo from public.booths where id=new.booth_id;
  select array_agg(w.uname) into us from public.prod_watch w where w.pid=new.id and w.uname<>coalesce(bo,'') and (w.ts is null or w.ts<now()-interval '6 hours');
  update public.prod_watch set p=np, o=no_ where pid=new.id;
  if us is null then return new; end if;
  update public.prod_watch set ts=now() where pid=new.id and uname=any(us);
  perform public.f_push_send(us, ttl, left(coalesce(new.d->>'name',''),80));
  return new;
exception when others then return new;
end $$;
drop trigger if exists f_push_bpwatch on public.booth_products;
create trigger f_push_bpwatch after update of d on public.booth_products for each row when (old.d is distinct from new.d) execute function public.f_trg_bpwatch();

-- [1.9.158] کلید nc (سقف اعلان به خواست کاربر) — تأییدنشده؛ بعد از [1.9.157] اجرا شود. پیش‌فرض خاموش. فقط اعلان‌های اختیاری (خبرم کن و محصول تازه) سقف می‌گیرند؛ پیام/سفارش نه.
create table if not exists public.push_pref(uname text primary key, c int not null default 0, n int not null default 0, d date);
alter table public.push_pref enable row level security;
create or replace function public.f_push_cap(us text[]) returns text[] language plpgsql security definer set search_path=public, extensions as $$
declare on_ text; r text[];
begin
  if us is null then return us; end if;
  select v::jsonb->>'nc' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return us; end if;
  select array_agg(x) into r from unnest(us) x
    where not exists(select 1 from public.push_pref p where p.uname=x and (p.c<0 or (p.c>0 and p.d=current_date and p.n>=p.c)));
  if r is not null then
    update public.push_pref set n=case when d=current_date then n+1 else 1 end, d=current_date where uname=any(r) and c>0;
  end if;
  return r;
exception when others then return us;
end $$;
create or replace function public.tapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; oid_ bigint; cc text; nn text; l jsonb; isadm boolean; ex text;
begin
  a := coalesce(a,'{}'::jsonb);
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin' and (coalesce(me->'pm','[]'::jsonb) ? 'all' or coalesce(me->'pm','[]'::jsonb) ? 'o');
  if op='tset' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint; cc := left(coalesce(a->>'c',''),40); nn := left(coalesce(a->>'n',''),120);
    if cc='' then delete from public.order_track where oid=oid_; else
      insert into public.order_track(oid,c,n) values(oid_,cc,nn) on conflict(oid) do update set c=excluded.c,n=excluded.n,t=now(); end if;
    return jsonb_build_object('ok',1);
  end if;
  if op='tmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'c',x.c,'n',x.n)),'[]'::jsonb) into l
      from public.order_track x join public.orders o on o.id=x.oid
      where o.d->>'u'=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rset' then
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' or coalesce(a->>'r','') !~ '^[1-4]$' then return jsonb_build_object('err','bad'); end if;
    oid_ := (a->>'id')::bigint;
    if not exists(select 1 from public.orders o where o.id=oid_ and o.d->>'u'=u) then return jsonb_build_object('err','perm'); end if;
    select s into ex from public.order_return where oid=oid_;
    if ex='ok' then return jsonb_build_object('err','locked'); end if;
    insert into public.order_return(oid,u,r,t) values(oid_,u,(a->>'r')::int,left(coalesce(a->>'t',''),200))
      on conflict(oid) do update set r=excluded.r,t=excluded.t,ts=now();
    return jsonb_build_object('ok',1);
  end if;
  if op='rmine' then
    select coalesce(jsonb_agg(jsonb_build_object('id',x.oid,'r',x.r,'t',x.t,'s',x.s)),'[]'::jsonb) into l
      from public.order_return x
      where x.u=u and x.oid in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 50);
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rlist' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',y.oid,'r',y.r,'t',y.t,'s',y.s)),'[]'::jsonb) into l
      from (select oid,r,t,s from public.order_return order by ts desc limit 100) y;
    return jsonb_build_object('ok',1,'l',l);
  end if;
  if op='rdone' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'id','') !~ '^[0-9]{1,15}$' then return jsonb_build_object('err','bad'); end if;
    update public.order_return set s='ok',ts=now() where oid=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;
  if op='ncset' then
    if coalesce(a->>'c','') !~ '^(-1|0|1|3)$' then return jsonb_build_object('err','bad'); end if;
    insert into public.push_pref(uname,c) values(u,(a->>'c')::int) on conflict(uname) do update set c=excluded.c;
    return jsonb_build_object('ok',1);
  end if;
  if op='fsync' then
    delete from public.booth_follow where uname=u;
    insert into public.booth_follow(uname,booth_id)
      select u, b.id from public.booths b where b.id in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30);
    return jsonb_build_object('ok',1);
  end if;
  if op='wsync' then
    delete from public.prod_watch where uname=u and pid not in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30);
    insert into public.prod_watch(uname,pid,p,o)
      select u, b.id, public.f_bp_price(b.d), coalesce(b.d->>'out','') in ('1','true') from public.booth_products b
      where b.id in (select (e)::bigint from jsonb_array_elements_text(case when jsonb_typeof(a->'ids')='array' then a->'ids' else '[]'::jsonb end) e where e ~ '^[0-9]{1,15}$' limit 30)
      on conflict(uname,pid) do nothing;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
grant execute on function public.tapp(text,text,text,jsonb) to anon, authenticated;
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''nc''' in d)=0 and position('''wn'')' in d)>0 then
    d := replace(d,'''wn'')','''wn'',''nc'')');
    execute d;
  end if;
end $do$;
create or replace function public.f_trg_bpwatch() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare on_ text; bo text; us text[]; np numeric; op_ numeric; no_ boolean; oo boolean; ttl text;
begin
  if coalesce(new.status,'on')<>'on' then return new; end if;
  select v::jsonb->>'wn' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return new; end if;
  np := public.f_bp_price(new.d); op_ := public.f_bp_price(old.d);
  no_ := coalesce(new.d->>'out','') in ('1','true'); oo := coalesce(old.d->>'out','') in ('1','true');
  if oo and not no_ then ttl := '✅ موجود شد';
  elsif np>0 and op_>0 and np<op_ then ttl := '💰 ارزان شد';
  else
    update public.prod_watch set p=np, o=no_ where pid=new.id and (p<>np or o<>no_);
    return new;
  end if;
  select owner into bo from public.booths where id=new.booth_id;
  select array_agg(w.uname) into us from public.prod_watch w where w.pid=new.id and w.uname<>coalesce(bo,'') and (w.ts is null or w.ts<now()-interval '6 hours');
  update public.prod_watch set p=np, o=no_ where pid=new.id;
  if us is null then return new; end if;
  update public.prod_watch set ts=now() where pid=new.id and uname=any(us);
  perform public.f_push_send(public.f_push_cap(us), ttl, left(coalesce(new.d->>'name',''),80));
  return new;
exception when others then return new;
end $$;
create or replace function public.f_trg_bprod() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare on_ text; bn text; bo text; us text[]; lt timestamptz;
begin
  if coalesce(new.status,'on')<>'on' then return new; end if;
  select v::jsonb->>'pf' into on_ from public.f_conf where k='xf';
  if coalesce(on_,'0')<>'1' then return new; end if;
  select ts into lt from public.booth_follow_last where booth_id=new.booth_id;
  if lt is not null and lt>now()-interval '1 hour' then return new; end if;
  select name, owner into bn, bo from public.booths where id=new.booth_id;
  select array_agg(f.uname) into us from public.booth_follow f where f.booth_id=new.booth_id and f.uname<>coalesce(bo,'');
  if us is null then return new; end if;
  insert into public.booth_follow_last(booth_id,ts) values(new.booth_id,now()) on conflict(booth_id) do update set ts=now();
  perform public.f_push_send(public.f_push_cap(us), '🆕 محصول تازه از '||coalesce(bn,'غرفه'), left(coalesce(new.d->>'name',''),80));
  return new;
exception when others then return new;
end $$;

-- [1.9.190] (تأییدنشده) کلید xic (آیکن‌های انتخابی) به لیست مجاز xset
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''xic''' in d)=0 and position('''nc'')' in d)>0 then
    d := replace(d,'''nc'')','''nc'',''xic'')');
    execute d;
  end if;
end $do$;

-- [1.9.325] (تأییدنشده) کلید xe (پنل‌های کشویی اکسپلورر) به لیست مجاز xset
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''xe''' in d)=0 and position('''xic'')' in d)>0 then
    d := replace(d,'''xic'')','''xic'',''xe'')');
    execute d;
  end if;
end $do$;

-- [1.9.327] (تأییدنشده) کلید xs (استودیو: ظاهر هر بخش) به لیست مجاز xset
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''xs''' in d)=0 and position('''xe'')' in d)>0 then
    d := replace(d,'''xe'')','''xe'',''xs'')');
    execute d;
  end if;
end $do$;

-- [1.9.354] (تأییدنشده) کلید xp (راحتی و پروفایل) به لیست مجاز xset
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''xp''' in d)=0 and position('''xs'')' in d)>0 then
    d := replace(d,'''xs'')','''xs'',''xp'')');
    execute d;
  end if;
end $do$;

-- [1.9.367] (تأییدنشده) C0: ستون‌های لوکیشن/ساعت/سطح تأیید غرفه (geo ، lvl ، vat) + opهای تازه‌ی bapp: cg_get cg_set (غرفه‌دار) ، cg_pub (عمومی ؛ فقط غرفه‌های فعال ؛ نشانی فقط در حالت دقیق) ، badm_lvl (فقط مدیر اصلی) + کلید cg به لیست مجاز xset. غیرحضوری (rm) فقط وقتی lvl>0 ؛ اجبار سمت سرور. به opهای قبلی دست نمی‌زند.
alter table public.booths add column if not exists geo jsonb not null default '{}'::jsonb;
alter table public.booths add column if not exists lvl smallint not null default 0;
alter table public.booths add column if not exists vat timestamptz;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cg_set' in d)=0 and position($a$'bord_st') then$a$ in d)>0 and position($b$if op='bpublic' then$b$ in d)>0 and position($c$if op='bpw' then$c$ in d)>0 and position($e$if op='badm_list' then$e$ in d)>0 then
    d := replace(d, $a$'bord_st') then$a$, $a$'bord_st','cg_get','cg_set') then$a$);
    d := replace(d, $c$if op='bpw' then$c$, $o$if op='cg_get' then
      return jsonb_build_object('ok',1,'geo',b.geo,'lvl',b.lvl);
    end if;
    if op='cg_set' then
      r := jsonb_build_object(
        'lat',case when (a->>'lat') ~ '^-?[0-9]{1,3}(\.[0-9]{1,6})?$' then case when abs((a->>'lat')::numeric)<=90 then (a->>'lat')::numeric end end,
        'lng',case when (a->>'lng') ~ '^-?[0-9]{1,3}(\.[0-9]{1,6})?$' then case when abs((a->>'lng')::numeric)<=180 then (a->>'lng')::numeric end end,
        'acc',case when a->>'acc'='n' then 'n' else 'x' end,
        'hrs',case when jsonb_typeof(a->'hrs')='object' and length((a->'hrs')::text)<=400 then a->'hrs' else '{}'::jsonb end,
        'rm',case when b.lvl>0 and (a->>'rm')='1' then 1 else 0 end,
        'ad',left(coalesce(a->>'ad',''),160),
        'nt',left(coalesce(a->>'nt',''),160));
      update booths set geo=r where id=b.id;
      return jsonb_build_object('ok',1,'geo',r,'lvl',b.lvl);
    end if;
    $o$ || $c$if op='bpw' then$c$);
    d := replace(d, $b$if op='bpublic' then$b$, $p$if op='cg_pub' then
      return jsonb_build_object('ok',1,'g',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'lvl',x.lvl,
        'rm',case when x.lvl>0 and (x.geo->>'rm')='1' then 1 else 0 end,'acc',x.geo->>'acc',
        'la',case when x.geo->>'acc'='n' then round((x.geo->>'lat')::numeric,2) else (x.geo->>'lat')::numeric end,
        'ln',case when x.geo->>'acc'='n' then round((x.geo->>'lng')::numeric,2) else (x.geo->>'lng')::numeric end,
        'hrs',x.geo->'hrs','ad',case when x.geo->>'acc'='n' then '' else x.geo->>'ad' end) order by x.id)
        from booths x where x.status='active' and (x.lvl>0 or (x.geo->>'lat') is not null)),'[]'::jsonb));
    end if;
    $p$ || $b$if op='bpublic' then$b$);
    d := replace(d, $e$if op='badm_list' then$e$, $m$if op='badm_lvl' then
      if coalesce(a->>'lvl','') not in ('0','1','2') then return jsonb_build_object('err','bad'); end if;
      update booths set lvl=(a->>'lvl')::smallint, vat=case when (a->>'lvl')<>'0' then now() else null end,
        geo=case when (a->>'lvl')='0' then jsonb_set(coalesce(geo,'{}'::jsonb),'{rm}','0'::jsonb) else geo end
      where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1);
    end if;

    $m$ || $e$if op='badm_list' then$e$);
    execute d;
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''cg''' in d)=0 and position('''xp'')' in d)>0 then
    d := replace(d,'''xp'')','''xp'',''cg'')');
    execute d;
  end if;
end $do$;

-- [1.9.370] (تأییدنشده) C2: تأیید غرفه ؛ ستون vreq + opهای غرفه‌دار vq_get vq_set + opهای مدیر badm_vq badm_vqi badm_vqd + اجبار سرور در bord (فقط وقتی کلید cg روشن است: غرفه‌ی تأییدنشده سفارش غیرحضوری نمی‌گیرد ؛ سفارش حضوری با pk=1 مجاز). بعد از [1.9.367] اجرا شود.
alter table public.booths add column if not exists vreq jsonb not null default '{}'::jsonb;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('vq_set' in d)=0 and position($a$'cg_set') then$a$ in d)>0 and position($c$if op='cg_get' then$c$ in d)>0 and position($e$if op='badm_lvl' then$e$ in d)>0 and position($f$insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,$f$ in d)>0 then
    d := replace(d, $a$'cg_set') then$a$, $a$'cg_set','vq_get','vq_set') then$a$);
    d := replace(d, $c$if op='cg_get' then$c$, $o$if op='vq_get' then
      return jsonb_build_object('ok',1,'st',coalesce(b.vreq->>'st',''),'why',coalesce(b.vreq->>'why',''),'lvl',b.lvl);
    end if;
    if op='vq_set' then
      if b.lvl>0 then return jsonb_build_object('err','done'); end if;
      if coalesce(b.vreq->>'st','')='pending' then return jsonb_build_object('err','wait'); end if;
      if (b.geo->>'lat') is null then return jsonb_build_object('err','noloc'); end if;
      if length(regexp_replace(coalesce(a->>'ph',''),'[^0-9]','','g'))<7 then return jsonb_build_object('err','bad'); end if;
      if length(coalesce(a->>'im',''))>120000 or (coalesce(a->>'im','')<>'' and left(a->>'im',10)<>'data:image') then return jsonb_build_object('err','big'); end if;
      update booths set vreq=jsonb_build_object('st','pending','ph',left(a->>'ph',30),'nt',left(coalesce(a->>'nt',''),300),'im',coalesce(a->>'im',''),'t',now()) where id=b.id;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cg_get' then$c$);
    d := replace(d, $e$if op='badm_lvl' then$e$, $m$if op='badm_vq' then
      return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'name',x.name,'owner',x.owner,'city',x.city,'phone',x.phone,'ph',x.vreq->>'ph','nt',x.vreq->>'nt','t',x.vreq->>'t','im',(coalesce(x.vreq->>'im','')<>''),'la',x.geo->'lat','ln',x.geo->'lng','ad',x.geo->>'ad') order by x.id) from booths x where x.vreq->>'st'='pending'),'[]'::jsonb));
    end if;
    if op='badm_vqi' then
      return jsonb_build_object('ok',1,'im',coalesce((select vreq->>'im' from booths where id=(a->>'id')::bigint),''));
    end if;
    if op='badm_vqd' then
      if coalesce(a->>'ok','')='1' then
        update booths set lvl=case when (a->>'lvl')='2' then 2 else 1 end, vat=now(), vreq=jsonb_build_object('st','ok','t',now()) where id=(a->>'id')::bigint and vreq->>'st'='pending';
      else
        update booths set vreq=jsonb_build_object('st','no','why',left(coalesce(a->>'why',''),200),'t',now()) where id=(a->>'id')::bigint and vreq->>'st'='pending';
      end if;
      return jsonb_build_object('ok',1);
    end if;
    $m$ || $e$if op='badm_lvl' then$e$);
    d := replace(d, $f$insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,$f$, $g$if coalesce((select nullif(c.v,'')::jsonb->>'cg' from public.f_conf c where c.k='xf'),'0')='1' and coalesce(b.lvl,0)=0 and coalesce(a->>'pk','')<>'1' then return jsonb_build_object('err','unv'); end if;
    insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,$g$);
    execute d;
  elsif position('vq_set' in d)=0 then
    raise exception 'C2: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.371] (تأییدنشده) C3: خرید حضوری ؛ ستون pk در booth_orders (رزرو: مهلت h ، کد c ، تأیید خریدار g ، تأیید غرفه‌دار d ، لغو x) + opهای تازه‌ی bapp: pk_cx pk_got (خریدار ؛ با شماره + کد) ، pk_chk (غرفه‌دار ؛ کد را تأیید و سفارش را می‌بندد) + کلید cp به لیست مجاز xset. به opهای قبلی دست نمی‌زند. بعد از [1.9.370] اجرا شود.
alter table public.booth_orders add column if not exists pk jsonb;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('pk_chk' in d)=0 and position($a$'vq_set') then$a$ in d)>0 and position($c$if op='vq_get' then$c$ in d)>0 and position($h$if op='bord' then$h$ in d)>0 and position($f$lines,total) values(b.id,$f$ in d)>0 and position($g$coalesce((a->>'total')::bigint,0));$g$ in d)>0 and position($i$'s',o.status,'t',o.created)$i$ in d)>0 then
    d := replace(d, $a$'vq_set') then$a$, $a$'vq_set','pk_chk') then$a$);
    d := replace(d, $c$if op='vq_get' then$c$, $o$if op='pk_chk' then
      update booth_orders set status='done', pk=coalesce(pk,'{}'::jsonb)||'{"d":1}'::jsonb where id=(a->>'id')::bigint and booth_id=b.id and status='new' and pk->>'c'=coalesce(a->>'c','');
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='vq_get' then$c$);
    d := replace(d, $h$if op='bord' then$h$, $p$if op='pk_cx' then
      update booth_orders set status='cancel', pk=coalesce(pk,'{}'::jsonb)||'{"x":1}'::jsonb where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status='new' and created>now()-interval '3 days';
      if not found then return jsonb_build_object('err','none'); end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='pk_got' then
      update booth_orders set pk=coalesce(pk,'{}'::jsonb)||'{"g":1}'::jsonb where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status<>'cancel' and created>now()-interval '3 days';
      if not found then return jsonb_build_object('err','none'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $p$ || $h$if op='bord' then$h$);
    d := replace(d, $f$lines,total) values(b.id,$f$, $q$lines,total,pk) values(b.id,$q$);
    d := replace(d, $g$coalesce((a->>'total')::bigint,0));$g$, $r$coalesce((a->>'total')::bigint,0),case when a->>'pk'='1' and coalesce(a->>'pc','')~'^[0-9]{4}$' and coalesce(a->>'rh','') in ('2','6','24') then jsonb_build_object('h',(a->>'rh')::int,'c',a->>'pc') else null end);$r$);
    d := replace(d, $i$'s',o.status,'t',o.created)$i$, $s$'s',o.status,'t',o.created,'pk',(o.pk-'c'))$s$);
    execute d;
  elsif position('pk_chk' in d)=0 then
    raise exception 'C3: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''cp''' in d)=0 and position('''cg'')' in d)>0 then
    d := replace(d,'''cg'')','''cg'',''cp'')');
    execute d;
  end if;
end $do$;

-- [1.9.373] (تأییدنشده) C5a: پیک انحصاری ؛ جدول couriers + تابع تازه‌ی yapp (yreg yme yset yadm_list yadm_set ؛ ادمین مثل bapp با حساب اصلی) + ستون booth_orders.cr + opهای bapp: cr_rdy (غرفه‌دار تأییدشده سفارش غیرحضوری را «آماده‌ی ارسال با پیک» می‌کند) و bords حالا cr هم برمی‌گرداند + کلید cr به لیست مجاز xset. به opهای قبلی دست نمی‌زند. بعد از [1.9.371] اجرا شود.
alter table public.booth_orders add column if not exists cr jsonb;

create table if not exists public.couriers(
  id bigserial primary key, uname text unique not null, pw text not null,
  name text not null, veh text default 'p', area text default '', st text default 'pending',
  created timestamptz default now());
alter table public.couriers enable row level security;

create or replace function public.yapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare c public.couriers; me jsonb := null; adm boolean := false; v text;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='yreg' then
    if u !~ '^[0-9]{10,15}$' or length(coalesce(p,''))<4 or length(coalesce(a->>'name',''))<2 then return jsonb_build_object('err','bad'); end if;
    if exists(select 1 from couriers where uname=u) then return jsonb_build_object('err','dup'); end if;
    v := case when a->>'veh' in ('p','m','c') then a->>'veh' else 'p' end;
    insert into couriers(uname,pw,name,veh,area) values(u,crypt(p,gen_salt('bf')),left(a->>'name',80),v,left(coalesce(a->>'area',''),80));
    return jsonb_build_object('ok',1,'me',jsonb_build_object('name',left(a->>'name',80),'veh',v,'area',left(coalesce(a->>'area',''),80),'st','pending'));
  end if;
  if op in ('yme','yset') then
    select * into c from couriers where uname=u and pw=crypt(p,pw);
    if not found then return jsonb_build_object('err','auth'); end if;
    if op='yset' then
      v := case when a->>'veh' in ('p','m','c') then a->>'veh' else c.veh end;
      update couriers set name=case when length(coalesce(a->>'name',''))>=2 then left(a->>'name',80) else name end, veh=v, area=left(coalesce(a->>'area',''),80) where id=c.id;
      return jsonb_build_object('ok',1);
    end if;
    return jsonb_build_object('ok',1,'me',jsonb_build_object('name',c.name,'veh',c.veh,'area',c.area,'st',c.st));
  end if;
  if op like 'yadm_%' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and not (me ? 'err') and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;
    if not adm then return jsonb_build_object('err','denied'); end if;
    if op='yadm_list' then
      return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'u',x.uname,'name',x.name,'veh',x.veh,'area',x.area,'st',x.st) order by (x.st='pending') desc, x.id desc) from (select * from couriers order by (st='pending') desc, id desc limit 40) x),'[]'::jsonb));
    end if;
    if op='yadm_set' then
      update couriers set st=case when a->>'ok'='1' then 'ok' else 'off' end where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1);
    end if;
  end if;
  return jsonb_build_object('err','op');
end $$;
grant execute on function public.yapp(text,text,text,jsonb) to anon, authenticated;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cr_rdy' in d)=0 and position($a$'pk_chk') then$a$ in d)>0 and position($c$if op='pk_chk' then$c$ in d)>0 and position($s$'pk',(o.pk-'c'))$s$ in d)>0 then
    d := replace(d, $a$'pk_chk') then$a$, $a$'pk_chk','cr_rdy') then$a$);
    d := replace(d, $c$if op='pk_chk' then$c$, $o$if op='cr_rdy' then
      if coalesce(b.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
      update booth_orders set cr='{"s":"rdy"}'::jsonb where id=(a->>'id')::bigint and booth_id=b.id and status='new' and pk is null and cr is null;
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='pk_chk' then$c$);
    d := replace(d, $s$'pk',(o.pk-'c'))$s$, $t$'pk',(o.pk-'c'),'cr',o.cr)$t$);
    execute d;
  elsif position('cr_rdy' in d)=0 then
    raise exception 'C5a: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position('''cr''' in d)=0 and position('''cp''' in d)>0 then
    d := replace(d,'''cp'')','''cp'',''cr'')');
    execute d;
  end if;
end $do$;

-- [1.9.374] (تأییدنشده) C5b: پیک ؛ yapp کامل‌تر (yjobs yacc yway ydone) + bapp: cr_pk (غرفه‌دار کد پیک را تأیید می‌کند) + cr_rdy حالا کد مشتری o می‌سازد + bords کد k را نشان نمی‌دهد. بعد از [1.9.373] اجرا شود.
create or replace function public.yapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare c public.couriers; me jsonb := null; adm boolean := false; v text; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='yreg' then
    if u !~ '^[0-9]{10,15}$' or length(coalesce(p,''))<4 or length(coalesce(a->>'name',''))<2 then return jsonb_build_object('err','bad'); end if;
    if exists(select 1 from couriers where uname=u) then return jsonb_build_object('err','dup'); end if;
    v := case when a->>'veh' in ('p','m','c') then a->>'veh' else 'p' end;
    insert into couriers(uname,pw,name,veh,area) values(u,crypt(p,gen_salt('bf')),left(a->>'name',80),v,left(coalesce(a->>'area',''),80));
    return jsonb_build_object('ok',1,'me',jsonb_build_object('name',left(a->>'name',80),'veh',v,'area',left(coalesce(a->>'area',''),80),'st','pending'));
  end if;
  if op in ('yme','yset','yjobs','yacc','yway','ydone') then
    select * into c from couriers where uname=u and pw=crypt(p,pw);
    if not found then return jsonb_build_object('err','auth'); end if;
    if op='yset' then
      v := case when a->>'veh' in ('p','m','c') then a->>'veh' else c.veh end;
      update couriers set name=case when length(coalesce(a->>'name',''))>=2 then left(a->>'name',80) else name end, veh=v, area=left(coalesce(a->>'area',''),80) where id=c.id;
      return jsonb_build_object('ok',1);
    end if;
    if op='yme' then
      return jsonb_build_object('ok',1,'me',jsonb_build_object('name',c.name,'veh',c.veh,'area',c.area,'st',c.st));
    end if;
    if c.st<>'ok' then return jsonb_build_object('err','st'); end if;
    if op='yjobs' then
      return jsonb_build_object('ok',1,
        'av',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'bn',b.name,'city',b.city,'n',jsonb_array_length(x.lines),'t',x.total) order by x.id) from (select * from booth_orders where status='new' and cr->>'s'='rdy' order by id limit 20) x join booths b on b.id=x.booth_id),'[]'::jsonb),
        'my',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'s',x.cr->>'s','bn',b.name,'bp',b.phone,'name',x.name,'phone',x.phone,'addr',x.addr,'k',case when x.cr->>'s'='acc' then x.cr->>'k' else null end) order by x.id) from booth_orders x join booths b on b.id=x.booth_id where x.status='new' and x.cr->>'c'=c.id::text and x.cr->>'s' in ('acc','pick','way')),'[]'::jsonb));
    end if;
    if op='yacc' then
      select count(*) into n from booth_orders where status='new' and cr->>'c'=c.id::text and cr->>'s' in ('acc','pick','way');
      if n>=3 then return jsonb_build_object('err','full'); end if;
      update booth_orders set cr=cr||jsonb_build_object('s','acc','c',c.id::text,'k',lpad((floor(random()*10000))::int::text,4,'0')) where id=(a->>'id')::bigint and status='new' and cr->>'s'='rdy';
      if not found then return jsonb_build_object('err','gone'); end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='yway' then
      update booth_orders set cr=cr||'{"s":"way"}'::jsonb where id=(a->>'id')::bigint and status='new' and cr->>'c'=c.id::text and cr->>'s'='pick';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='ydone' then
      update booth_orders set cr=cr||'{"s":"done"}'::jsonb, status='done' where id=(a->>'id')::bigint and status='new' and cr->>'c'=c.id::text and cr->>'s'='way' and cr->>'o'=coalesce(a->>'o','');
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
  end if;
  if op like 'yadm_%' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and not (me ? 'err') and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'all' then adm := true; end if;
    if not adm then return jsonb_build_object('err','denied'); end if;
    if op='yadm_list' then
      return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'u',x.uname,'name',x.name,'veh',x.veh,'area',x.area,'st',x.st) order by (x.st='pending') desc, x.id desc) from (select * from couriers order by (st='pending') desc, id desc limit 40) x),'[]'::jsonb));
    end if;
    if op='yadm_set' then
      update couriers set st=case when a->>'ok'='1' then 'ok' else 'off' end where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1);
    end if;
  end if;
  return jsonb_build_object('err','op');
end $$;
grant execute on function public.yapp(text,text,text,jsonb) to anon, authenticated;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cr_pk' in d)=0 and position($a$'cr_rdy') then$a$ in d)>0 and position($c$if op='cr_rdy' then$c$ in d)>0 and position($r$cr='{"s":"rdy"}'::jsonb$r$ in d)>0 and position($s$'cr',o.cr)$s$ in d)>0 then
    d := replace(d, $a$'cr_rdy') then$a$, $a$'cr_rdy','cr_pk') then$a$);
    d := replace(d, $r$cr='{"s":"rdy"}'::jsonb$r$, $r2$cr=jsonb_build_object('s','rdy','o',lpad((floor(random()*10000))::int::text,4,'0'))$r2$);
    d := replace(d, $c$if op='cr_rdy' then$c$, $o$if op='cr_pk' then
      update booth_orders set cr=cr||'{"s":"pick"}'::jsonb where id=(a->>'id')::bigint and booth_id=b.id and status='new' and cr->>'s'='acc' and cr->>'k'=coalesce(a->>'k','');
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_rdy' then$c$);
    d := replace(d, $s$'cr',o.cr)$s$, $t$'cr',(o.cr-'k'))$t$);
    execute d;
  elsif position('cr_pk' in d)=0 then
    raise exception 'C5b: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.375] (تأییدنشده) C5c: هزینه‌ی ارسال پیک ؛ opهای yapp: yfee_get (عمومی ، فقط می‌خواند) و yadm_fee (ادمین ؛ جدول ≤۵ منطقه در bcfg با کلید cr_fee) + yjobs حالا شناسه‌ی غرفه b را هم می‌دهد (برای مسیر). بعد از [1.9.374] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position('yfee_get' in d)=0 and position($a$if op='yreg' then$a$ in d)>0 and position($b$if op='yadm_set' then$b$ in d)>0 and position($c$'bp',b.phone,'name'$c$ in d)>0 then
    d := replace(d, $a$if op='yreg' then$a$, $o$if op='yfee_get' then
      return jsonb_build_object('ok',1,'l',coalesce((select nullif(v,'')::jsonb from bcfg where k='cr_fee'),'[]'::jsonb));
    end if;
    $o$ || $a$if op='yreg' then$a$);
    d := replace(d, $b$if op='yadm_set' then$b$, $p$if op='yadm_fee' then
      if jsonb_typeof(a->'l')<>'array' or jsonb_array_length(a->'l') not between 1 and 5 then return jsonb_build_object('err','bad'); end if;
      insert into bcfg(k,v) values('cr_fee',(select jsonb_agg(jsonb_build_object('n',left(coalesce(e->>'n',''),20),'f',least(greatest(coalesce((e->>'f')::numeric,0),0),1000000)::bigint,'m',least(greatest(coalesce((e->>'m')::numeric,1),1),600)::int))::text from jsonb_array_elements(a->'l') e))
        on conflict(k) do update set v=excluded.v;
      return jsonb_build_object('ok',1);
    end if;
    $p$ || $b$if op='yadm_set' then$b$);
    d := replace(d, $c$'bp',b.phone,'name'$c$, $q$'bp',b.phone,'b',x.booth_id,'name'$q$);
    execute d;
  elsif position('yfee_get' in d)=0 then
    raise exception 'C5c: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.376] (تأییدنشده) C5d: ستون‌های couriers.act (آنلاین) و cap (ظرفیت ۱..۳) + yapp: yme/yset آن‌ها را می‌خوانند/می‌نویسند ، yjobs برای پیک آفلاین سفارشی نشان نمی‌دهد ، yacc سقف cap را اجبار می‌کند ، ydone زمان تحویل dt را ثبت می‌کند ، op تازه‌ی yinc (آمار ارسال). بعد از [1.9.375] اجرا شود.
alter table public.couriers add column if not exists act boolean default true;
alter table public.couriers add column if not exists cap int default 3;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position('yinc' in d)=0 and position($a$('yme','yset','yjobs','yacc','yway','ydone')$a$ in d)>0 and position($b$'area',c.area,'st',c.st)$b$ in d)>0 and position($c$area=left(coalesce(a->>'area',''),80) where id=c.id;$c$ in d)>0 and position($e$from (select * from booth_orders where status='new' and cr->>'s'='rdy'$e$ in d)>0 and position($f$if n>=3 then$f$ in d)>0 and position($g$cr=cr||'{"s":"done"}'::jsonb, status='done'$g$ in d)>0 and position($h$if op='yacc' then$h$ in d)>0 then
    d := replace(d, $a$('yme','yset','yjobs','yacc','yway','ydone')$a$, $a$('yme','yset','yjobs','yacc','yway','ydone','yinc')$a$);
    d := replace(d, $b$'area',c.area,'st',c.st)$b$, $b2$'area',c.area,'st',c.st,'act',coalesce(c.act,true),'cap',coalesce(c.cap,3))$b2$);
    d := replace(d, $c$area=left(coalesce(a->>'area',''),80) where id=c.id;$c$, $c2$area=left(coalesce(a->>'area',''),80), act=case when a->>'act' in ('0','1') then (a->>'act')='1' else act end, cap=case when a->>'cap' in ('1','2','3') then (a->>'cap')::int else cap end where id=c.id;$c2$);
    d := replace(d, $e$from (select * from booth_orders where status='new' and cr->>'s'='rdy'$e$, $e2$from (select * from booth_orders where coalesce(c.act,true) and status='new' and cr->>'s'='rdy'$e2$);
    d := replace(d, $f$if n>=3 then$f$, $f2$if not coalesce(c.act,true) then return jsonb_build_object('err','off'); end if;
      if n>=coalesce(c.cap,3) then$f2$);
    d := replace(d, $g$cr=cr||'{"s":"done"}'::jsonb, status='done'$g$, $g2$cr=cr||jsonb_build_object('s','done','dt',now()), status='done'$g2$);
    d := replace(d, $h$if op='yacc' then$h$, $i$if op='yinc' then
      return jsonb_build_object('ok',1,
        'd',(select count(*) from booth_orders where cr->>'c'=c.id::text and cr->>'s'='done' and (cr->>'dt')::timestamptz>=current_date),
        'w',(select count(*) from booth_orders where cr->>'c'=c.id::text and cr->>'s'='done' and (cr->>'dt')::timestamptz>now()-interval '7 days'),
        'm',(select count(*) from booth_orders where cr->>'c'=c.id::text and cr->>'s'='done' and (cr->>'dt')::timestamptz>now()-interval '30 days'),
        'l',coalesce((select jsonb_agg(jsonb_build_object('bn',b.name,'t',x.cr->>'dt','tot',x.total) order by (x.cr->>'dt') desc) from (select * from booth_orders where cr->>'c'=c.id::text and cr->>'s'='done' and cr->>'dt' is not null order by (cr->>'dt') desc limit 15) x join booths b on b.id=x.booth_id),'[]'::jsonb));
    end if;
    $i$ || $h$if op='yacc' then$h$);
    execute d;
  elsif position('yinc' in d)=0 then
    raise exception 'C5d: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.377] (تأییدنشده) کرایه‌ی پیک در مبلغ سفارش: ردیف lines با ship=1 ؛ yjobs حالا کرایه‌ی f را در فهرست آماده و سفارش‌های من می‌دهد (پیک از غرفه‌دار می‌گیرد). بعد از [1.9.376] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position('''f'',(select coalesce(sum' in d)=0 and position($a$'t',x.total)$a$ in d)>0 and position($b$'k',case when x.cr->>'s'='acc'$b$ in d)>0 then
    d := replace(d, $a$'t',x.total)$a$, $a2$'t',x.total,'f',(select coalesce(sum((l->>'t')::bigint),0) from jsonb_array_elements(x.lines) l where l->>'ship'='1'))$a2$);
    d := replace(d, $b$'k',case when x.cr->>'s'='acc'$b$, $b2$'f',(select coalesce(sum((l->>'t')::bigint),0) from jsonb_array_elements(x.lines) l where l->>'ship'='1'),'k',case when x.cr->>'s'='acc'$b2$);
    execute d;
  elsif position('''f'',(select coalesce(sum' in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.378] (تأییدنشده) C5e: امتیاز و پیک مورد علاقه ؛ opهای bapp: cr_rate (غرفه‌دار ، ۱..۵ ، یک‌بار برای سفارش تحویل‌شده) و cr_fav (افزودن پیک به فهرست مورد علاقه در bcfg با کلید cfav_<غرفه>) + bords حالا نام پیک cn و نشان fv را هم می‌دهد ؛ yapp: yme میانگین rt و تعداد rn ، yjobs نشان fv. بعد از [1.9.377] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cr_rate' in d)=0 and position($a$'cr_pk') then$a$ in d)>0 and position($c$if op='cr_pk' then$c$ in d)>0 and position($s$'cr',(o.cr-'k'))$s$ in d)>0 then
    d := replace(d, $a$'cr_pk') then$a$, $a2$'cr_pk','cr_rate','cr_fav') then$a2$);
    d := replace(d, $c$if op='cr_pk' then$c$, $o$if op='cr_rate' then
      update booth_orders set cr=cr||jsonb_build_object('rt',(a->>'n')::int) where id=(a->>'id')::bigint and booth_id=b.id and cr->>'s'='done' and cr->>'rt' is null and coalesce(a->>'n','') in ('1','2','3','4','5');
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='cr_fav' then
      if not exists(select 1 from couriers where id::text=coalesce(a->>'c','')) then return jsonb_build_object('err','bad'); end if;
      insert into bcfg(k,v) values('cfav_'||b.id, jsonb_build_array(a->>'c')::text)
        on conflict(k) do update set v=(select jsonb_agg(distinct e)::text from (select jsonb_array_elements_text(nullif(bcfg.v,'')::jsonb) e union select (a->>'c')) q);
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_pk' then$c$);
    d := replace(d, $s$'cr',(o.cr-'k'))$s$, $t$'cr',((o.cr-'k')||jsonb_build_object('cn',(select name from couriers where id::text=o.cr->>'c'),'fv',coalesce((select (nullif(bcfg.v,'')::jsonb) ? (o.cr->>'c') from bcfg where k='cfav_'||b.id),false))))$t$);
    execute d;
  elsif position('cr_rate' in d)=0 then
    raise exception 'C5e: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position('''rn''' in d)=0 and position($a$'act',coalesce(c.act,true),'cap',coalesce(c.cap,3))$a$ in d)>0 and position($b$'city',b.city,'n',jsonb_array_length(x.lines)$b$ in d)>0 then
    d := replace(d, $a$'act',coalesce(c.act,true),'cap',coalesce(c.cap,3))$a$, $a2$'act',coalesce(c.act,true),'cap',coalesce(c.cap,3),'rt',(select round(avg((cr->>'rt')::numeric),1) from booth_orders where cr->>'c'=c.id::text and cr->>'rt' is not null),'rn',(select count(*) from booth_orders where cr->>'c'=c.id::text and cr->>'rt' is not null))$a2$);
    d := replace(d, $b$'city',b.city,'n',jsonb_array_length(x.lines)$b$, $b2$'city',b.city,'fv',coalesce((select (nullif(bcfg.v,'')::jsonb) ? c.id::text from bcfg where k='cfav_'||x.booth_id),false),'n',jsonb_array_length(x.lines)$b2$);
    execute d;
  elsif position('''rn''' in d)=0 then
    raise exception 'C5e: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.379] (تأییدنشده) C5f: مهلت انحصاری ۱۰ دقیقه‌ای برای پیک‌های مورد علاقه ؛ bapp: cr_rdy با a.x=1 ستون cr.xu (زمان پایان مهلت) را می‌گذارد (فقط اگر غرفه پیک مورد علاقه دارد) ؛ yapp: yjobs آن سفارش را تا پایان مهلت فقط به پیک‌های مورد علاقه‌ی همان غرفه نشان می‌دهد و yacc هم برای بقیه نمی‌پذیرد. + اصلاح nullif(v,'') ← nullif(bcfg.v,'') در [1.9.378] (متغیر v در تابع با ستون تداخل داشت). بعد از [1.9.378] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position($q$nullif(v,'')$q$ in d)>0 then
    d := replace(d, $q$nullif(v,'')$q$, $r$nullif(bcfg.v,'')$r$);
    execute d;
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position($q$nullif(v,'')$q$ in d)>0 then
    d := replace(d, $q$nullif(v,'')$q$, $r$nullif(bcfg.v,'')$r$);
    execute d;
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'xu'$x$ in d)=0 and position($a$cr=jsonb_build_object('s','rdy','o',lpad((floor(random()*10000))::int::text,4,'0'))$a$ in d)>0 then
    d := replace(d, $a$cr=jsonb_build_object('s','rdy','o',lpad((floor(random()*10000))::int::text,4,'0'))$a$, $a2$cr=jsonb_build_object('s','rdy','o',lpad((floor(random()*10000))::int::text,4,'0'),'xu',case when a->>'x'='1' and exists(select 1 from bcfg where bcfg.k='cfav_'||b.id and coalesce(bcfg.v,'') not in ('','[]')) then to_jsonb(now()+interval '10 minutes') else null end)$a2$);
    execute d;
  elsif position($x$'xu'$x$ in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'xu'$x$ in d)=0 and position($a$coalesce(c.act,true) and status='new' and cr->>'s'='rdy' order by id limit 20$a$ in d)>0 and position($b$where id=(a->>'id')::bigint and status='new' and cr->>'s'='rdy';$b$ in d)>0 then
    d := replace(d, $a$coalesce(c.act,true) and status='new' and cr->>'s'='rdy' order by id limit 20$a$, $a2$coalesce(c.act,true) and status='new' and cr->>'s'='rdy' and (cr->>'xu' is null or (cr->>'xu')::timestamptz<=now() or coalesce((select (nullif(bcfg.v,'')::jsonb) ? c.id::text from bcfg where bcfg.k='cfav_'||booth_orders.booth_id),false)) order by id limit 20$a2$);
    d := replace(d, $b$where id=(a->>'id')::bigint and status='new' and cr->>'s'='rdy';$b$, $b2$where id=(a->>'id')::bigint and status='new' and cr->>'s'='rdy' and (cr->>'xu' is null or (cr->>'xu')::timestamptz<=now() or coalesce((select (nullif(bcfg.v,'')::jsonb) ? c.id::text from bcfg where bcfg.k='cfav_'||booth_orders.booth_id),false));$b2$);
    execute d;
  elsif position($x$'xu'$x$ in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.380] (تأییدنشده) C5f/67: yapp: yjobs در فهرست «آماده‌ی ارسال» شناسه‌ی غرفه b را هم می‌دهد (برای مرتب‌سازی هم‌مسیر در برنامه ؛ بدون داده‌ی تازه). بعد از [1.9.379] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'city',b.city,'b',x.booth_id$x$ in d)=0 and position($a$'city',b.city,'fv'$a$ in d)>0 then
    d := replace(d, $a$'city',b.city,'fv'$a$, $a2$'city',b.city,'b',x.booth_id,'fv'$a2$);
    execute d;
  elsif position($x$'city',b.city,'b',x.booth_id$x$ in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در yapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.381] (تأییدنشده) C5f/78: کلید تازه‌ی cx (ارسال بیرونی ، پیش‌فرض خاموش) در لیست کلیدهای مجاز sapp ؛ bapp: op تازه‌ی cr_ext (غرفه‌دار تأییدشده ؛ cr={s:'ext',ec:کد رهگیری ≤۴۰ نویسه} روی سفارش جدید بدون پیک). بعد از [1.9.380] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cx'$x$ in d)=0 and position($a$'cp','cr')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr')$a$, $a2$'cp','cr','cx')$a2$);
    execute d;
  elsif position($x$'cx'$x$ in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cr_ext' in d)=0 and position($a$'cr_pk','cr_rate','cr_fav') then$a$ in d)>0 and position($c$if op='cr_rate' then$c$ in d)>0 then
    d := replace(d, $a$'cr_pk','cr_rate','cr_fav') then$a$, $a2$'cr_pk','cr_rate','cr_fav','cr_ext') then$a2$);
    d := replace(d, $c$if op='cr_rate' then$c$, $o$if op='cr_ext' then
      if coalesce(b.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
      update booth_orders set cr=jsonb_build_object('s','ext','ec',left(coalesce(a->>'ec',''),40)) where id=(a->>'id')::bigint and booth_id=b.id and status='new' and pk is null and cr is null;
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_rate' then$c$);
    execute d;
  elsif position('cr_ext' in d)=0 then
    raise exception 'C5f: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.382] (تأییدنشده) C5f/79: کلید تازه‌ی cy (کد رهگیری پست ، پیش‌فرض خاموش ؛ نیاز به cx) در لیست کلیدهای مجاز sapp ؛ bapp: op تازه‌ی cr_trk (غرفه‌دار تأییدشده ؛ فقط سفارش جدید با cr.s=ext ؛ ec ≤۴۰ نویسه). بعد از [1.9.381] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cy'$x$ in d)=0 and position($a$'cp','cr','cx')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx')$a$, $a2$'cp','cr','cx','cy')$a2$);
    execute d;
  elsif position($x$'cy'$x$ in d)=0 then
    raise exception 'C5f/79: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cr_trk' in d)=0 and position($a$'cr_pk','cr_rate','cr_fav','cr_ext') then$a$ in d)>0 and position($c$if op='cr_ext' then$c$ in d)>0 then
    d := replace(d, $a$'cr_pk','cr_rate','cr_fav','cr_ext') then$a$, $a2$'cr_pk','cr_rate','cr_fav','cr_ext','cr_trk') then$a2$);
    d := replace(d, $c$if op='cr_ext' then$c$, $o$if op='cr_trk' then
      if coalesce(b.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
      update booth_orders set cr=cr||jsonb_build_object('ec',left(coalesce(a->>'ec',''),40)) where id=(a->>'id')::bigint and booth_id=b.id and status='new' and pk is null and cr->>'s'='ext';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_ext' then$c$);
    execute d;
  elsif position('cr_trk' in d)=0 then
    raise exception 'C5f/79: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.383] (تأییدنشده) D1/134: کلید تازه‌ی cw (نوار جمع کل سبد ، پیش‌فرض خاموش ؛ فقط ظاهری) در لیست کلیدهای مجاز sapp. بعد از [1.9.382] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cw'$x$ in d)=0 and position($a$'cp','cr','cx','cy')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy')$a$, $a2$'cp','cr','cx','cy','cw')$a2$);
    execute d;
  elsif position($x$'cw'$x$ in d)=0 then
    raise exception 'D1/134: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.384] (تأییدنشده) D1/138: کلید تازه‌ی cv (یادداشت روی کالای سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.383] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cv'$x$ in d)=0 and position($a$'cp','cr','cx','cy','cw')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy','cw')$a$, $a2$'cp','cr','cx','cy','cw','cv')$a2$);
    execute d;
  elsif position($x$'cv'$x$ in d)=0 then
    raise exception 'D1/138: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.385] (تأییدنشده) D1/147: کلید تازه‌ی cj (انقضای سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.384] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cj'$x$ in d)=0 and position($a$'cp','cr','cx','cy','cw','cv')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy','cw','cv')$a$, $a2$'cp','cr','cx','cy','cw','cv','cj')$a2$);
    execute d;
  elsif position($x$'cj'$x$ in d)=0 then
    raise exception 'D1/147: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.386] (تأییدنشده) D1/140+141: کلید تازه‌ی ci (قالب و کد سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.385] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'ci'$x$ in d)=0 and position($a$'cp','cr','cx','cy','cw','cv','cj')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy','cw','cv','cj')$a$, $a2$'cp','cr','cx','cy','cw','cv','cj','ci')$a2$);
    execute d;
  elsif position($x$'ci'$x$ in d)=0 then
    raise exception 'D1/140: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.387] (تأییدنشده) D1/136: کلید تازه‌ی cl (بعداً می‌خرم ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.386] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cl'$x$ in d)=0 and position($a$'cp','cr','cx','cy','cw','cv','cj','ci')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy','cw','cv','cj','ci')$a$, $a2$'cp','cr','cx','cy','cw','cv','cj','ci','cl')$a2$);
    execute d;
  elsif position($x$'cl'$x$ in d)=0 then
    raise exception 'D1/136: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.388] (تأییدنشده) D1/146+135+133: کلیدهای تازه‌ی cb cq cu (پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.387] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cb'$x$ in d)=0 and position($a$'cp','cr','cx','cy','cw','cv','cj','ci','cl')$a$ in d)>0 then
    d := replace(d, $a$'cp','cr','cx','cy','cw','cv','cj','ci','cl')$a$, $a2$'cp','cr','cx','cy','cw','cv','cj','ci','cl','cb','cq','cu')$a2$);
    execute d;
  elsif position($x$'cb'$x$ in d)=0 then
    raise exception 'D1/146: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.389] (تأییدنشده) D1/142: کلید تازه‌ی cn (هشدار تغییر قیمت و موجودی سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.388] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cn'$x$ in d)=0 and position($a$'cl','cb','cq','cu')$a$ in d)>0 then
    d := replace(d, $a$'cl','cb','cq','cu')$a$, $a2$'cl','cb','cq','cu','cn')$a2$);
    execute d;
  elsif position($x$'cn'$x$ in d)=0 then
    raise exception 'D1/142: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.390] (تأییدنشده) D1/145: کلید تازه‌ی ce (وزن تقریبی سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.389] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'ce'$x$ in d)=0 and position($a$'cu','cn')$a$ in d)>0 then
    d := replace(d, $a$'cu','cn')$a$, $a2$'cu','cn','ce')$a2$);
    execute d;
  elsif position($x$'ce'$x$ in d)=0 then
    raise exception 'D1/145: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.391] (تأییدنشده) D1/137: کلید تازه‌ی cz (کشیدن برای حذف از سبد ، پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.390] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cz'$x$ in d)=0 and position($a$'cn','ce')$a$ in d)>0 then
    d := replace(d, $a$'cn','ce')$a$, $a2$'cn','ce','cz')$a2$);
    execute d;
  elsif position($x$'cz'$x$ in d)=0 then
    raise exception 'D1/137: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.392] (تأییدنشده) D1/139: کلید تازه‌ی ch (اگر نبود ، انتخاب مشتری ؛ پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.391] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'ch'$x$ in d)=0 and position($a$'ce','cz')$a$ in d)>0 then
    d := replace(d, $a$'ce','cz')$a$, $a2$'ce','cz','ch')$a2$);
    execute d;
  elsif position($x$'ch'$x$ in d)=0 then
    raise exception 'D1/139: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.393] (تأییدنشده) G0: کد ۴ رقمی بین غرفه‌دار و پیک برداشته شد (yacc دیگر k نمی‌سازد ؛ cr_pk شرط k ندارد). کد مشتری↔پیک (o) سر جایش. بعد از [1.9.392] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.yapp(text,text,text,jsonb)'::regprocedure);
  if position($k$,'k',lpad((floor(random()*10000))::int::text,4,'0'))$k$ in d)>0 then
    d := replace(d, $k$,'k',lpad((floor(random()*10000))::int::text,4,'0'))$k$, $k2$)$k2$);
    execute d;
  end if;
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position($p$ and cr->>'k'=coalesce(a->>'k','');$p$ in d)>0 then
    d := replace(d, $p$ and cr->>'k'=coalesce(a->>'k','');$p$, $p2$;$p2$);
    execute d;
  end if;
end $do$;

-- [1.9.394] (تأییدنشده) G1: کلید تازه‌ی pn (پنل جدید ، کیت ساده ؛ پیش‌فرض خاموش ؛ فقط کلاینت) در لیست کلیدهای مجاز sapp. بعد از [1.9.393] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'pn'$x$ in d)=0 and position($a$'ce','cz','ch')$a$ in d)>0 then
    d := replace(d, $a$'ce','cz','ch')$a$, $a2$'ce','cz','ch','pn')$a2$);
    execute d;
  elsif position($x$'pn'$x$ in d)=0 then
    raise exception 'G1: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.396] (تأییدنشده) G3: حالت تماس غرفه‌دار (کلید cc). bapp: op تازه‌ی cm_set (غرفه‌دار ، a/b/c ، ذخیره در bcfg با کلید cmode_<غرفه>) ؛ fapp: op عمومی تازه‌ی bcm (فقط حالت را برمی‌گرداند ؛ پیش‌فرض a) ؛ کلید cc در لیست مجاز sapp. بعد از [1.9.395] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cm_set' in d)=0 and position($c$if op='cr_pk' then$c$ in d)>0 then
    d := replace(d, $c$if op='cr_pk' then$c$, $o$if op='cm_set' then
      if coalesce(a->>'m','') not in ('a','b','c') then return jsonb_build_object('err','bad'); end if;
      insert into bcfg(k,v) values('cmode_'||b.id, a->>'m') on conflict(k) do update set v=excluded.v;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_pk' then$c$);
    execute d;
  elsif position('cm_set' in d)=0 then
    raise exception 'G3: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'bcm'$x$ in d)=0 and position($a$if op='public2' then$a$ in d)>0 then
    d := replace(d, $a$if op='public2' then$a$, $o$if op='bcm' then return jsonb_build_object('ok',1,'m',coalesce((select nullif(v,'') from bcfg where k='cmode_'||coalesce(a->>'b','')),'a')); end if;
  if op='public2' then$o$);
    execute d;
  elsif position($x$'bcm'$x$ in d)=0 then
    raise exception 'G3: نقطه‌ی اتصال در fapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cc'$x$ in d)=0 and position($a$'ce','cz','ch','pn')$a$ in d)>0 then
    d := replace(d, $a$'ce','cz','ch','pn')$a$, $a2$'ce','cz','ch','pn','cc')$a2$);
    execute d;
  elsif position($x$'cc'$x$ in d)=0 then
    raise exception 'G3: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.397] (تأییدنشده) G2b: ثبت‌نام دو مرحله‌ای با شماره (کلید ph ، پیش‌فرض خاموش). فقط کلید ph به لیست مجاز sapp اضافه می‌شود ؛ opی تازه ندارد. بعد از [1.9.396] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'ph'$x$ in d)=0 and position($a$'ch','pn','cc')$a$ in d)>0 then
    d := replace(d, $a$'ch','pn','cc')$a$, $a2$'ch','pn','cc','ph')$a2$);
    execute d;
  elsif position($x$'ph'$x$ in d)=0 then
    raise exception 'G2b: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.406] (تأییدنشده) G4-a: کارت غرفه برای خرید غیرحضوری (کلید cd ، پیش‌فرض خاموش). ستون booths.card ؛ opهای bapp: cd_get / cd_set (فقط خود غرفه‌دار ؛ cd_set فقط وقتی غرفه تأییدشده است lvl>0 ؛ شماره‌ی ۱۶ رقمی). خریدار هنوز چیزی نمی‌بیند ؛ نمایش به خریدار در G4-b همراه سفارش. کلید cd به لیست مجاز sapp. بعد از [1.9.397] و [1.9.395] اجرا شود.
alter table public.booths add column if not exists card jsonb not null default '{}'::jsonb;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('cd_set' in d)=0 and position($c$if op='cr_pk' then$c$ in d)>0 then
    d := replace(d, $c$if op='cr_pk' then$c$, $o$if op='cd_get' then
      return jsonb_build_object('ok',1,'lvl',b.lvl,'n',coalesce(b.card->>'n',''),'h',coalesce(b.card->>'h',''));
    end if;
    if op='cd_set' then
      if coalesce(b.lvl,0)<=0 then return jsonb_build_object('err','nv'); end if;
      if coalesce(a->>'n','') !~ '^[0-9]{16}$' or char_length(btrim(coalesce(a->>'h','')))<3 or char_length(coalesce(a->>'h',''))>40 then return jsonb_build_object('err','bad'); end if;
      update booths set card=jsonb_build_object('n',a->>'n','h',btrim(a->>'h')) where id=b.id;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_pk' then$c$);
    execute d;
  elsif position('cd_set' in d)=0 then
    raise exception 'G4-a: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'cd'$x$ in d)=0 and position($a$'ch','pn','cc','ph')$a$ in d)>0 then
    d := replace(d, $a$'ch','pn','cc','ph')$a$, $a2$'ch','pn','cc','ph','cd')$a2$);
    execute d;
  elsif position($x$'cd'$x$ in d)=0 then
    raise exception 'G4-a: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.407] (تأییدنشده) G4-b: پرداخت کارت‌به‌کارت سفارش غیرحضوری (کلید pq ، پیش‌فرض خاموش). ستون booth_orders.pay (s: wait/sent/ok/rej ، rc رسید متنی ، rj دلیل رد ، t ساعت هر مرحله) ؛ opهای bapp: pay_get pay_sent (خریدار با شماره‌ی تلفن ؛ فقط سفارش غیرحضوری ۲۴ ساعت اخیر ؛ فقط غرفه‌ی تأییدشده که کارت دارد) ، pay_ok pay_rj (غرفه‌دار) ؛ bords حالا pay هم برمی‌گرداند ؛ کلید pq به لیست مجاز sapp. بعد از [1.9.406] اجرا شود.
alter table public.booth_orders add column if not exists pay jsonb;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('pay_sent' in d)=0 and position($c$if op='cr_pk' then$c$ in d)>0 and position($h$if op='pk_cx' then$h$ in d)>0 and position($i$'pk',(o.pk-'c')$i$ in d)>0 then
    d := replace(d, $h$if op='pk_cx' then$h$, $p$if op='pay_get' then
      declare o public.booth_orders; bb public.booths;
      begin
        select * into o from booth_orders where booth_id=coalesce((a->>'b')::bigint,0) and phone=left(coalesce(a->>'phone',''),30) and pk is null and status='new' and created>now()-interval '24 hours' order by id desc limit 1;
        if not found then return jsonb_build_object('err','none'); end if;
        select * into bb from booths where id=o.booth_id;
        if coalesce(bb.lvl,0)<=0 or coalesce(bb.card->>'n','')='' then return jsonb_build_object('err','none'); end if;
        return jsonb_build_object('ok',1,'id',o.id,'total',o.total,'card',jsonb_build_object('n',bb.card->>'n','h',bb.card->>'h'),'pay',o.pay);
      end;
    end if;
    if op='pay_sent' then
      declare o public.booth_orders; bb public.booths;
      begin
        if char_length(btrim(coalesce(a->>'rc','')))<3 then return jsonb_build_object('err','bad'); end if;
        select * into o from booth_orders where booth_id=coalesce((a->>'b')::bigint,0) and phone=left(coalesce(a->>'phone',''),30) and pk is null and status='new' and created>now()-interval '24 hours' order by id desc limit 1;
        if not found then return jsonb_build_object('err','none'); end if;
        select * into bb from booths where id=o.booth_id;
        if coalesce(bb.lvl,0)<=0 or coalesce(bb.card->>'n','')='' then return jsonb_build_object('err','none'); end if;
        if coalesce(o.pay->>'s','wait') not in ('wait','rej') then return jsonb_build_object('err','bad'); end if;
        update booth_orders set pay=jsonb_build_object('s','sent','rc',left(btrim(a->>'rc'),300),'t',coalesce(pay->'t','{}'::jsonb)||jsonb_build_object('sent',now())) where id=o.id;
        return jsonb_build_object('ok',1);
      end;
    end if;
    $p$ || $h$if op='pk_cx' then$h$);
    d := replace(d, $c$if op='cr_pk' then$c$, $o$if op='pay_ok' then
      update booth_orders set pay=pay||jsonb_build_object('s','ok','t',coalesce(pay->'t','{}'::jsonb)||jsonb_build_object('ok',now())) where id=(a->>'id')::bigint and booth_id=b.id and pay->>'s'='sent';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    if op='pay_rj' then
      if char_length(btrim(coalesce(a->>'why','')))<2 then return jsonb_build_object('err','bad'); end if;
      update booth_orders set pay=pay||jsonb_build_object('s','rej','rj',left(btrim(a->>'why'),200),'t',coalesce(pay->'t','{}'::jsonb)||jsonb_build_object('rj',now())) where id=(a->>'id')::bigint and booth_id=b.id and pay->>'s'='sent';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $c$if op='cr_pk' then$c$);
    d := replace(d, $i$'pk',(o.pk-'c')$i$, $j$'pk',(o.pk-'c'),'pay',o.pay$j$);
    execute d;
  elsif position('pay_sent' in d)=0 then
    raise exception 'G4-b: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'pq'$x$ in d)=0 and position($a$'ph','cd')$a$ in d)>0 then
    d := replace(d, $a$'ph','cd')$a$, $a2$'ph','cd','pq')$a2$);
    execute d;
  elsif position($x$'pq'$x$ in d)=0 then
    raise exception 'G4-b: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.408] (تأییدنشده) G4-c1: مرحله‌ی «آماده‌سازی» بعد از تأیید پرداخت (کلید pq). op تازه‌ی bapp: pay_prep (غرفه‌دار ؛ فقط وقتی pay.s=ok و هنوز مرحله‌ای ثبت نشده) ← pay.f='prep' و ساعت t.prep. بعد از [1.9.407] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('pay_prep' in d)=0 and position($a$if op='pay_ok' then$a$ in d)>0 then
    d := replace(d, $a$if op='pay_ok' then$a$, $o$if op='pay_prep' then
      update booth_orders set pay=pay||jsonb_build_object('f','prep','t',coalesce(pay->'t','{}'::jsonb)||jsonb_build_object('prep',now())) where id=(a->>'id')::bigint and booth_id=b.id and pay->>'s'='ok' and coalesce(pay->>'f','')='';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $a$if op='pay_ok' then$a$);
    execute d;
  elsif position('pay_prep' in d)=0 then
    raise exception 'G4-c1: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.409] (تأییدنشده) G4-c2: وصل‌کردن پرداخت به پیک (کلید pq). ۱) cr_rdy: اگر سفارش pay دارد و هنوز تأیید نشده ، خطای pay ۲) pay_get حالا cr (بدون کد k) هم می‌دهد تا خریدار مرحله‌ی پیک و کد تحویل خودش را ببیند ۳) op تازه‌ی bapp: pay_cx (غرفه‌دار ؛ لغو سفارش بدون پرداخت‌تأییدشده بعد از ۲۴ ساعت). بعد از [1.9.408] اجرا شود.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.bapp(text,text,text,jsonb)'::regprocedure);
  if position('pay_cx' in d)=0 and position($a$if op='pay_prep' then$a$ in d)>0 and position($c$if op='cr_rdy' then$c$ in d)>0 and position($g$'h',bb.card->>'h'),'pay',o.pay)$g$ in d)>0 then
    d := replace(d, $a$if op='pay_prep' then$a$, $o$if op='pay_cx' then
      update booth_orders set status='cancel' where id=(a->>'id')::bigint and booth_id=b.id and pk is null and status='new' and cr is null and coalesce(pay->>'s','wait') in ('wait','rej') and created<now()-interval '24 hours';
      if not found then return jsonb_build_object('err','bad'); end if;
      return jsonb_build_object('ok',1);
    end if;
    $o$ || $a$if op='pay_prep' then$a$);
    d := replace(d, $c$if op='cr_rdy' then$c$, $r$if op='cr_rdy' then
      if exists(select 1 from booth_orders where id=(a->>'id')::bigint and booth_id=b.id and pay is not null and coalesce(pay->>'s','')<>'ok') then return jsonb_build_object('err','pay'); end if;
    $r$);
    d := replace(d, $g$'h',bb.card->>'h'),'pay',o.pay)$g$, $h$'h',bb.card->>'h'),'pay',o.pay,'cr',(o.cr-'k'))$h$);
    execute d;
  elsif position('pay_cx' in d)=0 then
    raise exception 'G4-c2: نقطه‌ی اتصال در bapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.423] (تأییدنشده) G8-a: «بررسی سفارش‌ها» برای مدیر (کلید og ؛ پیش‌فرض خاموش). ۱) تابع تازه‌ی gapp با دو op: ostk (سفارش‌های باز ۱۴ روز اخیر + آمار امروز ؛ حداکثر ۸۰) و ost (تغییر وضعیت به done یا cancel) ؛ فقط مدیر اصلی (pm all یا a) و فقط وقتی کلید og روشن است ۲) اضافه‌شدن og به فهرست کلیدهای مجاز xset در sapp. به توابع قبلی دست نمی‌زند جز همین یک فهرست.
create or replace function public.gapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; pm jsonb; d0 timestamptz := date_trunc('day', now());
begin
  a := coalesce(a,'{}'::jsonb);
  if op not in ('ostk','ost') then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  pm := coalesce(me->'pm','[]'::jsonb);
  if not ((me->>'role')='admin' and (pm ? 'all' or pm ? 'a')) then return jsonb_build_object('err','perm'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'og' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;

  if op='ostk' then
    return jsonb_build_object('ok',1,
      'l', coalesce((select jsonb_agg(to_jsonb(z) order by z.t desc) from (
            select o.id, o.booth_id as bid, b.name as bn, b.phone as bp, o.name as cn, o.phone as cp, o.total as tt,
                   (extract(epoch from o.created)*1000)::bigint as t,
                   (o.pk is not null and o.pk::text not in ('null','0','false')) as pk,
                   o.pay->>'s' as ps, o.cr->>'s' as cs
            from public.booth_orders o join public.booths b on b.id=o.booth_id
            where o.status='new' and o.created>now()-interval '14 days'
            order by o.created desc limit 80) z),'[]'::jsonb),
      'd', jsonb_build_object(
            'n',(select count(*) from public.booth_orders where created>=d0),
            'ok',(select count(*) from public.booth_orders where created>=d0 and status='done'),
            'x',(select count(*) from public.booth_orders where created>=d0 and status='cancel')));
  end if;

  if op='ost' then
    if coalesce(a->>'s','') not in ('done','cancel') then return jsonb_build_object('err','bad'); end if;
    update public.booth_orders set status=a->>'s' where id=(a->>'id')::bigint and status='new';
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
revoke all on function public.gapp(text,text,text,jsonb) from public;
grant execute on function public.gapp(text,text,text,jsonb) to anon, authenticated;

do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'pq','og'$x$ in d)>0 then null;
  elsif position($a$'ph','cd','pq')$a$ in d)>0 then
    d := replace(d, $a$'ph','cd','pq')$a$, $a2$'ph','cd','pq','og')$a2$);
    execute d;
  else
    raise exception 'G8-a: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

select 'ALL_SQL_DONE' as result;

-- [1.9.424] (تأییدنشده) G8-b: به gapp دو op تازه اضافه شد: oxl (لغوشده‌های ۳ روز اخیر ؛ حداکثر ۳۰) و orp (بازگشایی سفارش لغوشده ؛ فقط تا ۳ روز). تابع gapp دوباره ساخته می‌شود (همان G8-a + دو op) ؛ به توابع دیگر دست نمی‌زند. اگر [1.9.423] را اجرا کرده‌ای باز هم این بخش را اجرا کن.
create or replace function public.gapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; pm jsonb; d0 timestamptz := date_trunc('day', now());
begin
  a := coalesce(a,'{}'::jsonb);
  if op not in ('ostk','ost','oxl','orp') then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  pm := coalesce(me->'pm','[]'::jsonb);
  if not ((me->>'role')='admin' and (pm ? 'all' or pm ? 'a')) then return jsonb_build_object('err','perm'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'og' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;

  if op='ostk' then
    return jsonb_build_object('ok',1,
      'l', coalesce((select jsonb_agg(to_jsonb(z) order by z.t desc) from (
            select o.id, o.booth_id as bid, b.name as bn, b.phone as bp, o.name as cn, o.phone as cp, o.total as tt,
                   (extract(epoch from o.created)*1000)::bigint as t,
                   (o.pk is not null and o.pk::text not in ('null','0','false')) as pk,
                   o.pay->>'s' as ps, o.cr->>'s' as cs
            from public.booth_orders o join public.booths b on b.id=o.booth_id
            where o.status='new' and o.created>now()-interval '14 days'
            order by o.created desc limit 80) z),'[]'::jsonb),
      'd', jsonb_build_object(
            'n',(select count(*) from public.booth_orders where created>=d0),
            'ok',(select count(*) from public.booth_orders where created>=d0 and status='done'),
            'x',(select count(*) from public.booth_orders where created>=d0 and status='cancel')));
  end if;

  if op='ost' then
    if coalesce(a->>'s','') not in ('done','cancel') then return jsonb_build_object('err','bad'); end if;
    update public.booth_orders set status=a->>'s' where id=(a->>'id')::bigint and status='new';
    return jsonb_build_object('ok',1);
  end if;
  if op='oxl' then
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(to_jsonb(z) order by z.t desc) from (
            select o.id, b.name as bn, o.name as cn, o.phone as cp, o.total as tt, (extract(epoch from o.created)*1000)::bigint as t
            from public.booth_orders o join public.booths b on b.id=o.booth_id
            where o.status='cancel' and o.created>now()-interval '3 days'
            order by o.created desc limit 30) z),'[]'::jsonb));
  end if;

  if op='orp' then
    update public.booth_orders set status='new' where id=(a->>'id')::bigint and status='cancel' and created>now()-interval '3 days';
    if not found then return jsonb_build_object('err','none'); end if;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
revoke all on function public.gapp(text,text,text,jsonb) from public;
grant execute on function public.gapp(text,text,text,jsonb) to anon, authenticated;

select 'ALL_SQL_DONE' as result;

-- [1.9.433] (تأییدنشده) D2-a: فقط ثبت نام کلید dt (انتخاب تحویل) در فهرست کلیدهای مجاز xset در sapp. به توابع دیگر دست نمی‌زند. اگر dt را نخواستی روشن کنی لازم نیست اجرا کنی.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'pq','og','dt'$x$ in d)>0 then null;
  elsif position($a$'ph','cd','pq','og')$a$ in d)>0 then
    d := replace(d, $a$'ph','cd','pq','og')$a$, $a2$'ph','cd','pq','og','dt')$a2$);
    execute d;
  else
    raise exception 'D2-a: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

select 'ALL_SQL_DONE' as result;

-- [1.9.435] (تأییدنشده) D2-c: تابع تازه‌ی dapp با یک op: cv_p (تبدیل رزرو حضوری به سفارش ارسال ؛ با شماره + کد رزرو ؛ فقط غرفه‌ی تأییدشده ؛ فقط وقتی کلید dt روشن است). به توابع دیگر دست نمی‌زند.
create or replace function public.dapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare o public.booth_orders; bb public.booths; ad text;
begin
  a := coalesce(a,'{}'::jsonb);
  if op<>'cv_p' then return jsonb_build_object('err','bad'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'dt' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;
  ad := left(btrim(coalesce(a->>'ad','')),200);
  if length(ad)<5 then return jsonb_build_object('err','addr'); end if;
  select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status='new' and created>now()-interval '3 days' order by id desc limit 1;
  if not found then return jsonb_build_object('err','none'); end if;
  select * into bb from public.booths where id=o.booth_id;
  if not found or coalesce(bb.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
  update public.booth_orders set pk=null, addr=ad where id=o.id;
  return jsonb_build_object('ok',1);
end $$;
revoke all on function public.dapp(text,text,text,jsonb) from public;
grant execute on function public.dapp(text,text,text,jsonb) to anon, authenticated;

select 'ALL_SQL_DONE' as result;

-- [1.9.436] (تأییدنشده) D2-c2: تابع dapp دوباره ساخته می‌شود (همان 1.9.435 + op تازه‌ی cv_h: تبدیل سفارش پیک به رزرو حضوری ؛ فقط اگر پیک قبول نکرده و پرداختی ثبت نشده ؛ کرایه‌ی پیک از مبلغ کم می‌شود). به توابع دیگر دست نمی‌زند. اگر [1.9.435] را اجرا کرده‌ای باز هم این بخش را اجرا کن.
create or replace function public.dapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare o public.booth_orders; bb public.booths; ad text; tt numeric;
begin
  a := coalesce(a,'{}'::jsonb);
  if op not in ('cv_p','cv_h') then return jsonb_build_object('err','bad'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'dt' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;

  if op='cv_p' then
    ad := left(btrim(coalesce(a->>'ad','')),200);
    if length(ad)<5 then return jsonb_build_object('err','addr'); end if;
    select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status='new' and created>now()-interval '3 days' order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    select * into bb from public.booths where id=o.booth_id;
    if not found or coalesce(bb.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
    update public.booth_orders set pk=null, addr=ad where id=o.id;
    return jsonb_build_object('ok',1);
  end if;

  if op='cv_h' then
    if coalesce(a->>'c','') !~ '^[0-9]{4}$' or coalesce(a->>'h','') not in ('2','6','24') or coalesce(a->>'t','') !~ '^[0-9]{10,14}$' or coalesce(a->>'b','') !~ '^[0-9]{1,12}$' then return jsonb_build_object('err','bad'); end if;
    tt := (a->>'t')::numeric;
    select * into o from public.booth_orders where booth_id=(a->>'b')::bigint and phone=left(coalesce(a->>'phone',''),30) and status='new' and pk is null and created>now()-interval '3 days' and abs(extract(epoch from created)*1000-tt)<900000 order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    if o.cr is not null and coalesce(o.cr->>'s','')<>'rdy' then return jsonb_build_object('err','late'); end if;
    if o.pay is not null and coalesce(o.pay->>'s','')<>'wait' then return jsonb_build_object('err','late'); end if;
    update public.booth_orders set
      pk=jsonb_build_object('h',(a->>'h')::int,'c',a->>'c'), cr=null, pay=null,
      addr='🏪 حضوری (تبدیل از ارسال)',
      total=greatest(0,coalesce(o.total,0)-coalesce((select sum(case when coalesce(l->>'t','') ~ '^[0-9]+$' then (l->>'t')::bigint else 0 end) from jsonb_array_elements(o.lines) l where l->>'ship'='1'),0)),
      lines=coalesce((select jsonb_agg(l) from jsonb_array_elements(o.lines) l where coalesce(l->>'ship','')<>'1'),'[]'::jsonb)
    where id=o.id;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
revoke all on function public.dapp(text,text,text,jsonb) from public;
grant execute on function public.dapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.437] (تأییدنشده) D2-c3a: تابع dapp دوباره ساخته می‌شود (همان 1.9.436 + op تازه‌ی cv_d: «دوستم می‌گیرد» ؛ اسم گیرنده ≤۳۰ حرف داخل pk.f رزرو حضوری ؛ فقط رزرو باز و تحویل‌نشده). به توابع دیگر دست نمی‌زند. اگر [1.9.436] را اجرا کرده‌ای باز هم این بخش را اجرا کن.
create or replace function public.dapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare o public.booth_orders; bb public.booths; ad text; tt numeric;
begin
  a := coalesce(a,'{}'::jsonb);
  if op not in ('cv_p','cv_h','cv_d') then return jsonb_build_object('err','bad'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'dt' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;

  if op='cv_p' then
    ad := left(btrim(coalesce(a->>'ad','')),200);
    if length(ad)<5 then return jsonb_build_object('err','addr'); end if;
    select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status='new' and created>now()-interval '3 days' order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    select * into bb from public.booths where id=o.booth_id;
    if not found or coalesce(bb.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
    update public.booth_orders set pk=null, addr=ad where id=o.id;
    return jsonb_build_object('ok',1);
  end if;

  if op='cv_h' then
    if coalesce(a->>'c','') !~ '^[0-9]{4}$' or coalesce(a->>'h','') not in ('2','6','24') or coalesce(a->>'t','') !~ '^[0-9]{10,14}$' or coalesce(a->>'b','') !~ '^[0-9]{1,12}$' then return jsonb_build_object('err','bad'); end if;
    tt := (a->>'t')::numeric;
    select * into o from public.booth_orders where booth_id=(a->>'b')::bigint and phone=left(coalesce(a->>'phone',''),30) and status='new' and pk is null and created>now()-interval '3 days' and abs(extract(epoch from created)*1000-tt)<900000 order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    if o.cr is not null and coalesce(o.cr->>'s','')<>'rdy' then return jsonb_build_object('err','late'); end if;
    if o.pay is not null and coalesce(o.pay->>'s','')<>'wait' then return jsonb_build_object('err','late'); end if;
    update public.booth_orders set
      pk=jsonb_build_object('h',(a->>'h')::int,'c',a->>'c'), cr=null, pay=null,
      addr='🏪 حضوری (تبدیل از ارسال)',
      total=greatest(0,coalesce(o.total,0)-coalesce((select sum(case when coalesce(l->>'t','') ~ '^[0-9]+$' then (l->>'t')::bigint else 0 end) from jsonb_array_elements(o.lines) l where l->>'ship'='1'),0)),
      lines=coalesce((select jsonb_agg(l) from jsonb_array_elements(o.lines) l where coalesce(l->>'ship','')<>'1'),'[]'::jsonb)
    where id=o.id;
    return jsonb_build_object('ok',1);
  end if;
  if op='cv_d' then
    if coalesce(a->>'c','') !~ '^[0-9]{4}$' then return jsonb_build_object('err','bad'); end if;
    ad := left(btrim(regexp_replace(coalesce(a->>'f',''),'[<>]','','g')),30);
    select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=a->>'c' and status='new' and pk->>'d' is null and created>now()-interval '3 days' order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    update public.booth_orders set pk=case when ad='' then pk-'f' else pk||jsonb_build_object('f',ad) end where id=o.id;
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
revoke all on function public.dapp(text,text,text,jsonb) from public;
grant execute on function public.dapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.438] (تأییدنشده) D2-c3b: تابع dapp دوباره ساخته می‌شود (همان 1.9.437 + op تازه‌ی ow_new: غرفه‌دار سفارش تلفنی/پیامیِ مشتری را ثبت می‌کند ؛ با ورود غرفه‌دار ؛ حداکثر ۲۰ در ساعت ؛ فقط وقتی کلید dt روشن است). به توابع دیگر دست نمی‌زند. اگر [1.9.437] را اجرا کرده‌ای باز هم این بخش را اجرا کن.
create or replace function public.dapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare o public.booth_orders; bb public.booths; ad text; tt numeric; b public.booths; me jsonb := null; tn bigint;
begin
  a := coalesce(a,'{}'::jsonb);
  if op not in ('cv_p','cv_h','cv_d','ow_new') then return jsonb_build_object('err','bad'); end if;
  if coalesce((select nullif(c.v,'')::jsonb->>'dt' from public.f_conf c where c.k='xf'),'0')<>'1' then return jsonb_build_object('err','off'); end if;

  if op='cv_p' then
    ad := left(btrim(coalesce(a->>'ad','')),200);
    if length(ad)<5 then return jsonb_build_object('err','addr'); end if;
    select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=coalesce(a->>'c','') and status='new' and created>now()-interval '3 days' order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    select * into bb from public.booths where id=o.booth_id;
    if not found or coalesce(bb.lvl,0)=0 then return jsonb_build_object('err','unv'); end if;
    update public.booth_orders set pk=null, addr=ad where id=o.id;
    return jsonb_build_object('ok',1);
  end if;

  if op='cv_h' then
    if coalesce(a->>'c','') !~ '^[0-9]{4}$' or coalesce(a->>'h','') not in ('2','6','24') or coalesce(a->>'t','') !~ '^[0-9]{10,14}$' or coalesce(a->>'b','') !~ '^[0-9]{1,12}$' then return jsonb_build_object('err','bad'); end if;
    tt := (a->>'t')::numeric;
    select * into o from public.booth_orders where booth_id=(a->>'b')::bigint and phone=left(coalesce(a->>'phone',''),30) and status='new' and pk is null and created>now()-interval '3 days' and abs(extract(epoch from created)*1000-tt)<900000 order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    if o.cr is not null and coalesce(o.cr->>'s','')<>'rdy' then return jsonb_build_object('err','late'); end if;
    if o.pay is not null and coalesce(o.pay->>'s','')<>'wait' then return jsonb_build_object('err','late'); end if;
    update public.booth_orders set
      pk=jsonb_build_object('h',(a->>'h')::int,'c',a->>'c'), cr=null, pay=null,
      addr='🏪 حضوری (تبدیل از ارسال)',
      total=greatest(0,coalesce(o.total,0)-coalesce((select sum(case when coalesce(l->>'t','') ~ '^[0-9]+$' then (l->>'t')::bigint else 0 end) from jsonb_array_elements(o.lines) l where l->>'ship'='1'),0)),
      lines=coalesce((select jsonb_agg(l) from jsonb_array_elements(o.lines) l where coalesce(l->>'ship','')<>'1'),'[]'::jsonb)
    where id=o.id;
    return jsonb_build_object('ok',1);
  end if;
  if op='cv_d' then
    if coalesce(a->>'c','') !~ '^[0-9]{4}$' then return jsonb_build_object('err','bad'); end if;
    ad := left(btrim(regexp_replace(coalesce(a->>'f',''),'[<>]','','g')),30);
    select * into o from public.booth_orders where phone=left(coalesce(a->>'phone',''),30) and pk->>'c'=a->>'c' and status='new' and pk->>'d' is null and created>now()-interval '3 days' order by id desc limit 1;
    if not found then return jsonb_build_object('err','none'); end if;
    update public.booth_orders set pk=case when ad='' then pk-'f' else pk||jsonb_build_object('f',ad) end where id=o.id;
    return jsonb_build_object('ok',1);
  end if;
  if op='ow_new' then
    select * into b from public.booths where owner=u and pw=crypt(p,pw) and status='active';
    if not found then
      begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then select * into b from public.booths where owner=u and status='active'; end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;
    ad := left(btrim(regexp_replace(coalesce(a->>'d',''),'[<>]','','g')),200);
    if length(btrim(coalesce(a->>'n','')))<2 or length(regexp_replace(coalesce(a->>'ph',''),'[^0-9]','','g'))<7 or length(ad)<2 or coalesce(a->>'t','') !~ '^[0-9]{1,12}$' then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from public.booth_orders where booth_id=b.id and addr like '📞%' and created>now()-interval '1 hour')>=20 then return jsonb_build_object('err','many'); end if;
    tn := (a->>'t')::bigint;
    insert into public.booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,left(regexp_replace(btrim(a->>'n'),'[<>]','','g'),80),left(regexp_replace(a->>'ph','[^0-9+]','','g'),30),'📞 ثبت تلفنی توسط غرفه‌دار',jsonb_build_array(jsonb_build_object('p',0,'n',ad,'m','t','q',1,'u','','pr',tn,'t',tn)),tn);
    return jsonb_build_object('ok',1);
  end if;
  return jsonb_build_object('err','bad');
end $$;
revoke all on function public.dapp(text,text,text,jsonb) from public;
grant execute on function public.dapp(text,text,text,jsonb) to anon, authenticated;

-- [1.9.442] (تأییدنشده) S1: فقط ثبت نام کلید sc (سبد تازه) در فهرست کلیدهای مجاز xset در sapp. به توابع دیگر دست نمی‌زند. اگر sc را نخواستی روشن کنی لازم نیست اجرا کنی.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'pq','og','dt','sc'$x$ in d)>0 then null;
  elsif position($a$'ph','cd','pq','og','dt')$a$ in d)>0 then
    d := replace(d, $a$'ph','cd','pq','og','dt')$a$, $a2$'ph','cd','pq','og','dt','sc')$a2$);
    execute d;
  else
    raise exception 'S1: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

-- [1.9.449] (تأییدنشده) B1: فقط ثبت نام کلید wz (بخش شگفت‌انگیز خانه) در فهرست کلیدهای مجاز xset در sapp. به توابع دیگر دست نمی‌زند.
do $do$ declare d text; begin
  d := pg_get_functiondef('public.sapp(text,text,text,jsonb)'::regprocedure);
  if position($x$'dt','sc','wz'$x$ in d)>0 then null;
  elsif position($a$'dt','sc')$a$ in d)>0 then
    d := replace(d, $a$'dt','sc')$a$, $a2$'dt','sc','wz')$a2$);
    execute d;
  else
    raise exception 'B1: نقطه‌ی اتصال در sapp پیدا نشد ؛ این پیام را برای Claude بفرست';
  end if;
end $do$;

select 'ALL_SQL_DONE' as result;
