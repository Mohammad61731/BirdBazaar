-- انجمن بازارچه پرندگان (F1) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت کاربر: از همان تابع اصلی public.app (op=login) بررسی می‌شود؛ ادمین اصلی = role admin و pm شامل all.

create table if not exists public.f_push(
  token text primary key, uname text not null, upd timestamptz default now());
create index if not exists f_push_u on public.f_push(uname);
alter table public.f_push enable row level security;

create table if not exists public.f_rooms(
  id serial primary key, name text not null, emoji text default '💬', sort int default 0, status text default 'on');
create table if not exists public.f_msgs(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  uname text not null, kind text not null default 'text', body text default '', media text,
  reply_to bigint, pinned boolean default false, del boolean default false, created timestamptz default now());
create index if not exists f_msgs_room_id on public.f_msgs(room, id desc);
create table if not exists public.f_perm(
  uname text primary key, txt boolean default false, img boolean default false, vid boolean default false,
  fil boolean default false, muted boolean default false, blocked boolean default false);
create table if not exists public.f_reqs(
  id bigserial primary key, uname text not null, want jsonb default '{}'::jsonb, status text default 'new', created timestamptz default now());
create table if not exists public.f_react(
  msg bigint references public.f_msgs(id) on delete cascade, uname text, e text, primary key(msg, uname));
create table if not exists public.f_reports(
  id bigserial primary key, msg bigint, uname text, why text default '', created timestamptz default now());
create table if not exists public.f_prof(uname text primary key, avatar text default '');

-- [مورد ۲] مدیریت انجمن: رنگ اتاق، علامت «ویرایش شد»، پرسش‌های متداول
alter table public.f_rooms add column if not exists color text default '';
alter table public.f_msgs add column if not exists ed boolean default false;
-- [Q7] پرسش و پاسخ: qn = پیام پرسش است، sol = حل شد
alter table public.f_msgs add column if not exists qn boolean default false;
alter table public.f_msgs add column if not exists sol boolean default false;
create table if not exists public.f_faq(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  qu text default 'کاربر نمونه', q text not null, a text default '', sort int default 0, created timestamptz default now());
alter table public.f_faq enable row level security;
-- [P5] گزارش آگهی‌ها (هر کاربر برای هر آگهی یک گزارش؛ فقط ادمین می‌بیند)
create table if not exists public.f_arep(
  id bigserial primary key, ad bigint not null, uname text not null, why text default '', created timestamptz default now(), st text default 'new', unique(ad,uname));
alter table public.f_arep enable row level security;
-- [P4] فروخته شد / تمدید آگهی (جدا از جدول ads؛ صاحب آگهی از ads.d->>'own' بررسی می‌شود)
create table if not exists public.f_adx(
  ad bigint primary key, sold boolean default false, ren timestamptz, upd timestamptz default now());
alter table public.f_adx enable row level security;

alter table public.f_rooms enable row level security;
alter table public.f_msgs enable row level security;
alter table public.f_perm enable row level security;
alter table public.f_reqs enable row level security;
alter table public.f_react enable row level security;
alter table public.f_reports enable row level security;
alter table public.f_prof enable row level security;

insert into public.f_rooms(name,emoji,sort)
select x.n, x.e, x.s from (values ('گفتگوی عمومی پرندگان','🦜',1),('جوجه‌کشی و تخم‌گذاری','🥚',2),('سلامت و بیماری','🩺',3),('خرید و فروش','🛒',4)) as x(n,e,s)
where not exists (select 1 from public.f_rooms);

-- [1.9.53] کنترل انجمن از سمت سرور: fmode = on | closed | off | demo ، fslow = ثانیه‌ی فاصله‌ی بین دو پیام هر کاربر (0 = بدون محدودیت)
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;

create or replace function public.fapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb := null; who text := ''; ismain boolean := false;
  pr public.f_perm; k text; rid bigint; n int; fm text := 'on'; fs int := 0; wt int;
begin
  a := coalesce(a,'{}'::jsonb);
  select coalesce((select v from public.f_conf where k='fmode'),'on'), coalesce(nullif((select v from public.f_conf where k='fslow'),'')::int,0) into fm, fs;
  if fm not in ('on','closed','off','demo') then fm := 'on'; end if;
  if op='fping' then return jsonb_build_object('ok',1); end if;

  -- هویت (اختیاری): از تابع اصلی app
  if coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and (me ? 'err' or coalesce(me->>'role','')='') then me := null; end if;
    if me is not null then
      who := u;
      ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    end if;
  end if;
  select * into pr from public.f_perm where uname=who;

  if op='fwho' then
    return jsonb_build_object('ok',1,'me',who,'role',coalesce(me->>'role',''),'main',ismain,
      'perm',jsonb_build_object('txt',ismain or coalesce(pr.txt,false),'img',ismain or coalesce(pr.img,false),'vid',ismain or coalesce(pr.vid,false),'fil',ismain or coalesce(pr.fil,false),'muted',coalesce(pr.muted,false),'blocked',coalesce(pr.blocked,false)),
      'avatar',coalesce((select avatar from public.f_prof where uname=who),''),'mode',fm,'slow',fs);
  end if;

  if op='fpull' then
    if fm='off' and not ismain then
      return jsonb_build_object('ok',1,'mode',fm,'slow',fs,'rooms','[]'::jsonb,'msgs','[]'::jsonb,'av','{}'::jsonb,'pins','[]'::jsonb,'reqn',0);
    end if;
    n := least(greatest(coalesce((a->>'n')::int,30),1),60);
    return jsonb_build_object('ok',1,'mode',fm,'slow',fs,
      'rooms',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'name',r.name,'emoji',r.emoji,'color',coalesce(r.color,'')) order by r.sort,r.id) from public.f_rooms r where r.status='on'),'[]'::jsonb),
      'msgs',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'k',m.kind,'b',m.body,'md',case when coalesce(a->>'nomd','')='1' then null else m.media end,'rt',m.reply_to,'pin',m.pinned,'hm',(m.media is not null),'ed',coalesce(m.ed,false),'q',coalesce(m.qn,false),'s',coalesce(m.sol,false),'t',m.created,
              'r',coalesce((select jsonb_object_agg(x.e,x.c) from (select e,count(*) c from public.f_react where msg=m.id group by e) x),'{}'::jsonb)) order by m.id)
              from (select * from public.f_msgs where room=(a->>'room')::int and del=false
                     and id>coalesce((a->>'after')::bigint,0) and id<coalesce((a->>'before')::bigint,9223372036854775807)
                     order by id desc limit n) m),'[]'::jsonb),
      'av',case when coalesce(a->>'noav','')='1' then '{}'::jsonb else coalesce((select jsonb_object_agg(f.uname,f.avatar) from public.f_prof f where f.avatar<>'' and f.uname in
              (select distinct uname from (select uname from public.f_msgs where room=(a->>'room')::int and del=false order by id desc limit 60) z)),'{}'::jsonb) end,
      'pins',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'b',left(m.body,120))) from public.f_msgs m where m.room=(a->>'room')::int and m.pinned and m.del=false),'[]'::jsonb),
      'reqn',case when ismain then (select count(*) from public.f_reqs where status='new') else 0 end);
  end if;

  if op='ffaq' then
    return jsonb_build_object('ok',1,'faq',coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'qu',f.qu,'q',f.q,'a',f.a) order by f.sort,f.id) from public.f_faq f where f.room=(a->>'room')::int),'[]'::jsonb));
  end if;

  if who='' then return jsonb_build_object('err','login'); end if;

  if op='fsend' then
    if fm='off' and not ismain then return jsonb_build_object('err','off'); end if;
    if fm='demo' then return jsonb_build_object('err','demo'); end if;
    if fm='closed' and not ismain then return jsonb_build_object('err','closed'); end if;
    if fs>0 and not ismain then
      select ceil(fs - extract(epoch from (now()-max(created))))::int into wt from public.f_msgs where uname=who and created>now()-make_interval(secs=>fs);
      if wt is not null and wt>0 then return jsonb_build_object('err','slow','wait',wt); end if;
    end if;
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if coalesce(pr.muted,false) and not ismain then return jsonb_build_object('err','muted'); end if;
    k := coalesce(a->>'k','text');
    if k not in ('text','img','vid','file') then return jsonb_build_object('err','bad'); end if;
    if not ismain then
      if k='text' and not coalesce(pr.txt,false) then return jsonb_build_object('err','perm'); end if;
      if k='img' and not coalesce(pr.img,false) then return jsonb_build_object('err','perm'); end if;
      if k='vid' and not coalesce(pr.vid,false) then return jsonb_build_object('err','perm'); end if;
      if k='file' and not coalesce(pr.fil,false) then return jsonb_build_object('err','perm'); end if;
    end if;
    if length(coalesce(a->>'b',''))>2000 or length(coalesce(a->>'md',''))>4200000 then return jsonb_build_object('err','big'); end if;
    if k='text' and length(trim(coalesce(a->>'b','')))=0 then return jsonb_build_object('err','bad'); end if;
    if k<>'text' and coalesce(a->>'md','')='' then return jsonb_build_object('err','bad'); end if;
    if not exists (select 1 from public.f_rooms where id=(a->>'room')::int and status='on') then return jsonb_build_object('err','room'); end if;
    if (select count(*) from public.f_msgs where uname=who and created>now()-interval '1 minute')>=20 then return jsonb_build_object('err','many'); end if;
    insert into public.f_msgs(room,uname,kind,body,media,reply_to,qn)
      values((a->>'room')::int, who, k, coalesce(a->>'b',''), nullif(a->>'md',''), nullif(a->>'rt','')::bigint,
        (k='text' and coalesce(a->>'q','') in ('1','true') and nullif(a->>'rt','') is null)) returning id into rid;
    return jsonb_build_object('ok',1,'id',rid);
  end if;

  if op='fdel' then
    update public.f_msgs set del=true where id=(a->>'id')::bigint and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='freact' then
    if (a->>'e') not in ('👍','❤️','😂','🙏') then return jsonb_build_object('err','bad'); end if;
    if exists (select 1 from public.f_react where msg=(a->>'id')::bigint and uname=who and e=a->>'e') then
      delete from public.f_react where msg=(a->>'id')::bigint and uname=who;
    else
      insert into public.f_react(msg,uname,e) values((a->>'id')::bigint,who,a->>'e')
        on conflict (msg,uname) do update set e=excluded.e;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='fav_set' then
    if length(coalesce(a->>'img',''))>200000 then return jsonb_build_object('err','big'); end if;
    insert into public.f_prof(uname,avatar) values(who,coalesce(a->>'img','')) on conflict (uname) do update set avatar=excluded.avatar;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if exists (select 1 from public.f_reqs where uname=who and status='new') then return jsonb_build_object('err','dup'); end if;
    insert into public.f_reqs(uname,want) values(who,coalesce(a->'want','{}'::jsonb));
    return jsonb_build_object('ok',1);
  end if;

  if op='freport' then
    insert into public.f_reports(msg,uname,why) values((a->>'id')::bigint,who,left(coalesce(a->>'why',''),200));
    return jsonb_build_object('ok',1);
  end if;

  -- فقط ادمین اصلی
  if not ismain then return jsonb_build_object('err','denied'); end if;

  if op='freq_list' then
    return jsonb_build_object('ok',1,'reqs',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'u',q.uname,'want',q.want,'t',q.created,
      'av',coalesce((select avatar from public.f_prof where uname=q.uname),'')) order by q.id) from public.f_reqs q where q.status='new'),'[]'::jsonb));
  end if;

  if op='freq_ok' then
    insert into public.f_perm(uname,txt,img,vid,fil)
      select q.uname, coalesce((a->>'txt')::boolean,(q.want->>'txt')::boolean,true), coalesce((a->>'img')::boolean,(q.want->>'img')::boolean,false),
             coalesce((a->>'vid')::boolean,(q.want->>'vid')::boolean,false), coalesce((a->>'fil')::boolean,(q.want->>'fil')::boolean,false)
      from public.f_reqs q where q.id=(a->>'id')::bigint
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    update public.f_reqs set status='ok' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq_no' then
    update public.f_reqs set status='no' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_set' then
    insert into public.f_perm(uname,txt,img,vid,fil) values(a->>'uname',coalesce((a->>'txt')::boolean,false),coalesce((a->>'img')::boolean,false),coalesce((a->>'vid')::boolean,false),coalesce((a->>'fil')::boolean,false))
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_list' then
    return jsonb_build_object('ok',1,'perms',coalesce((select jsonb_agg(to_jsonb(x) order by x.uname) from public.f_perm x),'[]'::jsonb));
  end if;

  if op='fmute' then
    insert into public.f_perm(uname,muted) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set muted=excluded.muted;
    return jsonb_build_object('ok',1);
  end if;

  if op='fblock' then
    insert into public.f_perm(uname,blocked) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set blocked=excluded.blocked;
    return jsonb_build_object('ok',1);
  end if;

  if op='fsolve' then
    if who='' then return jsonb_build_object('err','login'); end if;
    update public.f_msgs set sol=coalesce((a->>'on')::boolean,true)
      where id=(a->>'id')::bigint and qn and del=false and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='arep' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if (select count(*) from public.f_arep where uname=who and created>now()-interval '1 minute')>=10 then return jsonb_build_object('err','many'); end if;
    insert into public.f_arep(ad,uname,why) values((a->>'ad')::bigint, who, left(coalesce(a->>'why',''),150))
      on conflict (ad,uname) do update set why=excluded.why, created=now(), st='new';
    return jsonb_build_object('ok',1);
  end if;

  if op='arep_list' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',z.ad,'n',z.n,'why',z.ws,'t',z.t) order by z.n desc, z.t desc)
      from (select ad, count(*) n, max(created) t, (array_agg(why order by created desc) filter (where why<>''))[1:3] ws
            from public.f_arep where st='new' group by ad order by count(*) desc, max(created) desc limit 100) z),'[]'::jsonb));
  end if;

  if op='arep_done' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    update public.f_arep set st='done' where ad=(a->>'ad')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='myorders' then
    if who='' then return jsonb_build_object('err','login'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'dt',z.d->>'dt','tt',z.d->'tt','st',coalesce(z.d->>'st','new'),'it',coalesce(z.d->'it','[]'::jsonb)) order by z.id desc)
      from (select id,d from public.orders where d->>'u'=who order by id desc limit 50) z),'[]'::jsonb));
  end if;

  if op='ptoken' or op='ptoken_del' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if length(coalesce(a->>'t',''))<20 then return jsonb_build_object('err','bad'); end if;
    if op='ptoken' then
      insert into public.f_push(token,uname,upd) values(a->>'t',who,now())
        on conflict (token) do update set uname=excluded.uname, upd=now();
    else
      delete from public.f_push where token=a->>'t' and uname=who;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='adx_list' then
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',ad,'s',coalesce(sold,false),'r',ren))
      from public.f_adx where coalesce(sold,false) or ren>now()-interval '30 days'),'[]'::jsonb));
  end if;

  if op='adx_sold' or op='adx_renew' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if not (ismain
        or ((me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')
        or exists(select 1 from public.ads x where x.id=(a->>'ad')::bigint and x.d->>'own'=who)) then
      return jsonb_build_object('err','denied');
    end if;
    if op='adx_sold' then
      insert into public.f_adx(ad,sold) values((a->>'ad')::bigint, coalesce((a->>'on')::boolean,true))
        on conflict (ad) do update set sold=excluded.sold, upd=now();
      return jsonb_build_object('ok',1);
    end if;
    if not ismain and exists(select 1 from public.f_adx where ad=(a->>'ad')::bigint and ren>now()-interval '1 day') then
      return jsonb_build_object('err','wait');
    end if;
    insert into public.f_adx(ad,ren) values((a->>'ad')::bigint, now())
      on conflict (ad) do update set ren=now(), upd=now();
    return jsonb_build_object('ok',1);
  end if;

  if op='fmode_set' then
    if not ismain then return jsonb_build_object('err','perm'); end if;
    if coalesce(a->>'mode','') not in ('on','closed','off','demo') then return jsonb_build_object('err','bad'); end if;
    insert into public.f_conf(k,v) values('fmode',a->>'mode') on conflict (k) do update set v=excluded.v;
    insert into public.f_conf(k,v) values('fslow',least(greatest(coalesce((a->>'slow')::int,0),0),3600)::text) on conflict (k) do update set v=excluded.v;
    return jsonb_build_object('ok',1);
  end if;

  if op='fpin' then
    update public.f_msgs set pinned=coalesce((a->>'on')::boolean,true) where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freport_list' then
    return jsonb_build_object('ok',1,'reports',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'msg',r.msg,'u',r.uname,'why',r.why,'t',r.created,'body',(select left(body,120) from public.f_msgs where id=r.msg),'by',(select uname from public.f_msgs where id=r.msg)) order by r.id desc) from public.f_reports r),'[]'::jsonb));
  end if;

  if op='freport_del' then
    delete from public.f_reports where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_set' then
    if length(trim(coalesce(a->>'name','x')))=0 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_rooms(name,emoji,sort,color) values(left(coalesce(a->>'name','اتاق'),60),left(coalesce(a->>'emoji','💬'),8),coalesce((a->>'sort')::int,(select coalesce(max(sort),0)+1 from public.f_rooms)),left(coalesce(a->>'color',''),9)) returning id into rid;
      return jsonb_build_object('ok',1,'id',rid);
    else
      update public.f_rooms set name=left(coalesce(a->>'name',name),60), emoji=left(coalesce(a->>'emoji',emoji),8), color=left(coalesce(a->>'color',color),9), sort=coalesce((a->>'sort')::int,sort), status=coalesce(a->>'status',status) where id=(a->>'id')::int;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_del' then
    delete from public.f_rooms where id=(a->>'id')::int;
    return jsonb_build_object('ok',1);
  end if;

  if op='fedit' then
    if length(trim(coalesce(a->>'b','')))=0 or length(a->>'b')>2000 then return jsonb_build_object('err','bad'); end if;
    update public.f_msgs set body=a->>'b', ed=true where id=(a->>'id')::bigint and kind='text';
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_set' then
    if length(trim(coalesce(a->>'q','')))=0 or length(a->>'q')>400 or length(coalesce(a->>'a',''))>1500 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_faq(room,qu,q,a,sort) values((a->>'room')::int,left(coalesce(nullif(trim(a->>'qu'),''),'کاربر نمونه'),40),a->>'q',coalesce(a->>'a',''),(select coalesce(max(sort),0)+1 from public.f_faq where room=(a->>'room')::int));
    else
      update public.f_faq set qu=left(coalesce(nullif(trim(a->>'qu'),''),qu),40), q=a->>'q', a=coalesce(a->>'a',a) where id=(a->>'id')::bigint;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_del' then
    delete from public.f_faq where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.fapp(text,text,text,jsonb) to anon, authenticated;


-- [1.9.55] پرسش و پاسخ‌های نمونه (گفتگوهای نمونه‌ی هر گروه؛ داخل خود چت نمایش داده می‌شوند، با برچسب «نمونه / نام‌ها فرضی»).
-- نمونه‌های قدیمی (نام «کاربر نمونه n») جایگزین می‌شوند؛ پرسش‌هایی که ادمین خودش ساخته یا ویرایش کرده دست نمی‌خورد. چند بار اجرا بی‌خطر است.
delete from public.f_faq where qu like 'کاربر نمونه%';
insert into public.f_faq(room,qu,q,a,sort)
select r.id, x.qu, x.q, x.a, x.s from public.f_rooms r
join (values
($q$گفتگوی عمومی پرندگان$q$,$q$امیر$q$,$q$برای شروع نگهداری از طوطی‌سانان چه چیزهایی لازم است؟$q$,$q$سلام امیر جان 🌿 یک قفس بزرگ و تمیز، ظرف آب و دانه‌ی جدا، دانه‌ی متنوع و باکیفیت، سبزی تازه، چوب‌نشیمن با ضخامت‌های مختلف و چند اسباب‌بازی ساده. قفس را دور از آشپزخانه، کوران و دود بگذارید.$q$,1),
($q$گفتگوی عمومی پرندگان$q$,$q$سارا$q$,$q$چه خوراکی‌هایی برای پرنده خطرناک است؟$q$,$q$سارا جان این‌ها را هرگز ندهید: آووکادو، شکلات، قهوه و چای، الکل، پیاز و سیر. دود ظرف‌های تفلون هم برای پرنده‌ها خیلی خطرناک است؛ هنگام پخت‌وپز پرنده را از آشپزخانه دور کنید.$q$,2),
($q$گفتگوی عمومی پرندگان$q$,$q$محمد$q$,$q$دمای مناسب نگهداری چقدر است؟$q$,$q$معمولاً بین ۲۰ تا ۲۵ درجه خوب است. مهم‌تر از عدد، ثابت‌بودن هواست: از کوران و تغییر ناگهانی دما دور نگه دارید. نور ملایم صبحگاهی هم عالی است، ولی قفس زیر آفتاب داغ ظهر نباشد.$q$,3),
($q$گفتگوی عمومی پرندگان$q$,$q$مریم$q$,$q$پرنده‌ام تنهاست، یک جفت دیگر برایش بگیرم؟$q$,$q$بستگی دارد. بیشتر طوطی‌سانان اجتماعی‌اند و به همراه یا وقت شما نیاز دارند. اگر جفت می‌گیرید، پرنده‌ی تازه را حداقل دو هفته جدا نگه دارید و بعد آرام آرام آشنا کنید.$q$,4),
($q$گفتگوی عمومی پرندگان$q$,$q$رضا$q$,$q$هر چند وقت قفس را بشویم؟$q$,$q$کف قفس را روزانه یا یک‌روز‌درمیان عوض کنید، ظرف آب و غذا را هر روز بشویید و یک‌بار در هفته شست‌وشوی کامل قفس و چوب‌ها را انجام بدهید. تمیزی بیشترین جلوگیری را از بیماری می‌کند.$q$,5),
($q$گفتگوی عمومی پرندگان$q$,$q$نرگس$q$,$q$پرنده‌ام پرهای خودش را می‌کند، چرا؟$q$,$q$دلیل‌های رایج: استرس، بی‌حوصلگی، تغذیه‌ی ضعیف، انگل یا بیماری. اول تغذیه، اسباب‌بازی و خواب کافی (حدود ۱۰ ساعت تاریکی) را بررسی کنید. اگر ادامه داشت حتماً دامپزشک پرندگان ببیند.$q$,6),
($q$گفتگوی عمومی پرندگان$q$,$q$آرمان$q$,$q$روزی چند ساعت باید با پرنده وقت بگذرانم؟$q$,$q$حداقل یکی دو ساعت تعامل و بازی خوب است. اگر چند ساعت بیرون از قفس می‌آید، حتماً زیر نظر باشید.$q$,7),
($q$گفتگوی عمومی پرندگان$q$,$q$هانیه$q$,$q$پرنده‌ام زیاد جیغ می‌زند، چه کنم؟$q$,$q$معمولاً از تنهایی، بی‌حوصلگی یا کم‌خوابی است. شب‌ها آرام و تاریک بخوابد، اسباب‌بازی بگذارید و وقتی آرام است تشویقش کنید، نه وقتی جیغ می‌زند.$q$,8),
($q$گفتگوی عمومی پرندگان$q$,$q$داریوش$q$,$q$چطور پرنده‌ام را رام کنم؟$q$,$q$با صبر. دست را آرام و بدون حرکت ناگهانی نزدیک ببرید، با کمی ارزن تشویق کنید و جلسه‌ها را کوتاه و روزانه نگه دارید. هرگز به‌زور نگیریدش.$q$,9),
($q$گفتگوی عمومی پرندگان$q$,$q$مینا$q$,$q$بهترین دانه کدام است؟$q$,$q$مخلوط مخصوص گونه‌ی خودش، به‌علاوه سبزی و میوه‌ی تازه. فقط دانه‌ی چرب مثل آفتابگردان زیاد نباشد. پلت باکیفیت هم گزینه‌ی خوبی است.$q$,10),
($q$گفتگوی عمومی پرندگان$q$,$q$فرزاد$q$,$q$پرنده را حمام کنم؟$q$,$q$اسپری آب ولرم یا ظرف کم‌عمق در هوای گرم عالی است. در هوای سرد و بعدش در کوران نگذاریدش تا خشک شود.$q$,11),
($q$گفتگوی عمومی پرندگان$q$,$q$پگاه$q$,$q$پرنده چند ساعت باید بخوابد؟$q$,$q$حدود ۱۰ تا ۱۲ ساعت تاریکی و آرامش. شب‌ها پارچه‌ی نازک روی قفس بیندازید و از تلویزیون و نور دورش کنید.$q$,12),
($q$گفتگوی عمومی پرندگان$q$,$q$کاوه$q$,$q$باز گذاشتن پرنده در خانه خطر ندارد؟$q$,$q$چرا. پنجره و در بسته، پنکه‌ی سقفی خاموش، آینه و شیشه‌ی تمیز، سیم برق و گیاهان سمی و ظرف‌های پر از آب (مثل لیوان) جزو خطرها هستند. حتماً مراقبش باشید.$q$,13),
($q$گفتگوی عمومی پرندگان$q$,$q$ترانه$q$,$q$برای سفر پرنده را چه کنم؟$q$,$q$سپردن به یک آدم مطمئن که قبلاً با پرنده کار کرده بهتر از جابه‌جایی است. غذا، آب و دستورالعمل کوتاه بدهید.$q$,14),
($q$گفتگوی عمومی پرندگان$q$,$q$بیژن$q$,$q$برای شروع مرغ‌عشق بگیرم یا کاکتیل؟$q$,$q$مرغ‌عشق کوچک‌تر و پرانرژی است؛ کاکتیل آرام‌تر و مهربان‌تر است ولی گرد و غبار بیشتری دارد. به وقتی که دارید و فضای خانه فکر کنید.$q$,15),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$علی$q$,$q$چه سنی برای جفت‌گیری مناسب است؟$q$,$q$پرنده‌ها باید کاملاً بالغ و سالم باشند، معمولاً بالای یک سال. جفت‌های لاغر یا پرنده‌های تازه‌خریداری‌شده را زود جفت نکنید. تشخیص جنسیت در بعضی گونه‌ها فقط با آزمایش DNA قطعی است.$q$,1),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$زهرا$q$,$q$جعبه‌ی لانه چه شکلی باشد؟$q$,$q$متناسب با گونه، با ورودی مناسب و کف نرم. جای آرام و کم‌رفت‌وآمد بگذارید و در روزهای اول بیش از حد سرک نکشید تا پرنده‌ها استرس نگیرند.$q$,2),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$پویا$q$,$q$تخم‌ها چند روز بعد جوجه می‌شوند؟$q$,$q$بسته به گونه فرق می‌کند؛ مثلاً قناری حدود ۱۳ تا ۱۴ روز و مرغ‌عشق و کاکتیل حدود ۱۸ تا ۲۱ روز. تاریخ شروع خوابیدن روی تخم‌ها را یادداشت کنید.$q$,3),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$مهدی$q$,$q$تخم‌ها را می‌شود دست زد؟$q$,$q$تا جای ممکن نه. اگر لازم شد با دست‌های تمیز و خیلی کوتاه. حدود ۵ تا ۷ روز بعد می‌شود با نور ملایم (شب‌تابی) پیدا کرد تخم بارور است یا نه.$q$,4),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ساناز$q$,$q$مادر روی تخم‌ها نمی‌خوابد، چه کنم؟$q$,$q$پرنده‌های تازه‌کار گاهی چند روز طول می‌کشد. محیط را آرام نگه دارید و مزاحم نشوید. اگر چند روز بیشتر طول کشید یا تخم‌ها سرد شد، با یک نفر باتجربه یا دامپزشک مشورت کنید.$q$,5),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$حسین$q$,$q$ماده تخم‌گذاری دارد؛ چه مکملی بدهم؟$q$,$q$استخوان سفید ماهی مرکب و غذای کلسیم‌دار کمک می‌کند. اگر ماده نشسته، پف کرده و بی‌حال است و تخم گیر کرده، فوراً به دامپزشک برسانید؛ گرم نگه داشتن در راه کمک می‌کند.$q$,6),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$شقایق$q$,$q$ماده چند تا تخم می‌گذارد؟$q$,$q$بسته به گونه فرق می‌کند؛ معمولاً بین سه تا هشت تا، و هر یکی دو روز یک تخم. تعداد زیاد پشت سر هم ماده را خسته می‌کند.$q$,7),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$امید$q$,$q$جوجه‌ها کی پر درمی‌آورند؟$q$,$q$معمولاً بین سه تا پنج هفته، بسته به گونه. تا آن موقع محیط گرم و آرام و بدون سر و صدا باشد.$q$,8),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سمیرا$q$,$q$تخم‌هایمان بارور نشدند، چرا؟$q$,$q$دلیل‌ها: جوانی یا ناباروری جفت، جنسیت اشتباه، تغذیه‌ی ضعیف، استرس یا دمای نامناسب. تغذیه و آرامش را بهتر کنید و چند هفته صبر کنید.$q$,9),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$وحید$q$,$q$قبل از جفت‌گیری غذای ویژه بدهم؟$q$,$q$کمی پروتئین بیشتر (مثل تخم‌مرغ آب‌پز)، دانه‌ی جوانه‌زده و کلسیم، ولی کم‌کم. زیاده‌روی در غذای چرب مناسب نیست.$q$,10),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$رها$q$,$q$جوجه‌ها را چه زمانی از والدین جدا کنم؟$q$,$q$زود نه. معمولاً بعد از اینکه خودشان غذا خوردن و پریدن را یاد گرفتند و حدود شش تا هشت هفته که بسته به گونه است.$q$,11),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$نیما$q$,$q$نور چقدر باشد؟$q$,$q$حدود ۱۲ تا ۱۴ ساعت روشنایی می‌تواند فصل جفت‌گیری را تحریک کند؛ شب‌ها هم تاریکی کامل بدهید.$q$,12),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$غزل$q$,$q$سالی چند بار جفت‌گیری مجاز است؟$q$,$q$بین دوره‌ها به ماده استراحت بدهید. پشت سر هم جوجه‌آوردن او را ضعیف می‌کند.$q$,13),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$سینا$q$,$q$جوجه را دستی پرورش بدهم؟$q$,$q$فقط اگر لازم باشد و تجربه دارید؛ خطر جوجه خیلی زیاد است. بهتر است با یک فرد باتجربه یا دامپزشک مشورت کنید.$q$,14),
($q$جوجه‌کشی و تخم‌گذاری$q$,$q$ملیحه$q$,$q$لانه را تمیز کنم؟$q$,$q$تا وقتی جوجه‌ها داخل‌اند دست‌کاری را حداقل کنید. بعد از جوجه‌درآمدن و ترک لانه تمیز و ضدعفونی کنید.$q$,15),
($q$سلامت و بیماری$q$,$q$آرش$q$,$q$پرنده‌ام پف کرده و کم‌غذا شده، چه کنم؟$q$,$q$این‌ها می‌تواند نشانه‌ی بیماری باشد و پرنده‌ها دردشان را تا آخر پنهان می‌کنند. گرم و آرام نگهش دارید، آب در دسترس باشد و هرچه زودتر به دامپزشک پرندگان نشانش بدهید.$q$,1),
($q$سلامت و بیماری$q$,$q$الهام$q$,$q$رنگ و حالت مدفوع عوض شده؛ نگران باشم؟$q$,$q$تغییر کوتاه بعد از خوردن میوه‌ی رنگی عادی است. اگر آبکی، بدبو، خونی یا چند روز ادامه‌دار بود و پرنده بی‌حال شد، عکس مدفوع را بگیرید و به دامپزشک نشان بدهید.$q$,2),
($q$سلامت و بیماری$q$,$q$کیان$q$,$q$عطسه و ترشح بینی دارد.$q$,$q$گاهی از گرد و غبار یا دود است، ولی ادامه‌ی آن می‌تواند عفونت تنفسی باشد. محیط را از دود و اسپری دور کنید و اگر چند روز ماند، معاینه لازم است.$q$,3),
($q$سلامت و بیماری$q$,$q$نیلوفر$q$,$q$منقار و ناخن‌ها بلند شده‌اند.$q$,$q$چوب و سنگ‌پای مخصوص بگذارید. کوتاه‌کردن را اگر بلد نیستید خودتان انجام ندهید؛ برش بیش از حد باعث خونریزی می‌شود. دامپزشک یا فرد باتجربه انجام بدهد.$q$,4),
($q$سلامت و بیماری$q$,$q$بهرام$q$,$q$می‌شود خودم دارو بدهم؟$q$,$q$لطفاً بدون تشخیص دامپزشک دارو یا آنتی‌بیوتیک ندهید؛ دوز اشتباه برای پرنده‌ی کوچک خطرناک است. این بخش برای تجربه و آگاهی است و جای دامپزشک را نمی‌گیرد.$q$,5),
($q$سلامت و بیماری$q$,$q$شیدا$q$,$q$پرنده‌ی جدید را چطور قرنطینه کنم؟$q$,$q$حداقل دو تا چهار هفته در اتاق جدا و با ظرف‌های جدا نگه دارید. اول دست‌های پرنده‌های سالم را بشویید، بعد سراغ پرنده‌ی جدید بروید تا بیماری منتقل نشود.$q$,6),
($q$سلامت و بیماری$q$,$q$رامین$q$,$q$دانه‌ی کپک‌زده را الک کنم و بدهم؟$q$,$q$نه، حتی کپک کم هم سم تولید می‌کند. دانه را دور بریزید و در ظرف دربسته و خشک نگه دارید.$q$,7),
($q$سلامت و بیماری$q$,$q$آزاده$q$,$q$پرنده با دهان باز نفس می‌کشد.$q$,$q$ممکن است تنگی نفس یا گرمازدگی باشد. محیط را خنک و آرام کنید و فوراً دامپزشک.$q$,8),
($q$سلامت و بیماری$q$,$q$احسان$q$,$q$ریزش پر طبیعی است؟$q$,$q$پرریزی فصلی عادی است. اگر جاهای بدون پر یا پوست قرمز دیدید، یا پرنده بی‌حال شد، معاینه لازم است.$q$,9),
($q$سلامت و بیماری$q$,$q$ملیکا$q$,$q$چشمش ورم کرده و ترشح دارد.$q$,$q$می‌تواند عفونت یا آسیب باشد. خودسرانه قطره نریزید؛ دامپزشک.$q$,10),
($q$سلامت و بیماری$q$,$q$شهاب$q$,$q$پایین قفس می‌نشیند و پایش ورم دارد.$q$,$q$ممکن است مشکل پا یا بیماری باشد. نشیمن نرم و کم‌ارتفاع بگذارید و برای معاینه ببرید.$q$,11),
($q$سلامت و بیماری$q$,$q$دلارام$q$,$q$پرنده‌ی تازه‌آورده بی‌حال است.$q$,$q$تغییر محیط استرس دارد. گرم، آرام و با غذا و آب در دسترس نگهش دارید؛ اگر دو روز نخورد یا بدتر شد، دامپزشک.$q$,12),
($q$سلامت و بیماری$q$,$q$بابک$q$,$q$ویتامین بدهم؟$q$,$q$غذای متنوع معمولاً کافی است. مکمل را بدون نظر دامپزشک زیاد ندهید.$q$,13),
($q$سلامت و بیماری$q$,$q$مسعود$q$,$q$چه علامت‌هایی اورژانسی است؟$q$,$q$خونریزی، نفس با دهان باز، افتادن از نشیمن، پف دائم، دو روز نخوردن یا تخم گیرکرده. فوراً به دامپزشک برسانید.$q$,14),
($q$خرید و فروش$q$,$q$یاسر$q$,$q$هنگام خرید پرنده چه چیزهایی را ببینم؟$q$,$q$پرنده فعال و کنجکاو باشد، چشم‌ها روشن، پرها مرتب، بینی خشک و تمیز، پاها و ناخن‌ها سالم. پرنده‌ای که پف‌کرده در گوشه نشسته را نخرید.$q$,1),
($q$خرید و فروش$q$,$q$فاطمه$q$,$q$پرنده را چطور با خیال راحت حمل کنم؟$q$,$q$در قفس یا جعبه‌ی کوچک با منفذ هوا، روی آن پارچه‌ی نازک بیندازید تا آرام باشد. در ماشین گرم یا سرد نگذارید و آب و میوه‌ی آبدار را فقط اگر مسیر طولانی است همراه ببرید.$q$,2),
($q$خرید و فروش$q$,$q$کامران$q$,$q$خرید حضوری بهتر است یا ارسالی؟$q$,$q$تا می‌توانید حضوری ببینید. اگر ارسالی است، از فروشنده ویدیو و عکس واضح بخواهید و پرداخت کامل پیش از دیدن پرنده را نپذیرید.$q$,3),
($q$خرید و فروش$q$,$q$لیلا$q$,$q$اطلاعات سن و جنسیت را چقدر باور کنم؟$q$,$q$تشخیص سن و جنس در بعضی گونه‌ها ظاهری نیست. اگر برایتان مهم است، از آزمایش DNA یا شناسنامه و حلقه‌ی پای پرنده کمک بگیرید.$q$,4),
($q$خرید و فروش$q$,$q$سجاد$q$,$q$بعد از خرید باید قرنطینه کنم؟$q$,$q$بله، پرنده‌ی تازه را چند هفته جدا نگه دارید و رفتارش را زیر نظر بگیرید، بعد کنار بقیه ببرید.$q$,5),
($q$خرید و فروش$q$,$q$ندا$q$,$q$اگر آگهی مشکوک بود چه کنم؟$q$,$q$از دکمه‌ی گزارش آگهی استفاده کنید تا ادمین بررسی کند. هیچ‌وقت پول بیعانه‌ی بزرگ ندهید و معامله‌ی حضوری را ترجیح بدهید. مسئولیت آگهی با ثبت‌کننده است.$q$,6),
($q$خرید و فروش$q$,$q$حمید$q$,$q$قیمت منصفانه چقدر است؟$q$,$q$با چند آگهی مشابه (گونه، سن، جهش) مقایسه کنید. عددهای پراکنده را معیار نگیرید.$q$,7),
($q$خرید و فروش$q$,$q$ثمین$q$,$q$حلقه‌ی پای پرنده چیست؟$q$,$q$حلقه‌ی بسته معمولاً نشانگر سال و محل پرورش است. به شناسایی منبع کمک می‌کند.$q$,8),
($q$خرید و فروش$q$,$q$جواد$q$,$q$از غرفه بخرم یا فروشنده‌ی خصوصی؟$q$,$q$هر دو ممکن است خوب باشند. غرفه معمولاً سابقه و پروفایل دارد؛ پروفایل و آگهی‌های قبلی فروشنده را ببینید.$q$,9),
($q$خرید و فروش$q$,$q$آیدا$q$,$q$با پرنده چه لوازمی بخرم؟$q$,$q$قفس مناسب، ظرف آب و غذا، چوب نشیمن، دانه‌ی همان برندی که فروشنده می‌دهد (تغییر ناگهانی غذا نکنید).$q$,10),
($q$خرید و فروش$q$,$q$رضوان$q$,$q$جفت بخرم؛ از جنسیت مطمئن شوم؟$q$,$q$در بسیاری از گونه‌ها ظاهر کافی نیست؛ اگر مهم است، آزمایش DNA بهترین راه است.$q$,11),
($q$خرید و فروش$q$,$q$سعید$q$,$q$می‌خواهم پرنده‌ام را بفروشم؛ آگهی چطور باشد؟$q$,$q$عکس و ویدیوی واضح، سن، جنس تقریبی، سلامت و قیمت بدون اغراق؛ و در بخش آگهی‌ها ثبت کنید.$q$,12),
($q$خرید و فروش$q$,$q$فرناز$q$,$q$بعد از فروش آگهی را چه کنم؟$q$,$q$از دکمه‌ی «فروخته شد» در صفحه‌ی آگهی استفاده کنید؛ اگر نشد، تمدیدش هم هست.$q$,13),
($q$خرید و فروش$q$,$q$پدرام$q$,$q$پرداخت امن چطور است؟$q$,$q$حضوری و بعد از دیدن پرنده؛ بیعانه‌ی بزرگ نپردازید.$q$,14),
($q$خرید و فروش$q$,$q$مهسا$q$,$q$فروشنده تضمین سلامت می‌دهد؟$q$,$q$با فروشنده درباره‌ی چند روز مهلت برای بررسی توافق کنید و بهتر است مکتوب باشد.$q$,15)
) as x(rn,qu,q,a,s) on x.rn=r.name
where not exists (select 1 from public.f_faq f where f.room=r.id and f.q=x.q);
