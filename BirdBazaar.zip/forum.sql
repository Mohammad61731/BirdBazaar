-- انجمن بازارچه پرندگان (F1) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت کاربر: از همان تابع اصلی public.app (op=login) بررسی می‌شود؛ ادمین اصلی = role admin و pm شامل all.

create table if not exists public.f_push(
  token text primary key, uname text not null, upd timestamptz default now());
create index if not exists f_push_u on public.f_push(uname);
alter table public.f_push enable row level security;

create table if not exists public.f_rooms(
  id serial primary key, name text not null, emoji text default '💬', sort int default 0, status text default 'on');
create table if not exists public.f_msgs(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  uname text not null, kind text not null default 'text', body text default '', media text,
  reply_to bigint, pinned boolean default false, del boolean default false, created timestamptz default now());
create index if not exists f_msgs_room_id on public.f_msgs(room, id desc);
create table if not exists public.f_perm(
  uname text primary key, txt boolean default false, img boolean default false, vid boolean default false,
  fil boolean default false, muted boolean default false, blocked boolean default false);
create table if not exists public.f_reqs(
  id bigserial primary key, uname text not null, want jsonb default '{}'::jsonb, status text default 'new', created timestamptz default now());
create table if not exists public.f_react(
  msg bigint references public.f_msgs(id) on delete cascade, uname text, e text, primary key(msg, uname));
create table if not exists public.f_reports(
  id bigserial primary key, msg bigint, uname text, why text default '', created timestamptz default now());
create table if not exists public.f_prof(uname text primary key, avatar text default '');

-- [مورد ۲] مدیریت انجمن: رنگ اتاق، علامت «ویرایش شد»، پرسش‌های متداول
alter table public.f_rooms add column if not exists color text default '';
alter table public.f_msgs add column if not exists ed boolean default false;
-- [Q7] پرسش و پاسخ: qn = پیام پرسش است، sol = حل شد
alter table public.f_msgs add column if not exists qn boolean default false;
alter table public.f_msgs add column if not exists sol boolean default false;
create table if not exists public.f_faq(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  qu text default 'کاربر نمونه', q text not null, a text default '', sort int default 0, created timestamptz default now());
alter table public.f_faq enable row level security;
-- [P5] گزارش آگهی‌ها (هر کاربر برای هر آگهی یک گزارش؛ فقط ادمین می‌بیند)
create table if not exists public.f_arep(
  id bigserial primary key, ad bigint not null, uname text not null, why text default '', created timestamptz default now(), st text default 'new', unique(ad,uname));
alter table public.f_arep enable row level security;
-- [P4] فروخته شد / تمدید آگهی (جدا از جدول ads؛ صاحب آگهی از ads.d->>'own' بررسی می‌شود)
create table if not exists public.f_adx(
  ad bigint primary key, sold boolean default false, ren timestamptz, upd timestamptz default now());
alter table public.f_adx enable row level security;

alter table public.f_rooms enable row level security;
alter table public.f_msgs enable row level security;
alter table public.f_perm enable row level security;
alter table public.f_reqs enable row level security;
alter table public.f_react enable row level security;
alter table public.f_reports enable row level security;
alter table public.f_prof enable row level security;

insert into public.f_rooms(name,emoji,sort)
select x.n, x.e, x.s from (values ('گفتگوی عمومی پرندگان','🦜',1),('جوجه‌کشی و تخم‌گذاری','🥚',2),('سلامت و بیماری','🩺',3),('خرید و فروش','🛒',4)) as x(n,e,s)
where not exists (select 1 from public.f_rooms);

create or replace function public.fapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb := null; who text := ''; ismain boolean := false;
  pr public.f_perm; k text; rid bigint; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='fping' then return jsonb_build_object('ok',1); end if;

  -- هویت (اختیاری): از تابع اصلی app
  if coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and (me ? 'err' or coalesce(me->>'role','')='') then me := null; end if;
    if me is not null then
      who := u;
      ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    end if;
  end if;
  select * into pr from public.f_perm where uname=who;

  if op='fwho' then
    return jsonb_build_object('ok',1,'me',who,'role',coalesce(me->>'role',''),'main',ismain,
      'perm',jsonb_build_object('txt',ismain or coalesce(pr.txt,false),'img',ismain or coalesce(pr.img,false),'vid',ismain or coalesce(pr.vid,false),'fil',ismain or coalesce(pr.fil,false),'muted',coalesce(pr.muted,false),'blocked',coalesce(pr.blocked,false)),
      'avatar',coalesce((select avatar from public.f_prof where uname=who),''));
  end if;

  if op='fpull' then
    n := least(greatest(coalesce((a->>'n')::int,30),1),60);
    return jsonb_build_object('ok',1,
      'rooms',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'name',r.name,'emoji',r.emoji,'color',coalesce(r.color,'')) order by r.sort,r.id) from public.f_rooms r where r.status='on'),'[]'::jsonb),
      'msgs',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'k',m.kind,'b',m.body,'md',case when coalesce(a->>'nomd','')='1' then null else m.media end,'rt',m.reply_to,'pin',m.pinned,'hm',(m.media is not null),'ed',coalesce(m.ed,false),'q',coalesce(m.qn,false),'s',coalesce(m.sol,false),'t',m.created,
              'r',coalesce((select jsonb_object_agg(x.e,x.c) from (select e,count(*) c from public.f_react where msg=m.id group by e) x),'{}'::jsonb)) order by m.id)
              from (select * from public.f_msgs where room=(a->>'room')::int and del=false
                     and id>coalesce((a->>'after')::bigint,0) and id<coalesce((a->>'before')::bigint,9223372036854775807)
                     order by id desc limit n) m),'[]'::jsonb),
      'av',case when coalesce(a->>'noav','')='1' then '{}'::jsonb else coalesce((select jsonb_object_agg(f.uname,f.avatar) from public.f_prof f where f.avatar<>'' and f.uname in
              (select distinct uname from (select uname from public.f_msgs where room=(a->>'room')::int and del=false order by id desc limit 60) z)),'{}'::jsonb) end,
      'pins',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'b',left(m.body,120))) from public.f_msgs m where m.room=(a->>'room')::int and m.pinned and m.del=false),'[]'::jsonb),
      'reqn',case when ismain then (select count(*) from public.f_reqs where status='new') else 0 end);
  end if;

  if op='ffaq' then
    return jsonb_build_object('ok',1,'faq',coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'qu',f.qu,'q',f.q,'a',f.a) order by f.sort,f.id) from public.f_faq f where f.room=(a->>'room')::int),'[]'::jsonb));
  end if;

  if who='' then return jsonb_build_object('err','login'); end if;

  if op='fsend' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if coalesce(pr.muted,false) and not ismain then return jsonb_build_object('err','muted'); end if;
    k := coalesce(a->>'k','text');
    if k not in ('text','img','vid','file') then return jsonb_build_object('err','bad'); end if;
    if not ismain then
      if k='text' and not coalesce(pr.txt,false) then return jsonb_build_object('err','perm'); end if;
      if k='img' and not coalesce(pr.img,false) then return jsonb_build_object('err','perm'); end if;
      if k='vid' and not coalesce(pr.vid,false) then return jsonb_build_object('err','perm'); end if;
      if k='file' and not coalesce(pr.fil,false) then return jsonb_build_object('err','perm'); end if;
    end if;
    if length(coalesce(a->>'b',''))>2000 or length(coalesce(a->>'md',''))>4200000 then return jsonb_build_object('err','big'); end if;
    if k='text' and length(trim(coalesce(a->>'b','')))=0 then return jsonb_build_object('err','bad'); end if;
    if k<>'text' and coalesce(a->>'md','')='' then return jsonb_build_object('err','bad'); end if;
    if not exists (select 1 from public.f_rooms where id=(a->>'room')::int and status='on') then return jsonb_build_object('err','room'); end if;
    if (select count(*) from public.f_msgs where uname=who and created>now()-interval '1 minute')>=20 then return jsonb_build_object('err','many'); end if;
    insert into public.f_msgs(room,uname,kind,body,media,reply_to,qn)
      values((a->>'room')::int, who, k, coalesce(a->>'b',''), nullif(a->>'md',''), nullif(a->>'rt','')::bigint,
        (k='text' and coalesce(a->>'q','') in ('1','true') and nullif(a->>'rt','') is null)) returning id into rid;
    return jsonb_build_object('ok',1,'id',rid);
  end if;

  if op='fdel' then
    update public.f_msgs set del=true where id=(a->>'id')::bigint and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='freact' then
    if (a->>'e') not in ('👍','❤️','😂','🙏') then return jsonb_build_object('err','bad'); end if;
    if exists (select 1 from public.f_react where msg=(a->>'id')::bigint and uname=who and e=a->>'e') then
      delete from public.f_react where msg=(a->>'id')::bigint and uname=who;
    else
      insert into public.f_react(msg,uname,e) values((a->>'id')::bigint,who,a->>'e')
        on conflict (msg,uname) do update set e=excluded.e;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='fav_set' then
    if length(coalesce(a->>'img',''))>200000 then return jsonb_build_object('err','big'); end if;
    insert into public.f_prof(uname,avatar) values(who,coalesce(a->>'img','')) on conflict (uname) do update set avatar=excluded.avatar;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if exists (select 1 from public.f_reqs where uname=who and status='new') then return jsonb_build_object('err','dup'); end if;
    insert into public.f_reqs(uname,want) values(who,coalesce(a->'want','{}'::jsonb));
    return jsonb_build_object('ok',1);
  end if;

  if op='freport' then
    insert into public.f_reports(msg,uname,why) values((a->>'id')::bigint,who,left(coalesce(a->>'why',''),200));
    return jsonb_build_object('ok',1);
  end if;

  -- فقط ادمین اصلی
  if not ismain then return jsonb_build_object('err','denied'); end if;

  if op='freq_list' then
    return jsonb_build_object('ok',1,'reqs',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'u',q.uname,'want',q.want,'t',q.created,
      'av',coalesce((select avatar from public.f_prof where uname=q.uname),'')) order by q.id) from public.f_reqs q where q.status='new'),'[]'::jsonb));
  end if;

  if op='freq_ok' then
    insert into public.f_perm(uname,txt,img,vid,fil)
      select q.uname, coalesce((a->>'txt')::boolean,(q.want->>'txt')::boolean,true), coalesce((a->>'img')::boolean,(q.want->>'img')::boolean,false),
             coalesce((a->>'vid')::boolean,(q.want->>'vid')::boolean,false), coalesce((a->>'fil')::boolean,(q.want->>'fil')::boolean,false)
      from public.f_reqs q where q.id=(a->>'id')::bigint
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    update public.f_reqs set status='ok' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq_no' then
    update public.f_reqs set status='no' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_set' then
    insert into public.f_perm(uname,txt,img,vid,fil) values(a->>'uname',coalesce((a->>'txt')::boolean,false),coalesce((a->>'img')::boolean,false),coalesce((a->>'vid')::boolean,false),coalesce((a->>'fil')::boolean,false))
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_list' then
    return jsonb_build_object('ok',1,'perms',coalesce((select jsonb_agg(to_jsonb(x) order by x.uname) from public.f_perm x),'[]'::jsonb));
  end if;

  if op='fmute' then
    insert into public.f_perm(uname,muted) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set muted=excluded.muted;
    return jsonb_build_object('ok',1);
  end if;

  if op='fblock' then
    insert into public.f_perm(uname,blocked) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set blocked=excluded.blocked;
    return jsonb_build_object('ok',1);
  end if;

  if op='fsolve' then
    if who='' then return jsonb_build_object('err','login'); end if;
    update public.f_msgs set sol=coalesce((a->>'on')::boolean,true)
      where id=(a->>'id')::bigint and qn and del=false and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='arep' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if (select count(*) from public.f_arep where uname=who and created>now()-interval '1 minute')>=10 then return jsonb_build_object('err','many'); end if;
    insert into public.f_arep(ad,uname,why) values((a->>'ad')::bigint, who, left(coalesce(a->>'why',''),150))
      on conflict (ad,uname) do update set why=excluded.why, created=now(), st='new';
    return jsonb_build_object('ok',1);
  end if;

  if op='arep_list' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',z.ad,'n',z.n,'why',z.ws,'t',z.t) order by z.n desc, z.t desc)
      from (select ad, count(*) n, max(created) t, (array_agg(why order by created desc) filter (where why<>''))[1:3] ws
            from public.f_arep where st='new' group by ad order by count(*) desc, max(created) desc limit 100) z),'[]'::jsonb));
  end if;

  if op='arep_done' then
    if not (ismain or (who<>'' and (me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')) then return jsonb_build_object('err','denied'); end if;
    update public.f_arep set st='done' where ad=(a->>'ad')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='myorders' then
    if who='' then return jsonb_build_object('err','login'); end if;
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'dt',z.d->>'dt','tt',z.d->'tt','st',coalesce(z.d->>'st','new'),'it',coalesce(z.d->'it','[]'::jsonb)) order by z.id desc)
      from (select id,d from public.orders where d->>'u'=who order by id desc limit 50) z),'[]'::jsonb));
  end if;

  if op='ptoken' or op='ptoken_del' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if length(coalesce(a->>'t',''))<20 then return jsonb_build_object('err','bad'); end if;
    if op='ptoken' then
      insert into public.f_push(token,uname,upd) values(a->>'t',who,now())
        on conflict (token) do update set uname=excluded.uname, upd=now();
    else
      delete from public.f_push where token=a->>'t' and uname=who;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='adx_list' then
    return jsonb_build_object('ok',1,'l',coalesce((select jsonb_agg(jsonb_build_object('ad',ad,'s',coalesce(sold,false),'r',ren))
      from public.f_adx where coalesce(sold,false) or ren>now()-interval '30 days'),'[]'::jsonb));
  end if;

  if op='adx_sold' or op='adx_renew' then
    if who='' then return jsonb_build_object('err','login'); end if;
    if not (ismain
        or ((me->>'role')='admin' and coalesce(me->'pm','[]'::jsonb) ? 'a')
        or exists(select 1 from public.ads x where x.id=(a->>'ad')::bigint and x.d->>'own'=who)) then
      return jsonb_build_object('err','denied');
    end if;
    if op='adx_sold' then
      insert into public.f_adx(ad,sold) values((a->>'ad')::bigint, coalesce((a->>'on')::boolean,true))
        on conflict (ad) do update set sold=excluded.sold, upd=now();
      return jsonb_build_object('ok',1);
    end if;
    if not ismain and exists(select 1 from public.f_adx where ad=(a->>'ad')::bigint and ren>now()-interval '1 day') then
      return jsonb_build_object('err','wait');
    end if;
    insert into public.f_adx(ad,ren) values((a->>'ad')::bigint, now())
      on conflict (ad) do update set ren=now(), upd=now();
    return jsonb_build_object('ok',1);
  end if;

  if op='fpin' then
    update public.f_msgs set pinned=coalesce((a->>'on')::boolean,true) where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freport_list' then
    return jsonb_build_object('ok',1,'reports',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'msg',r.msg,'u',r.uname,'why',r.why,'t',r.created,'body',(select left(body,120) from public.f_msgs where id=r.msg),'by',(select uname from public.f_msgs where id=r.msg)) order by r.id desc) from public.f_reports r),'[]'::jsonb));
  end if;

  if op='freport_del' then
    delete from public.f_reports where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_set' then
    if length(trim(coalesce(a->>'name','x')))=0 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_rooms(name,emoji,sort,color) values(left(coalesce(a->>'name','اتاق'),60),left(coalesce(a->>'emoji','💬'),8),coalesce((a->>'sort')::int,(select coalesce(max(sort),0)+1 from public.f_rooms)),left(coalesce(a->>'color',''),9)) returning id into rid;
      return jsonb_build_object('ok',1,'id',rid);
    else
      update public.f_rooms set name=left(coalesce(a->>'name',name),60), emoji=left(coalesce(a->>'emoji',emoji),8), color=left(coalesce(a->>'color',color),9), sort=coalesce((a->>'sort')::int,sort), status=coalesce(a->>'status',status) where id=(a->>'id')::int;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_del' then
    delete from public.f_rooms where id=(a->>'id')::int;
    return jsonb_build_object('ok',1);
  end if;

  if op='fedit' then
    if length(trim(coalesce(a->>'b','')))=0 or length(a->>'b')>2000 then return jsonb_build_object('err','bad'); end if;
    update public.f_msgs set body=a->>'b', ed=true where id=(a->>'id')::bigint and kind='text';
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_set' then
    if length(trim(coalesce(a->>'q','')))=0 or length(a->>'q')>400 or length(coalesce(a->>'a',''))>1500 then return jsonb_build_object('err','bad'); end if;
    if (a->>'id') is null then
      insert into public.f_faq(room,qu,q,a,sort) values((a->>'room')::int,left(coalesce(nullif(trim(a->>'qu'),''),'کاربر نمونه'),40),a->>'q',coalesce(a->>'a',''),(select coalesce(max(sort),0)+1 from public.f_faq where room=(a->>'room')::int));
    else
      update public.f_faq set qu=left(coalesce(nullif(trim(a->>'qu'),''),qu),40), q=a->>'q', a=coalesce(a->>'a',a) where id=(a->>'id')::bigint;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='ffaq_del' then
    delete from public.f_faq where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.fapp(text,text,text,jsonb) to anon, authenticated;


-- پرسش و پاسخ‌های نمونه (فقط اگر هنوز هیچ پرسشی نیست؛ ادمین از داخل برنامه ویرایش/حذف می‌کند)
insert into public.f_faq(room,qu,q,a,sort)
select r.id, x.qu, x.q, x.a, x.s from public.f_rooms r
join (values
 ('گفتگوی عمومی پرندگان','کاربر نمونه 1','برای شروع نگهداری از طوطی‌سانان چه چیزهایی لازم است؟','قفس بزرگ و تمیز، غذای متنوع (دانه، میوه و سبزی تازه)، آب تمیز، اسباب‌بازی و زمان بیرون‌آوردن از قفس. قبل از خرید حتماً درباره‌ی نیازهای گونه‌ی موردنظر تحقیق کنید.',1),
 ('جوجه‌کشی و تخم‌گذاری','کاربر نمونه 2','جفتم تخم گذاشته؛ چند روز تا جوجه‌درآوردن طول می‌کشد؟','بسته به گونه معمولاً بین ۱۸ تا ۲۸ روز. محیط آرام، دمای ثابت و تغذیه‌ی کافی مهم است؛ لانه را زیاد دستکاری نکنید.',1),
 ('سلامت و بیماری','کاربر نمونه 3','پرنده‌ام پرهایش را پف کرده و کم‌غذا شده؛ چه کنم؟','این‌ها می‌تواند نشانه‌ی بیماری باشد. پرنده را گرم و آرام نگه دارید و هرچه زودتر به دامپزشک پرندگان مراجعه کنید. خودسرانه دارو ندهید.',1),
 ('خرید و فروش','کاربر نمونه 4','هنگام خرید پرنده چه نکاتی را بررسی کنم؟','پرنده فعال و چشم‌ها روشن باشد، پرها مرتب، مدفوع سالم. اگر امکان دارد پرنده را حضوری ببینید و درباره‌ی سن و سابقه‌ی سلامت بپرسید.',1)
) as x(rn,qu,q,a,s) on x.rn=r.name
where not exists (select 1 from public.f_faq);
