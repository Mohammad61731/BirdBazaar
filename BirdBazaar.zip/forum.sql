-- انجمن بازارچه پرندگان (F1) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت کاربر: از همان تابع اصلی public.app (op=login) بررسی می‌شود؛ ادمین اصلی = role admin و pm شامل all.

create table if not exists public.f_rooms(
  id serial primary key, name text not null, emoji text default '💬', sort int default 0, status text default 'on');
create table if not exists public.f_msgs(
  id bigserial primary key, room int references public.f_rooms(id) on delete cascade,
  uname text not null, kind text not null default 'text', body text default '', media text,
  reply_to bigint, pinned boolean default false, del boolean default false, created timestamptz default now());
create index if not exists f_msgs_room_id on public.f_msgs(room, id desc);
create table if not exists public.f_perm(
  uname text primary key, txt boolean default false, img boolean default false, vid boolean default false,
  fil boolean default false, muted boolean default false, blocked boolean default false);
create table if not exists public.f_reqs(
  id bigserial primary key, uname text not null, want jsonb default '{}'::jsonb, status text default 'new', created timestamptz default now());
create table if not exists public.f_react(
  msg bigint references public.f_msgs(id) on delete cascade, uname text, e text, primary key(msg, uname));
create table if not exists public.f_reports(
  id bigserial primary key, msg bigint, uname text, why text default '', created timestamptz default now());
create table if not exists public.f_prof(uname text primary key, avatar text default '');

alter table public.f_rooms enable row level security;
alter table public.f_msgs enable row level security;
alter table public.f_perm enable row level security;
alter table public.f_reqs enable row level security;
alter table public.f_react enable row level security;
alter table public.f_reports enable row level security;
alter table public.f_prof enable row level security;

insert into public.f_rooms(name,emoji,sort)
select x.n, x.e, x.s from (values ('گفتگوی عمومی پرندگان','🦜',1),('جوجه‌کشی و تخم‌گذاری','🥚',2),('سلامت و بیماری','🩺',3),('خرید و فروش','🛒',4)) as x(n,e,s)
where not exists (select 1 from public.f_rooms);

create or replace function public.fapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare
  me jsonb := null; who text := ''; ismain boolean := false;
  pr public.f_perm; k text; rid bigint; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='fping' then return jsonb_build_object('ok',1); end if;

  -- هویت (اختیاری): از تابع اصلی app
  if coalesce(u,'')<>'' then
    begin
      me := public.app('login', u, p, '{}'::jsonb);
    exception when others then
      me := null;
    end;
    if me is not null and (me ? 'err' or coalesce(me->>'role','')='') then me := null; end if;
    if me is not null then
      who := u;
      ismain := ((me->>'role')='admin') and (coalesce(me->'pm','[]'::jsonb) ? 'all');
    end if;
  end if;
  select * into pr from public.f_perm where uname=who;

  if op='fwho' then
    return jsonb_build_object('ok',1,'me',who,'role',coalesce(me->>'role',''),'main',ismain,
      'perm',jsonb_build_object('txt',ismain or coalesce(pr.txt,false),'img',ismain or coalesce(pr.img,false),'vid',ismain or coalesce(pr.vid,false),'fil',ismain or coalesce(pr.fil,false),'muted',coalesce(pr.muted,false),'blocked',coalesce(pr.blocked,false)),
      'avatar',coalesce((select avatar from public.f_prof where uname=who),''));
  end if;

  if op='fpull' then
    n := least(greatest(coalesce((a->>'n')::int,30),1),60);
    return jsonb_build_object('ok',1,
      'rooms',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'name',r.name,'emoji',r.emoji) order by r.sort,r.id) from public.f_rooms r where r.status='on'),'[]'::jsonb),
      'msgs',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'k',m.kind,'b',m.body,'md',m.media,'rt',m.reply_to,'pin',m.pinned,'t',m.created,
              'r',coalesce((select jsonb_object_agg(x.e,x.c) from (select e,count(*) c from public.f_react where msg=m.id group by e) x),'{}'::jsonb)) order by m.id)
              from (select * from public.f_msgs where room=(a->>'room')::int and del=false
                     and id>coalesce((a->>'after')::bigint,0) and id<coalesce((a->>'before')::bigint,9223372036854775807)
                     order by id desc limit n) m),'[]'::jsonb),
      'av',coalesce((select jsonb_object_agg(f.uname,f.avatar) from public.f_prof f where f.avatar<>'' and f.uname in
              (select distinct uname from (select uname from public.f_msgs where room=(a->>'room')::int and del=false order by id desc limit 60) z)),'{}'::jsonb),
      'pins',coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'u',m.uname,'b',left(m.body,120))) from public.f_msgs m where m.room=(a->>'room')::int and m.pinned and m.del=false),'[]'::jsonb),
      'reqn',case when ismain then (select count(*) from public.f_reqs where status='new') else 0 end);
  end if;

  if who='' then return jsonb_build_object('err','login'); end if;

  if op='fsend' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if coalesce(pr.muted,false) and not ismain then return jsonb_build_object('err','muted'); end if;
    k := coalesce(a->>'k','text');
    if k not in ('text','img','vid','file') then return jsonb_build_object('err','bad'); end if;
    if not ismain then
      if k='text' and not coalesce(pr.txt,false) then return jsonb_build_object('err','perm'); end if;
      if k='img' and not coalesce(pr.img,false) then return jsonb_build_object('err','perm'); end if;
      if k='vid' and not coalesce(pr.vid,false) then return jsonb_build_object('err','perm'); end if;
      if k='file' and not coalesce(pr.fil,false) then return jsonb_build_object('err','perm'); end if;
    end if;
    if length(coalesce(a->>'b',''))>2000 or length(coalesce(a->>'md',''))>4200000 then return jsonb_build_object('err','big'); end if;
    if k='text' and length(trim(coalesce(a->>'b','')))=0 then return jsonb_build_object('err','bad'); end if;
    if k<>'text' and coalesce(a->>'md','')='' then return jsonb_build_object('err','bad'); end if;
    if not exists (select 1 from public.f_rooms where id=(a->>'room')::int and status='on') then return jsonb_build_object('err','room'); end if;
    if (select count(*) from public.f_msgs where uname=who and created>now()-interval '1 minute')>=20 then return jsonb_build_object('err','many'); end if;
    insert into public.f_msgs(room,uname,kind,body,media,reply_to)
      values((a->>'room')::int, who, k, coalesce(a->>'b',''), nullif(a->>'md',''), nullif(a->>'rt','')::bigint) returning id into rid;
    return jsonb_build_object('ok',1,'id',rid);
  end if;

  if op='fdel' then
    update public.f_msgs set del=true where id=(a->>'id')::bigint and (ismain or uname=who);
    return jsonb_build_object('ok',1);
  end if;

  if op='freact' then
    if (a->>'e') not in ('👍','❤️','😂','🙏') then return jsonb_build_object('err','bad'); end if;
    if exists (select 1 from public.f_react where msg=(a->>'id')::bigint and uname=who and e=a->>'e') then
      delete from public.f_react where msg=(a->>'id')::bigint and uname=who;
    else
      insert into public.f_react(msg,uname,e) values((a->>'id')::bigint,who,a->>'e')
        on conflict (msg,uname) do update set e=excluded.e;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  if op='fav_set' then
    if length(coalesce(a->>'img',''))>200000 then return jsonb_build_object('err','big'); end if;
    insert into public.f_prof(uname,avatar) values(who,coalesce(a->>'img','')) on conflict (uname) do update set avatar=excluded.avatar;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq' then
    if coalesce(pr.blocked,false) then return jsonb_build_object('err','blocked'); end if;
    if exists (select 1 from public.f_reqs where uname=who and status='new') then return jsonb_build_object('err','dup'); end if;
    insert into public.f_reqs(uname,want) values(who,coalesce(a->'want','{}'::jsonb));
    return jsonb_build_object('ok',1);
  end if;

  if op='freport' then
    insert into public.f_reports(msg,uname,why) values((a->>'id')::bigint,who,left(coalesce(a->>'why',''),200));
    return jsonb_build_object('ok',1);
  end if;

  -- فقط ادمین اصلی
  if not ismain then return jsonb_build_object('err','denied'); end if;

  if op='freq_list' then
    return jsonb_build_object('ok',1,'reqs',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'u',q.uname,'want',q.want,'t',q.created,
      'av',coalesce((select avatar from public.f_prof where uname=q.uname),'')) order by q.id) from public.f_reqs q where q.status='new'),'[]'::jsonb));
  end if;

  if op='freq_ok' then
    insert into public.f_perm(uname,txt,img,vid,fil)
      select q.uname, coalesce((a->>'txt')::boolean,(q.want->>'txt')::boolean,true), coalesce((a->>'img')::boolean,(q.want->>'img')::boolean,false),
             coalesce((a->>'vid')::boolean,(q.want->>'vid')::boolean,false), coalesce((a->>'fil')::boolean,(q.want->>'fil')::boolean,false)
      from public.f_reqs q where q.id=(a->>'id')::bigint
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    update public.f_reqs set status='ok' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freq_no' then
    update public.f_reqs set status='no' where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_set' then
    insert into public.f_perm(uname,txt,img,vid,fil) values(a->>'uname',coalesce((a->>'txt')::boolean,false),coalesce((a->>'img')::boolean,false),coalesce((a->>'vid')::boolean,false),coalesce((a->>'fil')::boolean,false))
      on conflict (uname) do update set txt=excluded.txt, img=excluded.img, vid=excluded.vid, fil=excluded.fil;
    return jsonb_build_object('ok',1);
  end if;

  if op='fperm_list' then
    return jsonb_build_object('ok',1,'perms',coalesce((select jsonb_agg(to_jsonb(x) order by x.uname) from public.f_perm x),'[]'::jsonb));
  end if;

  if op='fmute' then
    insert into public.f_perm(uname,muted) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set muted=excluded.muted;
    return jsonb_build_object('ok',1);
  end if;

  if op='fblock' then
    insert into public.f_perm(uname,blocked) values(a->>'uname',coalesce((a->>'on')::boolean,true)) on conflict (uname) do update set blocked=excluded.blocked;
    return jsonb_build_object('ok',1);
  end if;

  if op='fpin' then
    update public.f_msgs set pinned=coalesce((a->>'on')::boolean,true) where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='freport_list' then
    return jsonb_build_object('ok',1,'reports',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'msg',r.msg,'u',r.uname,'why',r.why,'t',r.created,'body',(select left(body,120) from public.f_msgs where id=r.msg),'by',(select uname from public.f_msgs where id=r.msg)) order by r.id desc) from public.f_reports r),'[]'::jsonb));
  end if;

  if op='freport_del' then
    delete from public.f_reports where id=(a->>'id')::bigint;
    return jsonb_build_object('ok',1);
  end if;

  if op='froom_set' then
    if (a->>'id') is null then
      insert into public.f_rooms(name,emoji,sort) values(left(coalesce(a->>'name','اتاق'),60),coalesce(a->>'emoji','💬'),coalesce((a->>'sort')::int,9));
    else
      update public.f_rooms set name=coalesce(a->>'name',name), emoji=coalesce(a->>'emoji',emoji), sort=coalesce((a->>'sort')::int,sort), status=coalesce(a->>'status',status) where id=(a->>'id')::int;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.fapp(text,text,text,jsonb) to anon, authenticated;
