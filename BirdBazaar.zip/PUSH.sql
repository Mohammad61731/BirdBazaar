-- اعلان گوشی (۹-ب مرحله‌ی ۲) — بعد از forum.sql در SQL Editor اجرا شود. چند بار اجرا بی‌خطر است.
-- پیش‌نیاز: Edge Function با نام push (supabase_functions/push.ts) و Secrets (PUSH_SETUP.txt).
-- کلید PUSH_KEY در این فایل نیست؛ جدا با یک دستور کوتاه گذاشته می‌شود.

create extension if not exists pg_net with schema extensions;
create table if not exists public.f_conf(k text primary key, v text);
alter table public.f_conf enable row level security;
insert into public.f_conf(k,v) values('pushurl','https://axgntmiouzwfotestwcs.supabase.co/functions/v1/push')
  on conflict (k) do update set v=excluded.v;

create or replace function public.f_push_send(unames text[], ttl text, bdy text)
returns void language plpgsql security definer set search_path=public, extensions as $$
declare kk text; uu text;
begin
  select v into kk from public.f_conf where k='pushkey';
  select v into uu from public.f_conf where k='pushurl';
  if coalesce(kk,'')='' or coalesce(uu,'')='' or unames is null or coalesce(array_length(unames,1),0)=0 then return; end if;
  perform net.http_post(url:=uu, body:=jsonb_build_object('users',to_jsonb(unames),'title',ttl,'body',left(coalesce(bdy,''),120)),
    headers:=jsonb_build_object('Content-Type','application/json','x-push-key',kk));
exception when others then null;
end $$;

-- پیام‌ها (m_msgs)
create or replace function public.f_trg_msg() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[]; t text := '📨 پیام جدید';
begin
  if coalesce(new.to_u,'')<>'' then r:=array[new.to_u];
  elsif new.grp='all' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u);
  elsif new.grp='admin' then t:='🛡 پیام مدیران'; r:=array(select username from public.staff where username<>new.from_u);
  elsif new.grp='booth' then t:='🏪 پیام غرفه‌داران'; r:=array(select owner from public.booths where owner<>new.from_u);
  elsif new.grp='user' then t:='📢 پیام مدیریت'; r:=array(select distinct uname from public.f_push where uname<>new.from_u
      and uname not in (select username from public.staff) and uname not in (select owner from public.booths));
  end if;
  perform public.f_push_send(r, t, new.body);
  return new;
exception when others then return new;
end $$;

-- سفارش اصلی (orders) → ادمین‌هایی که مجوز سفارش‌ها دارند
create or replace function public.f_trg_order() returns trigger language plpgsql security definer set search_path=public, extensions as $$
declare r text[];
begin
  r:=array(select username from public.staff where (to_jsonb(perms) ? 'o') or (to_jsonb(perms) ? 'all'));
  perform public.f_push_send(r, '🛒 سفارش جدید', coalesce(new.d->>'cu','')||' — '||coalesce(new.d->>'tt','')||' تومان');
  return new;
exception when others then return new;
end $$;

-- سفارش غرفه (booth_orders) → صاحب غرفه
create or replace function public.f_trg_border() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '🛒 سفارش جدید غرفه', coalesce(new.name,''));
  return new;
exception when others then return new;
end $$;

-- گفتگوی کاربر ↔ غرفه‌دار (c_msgs)
create or replace function public.f_trg_chat() returns trigger language plpgsql security definer set search_path=public, extensions as $$
begin
  if new.side='u' then
    perform public.f_push_send(array(select owner from public.booths where id=new.booth_id), '💬 پیام جدید از مشتری', case when new.k='t' then new.body else '📎' end);
  else
    perform public.f_push_send(array[new.cu], '💬 پاسخ غرفه‌دار', case when new.k='t' then new.body else '📎' end);
  end if;
  return new;
exception when others then return new;
end $$;

do $$ begin
  if to_regclass('public.m_msgs') is not null then
    drop trigger if exists f_push_msg on public.m_msgs;
    create trigger f_push_msg after insert on public.m_msgs for each row execute function public.f_trg_msg();
  end if;
  if to_regclass('public.orders') is not null then
    drop trigger if exists f_push_order on public.orders;
    create trigger f_push_order after insert on public.orders for each row execute function public.f_trg_order();
  end if;
  if to_regclass('public.booth_orders') is not null then
    drop trigger if exists f_push_border on public.booth_orders;
    create trigger f_push_border after insert on public.booth_orders for each row execute function public.f_trg_border();
  end if;
  if to_regclass('public.c_msgs') is not null then
    drop trigger if exists f_push_chat on public.c_msgs;
    create trigger f_push_chat after insert on public.c_msgs for each row execute function public.f_trg_chat();
  end if;
end $$;
