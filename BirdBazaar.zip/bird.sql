-- ===== BirdBazaar: سالن فروش و پرورش (مورد ۱۰) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- پیش‌نیاز: booth.sql قبلاً اجرا شده باشد (جدول booths). به bapp دست نمی‌زند؛ تابع جدید rapp می‌سازد.
create table if not exists public.booth_birds(
  id bigserial primary key,
  booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null,
  k text default 'sale',
  status text default 'on',
  created timestamptz default now());
alter table public.booth_birds enable row level security;

create or replace function public.rapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; me jsonb := null; nid bigint; kk text;
begin
  a := coalesce(a,'{}'::jsonb);

  -- عمومی: پرنده‌های روشن غرفه‌های فعال
  if op='rpublic' then
    return jsonb_build_object('ok',1,'birds',coalesce((
      select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'bn',x.name,'ph',x.phone,'city',x.city,'d',q.d,'k',q.k,'t',q.created) order by q.id desc)
      from (select * from booth_birds where status='on' order by id desc limit 120) q
      join booths x on x.id=q.booth_id where x.status='active'),'[]'::jsonb));
  end if;

  if op in ('rme','rset','rdel') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then
      begin
        me := public.app('login', u, p, '{}'::jsonb);
      exception when others then
        me := null;
      end;
      if me is not null and not (me ? 'err') and coalesce(me->>'role','')<>'' then
        select * into b from booths where owner=u and status<>'off';
      end if;
      if b.id is null then return jsonb_build_object('err','denied'); end if;
    end if;

    if op='rme' then
      return jsonb_build_object('ok',1,'birds',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'k',q.k,'s',q.status,'t',q.created) order by q.id desc) from booth_birds q where q.booth_id=b.id),'[]'::jsonb));
    end if;

    if op='rset' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      kk := case when (a->>'k')='show' then 'show' else 'sale' end;
      if (a->>'id') is null then
        if (select count(*) from booth_birds where booth_id=b.id)>=60 then return jsonb_build_object('err','many'); end if;
        insert into booth_birds(booth_id,d,k,status) values(b.id,a->'d',kk,case when (a->>'s')='off' then 'off' else 'on' end) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_birds set d=coalesce(a->'d',d), k=kk, status=case when (a->>'s') in ('on','off') then a->>'s' else status end where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='rdel' then
      delete from booth_birds where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  return jsonb_build_object('err','op');
end $$;
grant execute on function public.rapp(text,text,text,jsonb) to anon, authenticated;
