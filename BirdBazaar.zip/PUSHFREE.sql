-- اعلان آزاد ادمین (مورد ۱۵) — بعد از PUSH.sql اجرا شود. چند بار اجرا بی‌خطر است. به توابع قبلی دست نمی‌زند.
create or replace function public.pnapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; isadm boolean; ismain boolean; g text; t text; ttl text; b text; r text[];
begin
  a := coalesce(a,'{}'::jsonb);
  if op<>'pnotify' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  if not isadm then return jsonb_build_object('err','perm'); end if;
  b := left(btrim(coalesce(a->>'b','')),120);
  ttl := left(btrim(coalesce(a->>'title','')),60);
  if length(b)<1 then return jsonb_build_object('err','bad'); end if;
  if ttl='' then ttl := '📢 بازارچه پرندگان'; end if;
  g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
  if g is not null then
    if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
    if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
    if g='all' then r:=array(select distinct uname from public.f_push);
    elsif g='admin' then r:=array(select distinct username from public.staff);
    elsif g='booth' then r:=array(select distinct owner from public.booths);
    else r:=array(select distinct uname from public.f_push where uname not in (select username from public.staff) and uname not in (select owner from public.booths));
    end if;
  else
    if t is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
    r:=array[t];
  end if;
  perform public.f_push_send(r, ttl, b);
  return jsonb_build_object('ok',1,'n',coalesce(array_length(r,1),0),
    'reg',(select count(distinct uname) from public.f_push where uname=any(r)));
end $$;
grant execute on function public.pnapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as pushfree;
