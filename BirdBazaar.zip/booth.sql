-- ===== BirdBazaar: غرفه‌داران (G1) =====
-- اجرا: Supabase > SQL Editor > کل این فایل را بچسبان > Run. چند بار اجرا هم بی‌خطر است.
-- بعد از اجرا حتماً رمز مدیریت را عوض کن (آخر فایل).
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.booths(
  id bigserial primary key, owner text unique not null, pw text not null,
  name text not null, bio text default '', logo text default '', cover text default '',
  city text default '', phone text default '', status text default 'active',
  views int default 0, created timestamptz default now());
create table if not exists public.booth_products(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  d jsonb not null, status text default 'on', created timestamptz default now());
create table if not exists public.booth_views(
  booth_id bigint references public.booths(id) on delete cascade, day date, n int default 0,
  primary key(booth_id,day));
create table if not exists public.booth_reqs(
  id bigserial primary key, name text, phone text, city text, shop text, about text,
  status text default 'new', created timestamptz default now());
create table if not exists public.bcfg(k text primary key, v text);

alter table public.booths enable row level security;
alter table public.booth_products enable row level security;
alter table public.booth_views enable row level security;
create table if not exists public.booth_orders(
  id bigserial primary key, booth_id bigint references public.booths(id) on delete cascade,
  name text, phone text, addr text default '', lines jsonb not null default '[]'::jsonb,
  total bigint default 0, status text default 'new', created timestamptz default now());
alter table public.booth_reqs enable row level security;
alter table public.booth_orders enable row level security;
alter table public.bcfg enable row level security;

insert into public.bcfg values('admin_key','CHANGE_ME_123') on conflict do nothing;

create or replace function public.bapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare b public.booths; adm boolean; r jsonb; nid bigint; bid bigint;
begin
  a := coalesce(a,'{}'::jsonb);
  adm := (a->>'k') is not null and (a->>'k') = (select v from bcfg where k='admin_key');

  if op='bpublic' then
    return jsonb_build_object('ok',1,
      'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'name',x.name,'bio',x.bio,'logo',x.logo,'cover',x.cover,'city',x.city,'phone',x.phone,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id and q.status='on')) order by x.id) from booths x where x.status='active'),'[]'::jsonb),
      'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'b',q.booth_id,'d',q.d,'t',q.created) order by q.id desc) from booth_products q join booths x on x.id=q.booth_id where x.status='active' and q.status='on'),'[]'::jsonb));
  end if;

  if op='bview' then
    bid := (a->>'id')::bigint;
    if not exists(select 1 from booths where id=bid and status='active') then return jsonb_build_object('err','none'); end if;
    insert into booth_views(booth_id,day,n) values(bid,current_date,1) on conflict(booth_id,day) do update set n=booth_views.n+1;
    update booths set views=views+1 where id=bid;
    return jsonb_build_object('ok',1);
  end if;

  if op='breq' then
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_reqs where phone=a->>'phone' and status='new')>=3 then return jsonb_build_object('err','dup'); end if;
    insert into booth_reqs(name,phone,city,shop,about) values(left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'city',''),60),left(coalesce(a->>'shop',''),80),left(coalesce(a->>'about',''),600));
    return jsonb_build_object('ok',1);
  end if;

  -- ثبت سفارش مشتری (O1) — عمومی
  if op='bord' then
    if jsonb_typeof(a->'lines')<>'array' or jsonb_array_length(a->'lines')=0 or jsonb_array_length(a->'lines')>40 then return jsonb_build_object('err','bad'); end if;
    if length(coalesce(a->>'name',''))<2 or length(coalesce(a->>'phone',''))<7 then return jsonb_build_object('err','bad'); end if;
    if (select count(*) from booth_orders where phone=left(a->>'phone',30) and created>now()-interval '1 hour')>=5 then return jsonb_build_object('err','many'); end if;
    select * into b from booths where id=(a->>'b')::bigint and status='active';
    if not found then return jsonb_build_object('err','off'); end if;
    insert into booth_orders(booth_id,name,phone,addr,lines,total) values(b.id,left(a->>'name',80),left(a->>'phone',30),left(coalesce(a->>'addr',''),400),a->'lines',coalesce((a->>'total')::bigint,0));
    return jsonb_build_object('ok',1);
  end if;

  -- ورود غرفه‌دار
  if op in ('blogin','bme','bprod_set','bprod_del','bset','bpw','bords','bord_st') then
    select * into b from booths where owner=u and pw=crypt(p,pw) and status<>'off';
    if not found then return jsonb_build_object('err','denied'); end if;

    if op in ('blogin','bme') then
      return jsonb_build_object('ok',1,
        'booth',jsonb_build_object('id',b.id,'name',b.name,'bio',b.bio,'logo',b.logo,'cover',b.cover,'city',b.city,'phone',b.phone,'views',b.views,'status',b.status),
        'prods',coalesce((select jsonb_agg(jsonb_build_object('id',q.id,'d',q.d,'s',q.status,'t',q.created) order by q.id desc) from booth_products q where q.booth_id=b.id),'[]'::jsonb),
        'days',coalesce((select jsonb_agg(jsonb_build_object('day',v.day,'n',v.n) order by v.day) from booth_views v where v.booth_id=b.id and v.day>=current_date-6),'[]'::jsonb));
    end if;

    if op='bprod_set' then
      if length((a->'d')::text)>900000 then return jsonb_build_object('err','big'); end if;
      if (a->>'id') is null then
        insert into booth_products(booth_id,d,status) values(b.id,a->'d',coalesce(a->>'s','on')) returning id into nid;
      else
        nid := (a->>'id')::bigint;
        update booth_products set d=a->'d', status=coalesce(a->>'s',status) where id=nid and booth_id=b.id;
      end if;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='bords' then
      return jsonb_build_object('ok',1,'orders',coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'phone',o.phone,'addr',o.addr,'lines',o.lines,'total',o.total,'s',o.status,'t',o.created) order by o.id desc) from (select * from booth_orders where booth_id=b.id order by id desc limit 100) o),'[]'::jsonb));
    end if;
    if op='bord_st' then
      update booth_orders set status=a->>'s' where id=(a->>'id')::bigint and booth_id=b.id and (a->>'s') in ('new','done','cancel');
      return jsonb_build_object('ok',1);
    end if;

    if op='bprod_del' then
      delete from booth_products where id=(a->>'id')::bigint and booth_id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bset' then
      update booths set name=left(coalesce(nullif(a->>'name',''),name),80), bio=left(coalesce(a->>'bio',bio),600),
        logo=coalesce(a->>'logo',logo), cover=coalesce(a->>'cover',cover), city=left(coalesce(a->>'city',city),60), phone=left(coalesce(a->>'phone',phone),30)
      where id=b.id;
      return jsonb_build_object('ok',1);
    end if;

    if op='bpw' then
      if length(coalesce(a->>'np',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'np',gen_salt('bf')) where id=b.id;
      return jsonb_build_object('ok',1);
    end if;
  end if;

  -- مدیریت (نیازمند رمز مدیریت a.k)
  if op like 'badm_%' then
    if not adm then return jsonb_build_object('err','denied'); end if;

    if op='badm_list' then
      return jsonb_build_object('ok',1,
        'reqs',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from booth_reqs x where x.status='new'),'[]'::jsonb),
        'booths',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'owner',x.owner,'name',x.name,'city',x.city,'phone',x.phone,'status',x.status,'views',x.views,'n',(select count(*) from booth_products q where q.booth_id=x.id)) order by x.id desc) from booths x),'[]'::jsonb));
    end if;

    if op='badm_approve' then
      if length(coalesce(a->>'owner',''))<3 or length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      if exists(select 1 from booths where owner=a->>'owner') then return jsonb_build_object('err','taken'); end if;
      insert into booths(owner,pw,name,city,phone)
        select a->>'owner',crypt(a->>'pw',gen_salt('bf')),coalesce(nullif(shop,''),name),city,phone from booth_reqs where id=(a->>'id')::bigint
        returning id into nid;
      if nid is null then return jsonb_build_object('err','none'); end if;
      update booth_reqs set status='ok' where id=(a->>'id')::bigint;
      return jsonb_build_object('ok',1,'id',nid);
    end if;

    if op='badm_reject' then update booth_reqs set status='no' where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_status' then update booths set status=a->>'status' where id=(a->>'id')::bigint and (a->>'status') in ('active','off'); return jsonb_build_object('ok',1); end if;
    if op='badm_del' then delete from booths where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
    if op='badm_reset' then
      if length(coalesce(a->>'pw',''))<4 then return jsonb_build_object('err','bad'); end if;
      update booths set pw=crypt(a->>'pw',gen_salt('bf')) where id=(a->>'id')::bigint; return jsonb_build_object('ok',1);
    end if;
    if op='badm_pdel' then delete from booth_products where id=(a->>'id')::bigint; return jsonb_build_object('ok',1); end if;
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.bapp(text,text,text,jsonb) to anon, authenticated;

-- رمز مدیریت غرفه‌ها را عوض کن (فقط ادمین اصلی از آن در پنل استفاده می‌کند):
-- update public.bcfg set v='رمز-خودت' where k='admin_key';
