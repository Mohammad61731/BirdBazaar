-- بازارچه پرندگان: PSIG + PUSHFREE در یک فایل (بعد از forum.sql و PUSH.sql). چندبار اجرا بی‌خطر.
-- اگر پنجره‌ی RLS آمد «Run without RLS». آخرین خروجی باید ok باشد.

-- ===== بخش ۱: PSIG (مهر کل برای کاهش Egress) — تابع fapp زنده را پچ می‌کند؛ چندبار اجرا بی‌خطر =====
do $psig$
declare def text; marker text := $m$  if op='fping' then return jsonb_build_object('ok',1); end if;$m$; blk text;
begin
  select pg_get_functiondef('public.fapp(text,text,text,jsonb)'::regprocedure) into def;
  if def like '%op=''psig''%' then raise notice 'psig already present'; return; end if;
  if position(marker in def)=0 then raise exception 'fapp marker not found'; end if;
  blk := marker || E'\n' || $b$
  if op='psig' then
    declare ps text; pb text;
    begin
      begin
        ps := md5(coalesce(public.app('public','','','{}'::jsonb)::text,'')||'|'||coalesce((select string_agg(x.id::text||x.d::text,'|' order by x.id) from public.ads x),''));
      exception when others then ps := null; end;
      begin
        pb := md5(coalesce(public.bapp('bpublic','','','{}'::jsonb)::text,''));
      exception when others then pb := null; end;
      begin
        if pb is not null then pb := md5(pb||coalesce(public.rapp('rpublic','','','{}'::jsonb)::text,'')); end if;
      exception when others then null; end;
      return jsonb_build_object('ok',case when ps is null then 0 else 1 end,'s',ps,'b',pb);
    end;
  end if;$b$;
  execute replace(def, marker, blk);
end $psig$;

-- اعلان آزاد ادمین (مورد ۱۵) — بعد از PUSH.sql اجرا شود. چند بار اجرا بی‌خطر است. به توابع قبلی دست نمی‌زند.
create or replace function public.pnapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb; isadm boolean; ismain boolean; g text; t text; ttl text; b text; r text[];
begin
  a := coalesce(a,'{}'::jsonb);
  if op<>'pnotify' then return jsonb_build_object('err','bad'); end if;
  begin me := public.app('login', u, p, '{}'::jsonb); exception when others then me := null; end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  if not isadm then return jsonb_build_object('err','perm'); end if;
  b := left(btrim(coalesce(a->>'b','')),120);
  ttl := left(btrim(coalesce(a->>'title','')),60);
  if length(b)<1 then return jsonb_build_object('err','bad'); end if;
  if ttl='' then ttl := '📢 بازارچه پرندگان'; end if;
  g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
  if g is not null then
    if g not in ('all','booth','admin','user') then return jsonb_build_object('err','bad'); end if;
    if g in ('all','user') and not ismain then return jsonb_build_object('err','perm'); end if;
    if g='all' then r:=array(select distinct uname from public.f_push);
    elsif g='admin' then r:=array(select distinct username from public.staff);
    elsif g='booth' then r:=array(select distinct owner from public.booths);
    else r:=array(select distinct uname from public.f_push where uname not in (select username from public.staff) and uname not in (select owner from public.booths));
    end if;
  else
    if t is null then return jsonb_build_object('err','bad'); end if;
    if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
    r:=array[t];
  end if;
  perform public.f_push_send(r, ttl, b);
  return jsonb_build_object('ok',1,'n',coalesce(array_length(r,1),0),
    'reg',(select count(distinct uname) from public.f_push where uname=any(r)));
end $$;
grant execute on function public.pnapp(text,text,text,jsonb) to anon, authenticated;
select 'ok' as done, public.fapp('psig') as psig;
