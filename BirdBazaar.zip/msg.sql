-- صندوق پیام و اعلان (U3) — در Supabase > SQL Editor اجرا شود. چند بار اجرا هم بی‌خطر است.
-- هویت: از همان تابع اصلی public.app (op=login). مدیر = role admin. ارسال به «همه» فقط ادمین اصلی (pm شامل all).

create table if not exists public.m_msgs(
  id bigserial primary key, from_u text not null, to_u text, grp text,
  body text not null, created timestamptz default now());
create index if not exists m_msgs_to on public.m_msgs(to_u, id desc);
create index if not exists m_msgs_grp on public.m_msgs(grp, id desc);
create table if not exists public.m_read(
  uname text not null, msg bigint references public.m_msgs(id) on delete cascade, primary key(uname,msg));
alter table public.m_msgs enable row level security;
alter table public.m_read enable row level security;

create or replace function public.mapp(op text, u text default '', p text default '', a jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public, extensions as $$
declare me jsonb := null; who text := ''; ismain boolean := false; isadm boolean := false;
        isbooth boolean := false; nid bigint; g text; t text; b text; n int;
begin
  a := coalesce(a,'{}'::jsonb);
  if op='mping' then return jsonb_build_object('ok',1); end if;
  if coalesce(u,'')='' then return jsonb_build_object('err','auth'); end if;
  begin
    me := public.app('login', u, p, '{}'::jsonb);
  exception when others then
    me := null;
  end;
  if me is null or me ? 'err' or coalesce(me->>'role','')='' then return jsonb_build_object('err','auth'); end if;
  who := u;
  isadm := (me->>'role')='admin';
  ismain := isadm and (coalesce(me->'pm','[]'::jsonb) ? 'all');
  isbooth := exists(select 1 from public.booths x where x.owner=who and x.status='active');

  -- پیام‌های من: شخصی + گروهی که عضوشم
  if op='minbox' or op='mcount' then
    if op='mcount' then
      select count(*) into n from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm))
          and m.from_u<>who
          and not exists(select 1 from public.m_read r where r.uname=who and r.msg=m.id);
      return jsonb_build_object('ok',1,'n',n,'adm',isadm,'main',ismain,'booth',isbooth);
    end if;
    return jsonb_build_object('ok',1,'adm',isadm,'main',ismain,'booth',isbooth,
      'in',coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'f',x.from_u,'g',x.grp,'b',x.body,'t',x.created,
            'r',exists(select 1 from public.m_read r where r.uname=who and r.msg=x.id)) order by x.id desc)
          from (select * from public.m_msgs m where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm)) and m.from_u<>who order by m.id desc limit 60) x),'[]'::jsonb),
      'sent',case when isadm then coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'to',x.to_u,'g',x.grp,'b',x.body,'t',x.created) order by x.id desc)
          from (select * from public.m_msgs m where m.from_u=who order by m.id desc limit 40) x),'[]'::jsonb) else '[]'::jsonb end);
  end if;

  if op='mread' then
    if a ? 'all' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m
        where (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm)) and m.from_u<>who
        on conflict do nothing;
    elsif a ? 'id' then
      insert into public.m_read(uname,msg)
        select who,m.id from public.m_msgs m where m.id=(a->>'id')::bigint
          and (m.to_u=who or m.grp='all' or (m.grp='booth' and isbooth) or (m.grp='admin' and isadm))
        on conflict do nothing;
    end if;
    return jsonb_build_object('ok',1);
  end if;

  -- ارسال: فقط مدیران. «همه» فقط ادمین اصلی.
  if op='msend' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    b := left(btrim(coalesce(a->>'b','')),1000);
    if length(b)<1 then return jsonb_build_object('err','bad'); end if;
    g := nullif(a->>'g',''); t := nullif(btrim(coalesce(a->>'to','')),'');
    if g is not null then
      if g not in ('all','booth','admin') then return jsonb_build_object('err','bad'); end if;
      if g='all' and not ismain then return jsonb_build_object('err','perm'); end if;
      insert into public.m_msgs(from_u,grp,body) values(who,g,b) returning id into nid;
    else
      if t is null then return jsonb_build_object('err','bad'); end if;
      if not exists(select 1 from public.users x where x.username=t) then return jsonb_build_object('err','nouser'); end if;
      insert into public.m_msgs(from_u,to_u,body) values(who,t,b) returning id into nid;
    end if;
    return jsonb_build_object('ok',1,'id',nid);
  end if;

  -- حذف پیام ارسالی (فرستنده یا ادمین اصلی)
  if op='mdel' then
    if not isadm then return jsonb_build_object('err','perm'); end if;
    delete from public.m_msgs where id=(a->>'id')::bigint and (from_u=who or ismain);
    return jsonb_build_object('ok',1);
  end if;

  return jsonb_build_object('err','unknown');
end $$;

grant execute on function public.mapp(text,text,text,jsonb) to anon, authenticated;
